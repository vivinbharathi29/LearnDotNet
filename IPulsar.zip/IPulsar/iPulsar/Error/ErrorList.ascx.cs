﻿using System;

public partial class Error_ErrorList : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {           
            string strMessage = "";
            string errNumber = "";

            if (Request.QueryString["ErrNumber"] != null)
                errNumber = Request.QueryString["ErrNumber"].ToString();

            if (Request.QueryString["Message"] != null)
                strMessage = Request.QueryString["Message"].ToString();

            switch (errNumber)
            {
                case "1":
                    strMessage = "<Br>You do not have access to Pulsar.";
                    break;
                case "2":
                    strMessage = "<br>Something went wrong, try to go back to the home page and if the issue persists, please contact pulsar support ";
                    break;
                case "3":
                    strMessage = "<br>The application can't authenticate you";
                    break;
                case "4":
                    strMessage = "<br>Please use IE 11 in compatibility view";
                    break;
                case "5":
                    strMessage = "<br>You don't have permission to view this page.";
                    break;
                case "6":
                    strMessage = "<br>There are some issues with your account, please contact pulsar support to assist you.";
                    break;
                case "7":
                    strMessage = "<br>Pulsar is unable to authenticate you. Please contact Pulsar support team to assist you.";
                    break;
                case "8":
                    strMessage = "<br>Access denied. Please contact pulsar support.";
                    break;
                case "9":
                    strMessage = "<br>Your account was disabled. Please contact pulsar support.";
                    break;
                case "403":
                    strMessage = "<br>You don't have access.";
                    break;
                case "404":
                    strMessage = "<br>The resource cannot be found.";
                    break;
                default:
                    strMessage = "<br>Pulsar has encountered an error. You may want to contact Pulsar Support to explain the steps you did to produce the error.";
					break;
            }

            lblError.Text = strMessage;
            Session.Abandon();            
        }
    }
}
