﻿using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.Script.Serialization;

namespace ExcaliburAPI {
    public static class JsonUtil {
        public static string SeralizeRow( DataTable Table, int RowToSeralize) {
            JavaScriptSerializer js = new JavaScriptSerializer();
            Hashtable ht = new Hashtable();
            DataRow row = Table.Rows[RowToSeralize];
            StringBuilder sb = new StringBuilder();
            foreach ( DataColumn col in Table.Columns) {
                ht.Add( col.ColumnName.ToLower(), row[col.ColumnName].ToString().Trim() );
            }

            return js.Serialize( ht );
        }
        public static string SeralizeTable( DataTable Table ) {
            JavaScriptSerializer js = new JavaScriptSerializer();
            List<Hashtable> htList = new List<Hashtable>();
            StringBuilder sb = new StringBuilder();
            foreach ( DataRow row in Table.Rows ) {
                Hashtable ht = new Hashtable();
                foreach ( DataColumn col in Table.Columns ) {
                    ht.Add( col.ColumnName, row[col.ColumnName].ToString().Trim() );
                }
                htList.Add( ht );
            }
            return js.Serialize( htList );
        }
    }
}
