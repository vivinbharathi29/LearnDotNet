using HPQ.Excalibur;
using System;
using System.ComponentModel;
using System.Data;
using System.Security.Permissions;
using System.Web.Services;

[assembly: CLSCompliant(true)]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, Execution = true)]

namespace Excalibur
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://excalibur.bnb.nbgbu.psg.hp.com/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    [System.Web.Script.Services.ScriptService]
    public class Api : System.Web.Services.WebService
    {

        [WebMethod]
        public DataSet ListActiveProjects(string MinimumStatusId, string MaximumStatusId)
        {
            try
            {
                HPQ.Excalibur.Data dw = new Data();
                DataSet ds = new DataSet();
                DataTable dt = dw.ListProducts(MinimumStatusId, MaximumStatusId);
                ds.Tables.Add(dt.Copy());
                return ds;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public DataSet SelectImageSkuMatrix(string ProductVersionId)
        {
            try
            {
                HPQ.Excalibur.Data dw = new Data();
                DataSet ds = new DataSet();
                DataTable dt = dw.SelectImageSkuMatrix(ProductVersionId);
                ds.Tables.Add(dt.Copy());
                return ds;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}
