﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.SystemBoard
{
    public partial class SystemBoardDropdownLists_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "System Board Dropdown Lists";
            Page.Title = "System Board Dropdown Lists";
            if (!IsPostBack)
            {
                FillTablesDropDown();
            }

            GetPermission();
        }

        private void FillTablesDropDown()
        {
            DDLManageDropdownLists.Items.Add(new ListItem("Chip Set", "sbchipset"));
            DDLManageDropdownLists.Items.Add(new ListItem("Component", "sbchipsetcomponent"));
            DDLManageDropdownLists.Items.Add(new ListItem("Connector Name", "sbconnector"));
            DDLManageDropdownLists.Items.Add(new ListItem("Expansion Slot Type", "sbexpansionslot"));
            DDLManageDropdownLists.Items.Add(new ListItem("Program Phase", "sbprogramphase"));
            DDLManageDropdownLists.Items.Add(new ListItem("Step", "sbchipsetstep"));
            DDLManageDropdownLists.Items.Add(new ListItem("System Board Name", "systemboardname"));
            DDLManageDropdownLists.DataBind();
        }

        private void GetPermission()
        {  // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
            {
                Page.Title = "View System Board Dropdown List";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
            }
        }


        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> FillGrid(string TableName)
        {
            try
            {
                List<Dictionary<string, object>> dictList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dict = null;
                SystemBoardDropdownListsBLL objBLL = new SystemBoardDropdownListsBLL();
                DataSet ds = new DataSet();

                ds = objBLL.GetSelectedDropdownListDetails(TableName);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dict = new Dictionary<string, object>();
                    dict.Add("ID", ds.Tables[0].Rows[i]["ID"].ToString());
                    dict.Add("Value", ds.Tables[0].Rows[i]["Value"].ToString());
                    dict.Add("State", ds.Tables[0].Rows[i]["State"].ToString());
                    dictList.Add(dict);
                }
                return dictList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> FillPlatformGrid()
        {
            try
            {
                List<Dictionary<string, object>> dictList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dict = null;
                SystemBoardDropdownListsBLL objBLL = new SystemBoardDropdownListsBLL();
                DataSet ds = new DataSet();

                ds = objBLL.GetLCMPlatform();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dict = new Dictionary<string, object>();
                    dict.Add("PlatformID", ds.Tables[0].Rows[i]["PlatformID"].ToString());
                    dict.Add("ProductFamily", ds.Tables[0].Rows[i]["ProductFamily"].ToString());
                    dict.Add("PCA", ds.Tables[0].Rows[i]["PCA"].ToString());
                    dict.Add("Chassis", ds.Tables[0].Rows[i]["Chassis"].ToString());
                    dict.Add("IntroYear", ds.Tables[0].Rows[i]["IntroYear"].ToString());
                    dict.Add("Active", ds.Tables[0].Rows[i]["Active"].ToString());
                    dict.Add("WebCycle", ds.Tables[0].Rows[i]["WebCycle"].ToString());
                    dict.Add("GenericName", ds.Tables[0].Rows[i]["GenericName"].ToString());
                    dict.Add("MktNameMaster", ds.Tables[0].Rows[i]["MktNameMaster"].ToString());
                    dict.Add("MktFullName", ds.Tables[0].Rows[i]["MktFullName"].ToString());
                    dict.Add("SOARProduct", ds.Tables[0].Rows[i]["SOARProduct"].ToString());
                    dict.Add("WebReleaseDate", ds.Tables[0].Rows[i]["WebReleaseDate"].ToString());
                    dict.Add("BiosName", ds.Tables[0].Rows[i]["BiosName"].ToString());
                    dict.Add("Comments", ds.Tables[0].Rows[i]["Comments"].ToString());
                    dict.Add("SystemID", ds.Tables[0].Rows[i]["SystemID"].ToString());
                    dict.Add("SelSegments", ds.Tables[0].Rows[i]["SelSegments"].ToString());
                    dict.Add("Status", ds.Tables[0].Rows[i]["Status"].ToString());
                    dict.Add("SoftpaqNeedDate", ds.Tables[0].Rows[i]["SoftpaqNeedDate"].ToString());
                    dictList.Add(dict);
                }
                return dictList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}