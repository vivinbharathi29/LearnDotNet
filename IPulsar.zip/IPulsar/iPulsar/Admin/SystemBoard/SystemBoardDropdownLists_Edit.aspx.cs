﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.SystemBoard
{
    public partial class SystemBoardDropdownLists_Edit : System.Web.UI.Page
    {
        int DropdownListValueID;
        string TableName;
        protected void Page_Load(object sender, EventArgs e)
        {
            string mode;
            mode = Request.QueryString["mode"];
            DropdownListValueID = Convert.ToInt32(Request.QueryString["id"]);
            TableName = Request.QueryString["table"];
            Authenticate.ValidateSession();
            // Put user code to initialize the page here
            if (!IsPostBack)
            {
                if ((mode == "update"))
                {
                    LoadDropdownListValue(DropdownListValueID, TableName);
                    Page.Title = "Modify SystemBoard Dropdown Lists";
                    GetPermission();
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Dropdown Value";
                    pnlHistory.Visible = false;
                }
                LoadDropdownListValue(DropdownListValueID, TableName);
            }        
        }





        private void LoadDropdownListValue(int intDropdownListValueID, string strTableName)
        {
            SystemBoardDropdownListsBLL SBBll = new SystemBoardDropdownListsBLL();

            DataSet ds;

            ds = SBBll.GetDropdownListValueById(intDropdownListValueID, strTableName);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                txtName.Text = dr["Value"].ToString().Trim();
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                rbState.SelectedValue = dr["State"].ToString();
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }
        // Checking permission to disable save button for users with no permissions - Task 16178
        private void GetPermission()
        {  // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
            {
                Page.Title = "Edit System Board Dropdown Lists";
                this.btnSave.Enabled = false;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strName = "";
            int intSetInactive = 1;
            SystemBoardDropdownListsBLL objbll = new SystemBoardDropdownListsBLL();

            try
            {
                strName = txtName.Text.Trim();

                if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                    intSetInactive = 0;
                else
                    intSetInactive = 1;

                UserInfo obj = new UserInfo();

                objbll.UpdateDropdownListValue(DropdownListValueID, strName, intSetInactive, TableName, UserInfo.GetCurrentUserName().ToString());

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadGrid", "CloseEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }    


    }
}