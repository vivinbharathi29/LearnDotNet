﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class Admin_PulsarAdminOnly_BusinessSegments_Edit : System.Web.UI.Page
{
    int BusinessSegmentID;
    protected void Page_Load(object sender, EventArgs e)
    {Authenticate.ValidateSession();
        string mode;        
        mode = Request.QueryString["mode"];
        BusinessSegmentID = Convert.ToInt32(Request.QueryString["SegmentID"]);
        
        // Put user code to initialize the page here
        if (!IsPostBack)
        {
            if ((mode == "update"))
            {              
                Page.Title = "Modify Business Segment";               
            }
            else if (mode == "create")
            {
                Page.Title = "Add New Business Segment";
                pnlHistory.Visible = false;                
            }
            LoadSegmentData(BusinessSegmentID);
        }        
        GetPermission();
    }
    private void GetPermission()
    {
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        //if (!Role.IsCurrentUserInRole(Enumeration.Enum_FeatureCategory_Role.FeatureCategory_Editor.ToString()))
        // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
        {
            Page.Title = "View Business Segment";
            this.txtAbbreviation.Enabled = false;
            this.txtDescription.Enabled = false;
            this.txtSegmentName.Enabled = false;
            this.btnSave.Enabled = false;            
            this.rbState.Enabled = false;
            this.rbBusinessSector.Enabled = false;
            this.rbBusinessOperation.Enabled = false;
            this.lblEnter.Visible = false;  
        }
    }
    private void LoadSegmentData(int intCategoryID)
    {
        AdminBusinessSegmentsBLL adBll = new AdminBusinessSegmentsBLL();
        DataSet ds;

        ds = adBll.GetBusinessSegmentById(intCategoryID);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            txtSegmentName.Text = dr["SegmentName"].ToString().Trim();
            txtAbbreviation.Text = dr["Abbreviation"].ToString().Trim();
            txtDescription.Text = dr["Description"].ToString().Trim();
            lblTimeChanged.Text = dr["Updated"].ToString().Trim();
            lblTimeCreated.Text = dr["Created"].ToString().Trim();
            lblCreator.Text = dr["CreatedBy"].ToString().Trim();
            lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
            rbState.SelectedValue = dr["State"].ToString();
            rbBusinessSector.SelectedValue = dr["BusinessId"].ToString();
            rbBusinessOperation.SelectedValue = dr["Operation"].ToString();

            ds.Dispose();
            pnlHistory.Visible = true;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string strName = "";
        string strAbbreviation = "";
        string strDescription = "";
        int intSetInactive = 1;
        AdminBusinessSegmentsBLL da = new AdminBusinessSegmentsBLL();
        try
        {
            strName = txtSegmentName.Text.Trim();
            strAbbreviation = txtAbbreviation.Text.Trim();
            strDescription = txtDescription.Text.Trim();

            if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                intSetInactive = 0;
            else
                intSetInactive = 1;

            UserInfo obj = new UserInfo();
            da.UpdateBusinessSegment(BusinessSegmentID, strName, strAbbreviation, strDescription, intSetInactive, UserInfo.GetCurrentUserName().ToString(), Convert.ToInt32(rbBusinessSector.SelectedValue), Convert.ToInt32(rbBusinessOperation.SelectedValue));

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadbusinesssegment", "CloseBSEditPopup(true)", true);

            //set it to null so parent list will reload after edit window is closed
            Session["BusinessSegmentsList"] = null;
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }    
}

