﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;

public partial class Admin_PulsarAdminOnly_Teams_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "Teams";
        Page.Title = "Teams";
        if (!IsPostBack)
        {
            Session["TeamsList"] = null;
        }

        gridPopulate();
        GetPermission();
    }
    private void gridPopulate()
    {
        try
        {
            if (Session["TeamsList"] == null)
            {
                DataSet ds = new DataSet();
                AdminTeamsBLL adBll = new AdminTeamsBLL();
                ds = adBll.GetAllTeams();
                Session["TeamsList"] = ds;
            }

            BindGridData();
            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void BindGridData()
    {
        DataSet ds;
        ds = (DataSet)Session["TeamsList"];
        wdgTeams.Rows.Clear();
        wdgTeams.DataSource = ds;
        wdgTeams.DataBind();
    }
    protected void wdgTeams_OnInitializeRow(object sender, RowEventArgs e)
    {
        string TeamID = e.Row.DataKey[0].ToString();
        string sName = e.Row.Items.FindItemByKey("Name").Value.ToString();
        e.Row.Items.FindItemByKey("Name").Text = "<a onclick=\"return OpenTeamsEditPopUp('Teams_Edit.aspx?mode=update&ID=" + TeamID + "');\">" + sName + "</a>";
    }
    private bool DeleteRecord()
    {
        bool b = false;
        int intTeamID = 0;
        intTeamID = Convert.ToInt32(hdnTeamID.Value);
        AdminTeamsBLL avb = new AdminTeamsBLL();
        avb.DeleteTeam(intTeamID);
        b = true;
        Session["TeamsList"] = null;

        return b;
    }
    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
        {
            Page.Title = "View Teams List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }
    protected void btnDeleteTeam_Click(object sender, EventArgs e)
    {
        try
        {
            DeleteRecord();
            gridPopulate();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnRefeshGrid_Click(object sender, EventArgs e)
    {
        gridPopulate();
    }

    protected void btnCloneTeam_Click(object sender, EventArgs e)
    {
        int intTeamID = 0;
        intTeamID = Convert.ToInt32(hdnTeamID.Value);
        AdminTeamsBLL da = new AdminTeamsBLL();
        da.CloneTeam(intTeamID, UserInfo.GetCurrentUserName());
        //gridPopulate();
        //Bug 19039 - Task 19052 - Harris, Valerie - Refresh Teams Main page when Team is Cloned
        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadteam", "ReloadTeamsWindow(true)", true);
    }
}

