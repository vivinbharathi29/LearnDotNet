﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_PulsarAdminOnly_Teams_Edit : System.Web.UI.Page
{
	int _teamID;
	AdminTeamsBLL _da;

	private AdminTeamsBLL AdmTeamObj
	{
		get
		{
			if (_da == null)
				_da = new AdminTeamsBLL();

			return _da;
		}
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		Authenticate.ValidateSession();
		string mode = Request.QueryString["mode"];
		_teamID = Convert.ToInt32(Request.QueryString["ID"]);

		if (!IsPostBack)
		{
			if (mode == "update")
			{
				Page.Title = "Modify Team";
				btnRoles.Enabled = true;
			}
			else if (mode == "create")
			{
				Page.Title = "Add New Team";
				pnlHistory.Visible = false;
				btnRoles.Enabled = false;
			}

			//these can not be reload after postback you will loose data that use edit
			LoadAllPartners();
			LoadBusinessFunctions();
			LoadBusinessSegments(Convert.ToInt32(_teamID));
			LoadOwners(Convert.ToInt32(_teamID));
			LoadData(_teamID);
			hdnTeamID.Value = _teamID.ToString();
		}

		GetPermission();
	}

	private void GetPermission()
	{
		//*******************************************************************************************************
		//******************************You can either check role or permission *********************************
		//*******************************************************************************************************
		//if (!Role.IsCurrentUserInRole(Enumeration.Enum_FeatureCategory_Role.FeatureCategory_Editor.ToString()))
		// check permission from resource file instead of enums - task 19440
		if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
		{
			Page.Title = "View Team";
			this.txtTeamName.Enabled = false;
			this.ddlBusinessFunction.Enabled = false;
			this.ddlPartner.Enabled = false;
			this.rlbAvailable.Enabled = false;
			this.rlbSelected.Enabled = false;
			this.rlbAvailableOwners.Enabled = false;
			this.rlbSelectedOwners.Enabled = false;
			this.btnSave.Enabled = false;
			this.rbState.Enabled = false;
			this.btnClone.Enabled = false;
			this.lblEnter.Visible = false;
		}
	}

	private void LoadAllPartners()
	{
		AdminAddUserToTeamBLL da = new AdminAddUserToTeamBLL();
		var dsPartners = da.GetAllPartners();

		ddlPartner.DataSource = dsPartners;
		ddlPartner.DataTextField = "Name";
		ddlPartner.DataValueField = "PartnerID";
		ddlPartner.DataBind();

		ddlPartner.Items.Insert(0, new ListItem("Select a Partner", string.Empty));
	}

	private void LoadBusinessFunctions()
	{
		var dsBusinessFunctions = this.AdmTeamObj.GetAllBusinessFunctions();
		dsBusinessFunctions.Tables[0].DefaultView.RowFilter = "State = 'Active'";
		ddlBusinessFunction.DataSource = dsBusinessFunctions.Tables[0];
		ddlBusinessFunction.DataTextField = "Name";
		ddlBusinessFunction.DataValueField = "BusinessFunctionID";
		ddlBusinessFunction.DataBind();
	}

	private void LoadBusinessSegments(int intID)
	{
		try
		{
			var dsBusinessSegments = this.AdmTeamObj.Teams_BusinessSegments(intID);
			dsBusinessSegments.Tables[0].DefaultView.Sort = "Name Asc";
			rlbAvailable.DataSource = dsBusinessSegments.Tables[0];
			rlbAvailable.DataTextField = "Name";
			rlbAvailable.DataValueField = "ID";
			rlbAvailable.DataBind();

			if (dsBusinessSegments.Tables[1] != null)
			{
				rlbSelected.DataSource = dsBusinessSegments.Tables[1];
				rlbSelected.DataTextField = "Name";
				rlbSelected.DataValueField = "ID";
				rlbSelected.DataBind();
			}
		}
		catch (Exception ex)
		{
			lblError.Text = ex.Message;
			lblError.Visible = true;
		}
	}

	private void LoadOwners(int intID)
	{
		try
		{
			var dsOwners = this.AdmTeamObj.Teams_OwnersList(intID);
			dsOwners.Tables[0].DefaultView.Sort = "FullName Asc";
			rlbAvailableOwners.DataSource = dsOwners.Tables[0];
			rlbAvailableOwners.DataTextField = "FullName";
			rlbAvailableOwners.DataValueField = "UserID";
			rlbAvailableOwners.DataBind();

			if (dsOwners.Tables[1] != null)
			{
				rlbSelectedOwners.DataSource = dsOwners.Tables[1];
				rlbSelectedOwners.DataTextField = "FullName";
				rlbSelectedOwners.DataValueField = "UserID";
				rlbSelectedOwners.DataBind();
			}
		}
		catch (Exception ex)
		{
			lblError.Text = ex.Message;
			lblError.Visible = true;
		}
	}

	private void LoadData(int intTeamID)
	{
		var ds = this.AdmTeamObj.GetTeamById(intTeamID);
		if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
		{
			DataRow dr = ds.Tables[0].Rows[0];
			txtTeamName.Text = dr["TeamName"].ToString().Trim();
			ddlBusinessFunction.SelectedValue = dr["BusinessFunctionID"].ToString();
			ddlPartner.SelectedValue = dr["PartnerId"].ToString();
			lblTimeChanged.Text = dr["Updated"].ToString().Trim();
			lblTimeCreated.Text = dr["Created"].ToString().Trim();
			lblCreator.Text = dr["CreatedBy"].ToString().Trim();
			lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
			rbState.SelectedValue = dr["State"].ToString();
			pnlHistory.Visible = true;
		}
	}

	protected void btnSave_Click(object sender, EventArgs e)
	{
		string strName = "";
		int intBusinessFunctionID = 0;
		int intSetInactive = 1;
		try
		{
			intBusinessFunctionID = Convert.ToInt32(ddlBusinessFunction.SelectedItem.Value);
			strName = txtTeamName.Text.Trim();

			//get the list of selected business segements
			string selectedIDs = "";
			foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelected.Items)
			{
				selectedIDs += selectedItem.Value.Trim() + ",";
			}

			//get the list of selected owners
			string selectedOwnerIDs = "";
			foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelectedOwners.Items)
			{
				selectedOwnerIDs += selectedItem.Value.Trim() + ",";
			}

			if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
				intSetInactive = 0;
			else
				intSetInactive = 1;

			int tmp;
			int? partnerId = null;
			if (int.TryParse(ddlPartner.SelectedValue, out tmp))
				partnerId = tmp;

			_teamID = this.AdmTeamObj.UpdateTeam(Convert.ToInt32(hdnTeamID.Value), intBusinessFunctionID, strName, UserInfo.GetCurrentUserName()
				, intSetInactive, partnerId);

			//save business segments to different table
			if (selectedIDs.Trim().Length > 0)
				selectedIDs = selectedIDs.Substring(0, selectedIDs.Trim().Length - 1);

			this.AdmTeamObj.Team_BusinessSegmentsModify(_teamID, selectedIDs);

			//save owners to different table
			if (selectedOwnerIDs.Trim().Length > 0)
				selectedOwnerIDs = selectedOwnerIDs.Substring(0, selectedOwnerIDs.Trim().Length - 1);

			this.AdmTeamObj.Team_OwnersModify(_teamID, selectedOwnerIDs, UserInfo.GetCurrentUserName());

			ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadteam", "CloseTeamsEditPopup(true)", true);

			//set it to null so parent list will reload after edit window is closed
			Session["TeamsList"] = null;
		}
		catch (Exception ex)
		{
			lblError.Text = ex.Message;
			lblError.Visible = true;
		}
	}

	protected void btnClone_Click(object sender, EventArgs e)
	{
		int intNewTeamID = this.AdmTeamObj.CloneTeam(_teamID, UserInfo.GetCurrentUserName());
		hdnTeamID.Value = intNewTeamID.ToString();
		LoadData(intNewTeamID);
		LoadBusinessFunctions();
		LoadBusinessSegments(intNewTeamID);
		LoadOwners(intNewTeamID);
	}
}

