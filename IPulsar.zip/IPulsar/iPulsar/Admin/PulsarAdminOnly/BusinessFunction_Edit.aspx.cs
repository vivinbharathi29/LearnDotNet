﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace iPulsar.Admin.PulsarAdminOnly
{
    public partial class BusinessFunctions_Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            int intBusinessFunctionID = -1;
            if (Request.QueryString["BusinessFunctionID"] != null)
                intBusinessFunctionID = Convert.ToInt32(Request.QueryString["BusinessFunctionID"]);

            hdnBusinessFunctionID.Value = intBusinessFunctionID.ToString();
            if (!IsPostBack)
            {
                GetPermission();
                GetBusinessFunctionProperties();
            }


        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
            {
                Page.Title = "View Business Function";
                this.txtName.Enabled = false;
                this.txtDescription.Enabled = false;
                this.rbState.Enabled = false;
                this.btnSave.Enabled = false;
                this.lblEnter.Visible = false;
            }
        }

        private void GetBusinessFunctionProperties()
        {
            int intBusinessFunctionID = -1;
            intBusinessFunctionID = Convert.ToInt32(hdnBusinessFunctionID.Value);

            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            DataSet dsBusinessFunction = new DataSet();
            dsBusinessFunction = da.GetBusinessFunctionByID(intBusinessFunctionID);

            if (dsBusinessFunction.Tables.Count > 0)
            {
                if (dsBusinessFunction.Tables[0].Rows.Count > 0)
                {
                    txtName.Text = dsBusinessFunction.Tables[0].Rows[0]["Name"].ToString();
                    txtDescription.Text = dsBusinessFunction.Tables[0].Rows[0]["Description"].ToString();
                    rbState.SelectedValue = dsBusinessFunction.Tables[0].Rows[0]["State"].ToString();
                    lblCreator.Text = dsBusinessFunction.Tables[0].Rows[0]["CreatedBy"].ToString();
                    lblUpdater.Text = dsBusinessFunction.Tables[0].Rows[0]["UpdatedBy"].ToString();
                    lblTimeCreated.Text = dsBusinessFunction.Tables[0].Rows[0]["Created"].ToString();
                    lblTimeChanged.Text = dsBusinessFunction.Tables[0].Rows[0]["Updated"].ToString();
                    pnlHistory.Visible = true;
                }
                else
                {
                    pnlHistory.Visible = false;
                }
            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strName = "", strDescription = "";
            int intSetInactive = 1, intBusinessFunctionID = -1;
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            try
            {
                intBusinessFunctionID = Convert.ToInt32(hdnBusinessFunctionID.Value);
                strName = txtName.Text.Trim();
                strDescription = txtDescription.Text.Trim();

                if ((Convert.ToInt32(rbState.SelectedValue)) == 0)
                    intSetInactive = 0;
                else
                    intSetInactive = 1;

                UserInfo obj = new UserInfo();
                da.ModifyBusinessFunction(intBusinessFunctionID, strName, strDescription, intSetInactive, UserInfo.GetCurrentUserName().ToString());

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadBusinessFunction", "CloseBusinessFunctionEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}