﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;

public partial class Admin_PulsarAdminOnly_BusinessSegments_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "Business Segments";
        Page.Title = "Business Segments";
        if (!IsPostBack)
        {
            Session["BusinessSegmentsList"] = null;
        }

        gridPopulate();
        GetPermission();
    }

    private void gridPopulate()
    {
        try
        {
            if (Session["BusinessSegmentsList"] == null)
            {
                AdminBusinessSegmentsBLL adBll = new AdminBusinessSegmentsBLL();
                DataSet ds = new DataSet();
                ds = adBll.GetAllBusinessSegments();
                Session["BusinessSegmentsList"] = ds;
            }

            BindGridData();
            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void BindGridData()
    {
        DataSet ds;
        ds = (DataSet)Session["BusinessSegmentsList"];
        wdgBusinessSegments.Rows.Clear();
        wdgBusinessSegments.DataSource = ds;
        wdgBusinessSegments.DataBind();
    }
    protected void wdgBusinessSegments_OnInitializeRow(object sender, RowEventArgs e)
    {
        string BusinessSegmentID = e.Row.DataKey[0].ToString();
        string sName = e.Row.Items.FindItemByKey("SegmentName").Value.ToString();
        e.Row.Items.FindItemByKey("SegmentName").Text = "<a onclick=\"return OpenBSEditPopUp('BusinessSegments_Edit.aspx?mode=update&SegmentID=" + BusinessSegmentID + "');\">" + sName + "</a>";
    }
    private bool DeleteRecord()
    {
        bool b = false;
        int intBusinessSegmentID = 0;
        intBusinessSegmentID = Convert.ToInt32(hdnBusinessSegmentID.Value);
        AdminBusinessSegmentsBLL avb = new AdminBusinessSegmentsBLL();
        avb.DeleteBusinessSegment(intBusinessSegmentID);
        b = true;
        Session["BusinessSegmentsList"] = null;

        return b;
    }
    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
        {
            Page.Title = "View Business Segment List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }
    protected void btnDeleteBusinessSegment_Click(object sender, EventArgs e)
    {
        try
        {
            DeleteRecord();
            gridPopulate();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnRefeshGrid_Click(object sender, EventArgs e)
    {
        gridPopulate();
    }
}

