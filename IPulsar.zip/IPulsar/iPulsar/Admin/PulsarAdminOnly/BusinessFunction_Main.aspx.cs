﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;

namespace iPulsar.Admin.PulsarAdminOnly
{
    public partial class BusinessFunctions_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "Business Functions";
            Page.Title = "Business Functions";
            try
            {
                GetBusinessFunctionList();
                GetPermission();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void GetBusinessFunctionList()
        {
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            DataSet dsBusinessFunctions = new DataSet();
            dsBusinessFunctions = da.GetAllBusinessFunctions();

            BindBusinessFunctionGrid(dsBusinessFunctions);
            lblError.Text = "";
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
            {
                Page.Title = "View Business Function List";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
            {
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
            }
        }
       
        private void BindBusinessFunctionGrid(DataSet dsBusinessFunctions)
        {
            wdgBusinessFunction.Rows.Clear();
            wdgBusinessFunction.DataSource = dsBusinessFunctions;
            wdgBusinessFunction.DataBind();
        }
        protected void wdgBusinessFunction_OnInitializeRow(object sender, RowEventArgs e)
        {
            string BusinessFunctionID = e.Row.DataKey[0].ToString();
            string sName = e.Row.Items.FindItemByKey("Name").Value.ToString();
            e.Row.Items.FindItemByKey("Name").Text = "<a onclick=\"return OpenBusinessFunctionEditPopUp('BusinessFunction_Edit.aspx?mode=update&BusinessFunctionID=" + BusinessFunctionID + "');\">" + sName + "</a>";
        }
        protected void btnRefeshGrid_Click(object sender, EventArgs e)
        {
            GetBusinessFunctionList();
        }
        private void DeleteBusinessFunction()
        {
            //bool b = false;
            int intBusinessFunctionID = 0;
            intBusinessFunctionID = Convert.ToInt32(hdnBusinessFunctionID.Value);
                AdminBusinessFunctionsBAL avb = new AdminBusinessFunctionsBAL();
                avb.DeleteBusinessFunction(intBusinessFunctionID);
        }
        protected void btnDeleteBusinessFunction_Click(object sender, EventArgs e)
        {
            try
            {
                DeleteBusinessFunction();
                GetBusinessFunctionList();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}