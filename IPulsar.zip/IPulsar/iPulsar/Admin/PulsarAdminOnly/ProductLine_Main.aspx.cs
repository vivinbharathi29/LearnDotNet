﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;


namespace iPulsar.Admin.PulsarAdminOnly
{
    public partial class ProductLine : System.Web.UI.Page
    {
        int intProductLineID;

        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            MainMasterPage master = (MainMasterPage)Page.Master;
            Page.Title = "Product Lines";
            master.pageheader = "Product Lines";
            intProductLineID = Convert.ToInt32(Request.QueryString["ProductLineID"]);
            GetPermission();

        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ProductLine_Edit_Permission.ToString()))
            {
                Page.Title = "View Product Line List";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
            }

            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ProductLine_Delete_Permission.ToString()))
            {
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetProductLines()
        {
            try
            {
                List<Dictionary<string, object>> dicProductLineList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicProductLine = null;
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                DataSet dsProductLineList = new DataSet();
                dsProductLineList = da.GetProductLines();
                for (int i = 0; i < dsProductLineList.Tables[0].Rows.Count; i++)
                {
                    dicProductLine = new Dictionary<string, object>();
                    dicProductLine.Add("ProductLineID", dsProductLineList.Tables[0].Rows[i]["ProductLineID"].ToString());
                    dicProductLine.Add("ProductLine", dsProductLineList.Tables[0].Rows[i]["ProductLine"].ToString());
                    dicProductLine.Add("PLDescription", dsProductLineList.Tables[0].Rows[i]["PLDescription"].ToString());
                    dicProductLine.Add("State", dsProductLineList.Tables[0].Rows[i]["State"].ToString());
                    dicProductLineList.Add(dicProductLine);
                }
                return dicProductLineList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static string DeleteProductLine(int intProductLineID)
        {
            string strReturnMsg = "ProductLine successfully removed.";
            try
            {
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                da.DeleteProductLine(intProductLineID);
            }
            catch (Exception ex)
            {
                strReturnMsg = ex.Message;
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            }
            return strReturnMsg;
        }
    }
}