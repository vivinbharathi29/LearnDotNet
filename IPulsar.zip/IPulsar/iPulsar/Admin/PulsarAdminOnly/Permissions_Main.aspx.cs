﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;

namespace iPulsar.Admin.PulsarAdminOnly
{
    public partial class Permissions_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "Permissions";
            Page.Title = "Permissions";
            try
            {
                GetPermissionList();
                GetPermission();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
            {
                Page.Title = "View Permission List";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmPermisionsContextMenu.Items.FindItemByValue("Add").Enabled = false;
            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
            {
                rmPermisionsContextMenu.Items.FindItemByValue("Delete").Enabled = false;
            }
        }
        private void GetPermissionList()
        {
            AdminPermissionsBAL da = new AdminPermissionsBAL();

            DataSet dsPermissions = new DataSet();
            dsPermissions = da.GetAllPermissions();
            wdgPermission.Rows.Clear();
            wdgPermission.DataSource = dsPermissions;
            wdgPermission.DataBind();

            lblError.Text = "";
        }
        protected void wdgPermission_OnInitializeRow(object sender, RowEventArgs e)
        {
            string PermissionID = e.Row.DataKey[0].ToString();
            string sName = e.Row.Items.FindItemByKey("Name").Value.ToString();
            e.Row.Items.FindItemByKey("Name").Text = "<a onclick=\"return OpenPermissionEditPopUp('Permissions_Edit.aspx?mode=update&PermissionID=" + PermissionID + "');\">" + sName + "</a>";
        }
        protected void btnRefeshPerGrid_Click(object sender, EventArgs e)
        {
            GetPermissionList();
        }
        private void DeletePermission()
        {
            int intPermissionID = 0;
            intPermissionID = Convert.ToInt32(hdnPermissionID.Value);
            AdminPermissionsBAL avb = new AdminPermissionsBAL();
            avb.DeletePermission(intPermissionID);
        }
        protected void btnDeletePermission_Click(object sender, EventArgs e)
        {
            try
            {
                DeletePermission();
                GetPermissionList();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}