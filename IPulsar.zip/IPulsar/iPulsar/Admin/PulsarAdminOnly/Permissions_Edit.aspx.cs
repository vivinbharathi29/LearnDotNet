﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace iPulsar.Admin.PulsarAdminOnly
{
    public partial class Permissions_Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            int intPermissionID = -1;
            if (Request.QueryString["PermissionID"] != null)
                intPermissionID = Convert.ToInt32(Request.QueryString["PermissionID"]);

            hdnPermissionID.Value = intPermissionID.ToString();
            if (!IsPostBack)
                GetPermissionProperties();

            GetPermission();
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
            {
                Page.Title = "View Permission";
                this.txtPermName.Enabled = false;
                this.txtPermDescription.Enabled = false;
                this.rlbAvailable.Enabled = false;
                this.rlbSelected.Enabled = false;
                this.btnSave.Enabled = false;
                this.lblEnter.Visible = false;
            }
        }

        private void GetPermissionProperties()
        {
            int intPermissionID = -1;
            intPermissionID = Convert.ToInt32(hdnPermissionID.Value);

            AdminPermissionsBAL da = new AdminPermissionsBAL();
            DataSet dsPermission = new DataSet();
            dsPermission = da.GetPermissionByPermissionID(intPermissionID, 1); // include team names

            if (dsPermission.Tables.Count > 0)
            {
                if (dsPermission.Tables[0].Rows.Count > 0)
                {
                    txtPermName.Text = dsPermission.Tables[0].Rows[0]["Name"].ToString();
                    txtPermDescription.Text = dsPermission.Tables[0].Rows[0]["Description"].ToString();
                    //rbState.SelectedValue = dsPermission.Tables[0].Rows[0]["State"].ToString();
                    lblCreator.Text = dsPermission.Tables[0].Rows[0]["CreatedBy"].ToString();
                    lblUpdater.Text = dsPermission.Tables[0].Rows[0]["UpdatedBy"].ToString();
                    lblTimeCreated.Text = dsPermission.Tables[0].Rows[0]["Created"].ToString();
                    lblTimeChanged.Text = dsPermission.Tables[0].Rows[0]["Updated"].ToString();
                    pnlHistory.Visible = true;
                }
                else
                {
                    pnlHistory.Visible = false;
                }

                //load the roles
                rlbAvailable.DataSource = dsPermission.Tables[1];
                rlbAvailable.DataTextField = "RoleName";
                rlbAvailable.DataValueField = "RoleID";
                rlbAvailable.DataBind();

                rlbSelected.DataSource = dsPermission.Tables[2];
                rlbSelected.DataTextField = "RoleName";
                rlbSelected.DataValueField = "RoleID";
                rlbSelected.DataBind();
            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strName = "", strDescription = "";
            int intSetInactive = 1, intPermissionID = -1;
            AdminPermissionsBAL da = new AdminPermissionsBAL();
            try
            {
                intPermissionID = Convert.ToInt32(hdnPermissionID.Value);
                strName = txtPermName.Text.Trim();
                strDescription = txtPermDescription.Text.Trim();

                ////get the list of selected roles
                string selectedRoleIDs = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelected.Items)
                {
                    selectedRoleIDs = selectedRoleIDs == "" ? selectedItem.Value.Trim() : selectedRoleIDs + "," + selectedItem.Value.Trim();
                }

                UserInfo obj = new UserInfo();
                da.ModifyPermission(intPermissionID, strName, strDescription, intSetInactive, UserInfo.GetCurrentUserName().ToString(), selectedRoleIDs);

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadpermission", "ClosePermissionEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}