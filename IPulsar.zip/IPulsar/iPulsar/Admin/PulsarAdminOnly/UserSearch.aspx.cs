﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Services;

public partial class UserSearch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        if (Request.QueryString["TeamID"] != null)
            hdnTeamID.Value = Request.QueryString["TeamID"].ToString();
        else
            hdnTeamID.Value = "0";
    }

    private static List<string> SearchUsersInternal(string searchText)
    {
        Uri requestUri = HttpContext.Current.Request.Url;
        string apiUrl = requestUri.Scheme + "://" + requestUri.Host + "/PulsarAPI/svc/UserSearch/";
        string input = "?SearchText=" + searchText.Trim();

        HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri(apiUrl + "SearchUsersStrList" + input));
        httpRequest.ContentType = "application/x-www-form-urlencoded";
        httpRequest.ContentLength = 0;
        httpRequest.Credentials = CredentialCache.DefaultCredentials;
        httpRequest.Method = "POST";

        using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
        {
            using (Stream stream = httpResponse.GetResponseStream())
            {
                string resultJson = (new StreamReader(stream)).ReadToEnd();
                var pipeDelimitedUsersList = JsonConvert.DeserializeObject<List<string>>(resultJson);
                return pipeDelimitedUsersList;
            }
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> SearchUsers(string SearchText)
    {
        try
        {
            List<string> lstUsrList = SearchUsersInternal(SearchText);

            List<Dictionary<string, object>> users = new List<Dictionary<string, object>>();
            Dictionary<string, object> Dictionary = null;

            for (int i = 0; i < lstUsrList.Count(); i++)
            {
                Dictionary = new Dictionary<string, object>();
                Dictionary.Add("UserId", lstUsrList[i].Split('|')[0].ToString());
                Dictionary.Add("LastName", lstUsrList[i].Split('|')[1].ToString());
                Dictionary.Add("FirstName", lstUsrList[i].Split('|')[2].ToString());
                Dictionary.Add("FullName", lstUsrList[i].Split('|')[3].ToString());
                Dictionary.Add("Email", lstUsrList[i].Split('|')[4].ToString());
                Dictionary.Add("NtDomain", lstUsrList[i].Split('|')[5].ToString());
                Dictionary.Add("NtName", lstUsrList[i].Split('|')[6].ToString());
                Dictionary.Add("Phone", lstUsrList[i].Split('|')[7].ToString());
                Dictionary.Add("City", lstUsrList[i].Split('|')[8].ToString());
                Dictionary.Add("State", lstUsrList[i].Split('|')[9].ToString());
                Dictionary.Add("Country", lstUsrList[i].Split('|')[10].ToString());
                Dictionary.Add("EmployeeNo", lstUsrList[i].Split('|')[11].ToString());
                Dictionary.Add("NameExtension", lstUsrList[i].Split('|')[12].ToString());
                Dictionary.Add("IsActiveInGAL", lstUsrList[i].Split('|')[13].ToString());
                Dictionary.Add("PartnerId", lstUsrList[i].Split('|')[14].ToString());
                Dictionary.Add("UserGuid", lstUsrList[i].Split('|')[15].ToString());
                users.Add(Dictionary);
            }
            return users;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    private static string SearchActiveDirectoryUsersInternal(string searchText, string searchField, string searchTarget)
    {
        Uri requestUri = HttpContext.Current.Request.Url;
        string apiUrl = requestUri.Scheme + "://" + requestUri.Host + "/PulsarAPI/svc/UserSearch/";
        string input = "?SearchText=" + searchText.Trim() +
            "&SearchField=" + searchField.Trim() +
            "&SearchTarget=" + searchTarget.Trim();

        HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri(apiUrl + "SearchActiveDirectoryUsersJsonStr" + input));
        httpRequest.ContentType = "application/x-www-form-urlencoded";
        httpRequest.ContentLength = 0;
        httpRequest.Credentials = CredentialCache.DefaultCredentials;
        httpRequest.Method = "POST";

        using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
        {
            using (Stream stream = httpResponse.GetResponseStream())
            {
                string resultJson = (new StreamReader(stream)).ReadToEnd();
                return resultJson;
            }
        }
    }

    [WebMethod(EnableSession = true)]
    public static string SearchActiveDirectoryUsers(string SearchText, string SearchField, string SearchTarget)
    {
        try
        {
            return SearchActiveDirectoryUsersInternal(SearchText, SearchField, SearchTarget);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}

