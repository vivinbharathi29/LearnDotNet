﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class Roles_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        int intTeamID = 0;
        if (Request.QueryString["TeamID"] != null)
            intTeamID = Convert.ToInt32(Request.QueryString["TeamID"]);
        hdnTeamID.Value = intTeamID.ToString();
        if (!IsPostBack)
        {
            Session["Team_Roles"] = null;

        }

        GetPermission();
        LoadTeamRoles(intTeamID);
    }

    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
        {
            Page.Title = "View Roles";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmRolesContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
        {
            rmRolesContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }

    private void LoadTeamRoles(int intTeamID)
    {
        if (Session["Team_Roles"] == null)
        {
            AdminTeamsBLL da = new AdminTeamsBLL();
            DataSet dsRoles = new DataSet();
            dsRoles = da.GetRolesByTeamID(intTeamID);
            lblTeamName.Text = dsRoles.Tables[0].Rows[0]["Name"].ToString() + " Roles";
            Session["Team_Roles"] = dsRoles.Tables[1];
        }

        BindTeamRoles();
    }
    private void BindTeamRoles()
    {
        DataTable dtRoles = new DataTable();

        dtRoles = (DataTable)Session["Team_Roles"];

        wdgRoles.Rows.Clear();
        wdgRoles.DataSource = dtRoles;
        wdgRoles.DataBind();
    }
    protected void wdgRoles_InitializeRow(object sender, Infragistics.Web.UI.GridControls.RowEventArgs e)
    {
        string RoleID = e.Row.DataKey[0].ToString();
        string sName = e.Row.Items.FindItemByKey("Name").Value.ToString();
        e.Row.Items.FindItemByKey("Name").Text = "<a onclick=\"return OpenRolesEPopUp('Roles_Edit.aspx?RoleID=" + RoleID + "');\">" + sName + "</a>";
    }

    protected void btnRefeshGrid_Click(object sender, EventArgs e)
    {
        int intTeamID = 0;
        intTeamID = Convert.ToInt32(hdnTeamID.Value);
        LoadTeamRoles(intTeamID);
    }

    protected void btnDeleteTeamRole_Click(object sender, EventArgs e)
    {
        int intRoleID = 0;
        intRoleID = Convert.ToInt32(hdnRoleID.Value);
        AdminTeamsBLL da = new AdminTeamsBLL();
        try
        {
            da.DeleteRole(intRoleID);
            lblError.Text = "";
            lblError.Visible = false;
            int intTeamID = 0;
            intTeamID = Convert.ToInt32(hdnTeamID.Value);
            LoadTeamRoles(intTeamID);
            Session["Team_Roles"] = null;

            //Bug 19039 - Task 19052 - Harris, Valerie - Refresh Teams Main page when Team is Cloned
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadroles", "ReloadRolesList(" + intTeamID + ")", true);
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }

    }
}
