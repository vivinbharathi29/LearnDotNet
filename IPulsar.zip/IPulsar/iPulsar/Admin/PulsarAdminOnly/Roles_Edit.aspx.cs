﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Roles_Edit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        int intTeamID = 0, intRoleID = 0;
        if (Request.QueryString["TeamID"] != null)
            intTeamID = Convert.ToInt32(Request.QueryString["TeamID"]);
        if (Request.QueryString["TeamID"] != null)
            intRoleID = Convert.ToInt32(Request.QueryString["RoleID"]);

        hdnRoleID.Value = intRoleID.ToString();
        hdnTeamID.Value = intTeamID.ToString();

        if (!IsPostBack)
            LoadRoleData(intRoleID);

        GetPermission();
    }

    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
        {
            Page.Title = "View Role";
            this.txtRoleName.Enabled = false;
            this.txtRoleDescription.Enabled = false;
            this.rlbPermAvailable.Enabled = false;
            this.rlbPermSelected.Enabled = false;
            this.btnSave.Enabled = false;
            this.lblEnter.Visible = false;
        }
    }

    private void LoadRoleData(int intRoleID)
    {
        AdminTeamsBLL da = new AdminTeamsBLL();
        DataSet dsRoleInfo = new DataSet();

        dsRoleInfo = da.GetRoleByRoleID(intRoleID);

        if (intRoleID > 0)
            pnlHistory.Visible = true;
        else
            pnlHistory.Visible = false;

        if (dsRoleInfo.Tables.Count > 0)
        {
            if (intRoleID > 0)
            {
                //load role information
                txtRoleName.Text = dsRoleInfo.Tables[0].Rows[0]["RoleName"].ToString();
                txtRoleDescription.Text = dsRoleInfo.Tables[0].Rows[0]["Description"].ToString();
                //rbState.SelectedValue = dsRoleInfo.Tables[0].Rows[0]["State"].ToString();
                lblCreator.Text = dsRoleInfo.Tables[0].Rows[0]["CreatedBy"].ToString();
                lblTimeCreated.Text = dsRoleInfo.Tables[0].Rows[0]["Created"].ToString();
                lblUpdater.Text = dsRoleInfo.Tables[0].Rows[0]["UpdatedBy"].ToString();
                lblTimeChanged.Text = dsRoleInfo.Tables[0].Rows[0]["Updated"].ToString();
            }
            //load the selected permissions
            rlbPermSelected.DataSource = dsRoleInfo.Tables[1];
            rlbPermSelected.DataTextField = "Name";
            rlbPermSelected.DataValueField = "PermissionId";
            rlbPermSelected.DataBind();

            //load all the permissions
            rlbPermAvailable.DataSource = dsRoleInfo.Tables[2];
            rlbPermAvailable.DataTextField = "Name";
            rlbPermAvailable.DataValueField = "PermissionId";
            rlbPermAvailable.DataBind();
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        int intTeamID = 0, intRoleID = 0, intState = 1;
        string strRoleName = "", strRoleDescription = "", strPermissionIDs = "";
        try
        {

            intTeamID = Convert.ToInt32(hdnTeamID.Value);
            intRoleID = Convert.ToInt32(hdnRoleID.Value);

            strRoleName = txtRoleName.Text.Trim();
            strRoleDescription = txtRoleDescription.Text.Trim();

            foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbPermSelected.Items)
            {
                strPermissionIDs = strPermissionIDs == "" ? selectedItem.Value.Trim() : strPermissionIDs + "," + selectedItem.Value.Trim();
            }

            //intState = Convert.ToInt32(rbState.SelectedValue);

            AdminTeamsBLL da = new AdminTeamsBLL();
            da.ModifyTeamRole(intTeamID, intRoleID, strRoleName, strRoleDescription, intState, strPermissionIDs, UserInfo.GetCurrentUserName());

            lblError.Text = "";
            lblError.Visible = false;

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadrolelist", "CloseRoleEPopup(" + intTeamID + ",true)", true);

            //set it to null so parent list will reload after edit window is closed
            Session["Team_Roles"] = null;

        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
}