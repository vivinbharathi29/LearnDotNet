﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace iPulsar.Admin.PulsarAdminOnly
{
    public partial class ProductLine_Edit : System.Web.UI.Page
    {
        int ProductLineID;
        string mode;

        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            mode = Request.QueryString["mode"];
            ProductLineID = Convert.ToInt32(Request.QueryString["ProductLineID"]);

            if (!IsPostBack)
            {
                LoadBusSeg();
                if ((mode == "update"))
                {
                    LoadProductLine(ProductLineID);
                    Page.Title = "Modify Product Line";
                }
                else if (mode == "create")
                {
                    //ddlBusSeg.SelectedIndex = 0;
                    Page.Title = "Add New Product Line";
                    pnlHistory.Visible = false;
                }
            }
            GetPermission();

        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ProductLine_Edit_Permission.ToString()))
            {
                this.txtProductLine.Enabled = false;
                this.txtPLDescription.Enabled = false;
                this.rbState.Enabled = false;
                this.btnSave.Enabled = false;
                this.lblEnter.Visible = false;
            }
        }


        private void LoadBusSeg()
        {
            AdminBusinessSegmentsBLL da = new AdminBusinessSegmentsBLL();
            DataSet dsBusSeg = new DataSet();
            dsBusSeg = da.GetAllBusinessSegments();

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strProductLine = "";
            string strPLDescription = "";
            int intBusSegID;
            int intSetInactive = 1;
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            try
            {

                strProductLine = txtProductLine.Text.Trim();
                strPLDescription = txtPLDescription.Text.Trim();
                intBusSegID = 0; //Convert.ToInt32(ddlBusSeg.SelectedValue);
                if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                    intSetInactive = 0;
                else
                    intSetInactive = 1;

                ProductLineID = da.UpdateProductLine(ProductLineID, strProductLine, strPLDescription, intBusSegID,
                    UserInfo.GetCurrentUserName().ToString(), intSetInactive);

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadProductLine", "CloseProductLineEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        private void LoadProductLine(int ProductLineID)
        {
            AdminSCMCategoryBLL adBll = new AdminSCMCategoryBLL();
            DataSet ds;

            ds = adBll.GetProductLineById(ProductLineID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                txtProductLine.Text = dr["ProductLine"].ToString();
                txtPLDescription.Text = dr["PLDescription"].ToString();
                rbState.SelectedValue = dr["State"].ToString();
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }



    }
}