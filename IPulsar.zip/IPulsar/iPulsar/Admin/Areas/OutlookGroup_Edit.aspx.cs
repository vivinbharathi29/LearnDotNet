﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Services;

public partial class OutlookGroup_Edit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        if (!IsPostBack)
        {
            Page.Title = "Outlook Email Groups";
      
            LoadOwners();
        }

    }
    private void LoadOwners()
    {
        Groups da = new Groups();
        DataSet dsOLGroup = new DataSet();
        try
        {
            dsOLGroup = da.GetOutlookEmailGroup();
            dsOLGroup.Tables[0].DefaultView.Sort = "Description Asc";
            rlbAvailableOutlookGroup.DataSource = dsOLGroup.Tables[0];
            rlbAvailableOutlookGroup.DataTextField = "Description";
            rlbAvailableOutlookGroup.DataValueField = "Email";
            rlbAvailableOutlookGroup.DataBind();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    
}

