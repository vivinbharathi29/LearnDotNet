﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;


namespace iPulsar.Admin.Areas
{
    public partial class Languages_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            MainMasterPage master = (MainMasterPage)Page.Master;
            Page.Title = "Languages";
            master.pageheader = "Languages";
            GetPermission();
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Regions_Edit_Permission.ToString()))
            {
                Page.Title = "View Languages";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
                txtEditRight.Value = "0";

            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Regions_Delete_Permission.ToString()))
            {
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
                txtEditRight.Value = "0";
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllLanguages()
        {
            try
            {
                List<Dictionary<string, object>> dicLanguagesList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicRegion = null;

                AdminRegionsBLL da = new AdminRegionsBLL();
                DataSet dsRegionList = new DataSet();
                dsRegionList = da.GetAllLanguages();

                //fields:SELECT ID, old_Business, Consumer, Commercial, GMCode, Tablet, SMB, GeoID, Geo, Name, Dash, OptionConfig, LanguageCode, Keyboard, KWL, PowerCord, OSLanguage, OtherLanguage, DocKits, DisplayOrder, DisplayName, Active, Transitioning, MUI, RestoreMedia, ImageLanguage, PrintedDocs, Comments, AndroidMobilityConsumer '


                for (int i = 0; i < dsRegionList.Tables[0].Rows.Count; i++)
                {
                    dicRegion = new Dictionary<string, object>();
                    dicRegion.Add("LanguageID", dsRegionList.Tables[0].Rows[i]["ID"].ToString());
                    dicRegion.Add("Name", dsRegionList.Tables[0].Rows[i]["Language"].ToString());
                    dicRegion.Add("Abbreviation", dsRegionList.Tables[0].Rows[i]["Abbreviation"].ToString());
                    dicRegion.Add("Dash", dsRegionList.Tables[0].Rows[i]["Dash"].ToString());
                    dicRegion.Add("OrderID", dsRegionList.Tables[0].Rows[i]["OrderID"].ToString());
                    dicRegion.Add("Active", dsRegionList.Tables[0].Rows[i]["Active"].ToString());
                    dicRegion.Add("bused", dsRegionList.Tables[0].Rows[i]["bused"].ToString());
                    dicLanguagesList.Add(dicRegion);

                }
                return dicLanguagesList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static string DeleteLanguage(int intLanguageID)
        {
            string strReturnMsg = "Language is successfully removed.";
            try
            {
                AdminRegionsBLL da = new AdminRegionsBLL();
                da.DeleteCountry(intLanguageID); //language and country share teh same language table so use teh same sp here
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }
    }
}