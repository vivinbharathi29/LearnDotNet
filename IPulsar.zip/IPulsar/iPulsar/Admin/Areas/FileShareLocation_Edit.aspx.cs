﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class SystemAdmin_FileShareLocation_Edit : System.Web.UI.Page
{
    string mode;
    string type;
    int ShareID;
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession(false);

        mode = Request.QueryString["mode"];
        ShareID = Convert.ToInt32(Request.QueryString["ID"]);
        type = Request.QueryString["type"];

        Authenticate.ValidateSession();
        // Put user code to initialize the page here

        GetPermission();
        if (!IsPostBack)
        {
            if ((mode == "update"))
            {
                GetFileShareLocation();
                Page.Title = type == "scmx" ? "Modify Existing SCMX File Share Location" : "Modify Existing PCR File Share Location";
            }
            else if (mode == "create")
            {
                Page.Title = type == "scmx" ? "Create SCMX File Share Locations" : "Create PCR File Share Locations";
            }
        }
    }
    private void GetFileShareLocation()
    {
        AdminScmxPcsPcrBLL da = new AdminScmxPcsPcrBLL();
        DataSet ds = new DataSet();
        ds = da.GetFileShareLocation(ShareID, type);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];

            txtDescription.Text = dr["Description"].ToString();
            txtPath.Text = dr["Path"].ToString();
            txtEmail.Text = dr["Email"].ToString();
            lblTimeChanged.Text = dr["TimeChanged"].ToString().Trim();
            lblTimeCreated.Text = dr["TimeCreated"].ToString().Trim();
            lblCreator.Text = dr["Creator"].ToString().Trim();
            lblUpdater.Text = dr["Updater"].ToString().Trim();

            if (dr["Disabled"] != System.DBNull.Value)
                RDState.SelectedValue = "0";
            else
                RDState.SelectedValue = "1";

            ds.Dispose();
            pnlHistory.Visible = true;
        }  
    }

    private void GetPermission()
    {  
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SCMXEditor_Edit_Permission.ToString()))
        {
            //this.txtName.Enabled = false;
            this.btnSave.Enabled = false;
            this.lblEnter.Visible = false;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        AdminScmxPcsPcrBLL da = new AdminScmxPcsPcrBLL();
        try
        {
            UserInfo obj = new UserInfo();
            da.ModifyFileShareLocation(ShareID, txtDescription.Text, txtPath.Text, txtEmail.Text, type, UserInfo.GetCurrentUserName().ToString(), RDState.SelectedValue == "1");

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadFileShareLocationedit", "CloseEditPopup(true)", true);
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
}

