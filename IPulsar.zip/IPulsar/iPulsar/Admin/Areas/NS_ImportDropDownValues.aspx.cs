﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;

namespace iPulsar.Admin.Areas
{
    public partial class NS_ImportDropDownvalues : System.Web.UI.Page
    {
        //This page is not called now, leave it in the project in case things change
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            if (!IsPostBack)
            {
                string strFieldID = Tools.GetQueryStringValue(this.Page, "FieldId");
                string strNSID = Tools.GetQueryStringValue(this.Page, "NamingStandardID");
                if (strFieldID != "")
                    hdnFieldID.Value = strFieldID;

                if (strNSID != "")
                    hdnNamingStandardID.Value = strNSID;
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAvailDropDownValues()
        {
            try
            {
                List<Dictionary<string, object>> dicNSDropDownValuesList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicNSDropDownValues = null;

                AdminNamingStandardBAL da = new AdminNamingStandardBAL();
                DataSet dsNSDropDownValuesList = new DataSet();
                dsNSDropDownValuesList = da.ADMIN_NS_GetAvailDropDownValues();

                for (int i = 0; i < dsNSDropDownValuesList.Tables[0].Rows.Count; i++)
                {
                    dicNSDropDownValues = new Dictionary<string, object>();
                    for (int j = 0; j < dsNSDropDownValuesList.Tables[0].Columns.Count; j++)
                    {
                        dicNSDropDownValues.Add(dsNSDropDownValuesList.Tables[0].Columns[j].ColumnName, dsNSDropDownValuesList.Tables[0].Rows[i][dsNSDropDownValuesList.Tables[0].Columns[j]].ToString());
                    }

                    dicNSDropDownValuesList.Add(dicNSDropDownValues);
                }
                return dicNSDropDownValuesList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static string NSImportDropDownValues(string selRowString, string intTargetFieldID)
        {
            string strReturnMsg = "";
            try
            {
                using (var da = new AdminNamingStandardDAL())
                {
                    da.NSImportDropDownValues(Convert.ToInt32(intTargetFieldID), selRowString, UserInfo.GetCurrentUserName().ToString());
                }
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }
    }

}