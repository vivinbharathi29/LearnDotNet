﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Documents.Excel;

namespace iPulsar.Admin.Areas
{
    public partial class Regions_Export : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            CreateWorksheetData();
        }
        private void CreateWorksheetData()
        {
            int BusinesssegmentID = 0;
            int RegionID = 0;
            int StatusID = 0;
            AdminRegionsBLL da = new AdminRegionsBLL();
            DataSet dsRegionList = new DataSet();
            dsRegionList = da.GetAllRegions(BusinesssegmentID, RegionID, StatusID);

            int intRowIndex = 0, intColIndex = 0;

            Workbook wbRegionsExport = new Workbook(WorkbookFormat.Excel2007);
            Worksheet wsRegionsExport = wbRegionsExport.Worksheets.Add("Master Localization List");

            //specify the default font family
            Infragistics.Documents.Excel.IWorkbookFont defaultFont = wbRegionsExport.Styles.NormalStyle.StyleFormat.Font;
            defaultFont.Name = "Calibri";
            defaultFont.Height = 11 * 20;

            intRowIndex = 0;
            intColIndex = 0;

            #region column headers
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "ID", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Country Region", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "HP Code", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "DASH Code", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "GEO", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Business Segments", 320.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "State", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Country Code", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11, WrapText: false);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "GM Code", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Default OS/Image Languages", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Other OS/Image Languages", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "MUI", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Keyboard", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Keyboard Layout", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Power Cord", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Duckhead Power Cord", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Duckhead", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Image Docs", 320.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Printed Docs", 320.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsRegionsExport, intRowIndex, intColIndex, "Comments", 320.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            #endregion

            intRowIndex = 1;
            intColIndex = 0;
            System.Drawing.ColorConverter cc = new System.Drawing.ColorConverter();
            string strOtherOSlanguage = "";
            foreach (DataRow drData in dsRegionList.Tables[0].Rows)
            {
                intColIndex = 0;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["ID"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["Name"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["OptionConfig"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["Dash"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["Geo"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["BusSeg"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["Active"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["CountryCode"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["GMCode"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["OsLanguage"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;

                if (drData["OtherLanguage"] != null)
                {
                    strOtherOSlanguage = drData["OtherLanguage"].ToString();
                }
                else {
                    strOtherOSlanguage = "";
                }
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, strOtherOSlanguage, HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["MUI"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["Keyboard"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["KeyboardLayout"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["PowerCord"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["DuckheadPowerCord"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["Duckhead"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["DocKits"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["PrintedDocs"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsRegionsExport, intRowIndex, intColIndex, drData["Comments"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                intRowIndex++;
            }

            string strFileName = "";
            strFileName = "Master_Localization_List_" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString().PadLeft(2, '0').ToString() + DateTime.Now.Day.ToString().PadLeft(2, '0').ToString();
            Response.Clear();
            Response.AppendHeader("content-disposition", "attachment; filename=" + strFileName + ".xlsx");
            Response.ContentType = "application/octet-stream";
            wbRegionsExport.Save(Response.OutputStream);
            Response.End();
        }
    }
}
