﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ProductBrand_Exclusion : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        Page.Title = "ABT/XLR8 Report Exclusions";
        master.pageheader = "ABT/XLR8 Report Exclusions";
        LoadProductBrandExclusionList();
        GetPermission();
    }
    private void GetPermission()
    {
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ABTReport_Edit_Permission.ToString()))
        {
            this.SCMNamebox1View.Enabled = false;
            this.btnSave.Enabled = false;
            this.SCMNamebox2View.Enabled = false;
        }
    }

    private void LoadProductBrandExclusionList()
    {
        AdminProductBrandExclusionBLL da = new AdminProductBrandExclusionBLL();
        DataSet dsPBExclusionList = new DataSet();
        int intAreaID = 1;
        string strOriginalExcludedList = "";
        try
        {
            dsPBExclusionList = da.GetProductBrandExclusionList(intAreaID);
            DataView dv1 = dsPBExclusionList.Tables[0].DefaultView;
            dv1.RowFilter = "Excluded=0";
            SCMNamebox1View.DataSource = dv1;
            SCMNamebox1View.DataTextField = "FullProdName";
            SCMNamebox1View.DataValueField = "ID";
            SCMNamebox1View.DataBind();
            dv1.RowFilter = "Excluded=1";
            SCMNamebox2View.DataSource = dv1;
            SCMNamebox2View.DataTextField = "FullProdName";
            SCMNamebox2View.DataValueField = "ID";
            SCMNamebox2View.DataBind();
            //get the original list
            foreach (DataRow drExcluded in dv1.Table.Rows)
            {
                if (Convert.ToInt32(drExcluded["Excluded"]) == 1)
                {
                    strOriginalExcludedList = strOriginalExcludedList == "" ? Convert.ToString(drExcluded["ID"]) : strOriginalExcludedList + "," + Convert.ToString(drExcluded["ID"]);
                }
            }
            hdnOriList.Value = strOriginalExcludedList;
            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
        }
    }
    [WebMethod]
    public static List<Dictionary<string, string>> GetProductBrandExclusionList(int AreaID)
    {
        List<Dictionary<string, string>> lstProductBrandExclusionList = new List<Dictionary<string, string>>();
        Dictionary<string, string> dicProductBrandExclusion;
        try
        {
            AdminProductBrandExclusionBLL da = new AdminProductBrandExclusionBLL();
            DataSet dsPBExclusionList = da.GetProductBrandExclusionList(AreaID);

            for (int i = 0; i < dsPBExclusionList.Tables[0].Rows.Count; i++)
            {
                dicProductBrandExclusion = new Dictionary<string, string>();
                dicProductBrandExclusion.Add("ID", dsPBExclusionList.Tables[0].Rows[i]["ID"].ToString());
                dicProductBrandExclusion.Add("FullProdName", dsPBExclusionList.Tables[0].Rows[i]["FullProdName"].ToString());
                dicProductBrandExclusion.Add("Excluded", dsPBExclusionList.Tables[0].Rows[i]["Excluded"].ToString());

                lstProductBrandExclusionList.Add(dicProductBrandExclusion);
            }
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }

        return lstProductBrandExclusionList;
    }
    [WebMethod]
    public static string SaveProductBrandExclusionList(int AreaID, string ProductBrandIDs)
    {
        string strReturnMessage;
        try
        {
            AdminProductBrandExclusionBLL da = new AdminProductBrandExclusionBLL();
            da.SaveProductBrandExclusionList(AreaID, ProductBrandIDs);
            strReturnMessage = "Data saved successfully";
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strReturnMessage = ex.Message;
        }
        return strReturnMessage;
    }
}
