﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using System.Collections.Specialized;
using System.Configuration;

using Infragistics.Web.UI.GridControls;
using Infragistics.Web.UI.ListControls;

namespace iPulsar
{
    public partial class PulsarObjectPermission : System.Web.UI.Page
    {
        int intRequesterID;
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            UserInfo objuserInfo = UserInfo.GetCurrentUserInfo();
            intRequesterID = objuserInfo.ID; // currently logged in userid which will be the requesterid

            if (!IsPostBack)
            {
                lblError.Text = "";
                // Rename page title
                Page.Title = "What do I need to use the " + Request.QueryString["Title"].ToString();
                lblHeader.Text = Request.QueryString["Title"].ToString();
                hdnIsODM.Value = UserInfo.GetCurrentUserIsODM().ToString();
                hdnNonAutoApproveTeamExists.Value = "0";
            }
            else
            {
                //WebDataGrid1.Visible = true;
            }

            LoadPularObjectPermission();
        }

        private void LoadPularObjectPermission()
        {
            try
            {
                DataSet ds;
                PulsarObjectPermissionBLL adBll = new PulsarObjectPermissionBLL();
                if (Request.QueryString["PageUrl"].ToString() == "")
                    ds = adBll.GetPulsarObjectPermission();
                else
                    ds = adBll.GetPulsarObjectPermission(Request.QueryString["PageUrl"].ToString(), intRequesterID);

                DataView dv = ds.Tables[0].DefaultView;

                WebDataGrid1.Visible = true;
                WebDataGrid1.ClearDataSource();
                this.WebDataGrid1.DataSource = dv;
                WebDataGrid1.DataBind();
                // check permission from resource file instead of enums - task 19440
                if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
                {
                    WebDataGrid1.Behaviors.EditingCore.Behaviors.CellEditing.ColumnSettings["Description"].ReadOnly = true;
                }
                else
                {
                    WebDataGrid1.Behaviors.EditingCore.Behaviors.CellEditing.ColumnSettings["Description"].ReadOnly = false;
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        [WebMethod]
        public static string UpdatePulsarObjectPermission(int PulsarObjectId, string Description)
        {
            string strMsg = "";
            try
            {
                PulsarObjectPermissionBLL adBll = new PulsarObjectPermissionBLL();
                adBll.UpdatePulsarObjectPermission(PulsarObjectId, Description);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strMsg = ex.Message;
            }
            return strMsg;
        }

        protected void Webdatagrid1_InitializeRow(object sender, RowEventArgs e)
        {
            string checkboxstate = e.Row.Items.FindItemByKey("UserHasRole").Value.ToString().ToLower();
            if (checkboxstate == "true")
            {
                e.Row.Tag = "CannotEdit";
                e.Row.CssClass = "LockedRow";
                e.Row.Items.FindItemByKey("UserHasRole").CssClass = "disabled";
            }
            else
            {
                e.Row.Tag = "CanEdit";
            }
        }


        // PBI 7834 - Task 20271 - Ability to request access from ? page
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                AdminAddUserToTeamBLL adBll2 = new AdminAddUserToTeamBLL();
                string strTeamIds = "";
                int TeamID = 0;
                string strRoles = "";
                string strNoRoles = "";


                for (int i = 0; i < WebDataGrid1.Rows.Count; i++)
                {
                    if (WebDataGrid1.Rows[i].Items.FindItemByKey("UserHasRole").Value.ToString() == "True")
                    {
                        if (WebDataGrid1.Rows[i].Items.FindItemByKey("PreSelected").Value.ToString().ToLower() != "yes")
                        {
                            strTeamIds = strTeamIds == "" ? WebDataGrid1.Rows[i].Items.FindItemByKey("TeamId").Value.ToString() : strTeamIds + "," + WebDataGrid1.Rows[i].Items.FindItemByKey("TeamId").Value.ToString();
                        }
                    }
                }

                string[] arrTeamID = strTeamIds.Split(',');
                string[] arrTeamID_distinct = arrTeamID.Distinct().ToArray();


                for (int j = 0; j < arrTeamID_distinct.Length; j++)
                {
                    TeamID = Convert.ToInt32(arrTeamID_distinct[j]);
                    strRoles = "";
                    for (int k = 0; k < WebDataGrid1.Rows.Count; k++)
                    {
                        if (WebDataGrid1.Rows[k].Items.FindItemByKey("UserHasRole").Value.ToString() == "True")
                        {
                            if (WebDataGrid1.Rows[k].Items.FindItemByKey("PreSelected").Value.ToString().ToLower() != "yes")
                            {
                                if (Convert.ToInt32(WebDataGrid1.Rows[k].Items.FindItemByKey("TeamId").Value) == TeamID)
                                {
                                    strRoles = strRoles == "" ? WebDataGrid1.Rows[k].Items.FindItemByKey("RoleId").Value.ToString() : strRoles + "," + WebDataGrid1.Rows[k].Items.FindItemByKey("RoleId").Value.ToString();
                                }
                            }
                        }
                    }

                    if (strRoles != "")
                    {
                        adBll2.UserAccessRequest(strRoles, TeamID, intRequesterID, strNoRoles);
                        if (TeamID == 35 || TeamID == 125)
                        {
                            hdnNonAutoApproveTeamExists.Value = "1";
                        }
                    }
                }
                hdnDataSaved.Value = "Saved";
                //ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "RefreshPulsarObjectPermission", "RefreshPulsarObjectPermission()", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}