﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iPulsar.Old_App_Code.BLL.Admin;
using System.Data;

namespace iPulsar.Admin.Areas
{
    public partial class OperatingSystems_Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession(false);

            string mode;
            mode = Request.QueryString["mode"];

            if (!IsPostBack)
            {
                int ID = Convert.ToInt32(Request.QueryString["OSID"]);
                GetOSFamily();

                if ((mode == "update"))
                {
                    LoadOperatingSystem(ID);
                    Page.Title = "Modify Existing Operating System";
                    GetPermission();
                    rbStatus.Enabled = true;
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Operating System";
                    pnlHistory.Visible = false;
                    rbStatus.Enabled = false;
                }
            }
        }

        private void LoadOperatingSystem(int OSID)
        {
            AdminOperatingSystemsBLL da = new AdminOperatingSystemsBLL();
            DataSet ds;
            ds = da.GetSelectedOS(OSID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {

                DataRow dr = ds.Tables[0].Rows[0];
                txtCode.Text = dr["CVAKey"].ToString();
                txtName.Text = dr["Name"].ToString();
                txtDesc.Text = dr["OfficialName"].ToString();

                rbStatus.ClearSelection();
                rbStatus.Items.FindByValue(Convert.ToBoolean(dr["Active"]) ? "1" : "0").Selected = true;

                ddlFamily.ClearSelection();
                ddlFamily.Items.FindByValue(dr["OSFamilyId"].ToString()).Selected = true;


                chkMktSC.Checked = dr["SupplyChain"].ToString() == "Yes";
                chkRD.Checked = dr["Components"].ToString() == "Yes";
                
                //rbStatus.SelectedValue = dr["Active"].ToString();
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                ds.Dispose();
                pnlHistory.Visible = true;
            }



        }


        private void GetOSFamily()
        {
            AdminOperatingSystemsBLL da = new AdminOperatingSystemsBLL();
            DataSet ds = new DataSet();
            ds = da.GetOSFamily();
            ddlFamily.DataSource = ds;
            ddlFamily.DataTextField = "FamilyName";
            ddlFamily.DataValueField = "ID";
            ddlFamily.DataBind();

            ddlFamily.SelectedValue = "0";


        }



        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.OperatingSystems_Edit_Permission.ToString()))
            {
                Page.Title = "View Operating System";
                this.txtCode.Enabled = false;
                this.txtDesc.Enabled = false;
                this.txtName.Enabled = false;
                ddlFamily.Enabled = false;
                rbStatus.Enabled = false;
                // Disable buttons based on permission - Task 16666
                this.btnSave.Enabled = false;

            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strCode = "";
            string strName = "";
            string strDesc = "";
            int intStatus = 1;
            int intMktSC = 0;
            int intRD = 0;
            int intOSFamilyID = 0;
            int intOperatingSystemId = 0;
            AdminOperatingSystemsBLL da = new AdminOperatingSystemsBLL();
            try
            {
                strCode = txtCode.Text.ToString();
                strName = txtName.Text.ToString();
                strDesc = txtDesc.Text.ToString();
                intOSFamilyID = Convert.ToInt32(ddlFamily.SelectedValue);
                intRD = chkRD.Checked ? 1 : 0;
                intMktSC = chkMktSC.Checked ? 1 : 0;
                if (Request.QueryString["OSID"] != null)
                {
                    intOperatingSystemId = Convert.ToInt32(Request.QueryString["OSID"].ToString());
                }
                else
                {
                    intOperatingSystemId = -1;
                }

                intStatus = Convert.ToInt32(rbStatus.SelectedValue);

                intOperatingSystemId = da.UpdateOperatingSystem(intOperatingSystemId, strCode, strName, strDesc, intStatus,
            intMktSC, intRD, intOSFamilyID, UserInfo.GetCurrentUserName());



                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadoperatingsystem", "CloseEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }


    }
}


