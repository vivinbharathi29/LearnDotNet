﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.Areas
{
    public partial class CommAgencyCountry_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            MainMasterPage master = (MainMasterPage)Page.Master;
            Page.Title = "Comm Agency Country Defaults";
            master.pageheader = "Comm Agency Country Defaults";
            GetPermission();
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.CommAgencyAdmin_Edit_Permission.ToString()))
            {
                Page.Title = "Comm Agency Country Defaults";
                txtEditRight.Value = "0";

            }

        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetCommAgencyCountryDefaults()
        {
            try
            {
                List<Dictionary<string, object>> dicCountriesList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicRegion = null;

                AdminRegionsBLL da = new AdminRegionsBLL();
                DataSet ds = new DataSet();
                ds = da.GetCommAgencyCountryDefaults(0);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dicRegion = new Dictionary<string, object>();
                    dicRegion.Add("CountryID", ds.Tables[0].Rows[i]["CountryID"].ToString());
                    dicRegion.Add("Name", ds.Tables[0].Rows[i]["Name"].ToString());
                    dicRegion.Add("GEO", ds.Tables[0].Rows[i]["GEO"].ToString());
                    dicRegion.Add("Active", ds.Tables[0].Rows[i]["Active"].ToString());
                    dicRegion.Add("WWAN", ds.Tables[0].Rows[i]["WWAN"].ToString());
                    dicRegion.Add("NFC", ds.Tables[0].Rows[i]["NFC"].ToString());
                    dicRegion.Add("WiGig", ds.Tables[0].Rows[i]["WiGig"].ToString());
                    dicRegion.Add("WLAN", ds.Tables[0].Rows[i]["WLAN"].ToString());
                    dicRegion.Add("BT", ds.Tables[0].Rows[i]["BT"].ToString());

                    dicCountriesList.Add(dicRegion);

                }
                return dicCountriesList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}