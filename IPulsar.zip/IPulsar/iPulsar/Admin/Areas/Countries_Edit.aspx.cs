﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using Telerik.Web.UI;
using System.Web.Services;
namespace iPulsar.Admin.Areas
{
    public partial class Countries_Edit : System.Web.UI.Page
    {
        int CountryID;
        int GeoID;
        bool bEdit;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession(false);

            string mode;
            mode = Request.QueryString["mode"];
            CountryID = Convert.ToInt32(Request.QueryString["CountryID"]);
            hdnCountryID.Value = CountryID.ToString();
            GetPermission();
            
            if (!IsPostBack)
            {
                LoadPowerCordGEOs();
                if ((mode == "update"))
                {
                    LoadCountry(CountryID);
                    Page.Title = "Modify Country";
                
                    LoadLocalizationList(CountryID);
                    LoadGEO(GeoID);
                   
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Country";
                    pnlHistory.Visible = false;
                  
                    LoadLocalizationList(0);
                    LoadGEO(0);
                   
                }
               
            }
            if (!bEdit)
            { disablecontrols(); }
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Regions_Edit_Permission.ToString()))
            {
                bEdit = false;

            }
            else
            {
                bEdit = true;
            
            }
        }

        private void LoadPowerCordGEOs()
        {
            AdminRegionsBLL adBll = new AdminRegionsBLL();
            DataSet dsGEOList = new DataSet();
            try
            {
                dsGEOList = adBll.GePowerCordGEOs();

                ddlPowerCord.DataSource = dsGEOList.Tables[0];
                ddlPowerCord.DataTextField = "GEO";
                ddlPowerCord.DataValueField = "GEOID";
                ddlPowerCord.DataBind();
                ddlPowerCord.Items.Insert(0, new ListItem("", "0"));

                ddlDuckheadPowerCord.DataSource = dsGEOList.Tables[0];
                ddlDuckheadPowerCord.DataTextField = "GEO";
                ddlDuckheadPowerCord.DataValueField = "GEOID";
                ddlDuckheadPowerCord.DataBind();
                ddlDuckheadPowerCord.Items.Insert(0, new ListItem("", "0"));

                ddlDuckhead.DataSource = dsGEOList.Tables[0];
                ddlDuckhead.DataTextField = "GEO";
                ddlDuckhead.DataValueField = "GEOID";
                ddlDuckhead.DataBind();
                ddlDuckhead.Items.Insert(0, new ListItem("", "0"));
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void LoadCountry(int CountryID)
        {
            AdminRegionsBLL adBll = new AdminRegionsBLL();
            DataSet ds;

            ds = adBll.GetCountryById(CountryID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                txtName.Text = dr["Name"].ToString();
                txtHPCode.Text = dr["HPCode"].ToString();
                txtCPQCode.Text = dr["CPQCode"].ToString();

                if (dr["State"].ToString().ToLower() == "true" || dr["State"].ToString() == "1")
                    rbState.SelectedValue = "1";
                else
                    rbState.SelectedValue = "0";

                if (dr["Export"].ToString().ToLower() == "true" || dr["Export"].ToString() == "1")
                    chkExport.Checked = true;
                else
                    chkExport.Checked = false;

                if (dr["LegalRisk"].ToString().ToLower() == "true" || dr["LegalRisk"].ToString() == "1")
                    chkLegalRisk.Checked = true;
                else
                    chkLegalRisk.Checked = false;

                txtLegalRiskDescription.Value = dr["LegalRiskDescription"].ToString();

                if (dr["ExportCompliance"].ToString().ToLower() == "true" || dr["ExportCompliance"].ToString() == "1")
                    chkExportcompliance.Checked = true;
                else
                    chkExportcompliance.Checked = false;
                
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                GeoID = Int32.Parse(dr["NewGeoID"].ToString());
                ddlPowerCord.SelectedValue = dr["PowerCordGEOID"].ToString();
                ddlDuckheadPowerCord.SelectedValue = dr["DuckheadPowerCordGEOID"].ToString();
                ddlDuckhead.SelectedValue = dr["DuckheadGEOID"].ToString();
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }
        private void disablecontrols()
        {
            Page.Title = "View Master Country";
            //  this.txtHPCode.Enabled = false;
            this.btnSave.Enabled = false;
            this.rbState.Enabled = false;
            this.lblEnter.Visible = false;
            // this.txtDash.Enabled = false;
            txtName.Enabled = false;
            txtHPCode.Enabled = false;
            txtCPQCode.Enabled = false;
            chkExportcompliance.Enabled = false;
            chkExport.Enabled = false;
            DDLGEO.Enabled = false;
            rlbAvailableLocalizations.Enabled = false;
            rlbSelectedLocalizations.Enabled = false;
            ddlPowerCord.Enabled = false;
            ddlDuckheadPowerCord.Enabled = false;
            ddlDuckhead.Enabled = false;
            chkLegalRisk.Enabled = false;
            txtLegalRiskDescription.Disabled = true;
        }
        private void LoadLocalizationList(int CountryID)
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            DataSet dsLocalizationList = new DataSet();
           
           
            try
            {
                dsLocalizationList = da.usp_ADMIN_Country_ViewLocalizations(CountryID);
               
                DataView DV1 = dsLocalizationList.Tables[0].DefaultView;
               
                // Localization
                rlbAvailableLocalizations.DataSource = DV1;
                rlbAvailableLocalizations.DataTextField = "Name";
                rlbAvailableLocalizations.DataValueField = "ID";
                rlbAvailableLocalizations.DataBind();

                DataView DV2 = dsLocalizationList.Tables[1].DefaultView;
                rlbSelectedLocalizations.DataSource = DV2;
                rlbSelectedLocalizations.DataTextField = "Name";
                rlbSelectedLocalizations.DataValueField = "ID";
                rlbSelectedLocalizations.DataBind();
                                     
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        private void LoadGEO(int intGeoID)
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsGEOList = new DataSet();
            DataSet dsSelectedGEO = new DataSet();

            try
            {
                dsGEOList = da.GetGEO();
                dsGEOList.Tables[0].DefaultView.Sort = "Name Asc";
                DDLGEO.DataSource = dsGEOList.Tables[0];
                DDLGEO.DataTextField = "Name";
                DDLGEO.DataValueField = "GEOID";
                DDLGEO.DataBind();
                DDLGEO.Items.Insert(0, new ListItem("Please Select a GEO", "0"));
                DDLGEO.SelectedValue = intGeoID.ToString();

            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        

       
        protected void btnSave_Click(object sender, EventArgs e)
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            try
            {
                string strCountryName = txtName.Text.Trim();
                string strHPCode = txtHPCode.Text.Trim();
                string strCPQCode = txtCPQCode.Text.Trim();
                int intState = 0;
                if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                    intState = 1;
                int intGeoID = Int32.Parse(DDLGEO.SelectedValue);
                int intExport =0;
                if (chkExport.Checked)
                    intExport = 1;

                int intLegalRisk = 0;
                string LegalRiskDescription = string.Empty;
                if (chkLegalRisk.Checked)
                {
                    intLegalRisk = 1;
                    LegalRiskDescription = txtLegalRiskDescription.Value;
                }

                int intExportCompliance =0;
                if (chkExportcompliance.Checked)
                     intExportCompliance = 1;

                int intPowerCordGEOID = Int32.Parse(ddlPowerCord.SelectedValue);
                int intDuckheadPowerCordGEOID = Int32.Parse(ddlDuckheadPowerCord.SelectedValue);
                int intDuckheadGEOID = Int32.Parse(ddlDuckhead.SelectedValue);

                //get the list of selected OSLocalizations
                string strLocalization = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelectedLocalizations.Items)
                {   if (selectedItem.Checked)
                        strLocalization += selectedItem.Value.Trim() + "_1" + ",";
                    else
                        strLocalization += selectedItem.Value.Trim() + "_0" + ",";
                }

                if (strLocalization.Trim().Length > 0)
                {
                    strLocalization = strLocalization.Substring(0, strLocalization.Trim().Length - 1);
                }
              
                
                CountryID = da.UpdateCountry(CountryID, strCountryName, strHPCode,  strCPQCode,intExport, intExportCompliance, intState,
                        intGeoID, strLocalization, UserInfo.GetCurrentUserName().ToString(),
                        intPowerCordGEOID, intDuckheadPowerCordGEOID, intDuckheadGEOID, intLegalRisk, LegalRiskDescription
                  );

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadCountry", "CloseCountryEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }


        protected void rlbSelectedLocalizations_ItemDataBound(object sender, Telerik.Web.UI.RadListBoxItemEventArgs e)
        {
            RadListBoxItem item = (RadListBoxItem)e.Item;
            DataRowView row = (DataRowView)item.DataItem;
            if (Convert.ToBoolean(row["Defaultlocalization"]))     
            {
                item.Checked = true;
            }
        }
    }
}



