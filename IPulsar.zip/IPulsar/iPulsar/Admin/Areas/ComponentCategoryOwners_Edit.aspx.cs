﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace iPulsar.Admin.Areas
{
    public partial class ComponentCategoryOwners_Edit : System.Web.UI.Page
    {
        int ComponentCategoryID;
        protected void Page_Load(object sender, EventArgs e)
        {
             Authenticate.ValidateSession(false);           
            ComponentCategoryID = Convert.ToInt32(Request.QueryString["CategoryID"]);

            if (!IsPostBack)
            {
                LoadComponentCategory(ComponentCategoryID);
                LoadOwners(Convert.ToInt32(ComponentCategoryID));
            }

            GetPermission();
        }
        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ComponentCategory_Edit_Permission.ToString()))
            {
                Page.Title = "View Component Category";
                this.rlbAvailableOwners.Enabled = false;
                this.rlbSelectedOwners.Enabled = false;
                this.btnSave.Enabled = false;               
                this.lblEnter.Visible = false;
                this.btnUserSearch.Disabled = true;
            }
        }
       
       
        private void LoadOwners(int intCategoryID)
        {
            AdminComponentCategoryBLL da = new AdminComponentCategoryBLL();
            DataSet dsOwners = new DataSet();
            try
            {
                dsOwners = da.ComponentCategory_OwnersList(intCategoryID);
                dsOwners.Tables[0].DefaultView.Sort = "FullName Asc";
                rlbAvailableOwners.DataSource = dsOwners.Tables[0];
                rlbAvailableOwners.DataTextField = "FullName";
                rlbAvailableOwners.DataValueField = "UserID";
                rlbAvailableOwners.DataBind();

                if (dsOwners.Tables[1] != null)
                {
                    rlbSelectedOwners.DataSource = dsOwners.Tables[1];
                    rlbSelectedOwners.DataTextField = "FullName";
                    rlbSelectedOwners.DataValueField = "UserID";
                    rlbSelectedOwners.DataBind();
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
       
        private void LoadComponentCategory(int intCategoryID)
        {
            AdminComponentCategoryBLL adBll = new AdminComponentCategoryBLL();
            DataSet ds;

            ds = adBll.GetComponentCategoryByID(intCategoryID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];             
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                lblCatName.Text = dr["Name"].ToString();
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
                     
            AdminComponentCategoryBLL da = new AdminComponentCategoryBLL();
            try
            {
               
               
                //get the list of selected naming standard
                string selectedOwnerIDs = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelectedOwners.Items)
                {
                    selectedOwnerIDs += selectedItem.Value.Trim() + ",";
                }
                              
                //save owners to different table
                if (selectedOwnerIDs.Trim().Length > 0)
                {
                    selectedOwnerIDs = selectedOwnerIDs.Substring(0, selectedOwnerIDs.Trim().Length - 1);
                }
                da.ComponentCategory_OwnersModify(ComponentCategoryID, selectedOwnerIDs, UserInfo.GetCurrentUserName().ToString());

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadFeaturewithoutRoots", "CloseCCEditPopup(true)", true);

               
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}


