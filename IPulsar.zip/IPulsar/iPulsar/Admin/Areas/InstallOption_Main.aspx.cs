﻿using iPulsar.Old_App_Code.BLL.Admin;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.Areas
{
    public partial class InstallOption_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession();

            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "Install Options / Install Option Combinations";
            Page.Title = "Install Options / Install Option Combinations";

            if (!IsPostBack)
            {
                hdnUser.Value = UserInfo.GetCurrentUserName().ToString();
            }

            GetPermission();
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.AdminInstallOption_Edit_Permission.ToString()))
            {
                Page.Title = "View Install Option List";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmIOContextMenu.Items.FindItemByValue("Add").Enabled = false;
                rmIOCContextMenu.Items.FindItemByValue("Add").Enabled = false;
            }
        }


        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> FillIOGrid()
        {
            try
            {
                List<Dictionary<string, object>> dictList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dict = null;
                InstallOptionBLL objBLL = new InstallOptionBLL();
                DataSet ds = new DataSet();

                ds = objBLL.GetInstallOptionList(0);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dict = new Dictionary<string, object>();
                    dict.Add("ID", ds.Tables[0].Rows[i]["ID"].ToString());
                    dict.Add("DMIString", ds.Tables[0].Rows[i]["DMIString"].ToString());
                    dict.Add("DMICode", ds.Tables[0].Rows[i]["DMICode"].ToString());
                    dict.Add("FieldDesc", ds.Tables[0].Rows[i]["Description"].ToString());
                    dict.Add("StandAlone", ds.Tables[0].Rows[i]["AllowStandAlone"].ToString());
                    dict.Add("State", ds.Tables[0].Rows[i]["State"].ToString());
                    dict.Add("ChannelPartner", ds.Tables[0].Rows[i]["ChannelPartner"].ToString());
                    dictList.Add(dict);
                }
                return dictList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> FillIOCGrid()
        {
            try
            {
                List<Dictionary<string, object>> dictList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dict = null;
                InstallOptionBLL objBLL = new InstallOptionBLL();
                DataSet ds = new DataSet();

                ds = objBLL.GetInstallOptionList(1);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dict = new Dictionary<string, object>();
                    dict.Add("ID", ds.Tables[0].Rows[i]["ID"].ToString());
                    dict.Add("DMIString", ds.Tables[0].Rows[i]["DMIString"].ToString());
                    dict.Add("FieldDesc", ds.Tables[0].Rows[i]["Description"].ToString());
                    dict.Add("State", ds.Tables[0].Rows[i]["State"].ToString());
                    dict.Add("ChannelPartner", ds.Tables[0].Rows[i]["ChannelPartner"].ToString());
                    dictList.Add(dict);
                }
                return dictList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static string RemoveInstallOption(int intIOID, string strUser)
        {
            string strReturnMsg = "Install Option successfully removed. Install Option changes are not Synchronized with IRS. Please go to IRS / Admin / Install Options / Install Options or Install Options Combinations and make the same changes that were just done in Pulsar.";
            try
            {
                InstallOptionBLL da = new InstallOptionBLL();
                da.DeleteInstallOption(intIOID, strUser);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataSet ds;
            InstallOptionBLL BLL = new InstallOptionBLL();

            ds = BLL.GetInstallOptionList(0);

            StringBuilder str = new StringBuilder();
            str.AppendLine("[Options]");
            for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
            {
                str.AppendLine(ds.Tables[0].Rows[i][1].ToString() + "=" + ds.Tables[0].Rows[i][3].ToString());
            }

            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=DMI.ini");
            Response.Charset = "";
            Response.ContentType = "application/vnd.text";
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
            Response.Write(str.ToString());
            Response.End();
            ds.Clear();
        }
    }
}