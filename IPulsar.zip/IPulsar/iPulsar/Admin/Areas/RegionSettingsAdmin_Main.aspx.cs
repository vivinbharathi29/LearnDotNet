﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;

public partial class RegionSettingsAdmin_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();

        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "Region Settings Admin";
        Page.Title = "Region Settings Admin";
        if (!IsPostBack)
        {
            GetPermission();
        }
    }
    private void GetPermission()
    {
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.RegionSettings_Edit_Permission.ToString()))
        {
            Page.Title = "Region Settings Admin";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.RegionSettings_Delete_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }

    [WebMethod]
    public static List<Dictionary<string, object>> GetAllRegionSettings()
    {
        try
        {
            List<Dictionary<string, object>> dicRegionSettingList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicRegionSetting = null;
            AdminRegionSettingsAdminBLL da = new AdminRegionSettingsAdminBLL();
            DataSet dsRegionSettingsList = new DataSet();
            dsRegionSettingsList = da.GetAllRegionSettings();
            for (int i = 0; i < dsRegionSettingsList.Tables[0].Rows.Count; i++)
            {
                dicRegionSetting = new Dictionary<string, object>();
                dicRegionSetting.Add("RegionSettingID", dsRegionSettingsList.Tables[0].Rows[i]["RegionSettingID"].ToString());
                dicRegionSetting.Add("BusinessSegment", dsRegionSettingsList.Tables[0].Rows[i]["BusinessSegmentName"].ToString());
                dicRegionSetting.Add("GEO", dsRegionSettingsList.Tables[0].Rows[i]["GeoShortName"].ToString());
                dicRegionSetting.Add("TotalUser", dsRegionSettingsList.Tables[0].Rows[i]["TotalUser"].ToString());
                dicRegionSettingList.Add(dicRegionSetting);
            }
            return dicRegionSettingList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod]
    public static void DeleteBusinessSegment(int RegionSettingID)
    {
        try
        {
            AdminRegionSettingsAdminBLL da = new AdminRegionSettingsAdminBLL();
            da.DeleteBusinessSegment(RegionSettingID);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}