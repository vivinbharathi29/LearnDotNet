﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class SystemAdmin_EmailTemplate_Edit : System.Web.UI.Page
{
    int EmailID;
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession(false);
        string mode;
        mode = Request.QueryString["mode"];
        EmailID = Convert.ToInt32(Request.QueryString["EmailID"]);
        Authenticate.ValidateSession();
        // Put user code to initialize the page here

        if (!IsPostBack)
        {
            if ((mode == "update"))
            {
                GetEmailTemplate(EmailID);
                Page.Title = "Modify Pre-defined Email Body";
                GetPermission();
            }
            else if (mode == "create")
            {
                Page.Title = "Add Pre-defined Email Body";
                pnlHistory.Visible = false;
            }
        }
    }
    private void GetEmailTemplate(int EmailID)
    {
        AdminScmxPcsPcrBLL da = new AdminScmxPcsPcrBLL();
        DataSet ds = new DataSet();
        ds = da.GetEmailTemplate(EmailID);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];

            txtSubject.Text = dr["Subject"].ToString();
            txtEmailContent.Value = dr["Body"].ToString();
            lblTimeChanged.Text = dr["Updated"].ToString().Trim();
            lblTimeCreated.Text = dr["Created"].ToString().Trim();
            lblCreator.Text = dr["CreatedBy"].ToString().Trim();
            lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();

            ds.Dispose();
            pnlHistory.Visible = true;
        }  
    }

    private void GetPermission()
    {  
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SCMXEditor_Edit_Permission.ToString()))
        {
            Page.Title = "View Feature Category";

            //this.txtName.Enabled = false;
            this.btnSave.Enabled = false;
            this.lblEnter.Visible = false;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        AdminScmxPcsPcrBLL da = new AdminScmxPcsPcrBLL();
        try
        {
            UserInfo obj = new UserInfo();
            da.ModifyEmailTemplate(EmailID, txtSubject.Text, txtEmailContent.Value, UserInfo.GetCurrentUserName().ToString());

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloademailtemplateedit", "CloseEditPopup(true)", true);
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
}

