﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;
using System.Web.Services;


public partial class Admin_Areas_Brands_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession();

        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "Brands";
        Page.Title = "Brands";
        GetPermission();
    }

    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Brand_Edit_Permission.ToString()))
        {
            Page.Title = "View Brands List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }

        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Brand_Delete_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetBrands()
    {
        try
        {
            List<Dictionary<string, object>> dicList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dic = null;
            AdminBrandsBLL da = new AdminBrandsBLL();
            DataSet dsList = new DataSet();
            dsList = da.GetBrands(-1);
            for (int i = 0; i < dsList.Tables[0].Rows.Count; i++)
            {
                dic = new Dictionary<string, object>();
                dic.Add("ID", dsList.Tables[0].Rows[i]["ID"].ToString());
                dic.Add("Name", dsList.Tables[0].Rows[i]["Name"].ToString());
                dic.Add("BusinessSegment", dsList.Tables[0].Rows[i]["BusinessSegment"].ToString());
                dic.Add("Abbreviation", dsList.Tables[0].Rows[i]["Abbreviation"].ToString());
                dic.Add("RasSegment", dsList.Tables[0].Rows[i]["RASSegment"].ToString());
                dic.Add("Suffix", dsList.Tables[0].Rows[i]["Suffix"].ToString());
                dic.Add("StreetName1", dsList.Tables[0].Rows[i]["StreetName"].ToString());
                dic.Add("StreetName2", dsList.Tables[0].Rows[i]["StreetName2"].ToString());
                dic.Add("StreetName3", dsList.Tables[0].Rows[i]["StreetName3"].ToString());
                dic.Add("ShowSeriesInLogo", dsList.Tables[0].Rows[i]["ShowSeriesNumberInLogoBadge"].ToString());
                dic.Add("ShowSeriesInBrand", dsList.Tables[0].Rows[i]["ShowSeriesNumberInBrandname"].ToString());
                dic.Add("State", dsList.Tables[0].Rows[i]["State"].ToString());
                dicList.Add(dic);
            }
            return dicList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static List<string> GetUserPermission()
    {
        try
        {
            return Permission.GetUserPermissions(UserInfo.GetCurrentUserID());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static string RemoveBrand(int intBrandID)
    {
        string strReturnMsg = "";
        try
        {
            AdminBrandsBLL da = new AdminBrandsBLL();
            da.DeleteBrand(intBrandID);
            strReturnMsg = "Brand successfully removed.";
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strReturnMsg = ex.Message;
        }
        return strReturnMsg;
    }
}