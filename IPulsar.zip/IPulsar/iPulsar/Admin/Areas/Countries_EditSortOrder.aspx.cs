﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace iPulsar.Admin.Areas
{
    public partial class Countries_EditSortOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            if (!IsPostBack)
                LoadCountries();
        }
        private void LoadCountries()
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            DataSet dsRegionList = new DataSet();
            dsRegionList = da.GetAllCountries();
            DataView dvCountry = dsRegionList.Tables[0].DefaultView;
            dvCountry.Sort = "OrderID asc, Name asc";
            LstCountries.DataSource = dvCountry;
            LstCountries.DataTextField = "Name";
            LstCountries.DataValueField = "ID";
            LstCountries.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            StringBuilder strCountries = new StringBuilder();
            if (LstCountries.Items.Count > 0)
            {
                strCountries.Append("<Countries>");
                foreach (Telerik.Web.UI.RadListBoxItem Country in LstCountries.Items)
                {
                    //selectedIDs += selectedItem.Value.Trim() + ",";
                    strCountries.Append("<Country>");
                    strCountries.Append("<CountryID>" + Country.Value + "</CountryID>");
                    strCountries.Append("<SortOrder>" + (Country.Index + 1).ToString() + "</SortOrder>");
                    strCountries.Append("</Country>");
                }
                strCountries.Append("</Countries>");
                AdminRegionsBLL da = new AdminRegionsBLL();
                da.UpdateSCMCategorySortOrder(strCountries.ToString());

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadCountryfromsortorder", "CloseCountrySortOrderPopup(true)", true);
            }
        }
    }
}