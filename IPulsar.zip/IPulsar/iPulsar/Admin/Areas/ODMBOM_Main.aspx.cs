﻿using iPulsar.Old_App_Code.BLL.Admin;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.Areas
{
    public partial class ODMBOM_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "ODM BOM Visibility";
            Page.Title = "ODM BOM Visibility";

            if (!IsPostBack)
            {
                hdnUser.Value = UserInfo.GetCurrentUserName().ToString();
            }

            GetPermission();
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ABTReport_Edit_Permission.ToString()))
            {
                // Disable buttons based on permission - Task 16666
                Page.Title = "View ODM BOM Visibility List";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
                txtDeleteRight.Value = "0";
            }
        }


        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> FillGrid()
        {
            try
            {
                List<Dictionary<string, object>> dictList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dict = null;
                ODMBOMBLL objBLL = new ODMBOMBLL();
                DataSet ds = new DataSet();

                ds = objBLL.GetAllODMBOMList();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dict = new Dictionary<string, object>();
                    dict.Add("ID", ds.Tables[0].Rows[i]["ID"].ToString());
                    dict.Add("Value", ds.Tables[0].Rows[i]["Value"].ToString());
                    dict.Add("State", ds.Tables[0].Rows[i]["State"].ToString());
                    dictList.Add(dict);
                }
                return dictList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static string RemoveODMBOM(int intID, string strUser)
        {
            string strReturnMsg = "ODM BOM successfully removed.";
            try
            {
                ODMBOMBLL da = new ODMBOMBLL();
                da.DeleteODMBOM(intID, strUser);
            }
            catch (Exception ex)
            {
                strReturnMsg = ex.Message;
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            }
            return strReturnMsg;
        }
    }
}