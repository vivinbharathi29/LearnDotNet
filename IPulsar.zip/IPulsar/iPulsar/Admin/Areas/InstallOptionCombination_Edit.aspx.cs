﻿using iPulsar.Old_App_Code.BLL.Admin;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.Areas
{
    public partial class InstallOptionCombination_Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession(false);

            string mode;
            mode = Request.QueryString["mode"];

            if (!IsPostBack)
            {
                int ID = Convert.ToInt32(Request.QueryString["IOID"]);
                LoadInstallOptions(ID);

                if ((mode == "update"))
                {
                    LoadInstallOptionCombination(ID);
                    Page.Title = "Modify Existing Install Option Combination";
                    GetPermission();
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Install Option Combination";
                    pnlHistory.Visible = false;
                }



            }
        }


        private void LoadInstallOptionCombination(int intIOID)
        {
            InstallOptionBLL da = new InstallOptionBLL();
            DataSet ds;
            ds = da.GetSelectedInstallOption(intIOID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {

                DataRow dr = ds.Tables[0].Rows[0];
               // txtDMIString.Text = dr["DMIString"].ToString();
                txtFieldDesc.Text = dr["Description"].ToString();
                rbStatus.SelectedValue = dr["State"].ToString();
                chkChannelpartner.Checked = Convert.ToBoolean(dr["Channelpartner"].ToString());
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }

        private void LoadInstallOptions(int intIOID)
        {
            InstallOptionBLL da = new InstallOptionBLL();
            DataSet ds = new DataSet();
            try
            {
                ds = da.Combination_InstallOptions(intIOID);

                RLBAvailIO.DataSource = ds.Tables[0];
                RLBAvailIO.DataTextField = "DMIString";
                RLBAvailIO.DataValueField = "Id";
                RLBAvailIO.DataBind();

                if (ds.Tables[1] != null)
                {

                    RLBSelIO.DataSource = ds.Tables[1];
                    RLBSelIO.DataTextField = "DMIString";
                    RLBSelIO.DataValueField = "Id";
                    RLBSelIO.DataBind();
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }



        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.AdminInstallOption_Edit_Permission.ToString()))
            {
                Page.Title = "View Install Option";
                this.txtFieldDesc.Enabled = false;
                this.btnSave.Enabled = false;
                this.rbStatus.Enabled = false;
                this.lblEnter.Visible = false;
            }
        }



        protected void btnSave_Click(object sender, EventArgs e)
        {
            
            string strDescription = "";
            int intSetInactive = 1;
            int intInstallOptionCombId = 0;
            int intChannelpartner = 0;
            if (chkChannelpartner.Checked)
                intChannelpartner = 1;
            InstallOptionBLL da = new InstallOptionBLL();
            try
            {
                
               // strDMIString = txtDMIString.Text.ToString();
                strDescription = txtFieldDesc.Text.ToString();
                if (Request.QueryString["IOID"] != null)
                {
                    intInstallOptionCombId = Convert.ToInt32(Request.QueryString["IOID"].ToString());
                }
                else
                {
                    intInstallOptionCombId = -1;
                }

                //get the list of selected Operating Releases
                string strDMIString = "";
                int count = 0;
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in RLBSelIO.Items)
                {
                    if (count != RLBSelIO.Items.Count - 1)
                    {
                        strDMIString += selectedItem.Text.Trim() + ",";
                    }
                    else
                    {
                        strDMIString += selectedItem.Text.Trim();
                    }
                    count++;
                }

                intSetInactive = Convert.ToInt32(rbStatus.SelectedValue);

                intInstallOptionCombId = da.UpdateInstallOptionCombination(intInstallOptionCombId, strDMIString, strDescription, intSetInactive, UserInfo.GetCurrentUserName(), intChannelpartner);



                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadInstallOption", "CloseIOCEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        } 

    }
}