﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class Admin_ABTBusinessSegment_Edit : System.Web.UI.Page
{
    int BusinessSegmentID;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() will make sure you are who you are 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        string mode;        
        mode = Request.QueryString["mode"];
        BusinessSegmentID = Convert.ToInt32(Request.QueryString["SegmentID"]);
        
        // Put user code to initialize the page here
        if (!IsPostBack)
        {
            if ((mode == "update"))
            {              
                Page.Title = "Modify Business Segment";               
            }
            else if (mode == "create")
            {
                Page.Title = "Add New Business Segment";
                pnlHistory.Visible = false;                
            }

            LoadSegmentData(BusinessSegmentID);
        }       
 
        GetPermission();
    }
    private void GetPermission()
    {
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        //if (!Role.IsCurrentUserInRole(Enumeration.Enum_FeatureCategory_Role.FeatureCategory_Editor.ToString()))
        // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ABTReport_Edit_Permission.ToString()))
        {
            Page.Title = "View Business Segment";
            this.txtSegmentName.Enabled = false;
            this.btnSave.Enabled = false;            
            this.rbState.Enabled = false;
            this.lblEnter.Visible = false;  
        }
    }
    private void LoadSegmentData(int intCategoryID)
    {
        AdminABTBusinessSegmentBLL adBll = new AdminABTBusinessSegmentBLL();
        DataSet ds;

        ds = adBll.GetBusinessSegmentById(intCategoryID);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            txtSegmentName.Text = dr["SegmentName"].ToString().Trim();
            lblTimeChanged.Text = dr["Updated"].ToString().Trim();
            lblTimeCreated.Text = dr["Created"].ToString().Trim();
            lblCreator.Text = dr["CreatedBy"].ToString().Trim();
            lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
            rbState.SelectedValue = dr["State"].ToString();
            ds.Dispose();
            pnlHistory.Visible = true;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string strName = "";
        string strAbbreviation = "";
        int State = 1;
        AdminABTBusinessSegmentBLL da = new AdminABTBusinessSegmentBLL();
        try
        {
            if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                State = 1;
            else
                State = 0;

            strName = txtSegmentName.Text.Trim();
            da.UpdateBusinessSegment(BusinessSegmentID, strName, strAbbreviation, State, UserInfo.GetCurrentUserName().ToString());

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadbusinesssegment", "CloseBSEditPopup(true)", true);
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }    
}

