﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Admin.Areas
{
    public partial class ABTReport_Exclusion_ChangeHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            int intAreaID = 1;
            if (Request.QueryString["AreaID"] != null)
            {
                intAreaID = Convert.ToInt32(Request.QueryString["AreaID"]);
                hdnAreaID.Value = intAreaID.ToString();
            }

        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllExclusionHistory(int AreaID)
        {
            try
            {
                List<Dictionary<string, object>> dicNonSharedAVsList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicNonSharedAV = null;
                AdminProductBrandExclusionBLL da = new AdminProductBrandExclusionBLL();
                DataSet dsExclusionHistorylist = new DataSet();
                dsExclusionHistorylist = da.Admin_ViewABTReportExclusionHistory(AreaID);
                for (int i = 0; i < dsExclusionHistorylist.Tables[0].Rows.Count; i++)
                {
                    dicNonSharedAV = new Dictionary<string, object>();
                    dicNonSharedAV.Add("ChangeHistoryID", dsExclusionHistorylist.Tables[0].Rows[i]["ChangeHistoryID"].ToString());
                    dicNonSharedAV.Add("SCMName", dsExclusionHistorylist.Tables[0].Rows[i]["SCMName"].ToString());
                    dicNonSharedAV.Add("ChangeType", dsExclusionHistorylist.Tables[0].Rows[i]["ChangeType"].ToString());
                    dicNonSharedAV.Add("Created", dsExclusionHistorylist.Tables[0].Rows[i]["Created"].ToString());
                    dicNonSharedAV.Add("CreatedBy", dsExclusionHistorylist.Tables[0].Rows[i]["CreatedBy"].ToString());
                    dicNonSharedAVsList.Add(dicNonSharedAV);
                }
                return dicNonSharedAVsList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}
