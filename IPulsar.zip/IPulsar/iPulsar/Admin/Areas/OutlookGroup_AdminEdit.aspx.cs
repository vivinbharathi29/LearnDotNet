﻿using System;
using System.Data;
using System.Web.UI;

public partial class SystemAdmin_OutlookGroup_AdminEdit : System.Web.UI.Page
{
    int _ID;
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession(false);
        string mode;
        mode = Request.QueryString["mode"];
        _ID = Convert.ToInt32(Request.QueryString["ID"]);
        Authenticate.ValidateSession();
        // Put user code to initialize the page here

        if (!IsPostBack)
        {
            if ((mode == "update"))
            {
                GetOutlookGroup(_ID);
                Page.Title = "Modify Existing Outlook Groups";
                GetPermission();
            }
            else if (mode == "create")
            {
                Page.Title = "Add New Outlook Groups";
                pnlHistory.Visible = false;
            }
        }
    }
    private void GetOutlookGroup(int ID)
    {
        AdminScmxPcsPcrBLL da = new AdminScmxPcsPcrBLL();
        DataSet ds = new DataSet();
        ds = da.GetOutlookGroup(ID);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];

            txtDescription.Text = dr["Description"].ToString();
            txtEmail.Text = dr["Email"].ToString();
            lblTimeChanged.Text = dr["Updated"].ToString().Trim();
            lblTimeCreated.Text = dr["Created"].ToString().Trim();
            lblCreator.Text = dr["CreatedBy"].ToString().Trim();
            lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();

            ds.Dispose();
            pnlHistory.Visible = true;
        }  
    }

    private void GetPermission()
    {  
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SCMXEditor_Edit_Permission.ToString()))
        {
            Page.Title = "View Feature Category";

            //this.txtName.Enabled = false;
            this.btnSave.Enabled = false;
            this.lblEnter.Visible = false;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        AdminScmxPcsPcrBLL da = new AdminScmxPcsPcrBLL();
        try
        {
            UserInfo obj = new UserInfo();
            da.ModifyOutlookGroup(_ID, txtDescription.Text, txtEmail.Text, UserInfo.GetCurrentUserName().ToString());

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadoutlookgroupedit", "CloseEditPopup(true)", true);
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
}

