﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;

namespace iPulsar.Admin.Areas
{
    public partial class GoToMarket_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession();

            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "Go To Market (GTM)";
            Page.Title = "Go To Market (GTM)";

            gridPopulate();
            GetPermission();
        }

        private void gridPopulate()
        {
            try
            {
                DataSet ds;
                AdminGoToMarketBLL adBll = new AdminGoToMarketBLL();
                ds = adBll.GetGoToMarket(0);
                BindGridData(ds);
                lblError.Text = "";
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        private void BindGridData(DataSet ds)
        {
            wdgGoToMarket.Rows.Clear();
            wdgGoToMarket.DataSource = ds;
            wdgGoToMarket.DataBind();
        }
        protected void wdgGoToMarket_OnInitializeRow(object sender, RowEventArgs e)
        {
            string GoToMarketId = e.Row.DataKey[0].ToString();
            string sName = e.Row.Items.FindItemByKey("GTMName").Value.ToString();
            e.Row.Items.FindItemByKey("GTMName").Text = "<a onclick=\"return OpenEditPopUp('GoToMarket_Edit.aspx?mode=update&GoToMarketId=" + GoToMarketId + "');\">" + sName + "</a>";
        }
        private bool DeleteRecord()
        {
            bool b = false;
            int GoToMarketId = 0;
            GoToMarketId = Convert.ToInt32(hdnGoToMarketID.Value);
                if (!Authenticate.IsSessionExpired())
                {
                    AdminGoToMarketBLL avb = new AdminGoToMarketBLL();
                    avb.DeleteGoToMarket(GoToMarketId);
                    b = true;
                    //by setting it to null will trigger the grid to rebind with new data
                }

            return b;
        }
        private void GetPermission()
        {
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.GoToMarket_Edit_Permission.ToString()))
            {
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.GoToMarket_Delete_Permission.ToString()))
            {
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
            }
        }
        protected void btnDeleteGoToMarket_Click(object sender, EventArgs e)
        {
            try
            {
                DeleteRecord();
                gridPopulate();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        protected void btnRefeshGrid_Click(object sender, EventArgs e)
        {
            gridPopulate();
        }
    }
}