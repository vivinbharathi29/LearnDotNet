﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;
using System.Text;
using System.Web.Services;

namespace iPulsar.Admin.Areas
{
    public partial class UnlockSCMs_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession();

            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "Locked SCMs";
            Page.Title = "Unlock SCMs";
            hdnUserID.Value = UserInfo.GetCurrentUserID().ToString();
            if (!IsPostBack)
            {
                gridPopulate();
            }
        }
        private void gridPopulate()
        {
            try
            {
                ViewState["wdgUnlockSCMsSortDirection"] = "ASC";
                Session["UnlockSCMs"] = null;
                AdminUnlockSCMsBLL adBll = new AdminUnlockSCMsBLL();
                adBll.GetLockedSCMs(UserInfo.GetCurrentUserID());
                lblError.Text = "";
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        [WebMethod(EnableSession = true)]
        public static void UnlockSCMs(string strXML)
        {
            try
            {
                AdminUnlockSCMsBLL avb = new AdminUnlockSCMsBLL();
                avb.UnlockSCMs(strXML.ToString());
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        protected void btnRefeshGrid_Click(object sender, EventArgs e)
        {
            gridPopulate();
        }
        protected void wdgUnlockSCMs_ColumnSorted(object sender, SortingEventArgs e)
        {
            if (e.Column.Index == 0)
            {
                SortedColumnInfo column = e.SortedColumns[0];
                e.SortedColumns.Remove(column);
                GridField gf = wdgUnlockSCMs.Columns["AddState"];

                if (ViewState["wdgUnlockSCMsSortDirection"].ToString() == "ASC")
                {
                    e.SortedColumns.Add(gf, Infragistics.Web.UI.SortDirection.Descending);
                    ViewState["wdgUnlockSCMsSortDirection"] = "DESC";
                }
                else
                {
                    ViewState["wdgUnlockSCMsSortDirection"] = "ASC";
                    e.SortedColumns.Add(gf, Infragistics.Web.UI.SortDirection.Ascending);
                }
            }
            else
                wdgUnlockSCMs.Columns[0].Header.Text = "Sort";
        }

        [System.Web.Services.WebMethod]
        public static string SetLockedSCMAddState(int ID, int state)
        {
            /* On server side we can do any thing. Like we can access the Session.
             * We can do database access operation. Without postback.
             */
            try
            {
                AdminUnlockSCMsBLL obj = new AdminUnlockSCMsBLL();
                obj.SetLockedSCMAddState(ID, state);

                return state.ToString();
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}