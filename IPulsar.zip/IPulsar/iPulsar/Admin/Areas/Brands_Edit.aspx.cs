﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class Admin_Areas_Brands_Edit : System.Web.UI.Page
{
    int BrandID;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        string mode;
        mode = Request.QueryString["mode"];
        BrandID = Convert.ToInt32(Request.QueryString["BrandID"]);

        hdnBrandID.Text = BrandID.ToString();
               
        if (!IsPostBack)
        {
            GetBusinessSegments();
            if ((mode == "update"))
            {
                LoadBrandData(BrandID);

                Page.Title = "Modify Existing Brand";
                GetPermission();
            }
            else if (mode == "create")
            {
                Page.Title = "Add New Brand";
                pnlHistory.Visible = false;
                btnCreateFormula.Enabled = false;
            }
        }
    }
    private void GetBusinessSegments()
    {
       
        AdminBrandsBLL da = new AdminBrandsBLL();
        DataSet ds = new DataSet();
        ds = da.GetBusinessSegments();
        ddlBusinessSegment.DataSource = ds;
        ddlBusinessSegment.DataTextField = "Name";
        ddlBusinessSegment.DataValueField = "BusinessSegmentId";
        ddlBusinessSegment.DataBind();

        ddlBusinessSegment.Items.Insert(0, new ListItem(String.Empty, "0"));
        ddlBusinessSegment.SelectedIndex = 0;
    }
    private void LoadBrandData(int BrandID)
    {
        AdminBrandsBLL da = new AdminBrandsBLL();
        DataSet ds = new DataSet();
        ds = da.GetBrands(BrandID);
        rbState.SelectedValue = "0";
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            txtName.Text = dr["Name"].ToString();
            ddlBusinessSegment.SelectedValue = dr["BusinessSegmentID"].ToString().Trim();
            txtAbbreviation.Text = dr["Abbreviation"].ToString();
            txtRasSegment.Text = dr["RASSegment"].ToString();
            txtSuffix.Text = dr["Suffix"].ToString();
            txtStreetName1.Text = dr["StreetName"].ToString();

            txtStreetName2.Text = dr["StreetName2"].ToString();
            txtStreetName3.Text = dr["StreetName3"].ToString();
			
            if ((bool)dr["ShowSeriesNumberInLogoBadge"])
            {
                chkSeriesInLogoBadge.Checked = true;
            }
            if ((bool)dr["ShowSeriesNumberInBrandname"])
                chkSeriesInBrandName.Checked = true;
            lblTimeChanged.Text = dr["Updated"].ToString().Trim();
            lblTimeCreated.Text = dr["Created"].ToString().Trim();
            lblCreator.Text = dr["CreatedBy"].ToString().Trim();
            lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
            if ((bool)dr["Active"])
            {
                rbState.SelectedValue = "1";
            }
            if ((bool)dr["PowerCord"])
            {
                chkPowerCord.Checked = true;
            }
            if ((bool)dr["DuckheadPowerCord"])
            {
                chkDuckheadPowerCord.Checked = true;
            }
            if ((bool)dr["Duckhead"])
            {
                chkDuckhead.Checked = true;
            }
            ds.Dispose();
            pnlHistory.Visible = true;
        }  
    }
    private void GetPermission()
    {
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Brand_Edit_Permission.ToString()))
        {
            Page.Title = "View Brand";

            this.txtName.Enabled = false;
            this.ddlBusinessSegment.Enabled = false;
            this.txtAbbreviation.Enabled = false;
            this.txtRasSegment.Enabled = false;
            this.txtSuffix.Enabled = false;
            this.txtStreetName1.Enabled = false;
            this.txtStreetName2.Enabled = false;
            this.txtStreetName3.Enabled = false;
			this.chkSeriesInLogoBadge.Enabled = false;
            this.chkSeriesInBrandName.Enabled = false;
            this.lblEnter.Visible = false;
            this.rbState.Enabled = false;
            this.btnCreateFormula.Enabled = false;
            this.btnSave.Enabled = false;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        int intSetInactive = 0;
        int intSeriesInLogoBadge = 0;
        int intSeriesInBrandName = 0;
        int intPowerCord = 0;
        int intDuckheadPowerCord = 0;
        int intDuckhead = 0;
        AdminBrandsBLL da = new AdminBrandsBLL();
        try
        {
            if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                intSetInactive = 0;
            else
                intSetInactive = 1;

            if (chkSeriesInLogoBadge.Checked)
            {
                intSeriesInLogoBadge = 1;
            }

            if (chkSeriesInBrandName.Checked)
            {
                intSeriesInBrandName = 1;
            }

            if (chkPowerCord.Checked)
            {
                intPowerCord = 1;
            }

            if (chkDuckheadPowerCord.Checked)
            {
                intDuckheadPowerCord = 1;
            }

            if (chkDuckhead.Checked)
            {
                intDuckhead = 1;
            }

            da.ModifyBrand(BrandID, txtName.Text, Convert.ToInt32(ddlBusinessSegment.SelectedItem.Value), txtAbbreviation.Text, txtRasSegment.Text, txtSuffix.Text, txtStreetName1.Text, txtStreetName2.Text, txtStreetName3.Text, intSeriesInLogoBadge, intSeriesInBrandName, UserInfo.GetCurrentUserName(), intSetInactive , intPowerCord, intDuckheadPowerCord, intDuckhead);

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadpartneredit", "CloseEditPopup(true)", true);
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnRefreshFieldList_Click(object sender, EventArgs e)
    {
        int BrandId = 0;
        BrandId = Convert.ToInt32(hdnBrandID.Text.Trim());
    }   
}

