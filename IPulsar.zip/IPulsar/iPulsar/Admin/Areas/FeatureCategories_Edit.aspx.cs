﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Services;

public partial class Admin_Areas_FeatureCategory_Editt : System.Web.UI.Page
{
    int FeatureCategoryID;
    int LinkedComponentcategoryID = 0;
    string LinkedComponentcategoryName = "";
    int LinkedSCMcategoryID = 0;
    string LinkedSCMcategoryName = "";
    int LinkedPhwebcategoryID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        string mode;
        mode = Request.QueryString["mode"];
        FeatureCategoryID = Convert.ToInt32(Request.QueryString["CategoryID"]);
        hdnCategoryID.Value = FeatureCategoryID.ToString();
        if (!IsPostBack)
        {
            if ((mode == "update"))
            {
                LoadFeatureCategory(FeatureCategoryID);
                LoadPhWebCategory(LinkedPhwebcategoryID);
                Page.Title = "Modify Feature Category";
            }
            else if (mode == "create")
            {
                Page.Title = "Add New Feature Category";
                LoadPhWebCategory(0);
                pnlHistory.Visible = false;
            }
            FillComponentcategoryEditor();
            LoadFeatureClass();
            LoadNamingStandard(Convert.ToInt32(FeatureCategoryID)); //shraddha 9002
            LoadSCMCategory();
        }
        GetPermission();
    }

    private void GetPermission()
    {
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        //if (!Role.IsCurrentUserInRole(Enumeration.Enum_FeatureCategory_Role.FeatureCategory_Editor.ToString()))
        // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.FeatureCategory_Edit_Permission.ToString()))
        {
            Page.Title = "View Feature Category";

            this.ddlFeatureClass.Enabled = false;
            this.txtCategoryName.Enabled = false;
            this.btnSave.Enabled = false;
            this.rbState.Enabled = false;
            this.lblEnter.Visible = false;
            //shraddha 9002
            this.rlbAvailable.Enabled = false;
            this.rlbSelected.Enabled = false;
            //shraddha 9002
            this.DDLComponentCategory.Enabled = false;
        }
    }

    private void LoadFeatureClass()
    {
        AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
        DataSet dsFeatureClass = new DataSet();
        dsFeatureClass = da.GetAllFeatureClass();

        ddlFeatureClass.DataSource = dsFeatureClass;
        ddlFeatureClass.DataTextField = "Name";
        ddlFeatureClass.DataValueField = "FeatureClassId";
        ddlFeatureClass.DataBind();
    }
    //shraddha 9002
    private void LoadNamingStandard(int intCategoryID)
    {
        AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
        DataSet dsNamingStandard = new DataSet();
        try
        {
           
            bool bAlternativeNamingStandard_edit = false;
            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.AlternativeNamingStandard_Edit_Permission))
            {
                bAlternativeNamingStandard_edit = true;
            }
            dsNamingStandard = da.FeatureCategory_NamingStandardList(intCategoryID, true);
            dsNamingStandard.Tables[0].DefaultView.Sort = "Name Asc";
            dsNamingStandard.Tables[0].DefaultView.RowFilter = !bAlternativeNamingStandard_edit ? "Disabled is null" : "";
            rlbAvailable.DataSource = dsNamingStandard.Tables[0];
            rlbAvailable.DataTextField = "Name";
            rlbAvailable.DataValueField = "NamingStandardID";
            rlbAvailable.DataBind();

            if (dsNamingStandard.Tables[1] != null)
            {
                rlbSelected.DataSource = dsNamingStandard.Tables[1];
                rlbSelected.DataTextField = "Name";
                rlbSelected.DataValueField = "NamingStandardID";
                rlbSelected.DataBind();
            }

            DataView dvNamingStandard = dsNamingStandard.Tables[1].DefaultView;
            for (int i = 0; i < rlbSelected.Items.Count; i++)
            {
                dvNamingStandard.RowFilter = string.Format("NamingStandardId = {0} AND Disabled IS NOT NULL", rlbSelected.Items[i].Value);
                if (dvNamingStandard.Count > 0)
                {
                    rlbSelected.Items[i].Text = string.Format("{0}(Inactive)", rlbSelected.Items[i].Text);
                }               
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    //shraddha 9002

    private void LoadFeatureCategory(int FeatureCategoryID)
    {
        AdminFeatureCategoryBLL adBll = new AdminFeatureCategoryBLL();
        DataSet ds;

        ds = adBll.GetFeatureCategoryById(FeatureCategoryID);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];

            ddlFeatureClass.SelectedValue = dr["FeatureClassId"].ToString().Trim();

            lblTimeChanged.Text = dr["Updated"].ToString().Trim();
            lblTimeCreated.Text = dr["Created"].ToString().Trim();
            lblCreator.Text = dr["CreatedBy"].ToString().Trim();
            lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();

            rbState.SelectedValue = dr["State"].ToString();
            txtCategoryName.Text = dr["Name"].ToString();
            LinkedComponentcategoryID = Int32.Parse(dr["ComponentCategoryID"].ToString());
            LinkedComponentcategoryName = dr["Name"].ToString();

            LinkedSCMcategoryID = Int32.Parse(dr["SCMCategoryID"].ToString());
            LinkedSCMcategoryName = dr["SCMName"].ToString();
            LinkedPhwebcategoryID = Convert.ToInt32(dr["AMOPhwebcategoryID"].ToString());
            chkLTF.Checked = Convert.ToBoolean(dr["LongTermForecast"].ToString());
            chkLocalized.Checked = Convert.ToBoolean(dr["Localized"].ToString());
            chkMktUsage.Checked = Convert.ToBoolean(dr["MarketingUsage"].ToString());
            hdnActiveFeatureExists.Value = dr["ActiveFeatureExists"].ToString();
            hdnPrevState.Value = dr["State"].ToString();
            ds.Dispose();
            pnlHistory.Visible = true;
        }
    }

    private void LoadSCMCategory()
    {
        DataSet ds;
        AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
        try
        {
            ds = da.GetAllSCMCategory();
            DDLSCMCategory.DataSource = ds.Tables[0].DefaultView;
            DDLSCMCategory.DataBind();

            ListItem it1 = new ListItem();
            it1.Value = "0";
            it1.Text = "";
            DDLSCMCategory.Items.Insert(0, it1);

            DataRow dr = ds.Tables[0].Rows[0];
            string prevSCMCategory = "";
            prevSCMCategory = LinkedSCMcategoryID.ToString();
            if (DDLSCMCategory.Items.FindByValue(prevSCMCategory.ToString()) != null)
            {
                DDLSCMCategory.SelectedValue = LinkedSCMcategoryID.ToString();
            }
            else
            {
                ListItem it2 = new ListItem();
                it2.Value = LinkedSCMcategoryID.ToString().Trim();
                it2.Text = LinkedSCMcategoryName.ToString().Trim();
                DDLSCMCategory.Items.Insert(0, it2);
                it2.Selected = true;
            }

            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }


    }
    private void LoadPhWebCategory(int intLinkedPhwebcategoryID)
    {
        DataSet ds;
        AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
        try
        {
            ds = da.GetAllPhWebCategories();
            DataView dv;
            dv = ds.Tables[0].DefaultView;
            DDLPhWebCategory.DataSource = dv;
            DDLPhWebCategory.DataBind();

            ListItem it1 = new ListItem();
            it1.Value = "0";
            it1.Text = "";
            DDLPhWebCategory.Items.Insert(0, it1);

            DataRow dr = ds.Tables[0].Rows[0];
            string prevPhWebCategory = "";
            prevPhWebCategory = intLinkedPhwebcategoryID.ToString();
            if (DDLPhWebCategory.Items.FindByValue(prevPhWebCategory.ToString()) != null)
            {
                DDLPhWebCategory.SelectedValue = intLinkedPhwebcategoryID.ToString();
            }


            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        int featureClassID = 0;
        string featureName = "";
        int setInactive = 1;
        int selectedComponentCategoryID = 0;
        int LTF = 0;
        int SCMCategoryID = 0;
        int localized = 0;
        int mktUsage = 0;
        int linkedPhwebcategory = 0;

        AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
        try
        {
            featureClassID = Convert.ToInt32(ddlFeatureClass.SelectedItem.Value);
            selectedComponentCategoryID = Convert.ToInt32(DDLComponentCategory.SelectedItem.Value);
            featureName = txtCategoryName.Text.Trim();
            SCMCategoryID = Convert.ToInt32(DDLSCMCategory.SelectedValue);
            linkedPhwebcategory = Convert.ToInt32(DDLPhWebCategory.SelectedValue);
            //get the list of selected naming standard
            string selectedIDs = "";
            foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelected.Items)
            {
                selectedIDs += selectedItem.Value.Trim() + ",";
            }

            if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                setInactive = 0;
            else
                setInactive = 1;

            if (chkLTF.Checked)
                LTF = 1;

            if (chkLocalized.Checked)
                localized = 1;

            if (chkMktUsage.Checked)
                mktUsage = 1;

            FeatureCategoryID = da.UpdateFeatureCategory(FeatureCategoryID, featureClassID, featureName,
                UserInfo.GetCurrentUserName(), setInactive, selectedComponentCategoryID, LTF, localized, mktUsage, SCMCategoryID, linkedPhwebcategory);

            //save naming standard to different table
            if (selectedIDs.Trim().Length > 0)
            {
                selectedIDs = selectedIDs.Substring(0, selectedIDs.Trim().Length - 1);
            }
            da.FeatureCategory_NamingStandardModify(FeatureCategoryID, selectedIDs);

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadfeaturecategory", "CloseFCEditPopup(true)", true);

            //set it to null so parent list will reload after edit window is closed
            Session["FeatureCategoryList"] = null;
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }

    private void FillComponentcategoryEditor()
    {
        DataSet ds;
        AdminComponentCategoryBLL adBll = new AdminComponentCategoryBLL();
        try
        {
            ds = adBll.GetAllComponentCategory();
            DataView dv;
            dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "State = 'Active'";
            DDLComponentCategory.DataSource = dv;
            DDLComponentCategory.DataBind();

            ListItem it1 = new ListItem();
            it1.Value = "0";
            it1.Text = "";
            DDLComponentCategory.Items.Insert(0, it1);

            DataRow dr = ds.Tables[0].Rows[0];
            string prevComponentCategory = "";
            prevComponentCategory = LinkedComponentcategoryID.ToString();
            if (DDLComponentCategory.Items.FindByValue(prevComponentCategory.ToString()) != null)
            {
                DDLComponentCategory.SelectedValue = LinkedComponentcategoryID.ToString();
            }
            else
            {
                ListItem it2 = new ListItem();
                it2.Value = LinkedComponentcategoryID.ToString().Trim();
                it2.Text = LinkedComponentcategoryName.ToString().Trim();
                DDLComponentCategory.Items.Insert(0, it2);
                it2.Selected = true;
            }

            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }


    }

    // Add FeatureCategory and Component linkage table - task 20248
    [WebMethod]
    public static List<Dictionary<string, string>> GetLinkedComponentCategories(int FeatureCategoryID)
    {
        try
        {
            List<Dictionary<string, string>> lstLinkedNames = new List<Dictionary<string, string>>();

            DataSet ds = new DataSet();
            AdminFeatureCategoryBLL adBll = new AdminFeatureCategoryBLL();
            ds = adBll.GetLinkedComponentCategories(FeatureCategoryID);
            DataTable dt = new DataTable();
            dt = ds.Tables[0];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Dictionary<string, string> dc = new Dictionary<string, string>();
                dc.Add("ComponentCategoryID", dt.Rows[i]["ComponentCategoryId"].ToString());
                dc.Add("Information", dt.Rows[i]["Name"].ToString() + "|" + dt.Rows[i]["ComponentType"].ToString() + "|" + dt.Rows[i]["NamingStandards"].ToString() + "|" + dt.Rows[i]["State"].ToString());
                lstLinkedNames.Add(dc);
            }
            return lstLinkedNames;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}

