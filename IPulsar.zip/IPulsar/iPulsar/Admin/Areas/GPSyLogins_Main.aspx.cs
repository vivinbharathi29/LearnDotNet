﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;

public partial class Admin_GPSyLogins_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession();

        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "GPSy Login Names";
        Page.Title = "GPSy Login Names";

        if (!IsPostBack)
        {
            Session["GPSyLoginNameList"] = null;
            hdnCurrentUser.Value = UserInfo.GetCurrentUserName().ToString();
        }

        gridPopulate();
        GetPermission();
    }

    private void gridPopulate()
    {
        try
        {
            if (Session["GPSyLoginNameList"] == null)
            {
                DataSet ds;
                AdminGPSyNameBLL adBll = new AdminGPSyNameBLL();
                ds = adBll.ViewGPSyName(0);
                Session["GPSyLoginNameList"] = ds;
            }

            BindGridData();
            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void BindGridData()
    {
        DataSet ds;
        ds = (DataSet)Session["GPSyLoginNameList"];
        wdgGPSyLogin.Rows.Clear();
        wdgGPSyLogin.DataSource = ds;
        wdgGPSyLogin.DataBind();
    }
    private bool DeleteRecord()
    {
        bool b = false;
        int uID = 0;
        uID = Convert.ToInt32(hdnID.Value);
        string currentUser = hdnCurrentUser.Value;

        if (!Authenticate.IsSessionExpired())
        {
            AdminGPSyNameBLL adBll = new AdminGPSyNameBLL();
            adBll.DeleteGPSyName(currentUser, "", uID);
            b = true;
            //set to null so on postback it will rebind the grid with new data from database
            Session["GPSyLoginNameList"] = null;
        }

        return b;
    }
    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        //if (!Permission.IsCurrentUserHasPermission(Enumeration.Enum_System_Role.System_Admin.ToString()))
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.GPSyLoginName_Edit_Permission.ToString()))
        {
            Page.Title = "View GPSy Login Names";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.GPSyLoginName_Delete_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }
    protected void btnDeleteGPSy_Click(object sender, EventArgs e)
    {
        try
        {
            DeleteRecord();
            gridPopulate();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnRefeshGrid_Click(object sender, EventArgs e)
    {
        gridPopulate();
    }

    protected void wdgGPSyLogin_InitializeRow(object sender, RowEventArgs e)
    {
        string uID = e.Row.DataKey[0].ToString();
        string sName = e.Row.Items.FindItemByKey("UserName").Value.ToString();
        e.Row.Items.FindItemByKey("UserName").Text = "<a onclick=\"return OpenGPSyEditPopUp('GPSyLogins_Edit.aspx?mode=update&UserID=" + uID + "');\">" + sName + "</a>";
    }

}

