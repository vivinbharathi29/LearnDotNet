﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Services;

public partial class Admin_Areas_ComponentCategory_Edit : System.Web.UI.Page
{
    int ComponentCategoryID;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        string mode;
        mode = Request.QueryString["mode"];
        ComponentCategoryID = Convert.ToInt32(Request.QueryString["CategoryID"]);
        hdnCategoryID.Value = ComponentCategoryID.ToString();
        if (!IsPostBack)
        {
            LoadFeatureCategory();

            if ((mode == "update"))
            {
                LoadComponentCategory(ComponentCategoryID);
                Page.Title = "Modify Component Category";
            }
            else if (mode == "create")
            {
                Page.Title = "Add New Component Category";
                pnlHistory.Visible = false;
            }

            LoadComponentTypes();
            LoadNamingStandard(Convert.ToInt32(ComponentCategoryID));
            LoadOwners(Convert.ToInt32(ComponentCategoryID));
        }

        GetPermission();
    }
    private void GetPermission()
    {
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        //if (!Role.IsCurrentUserInRole(Enumeration.Enum_FeatureCategory_Role.FeatureCategory_Editor.ToString()))
        // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ComponentCategory_Edit_Permission.ToString()))
        {
            Page.Title = "View Component Category";

            this.ddlComponentType.Enabled = false;
            this.txtCategoryName.Enabled = false;
            this.btnSave.Enabled = false;
            this.rbState.Enabled = false;
            this.lblEnter.Visible = false;

            this.rlbAvailable.Enabled = false;
            this.rlbSelected.Enabled = false;

            this.rlbAvailableOwners.Enabled = false;
            this.rlbSelectedOwners.Enabled = false;

            this.ddlFeatureCategory.Enabled = false;
            this.btnUserSearch.Disabled = true;
        }
    }
    private void LoadComponentTypes()
    {
        AdminComponentCategoryBLL da = new AdminComponentCategoryBLL();
        DataSet dsComponentType = new DataSet();
        dsComponentType = da.GetAllComponentTypes();
        ddlComponentType.DataSource = dsComponentType;
        ddlComponentType.DataTextField = "Name";
        ddlComponentType.DataValueField = "ComponentTypeID";
        ddlComponentType.DataBind();
    }
    private void LoadNamingStandard(int intCategoryID)
    {
        AdminComponentCategoryBLL da = new AdminComponentCategoryBLL();
        DataSet dsNamingStandard = new DataSet();
        try
        {
            dsNamingStandard = da.ComponentCategory_NamingStandardList(intCategoryID, true);
            bool isAlternativeNamingStandardEditor = false;
            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.AlternativeNamingStandard_Edit_Permission))
            {
                isAlternativeNamingStandardEditor = true;
            }
            dsNamingStandard.Tables[0].DefaultView.RowFilter = !isAlternativeNamingStandardEditor ? "Disabled is null" : "";
            dsNamingStandard.Tables[0].DefaultView.Sort = "Name Asc";           
            rlbAvailable.DataSource = dsNamingStandard.Tables[0];
            rlbAvailable.DataTextField = "Name";
            rlbAvailable.DataValueField = "NamingStandardID";
            rlbAvailable.DataBind();

            if (dsNamingStandard.Tables[1] != null)
            {
                rlbSelected.DataSource = dsNamingStandard.Tables[1];
                rlbSelected.DataTextField = "Name";
                rlbSelected.DataValueField = "NamingStandardID";
                rlbSelected.DataBind();
            }

            DataView dvNamingStandard = dsNamingStandard.Tables[1].DefaultView;
            for (int i = 0; i < rlbSelected.Items.Count; i++)
            {
                dvNamingStandard.RowFilter = string.Format("NamingStandardId = {0} AND Disabled IS NOT NULL", rlbSelected.Items[i].Value);
                if (dvNamingStandard.Count > 0)
                {
                    rlbSelected.Items[i].Text = string.Format("{0}(Inactive)", rlbSelected.Items[i].Text);
                }
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void LoadOwners(int intCategoryID)
    {
        AdminComponentCategoryBLL da = new AdminComponentCategoryBLL();
        DataSet dsOwners = new DataSet();
        try
        {
            dsOwners = da.ComponentCategory_OwnersList(intCategoryID);
            dsOwners.Tables[0].DefaultView.Sort = "FullName Asc";
            rlbAvailableOwners.DataSource = dsOwners.Tables[0];
            rlbAvailableOwners.DataTextField = "FullName";
            rlbAvailableOwners.DataValueField = "UserID";
            rlbAvailableOwners.DataBind();

            if (dsOwners.Tables[1] != null)
            {
                rlbSelectedOwners.DataSource = dsOwners.Tables[1];
                rlbSelectedOwners.DataTextField = "FullName";
                rlbSelectedOwners.DataValueField = "UserID";
                rlbSelectedOwners.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void LoadFeatureCategory()
    {
        AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
        DataSet dsFeatureCategory = new DataSet();
        try
        {
            dsFeatureCategory = da.GetAllFeatureCategory();
            DataView dv;
            dv = dsFeatureCategory.Tables[0].DefaultView;
            dv.RowFilter = "State = 'Active'";
            ddlFeatureCategory.DataSource = dv;
            ddlFeatureCategory.DataTextField = "Name";
            ddlFeatureCategory.DataValueField = "FeatureCategoryId";
            ddlFeatureCategory.DataBind();


            ListItem it1 = new ListItem();
            it1.Value = "-1";
            it1.Text = "No linkage required";
            ddlFeatureCategory.Items.Insert(0, it1);

            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void LoadComponentCategory(int intCategoryID)
    {
        AdminComponentCategoryBLL adBll = new AdminComponentCategoryBLL();
        DataSet ds;

        ds = adBll.GetComponentCategoryByID(intCategoryID);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            ddlComponentType.SelectedValue = dr["ComponentTypeID"].ToString().Trim();
            string prevFeatCategory = "";
            prevFeatCategory = dr["FeatureCategoryID"].ToString().Trim();
            if (ddlFeatureCategory.Items.FindByValue(prevFeatCategory.ToString()) != null)
            {
                ddlFeatureCategory.SelectedValue = dr["FeatureCategoryID"].ToString().Trim();
            }
            else
            {
                ListItem it1 = new ListItem();
                it1.Value = dr["FeatureCategoryID"].ToString().Trim();
                it1.Text = dr["FeatureCategoryName"].ToString().Trim();
                ddlFeatureCategory.Items.Insert(0, it1);
                it1.Selected = true;
            };
            ddlFeatureCategory.SelectedValue = dr["FeatureCategoryID"].ToString().Trim();
            lblTimeChanged.Text = dr["Updated"].ToString().Trim();
            lblTimeCreated.Text = dr["Created"].ToString().Trim();
            lblCreator.Text = dr["CreatedBy"].ToString().Trim();
            lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
            chkInIRS.Checked = int.Parse(dr["ComponentTypeID"].ToString()) == 1 ? dr["InIRS"].ToString().Equals("1") : false;
            rbState.SelectedValue = dr["State"].ToString();
            txtCategoryName.Text = dr["Name"].ToString();
            if (dr["InIRS"].ToString().Equals("1"))
            {
                chkInIRS.Enabled = false;
            }
            ds.Dispose();
            pnlHistory.Visible = true;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        int intComponentType = 0;
        int intFeatureCategory = 0;
        string strName = "";
        int intSetInactive = 1;
        int intInIRS = 0;
        AdminComponentCategoryBLL da = new AdminComponentCategoryBLL();
        try
        {
            intComponentType = Convert.ToInt32(ddlComponentType.SelectedItem.Value);
            intFeatureCategory = Convert.ToInt32(ddlFeatureCategory.SelectedItem.Value);
            strName = txtCategoryName.Text.Trim();

            //get the list of selected naming standard
            string selectedIDs = "";
            foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelected.Items)
            {
                selectedIDs += selectedItem.Value.Trim() + ",";
            }

            //get the list of selected naming standard
            string selectedOwnerIDs = "";
            foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelectedOwners.Items)
            {
                selectedOwnerIDs += selectedItem.Value.Trim() + ",";
            }

            if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                intSetInactive = 0;
            else
                intSetInactive = 1;

            if (chkInIRS.Checked)
                intInIRS = 1;

            UserInfo obj = new UserInfo();
            ComponentCategoryID = da.UpdateComponentCategory(ComponentCategoryID, intComponentType, strName, UserInfo.GetCurrentUserName().ToString(), intSetInactive, intFeatureCategory, intInIRS);

            //save naming standard to different table
            if (selectedIDs.Trim().Length > 0)
            {
                selectedIDs = selectedIDs.Substring(0, selectedIDs.Trim().Length - 1);
            }
            da.ComponentCategory_NamingStandardModify(ComponentCategoryID, selectedIDs);

            //save owners to different table
            if (selectedOwnerIDs.Trim().Length > 0)
            {
                selectedOwnerIDs = selectedOwnerIDs.Substring(0, selectedOwnerIDs.Trim().Length - 1);
            }
            da.ComponentCategory_OwnersModify(ComponentCategoryID, selectedOwnerIDs, UserInfo.GetCurrentUserName().ToString());

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadcomponentcategory", "CloseCCEditPopup(true)", true);

            //set it to null so parent list will reload after edit window is closed
            Session["ComponentCategoryList"] = null;
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }

    // Add ComponentCategory and feature linkage table - task 20249

    [WebMethod]
    public static List<Dictionary<string, string>> GetLinkedFeatureCategories(int ComponentCategoryID)
    {
        try
        {
            List<Dictionary<string, string>> lstLinkedNames = new List<Dictionary<string, string>>();

            DataSet ds = new DataSet();
            AdminComponentCategoryBLL adBll = new AdminComponentCategoryBLL();
            ds = adBll.GetLinkedFeatureCategories(ComponentCategoryID);
            DataTable dt = new DataTable();
            dt = ds.Tables[0];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Dictionary<string, string> dc = new Dictionary<string, string>();
                dc.Add("FeatureCategoryID", dt.Rows[i]["FeatureCategoryId"].ToString());
                dc.Add("Information", dt.Rows[i]["Name"].ToString() + "|" + dt.Rows[i]["FeatureClass"].ToString() + "|" + dt.Rows[i]["NamingStandards"].ToString() + "|" + dt.Rows[i]["State"].ToString());
                lstLinkedNames.Add(dc);
            }
            return lstLinkedNames;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}

