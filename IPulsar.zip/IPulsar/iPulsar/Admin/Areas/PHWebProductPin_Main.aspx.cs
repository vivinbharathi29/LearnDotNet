﻿using iPulsar.Old_App_Code.BLL.Admin;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.Areas
{
    public partial class PHWebProductPin_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession();

            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "PHweb Product Pin";
            Page.Title = "PHweb Product Pin";
            if (!IsPostBack)
            {
                hdnUser.Value = UserInfo.GetCurrentUserName().ToString();
            }            
        }        

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> FillGrid()
        {
            try
            {
                List<Dictionary<string, object>> dictList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dict = null;
                PHWebProductPinBLL objBLL = new PHWebProductPinBLL();
                DataSet ds = new DataSet();

                ds = objBLL.GetPHWebProductPinList();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dict = new Dictionary<string, object>();
                    dict.Add("ID", ds.Tables[0].Rows[i]["ID"].ToString());
                    dict.Add("ProductLine", ds.Tables[0].Rows[i]["ProductLineName"].ToString());
                    dict.Add("SCMCategory", ds.Tables[0].Rows[i]["SCMCategoryName"].ToString());
                    dict.Add("ProductPin", ds.Tables[0].Rows[i]["ProductPin"].ToString());

                    dictList.Add(dict);
                }
                return dictList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}