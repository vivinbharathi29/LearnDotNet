﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;
using iPulsar.Old_App_Code.BLL.Admin;
using System.Web.Services;

namespace iPulsar.Admin.Areas
{
    public partial class OperatingSystems_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession();

            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "Operating Systems";
            Page.Title = "Operating Systems";

            GetPermission();
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.OperatingSystems_Edit_Permission.ToString()))
            {
                Page.Title = "View Operating Systems List";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";

                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;

            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.OperatingSystems_Delete_Permission.ToString()))
            {
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
                txtDeleteRight.Value = "0";
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetOSList()
        {
            try
            {
                List<Dictionary<string, object>> dictList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dict = null;
                AdminOperatingSystemsBLL da = new AdminOperatingSystemsBLL();
                DataSet ds = new DataSet();

                ds = da.GetAllOS();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dict = new Dictionary<string, object>();
                    dict.Add("ID", ds.Tables[0].Rows[i]["ID"].ToString());
                    dict.Add("Name", ds.Tables[0].Rows[i]["Name"].ToString());
                    dict.Add("OfficialName", ds.Tables[0].Rows[i]["OfficialName"].ToString());
                    dict.Add("CVAKey", ds.Tables[0].Rows[i]["CVAKey"].ToString());
                    dict.Add("State", ds.Tables[0].Rows[i]["State"].ToString());
                    dict.Add("FamilyName", ds.Tables[0].Rows[i]["FamilyName"].ToString());
                    dict.Add("Components", ds.Tables[0].Rows[i]["Components"].ToString());
                    dict.Add("SupplyChain", ds.Tables[0].Rows[i]["SupplyChain"].ToString());
                    dict.Add("bUsedinComp", ds.Tables[0].Rows[i]["bUsedinComp"].ToString());
                    dictList.Add(dict);
                }
                return dictList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static string RemoveOperatingSystem(int intOSID)
        {
            string strReturnMsg = "Operating System successfully removed.";
            try
            {
                AdminOperatingSystemsBLL da = new AdminOperatingSystemsBLL();
                da.DeleteOperatingSystem(intOSID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }
    }
}