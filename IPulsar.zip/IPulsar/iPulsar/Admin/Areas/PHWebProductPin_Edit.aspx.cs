﻿using iPulsar.Old_App_Code.BLL.Admin;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.Areas
{
    public partial class PHWebProductPin_Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession(false);

            string mode;
            mode = Request.QueryString["mode"];

            if (!IsPostBack)
            {
                int ID = Convert.ToInt32(Request.QueryString["ID"]);

                if ((mode == "update"))
                {
                    LoadPHWebProductPin(ID);
                    Page.Title = "Modify Existing PHweb Product Pin";                   
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New PHweb Product Pin";
                    pnlHistory.Visible = false;
                }
            }
            GetPermission();
        }


        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.PHwebProductPin_Edit_Permission.ToString()))
            {
                Page.Title = "PHweb Product Pin";
                this.txtProductPin.Enabled = false;
                btnSave.Enabled = false;
            }
        }

        private void LoadPHWebProductPin(int ID)
        {
            PHWebProductPinBLL da = new PHWebProductPinBLL();
            DataSet ds;
            ds = da.GetSelectedPHWebProductPin(ID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                
                lblProductLine.Text = dr["ProductLineName"].ToString();
                lblSCMCategory.Text = dr["SCMCategoryName"].ToString();
                txtProductPin.Text = dr["ProductPin"].ToString();
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
              
                ds.Dispose();
                pnlHistory.Visible = true;

            }

        }             

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strProductPin = "";
            int intId = 0;
            PHWebProductPinBLL da = new PHWebProductPinBLL();
            try
            {
                strProductPin = txtProductPin.Text.ToString();

                if (Request.QueryString["ID"] != null)
                {
                    intId = Convert.ToInt32(Request.QueryString["ID"].ToString());
                }
                else
                {
                    intId = -1;
                }

                intId = da.UpdatePHWebProductPin(intId, strProductPin, UserInfo.GetCurrentUserName());

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadODMBOM", "CloseEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }

        }
    }
}