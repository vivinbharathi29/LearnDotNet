﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class RegionSettingsAdmin_Edit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();

        Page.Title = "Add New Business Segment";
        GetPermission();
        GetUnusedBusinessSegments();
    }
    private void GetUnusedBusinessSegments()
    {
        try
        {
            AdminRegionSettingsAdminBLL da = new AdminRegionSettingsAdminBLL();
            DataSet ds = da.GetUnusedBusinessSegments();
            if (ds.Tables[0].Rows.Count == 0)
            {
                lblError.Text = "All Business Segments have been selected";
                btnSave.Enabled = false;
                lblError.Visible = true;
            }
            else
            {
                rlbAvailable.DataSource = ds.Tables[0];
                rlbAvailable.DataTextField = "Name";
                rlbAvailable.DataValueField = "BusinessSegmentID";
                rlbAvailable.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblError.Visible = true;
            lblError.Text = ex.Message;
        }
    }
    private void GetPermission()
    {
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.RegionSettings_Edit_Permission.ToString()))
        {
            Page.Title = "View Business Segment";
            this.btnSave.Enabled = false;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            string selectedIDs = "";
            foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelected.Items)
            {
                selectedIDs += selectedItem.Value.Trim() + ",";
            }
            if (selectedIDs.Trim().Length > 0)
                selectedIDs = selectedIDs.Substring(0, selectedIDs.Length - 1);

            AdminRegionSettingsAdminBLL da = new AdminRegionSettingsAdminBLL();
            da.AddBusinessSegment(selectedIDs, UserInfo.GetCurrentUserName());

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadregionsettings", "CloseEditPopup(true)", true);
        }
        catch (Exception ex)
        {
            lblError.Visible = true;
            lblError.Text = ex.Message;
        }
    }
}
