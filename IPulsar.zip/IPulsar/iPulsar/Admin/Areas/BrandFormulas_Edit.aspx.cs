﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Areas_BrandFormulas_Edit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        if (!IsPostBack)
        {
            hdnBrandID.Value = Request.QueryString.Get("BrandID").ToString();
            GetPermission();
            LoadBrandFormulaName();
            GetAllBrands();
        }
    }
    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if ((!Permission.IsCurrentUserHasPermission(Resources.Permissions.NamingStandard_Edit_Permission.ToString()))
            && (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Brand_Edit_Permission.ToString())))
        // allow a user with Brand edit permission to edit the create formulas
        {

            Page.Title = "View Brand Formula";
            DisableControls();

        }
    }
    private void DisableControls()
    {
        btnSave.Enabled = false;
        lnkImportBrandFormula.Disabled = true;
        lnkImportBrandFormula.Attributes["Class"] = "disabled";
        hdnCanEdit.Value = "0";

    }
    private void LoadBrandFormulaName()
    {
        DataSet ds = new DataSet();
        try
        {
            AdminBrandsBLL da = new AdminBrandsBLL();
            ds = da.GetAllBrandFormulaName(Int32.Parse(hdnBrandID.Value));
            ddlBrandFormulaName.DataSource = ds;
            ddlBrandFormulaName.DataTextField = "Name";
            ddlBrandFormulaName.DataValueField = "BrandFormulaNameID";
            ddlBrandFormulaName.DataBind();

            ddlBrandFormulaName.Items.Insert(0, new ListItem("Select a formula name", "0"));
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }

    private void GetAllBrands()
    {
        AdminBrandsBLL da = new AdminBrandsBLL();
        DataSet dsBrands = new DataSet();
        dsBrands = da.GetAllBrandsWithFormula();

        ddlBrand.DataSource = dsBrands;
        ddlBrand.DataTextField = "Name";
        ddlBrand.DataValueField = "ID";
        ddlBrand.DataBind();

        if (ddlBrand.Items.FindByValue(hdnBrandID.Value) != null)
            ddlBrand.SelectedValue = hdnBrandID.Value;

    }
    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetAllBrandsWithFormula()
    {
        try
        {
            AdminBrandsBLL da = new AdminBrandsBLL();
            DataSet ds = da.GetAllBrandsWithFormula();

            List<Dictionary<string, string>> lstBrands = new List<Dictionary<string, string>>();
            Dictionary<string, string> dicBrands = null;
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                dicBrands = new Dictionary<string, string>();
                dicBrands.Add("BrandID", ds.Tables[0].Rows[i]["ID"].ToString());
                dicBrands.Add("BrandName", ds.Tables[0].Rows[i]["Name"].ToString());

                lstBrands.Add(dicBrands);
            }
            return lstBrands;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetAllBrandFormulaNames(int intBrandID)
    {
        try
        {
            AdminBrandsBLL da = new AdminBrandsBLL();
            DataSet ds = da.GetAllBrandFormulaName(intBrandID);

            List<Dictionary<string, string>> lstBrandFormulaName = new List<Dictionary<string, string>>();
            Dictionary<string, string> dicBrandFormulaName = null;
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                dicBrandFormulaName = new Dictionary<string, string>();
                dicBrandFormulaName.Add("BrandFormulaNameID", ds.Tables[0].Rows[i]["BrandFormulaNameID"].ToString());
                dicBrandFormulaName.Add("BrandFormulaName", ds.Tables[0].Rows[i]["Name"].ToString());

                lstBrandFormulaName.Add(dicBrandFormulaName);
            }
            return lstBrandFormulaName;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetBrandFields(int BrandID, int BrandFormulaNameID, int whichList, int ImportToBrandFormulaNameID)
    {
        try
        {
            AdminBrandsBLL da = new AdminBrandsBLL();
            DataSet ds = da.GetBrandFieldsByFormulaNameID(BrandID, BrandFormulaNameID, ImportToBrandFormulaNameID);

            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> Dictionary = null;

            for (int i = 0; i < ds.Tables[whichList].Rows.Count; i++)
            {
                Dictionary = new Dictionary<string, string>();
                Dictionary.Add("FieldID", ds.Tables[whichList].Rows[i]["FieldID"].ToString());
                Dictionary.Add("FieldValues", ds.Tables[whichList].Rows[i]["FixedLengthFieldName"] + Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["FieldType"].ToString() + Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["Required"].ToString() +
                                                Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["FieldColumns"].ToString() + Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["FieldText"].ToString() +
                                                Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["BrandFormulaID"].ToString() + Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["ColumnNumber"].ToString() +
                                                Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["AddSpace"].ToString());
                rows.Add(Dictionary);
            }

            if (whichList == 0)
            {
                Dictionary = new Dictionary<string, string>();
                Dictionary.Add("FieldID", "0");
                Dictionary.Add("FieldValues", "Text to add to formula" + Char.ConvertFromUtf32(3) + "Text box field" + Char.ConvertFromUtf32(3) + "No" + Char.ConvertFromUtf32(3) + "");
                rows.Add(Dictionary);
            }
            return rows;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static void SaveBrandFormula(int intBrandFormulaNameID, int intBrandID, string strFieldList)
    {
        try
        {
            AdminBrandsBLL da = new AdminBrandsBLL();
            da.SaveFormula(intBrandFormulaNameID, intBrandID, strFieldList, UserInfo.GetCurrentUserName());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetBrandFormulaNameByBrandID(int intBrandID)
    {
        try
        {
            AdminBrandsBLL da = new AdminBrandsBLL();

            DataSet dsBrandFormulaName = da.GetAllFormulaNameByBrandID(intBrandID);

            List<Dictionary<string, string>> lstBrandFormulaName = new List<Dictionary<string, string>>();

            for (int i = 0; i < dsBrandFormulaName.Tables[0].Rows.Count; i++)
            {
                Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                Dictionary.Add("BrandFormulaNameID", dsBrandFormulaName.Tables[0].Rows[i]["BrandFormulaNameID"].ToString());
                Dictionary.Add("BrandFormulaName", dsBrandFormulaName.Tables[0].Rows[i]["Name"].ToString());
                lstBrandFormulaName.Add(Dictionary);
            }
            return lstBrandFormulaName;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod]
    public static string GetDropDownValueByColumnNumber(int BrandID, int intFieldID, int intColumnNumber)
    {
        try
        {
            string strDDValue = "";
            AdminBrandsBLL da = new AdminBrandsBLL();
            DataSet dsList = da.GetBrands(BrandID);

            switch (intColumnNumber)
            {
                case 1:
                    strDDValue = dsList.Tables[0].Rows[0]["StreetName"].ToString() + ":40";
                    break;
                case 2:
                    strDDValue = dsList.Tables[0].Rows[0]["StreetName2"].ToString() + ":40";
                    break;
                case 3:
                    strDDValue = dsList.Tables[0].Rows[0]["StreetName3"].ToString() + ":40";
                    break;
            }
            return strDDValue;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod]
    public static int GetMaximumTextLength(int intFieldID)
    {
        try
        {
            return 40;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod]
    public static string ImportBrandFormula(int intImportFromBrandID, int intImportToBrandID, int intImportToFormulaNameID, string strImportFromFormulaNameIDs)
    {
        try
        {
            string strMsg = "Formula imported successfully.";
            try
            {
                AdminBrandsBLL da = new AdminBrandsBLL();
                da.ImportBrandFormula(intImportFromBrandID, intImportToBrandID, intImportToFormulaNameID, strImportFromFormulaNameIDs, UserInfo.GetCurrentUserName());
            }
            catch (Exception ex)
            {
                strMsg = ex.Message;
            }
            return strMsg;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}