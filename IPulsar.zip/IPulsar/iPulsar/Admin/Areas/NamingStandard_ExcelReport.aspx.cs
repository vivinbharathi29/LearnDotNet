﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Documents.Excel;

namespace iPulsar.Admin.Areas
{
    public partial class NamingStandard_ExcelReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession(false);
            int intNamingStandardID = 0;
            if (Request.QueryString["NamingStandardID"] != null)
                intNamingStandardID = Convert.ToInt32(Request.QueryString["NamingStandardID"]);
            GetReportData(intNamingStandardID);
        }

        private void GetReportData(int intNamingStandardID)
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            DataSet dsNamingStandardFieldsAndFormulas = da.GetNamingStandardFieldsAndFormulas(intNamingStandardID);

            string strNSName = "";
            strNSName = dsNamingStandardFieldsAndFormulas.Tables[0].Rows[0]["Name"].ToString();
            DataTable dtNamingStandardFields = new DataTable();
            dtNamingStandardFields = dsNamingStandardFieldsAndFormulas.Tables[1];
            DataTable dtFormula = new DataTable();
            dtFormula = dsNamingStandardFieldsAndFormulas.Tables[2];

            DataTable dtDropDownValues = new DataTable();
            dtDropDownValues = dsNamingStandardFieldsAndFormulas.Tables[3];

            CreateExcelReport(strNSName, dtNamingStandardFields, dtFormula, dtDropDownValues);
        }

        private void CreateExcelReport(string strName, DataTable dtNamingStandardFields, DataTable dtFormula, DataTable dtDropDownValues)
        {
            Workbook wbNSReport = new Workbook(WorkbookFormat.Excel2007);
            //specify the default font family
            Infragistics.Documents.Excel.IWorkbookFont defaultFont = wbNSReport.Styles.NormalStyle.StyleFormat.Font;
            defaultFont.Name = "Arial";
            defaultFont.Height = 9 * 20;

            Worksheet wsNSReport = wbNSReport.Worksheets.Add("Naming Standard Report");

            int intRowIndex = 0, intColumnIndex = 0, intFieldID = 0;
            //add the headers for the naming standard fields
            wsNSReport.Rows[intRowIndex].Height = Convert.ToInt32(20 * 20.0);
            for (int i = 1; i < dtNamingStandardFields.Columns.Count; i++)
            {
                wsNSReport.Rows[intRowIndex].Cells[intColumnIndex].Value = dtNamingStandardFields.Columns[i].Caption;
                wsNSReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.Alignment = HorizontalCellAlignment.Center;
                wsNSReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsNSReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#5B9BD5"));
                //format the width if the columns
                if (dtNamingStandardFields.Columns[i].Caption == "Field Name")
                    wsNSReport.Columns[intColumnIndex].SetWidth(200, WorksheetColumnWidthUnit.Point);
                else if (dtNamingStandardFields.Columns[i].Caption == "Field Type")
                    wsNSReport.Columns[intColumnIndex].SetWidth(150, WorksheetColumnWidthUnit.Point);
                else if (dtNamingStandardFields.Columns[i].Caption == "Text Length")
                    wsNSReport.Columns[intColumnIndex].SetWidth(100, WorksheetColumnWidthUnit.Point);
                else if (dtNamingStandardFields.Columns[i].Caption == "Required")
                    wsNSReport.Columns[intColumnIndex].SetWidth(75, WorksheetColumnWidthUnit.Point);
                else if (dtNamingStandardFields.Columns[i].Caption.IndexOf("Use") > -1)
                    wsNSReport.Columns[intColumnIndex].SetWidth(100, WorksheetColumnWidthUnit.Point);
                else if (dtNamingStandardFields.Columns[i].Caption == "Instructions")
                    wsNSReport.Columns[intColumnIndex].SetWidth(100, WorksheetColumnWidthUnit.Point);
                intColumnIndex++;
            }
            //add columns for the DropDownValues
            for (int i = 1; i < dtDropDownValues.Columns.Count - 1; i++)
            {
                wsNSReport.Rows[intRowIndex].Cells[intColumnIndex].Value = dtDropDownValues.Columns[i].Caption;
                wsNSReport.Columns[intColumnIndex].SetWidth(180, WorksheetColumnWidthUnit.Point);
                wsNSReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.Alignment = HorizontalCellAlignment.Center;
                wsNSReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsNSReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#5B9BD5"));
                intColumnIndex++;
            }
            intRowIndex++;
            //add rows to the naming standard field 
            string strDropDownValues = "";
            for (int i = 0; i < dtNamingStandardFields.Rows.Count; i++)
            {
                wsNSReport.Rows[intRowIndex].Height = Convert.ToInt32(15.75 * 20.0);
                intFieldID = Convert.ToInt32(dtNamingStandardFields.Rows[i]["FieldID"].ToString());
                wsNSReport.Rows[intRowIndex].Cells[0].Value = dtNamingStandardFields.Rows[i]["Field Name"].ToString();
                wsNSReport.Rows[intRowIndex].Cells[1].Value = dtNamingStandardFields.Rows[i]["Field Type"].ToString();
                wsNSReport.Rows[intRowIndex].Cells[2].Value = Convert.ToInt32(dtNamingStandardFields.Rows[i]["Text Length"]) == 0 ? "" : dtNamingStandardFields.Rows[i]["Text Length"].ToString();
                wsNSReport.Rows[intRowIndex].Cells[3].Value = dtNamingStandardFields.Rows[i]["Required"].ToString();
                wsNSReport.Rows[intRowIndex].Cells[4].Value = dtNamingStandardFields.Rows[i]["Use In Root"].ToString();
                wsNSReport.Rows[intRowIndex].Cells[5].Value = dtNamingStandardFields.Rows[i]["Use In Feature"].ToString();
                wsNSReport.Rows[intRowIndex].Cells[6].Value = dtNamingStandardFields.Rows[i]["Instructions"].ToString();
                DataRow[] drDDValues = dtDropDownValues.Select("FieldID = " + intFieldID, "RowNumber");
                for (int ddColumns = 1; ddColumns < dtDropDownValues.Columns.Count - 1; ddColumns++)
                {
                    strDropDownValues = "";
                    for (int ddRows = 0; ddRows < drDDValues.Length; ddRows++)
                    {
                        strDropDownValues = strDropDownValues == "" ? drDDValues[ddRows][ddColumns].ToString() : strDropDownValues + ", " + drDDValues[ddRows][ddColumns].ToString();
                    }
                    wsNSReport.Rows[intRowIndex].Cells[6 + ddColumns].Value = strDropDownValues;
                    wsNSReport.Rows[intRowIndex].Cells[6 + ddColumns].CellFormat.LeftBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));
                    wsNSReport.Rows[intRowIndex].Cells[6 + ddColumns].CellFormat.BottomBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));
                }

                for (int formatindex = 0; formatindex < 6 + dtDropDownValues.Columns.Count - 1; formatindex++)
                {
                    if (i % 2 != 0)
                    {
                        wsNSReport.Rows[intRowIndex].Cells[formatindex].CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#DDEBF7"));
                    }
                    wsNSReport.Rows[intRowIndex].Cells[formatindex].CellFormat.LeftBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));
                    wsNSReport.Rows[intRowIndex].Cells[formatindex].CellFormat.BottomBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));
                }

                intRowIndex++;
            }

            intRowIndex++;
            //add header for Fromula
            wsNSReport.Rows[intRowIndex].Height = Convert.ToInt32(40 * 20.0);
            wsNSReport.Rows[intRowIndex].Cells[0].CellFormat.Font.Height = 20 * 20;
            wsNSReport.Rows[intRowIndex].Cells[0].Value = "Formula";
            wsNSReport.Rows[intRowIndex].Cells[0].CellFormat.Font.Bold = ExcelDefaultableBoolean.True;

            intRowIndex++;
            wsNSReport.Rows[intRowIndex].Height = Convert.ToInt32(20 * 20.0);
            //add header for Fromula table
            wsNSReport.Rows[intRowIndex].CellFormat.Alignment = HorizontalCellAlignment.Center;
            wsNSReport.Rows[intRowIndex].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;

            wsNSReport.Rows[intRowIndex].Cells[0].Value = "Name";
            wsNSReport.Rows[intRowIndex].Cells[0].CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#5B9BD5"));

            WorksheetMergedCellsRegion mergedHeaderCell1;
            mergedHeaderCell1 = wsNSReport.MergedCellsRegions.Add(intRowIndex, 1, intRowIndex, 3);
            mergedHeaderCell1.Value = "Syntax";
            mergedHeaderCell1.CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#5B9BD5"));

            WorksheetMergedCellsRegion mergedHeaderCell2;
            mergedHeaderCell2 = wsNSReport.MergedCellsRegions.Add(intRowIndex, 4, intRowIndex, 6);
            mergedHeaderCell2.Value = "Example";
            mergedHeaderCell2.CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#5B9BD5"));

            intRowIndex++;
            for (int i = 0; i < dtFormula.Rows.Count; i++)
            {
                wsNSReport.Rows[intRowIndex].Height = Convert.ToInt32(15.75 * 20.0);

                wsNSReport.Rows[intRowIndex].Cells[0].Value = dtFormula.Rows[i]["Name"].ToString();
                wsNSReport.Rows[intRowIndex].Cells[0].CellFormat.LeftBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));
                wsNSReport.Rows[intRowIndex].Cells[0].CellFormat.BottomBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));

                WorksheetMergedCellsRegion mergedCell;
                mergedCell = wsNSReport.MergedCellsRegions.Add(intRowIndex, 1, intRowIndex, 3);
                mergedCell.Value = dtFormula.Rows[i]["Syntax"].ToString();
                mergedCell.CellFormat.BottomBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));
                mergedCell.CellFormat.LeftBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));

                WorksheetMergedCellsRegion mergedCell1;
                mergedCell1 = wsNSReport.MergedCellsRegions.Add(intRowIndex, 4, intRowIndex, 6);
                mergedCell1.Value = dtFormula.Rows[i]["Example"].ToString();
                mergedCell1.CellFormat.BottomBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));
                mergedCell1.CellFormat.LeftBorderColorInfo = new WorkbookColorInfo(System.Drawing.ColorTranslator.FromHtml("#000000"));

                if (i % 2 != 0)
                {
                    wsNSReport.Rows[intRowIndex].Cells[0].CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#DDEBF7"));
                    mergedCell.CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#DDEBF7"));
                    mergedCell1.CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#DDEBF7"));
                }
                intRowIndex++;
            }

            //save the excel report
            Response.Clear();
            Response.AppendHeader("content-disposition", "attachment; filename= " + strName + ".xlsx");
            Response.ContentType = "application/octet-stream";
            wbNSReport.Save(Response.OutputStream);
            Response.End();
        }
    }
}