﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;

public partial class Admin_Areas_NamingStandardFormula_DropDownValues : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        int intFieldID = 0;
        if (Request.QueryString.Get("FieldID") != null)
            intFieldID = Convert.ToInt32(Request.QueryString.Get("FieldID"));

        GetDropDownValues(intFieldID);
        
    }
    private void GetDropDownValues(int intFieldID)
    {
        //get from the database
        AdminNamingStandardBAL da = new AdminNamingStandardBAL();
        DataSet dsDropDownValues = new DataSet();
        DataTable dtDropDownValues = new DataTable();
        dsDropDownValues = da.GetNamingStandardFieldByFieldID(intFieldID);
        dtDropDownValues = dsDropDownValues.Tables[1];
        lblFieldName.Text = dsDropDownValues.Tables[0].Rows[0]["FieldName"].ToString();
        string strColName = "";
        if (dtDropDownValues.Rows.Count > 0)
        {
            //Yong added this comment: the sp added one more column in front so start i=3 here:
            for (int i = 2; i < dtDropDownValues.Columns.Count; i++)
            {
                //create datacolumn for the grid                
                //if (dtDropDownValues.Columns[i].ColumnName == "1")
                //    strColName = "Display Name " + char.ConvertFromUtf32(64 + Convert.ToInt32(dtDropDownValues.Columns[i].ColumnName));
                //else
                if (i == 2)
                    strColName = "State";
                else
                    strColName = dtDropDownValues.Columns[i].ColumnName.Split('|')[4];
                // strColName = char.ConvertFromUtf32(64 + Convert.ToInt32(dtDropDownValues.Columns[i].ColumnName.Split('|')[0]));

                AddNewGridColumn(strColName, dtDropDownValues.Columns[i].ColumnName, 100);
            }
            //Add a status column
            DataTable dt = new DataTable();
            BindDropDownGrid(dtDropDownValues);
        }
    }
    private void AddNewGridColumn(string strColumnName, string strKey, int intWidth)
    {
        Infragistics.Web.UI.GridControls.UnboundField newcolumn = new Infragistics.Web.UI.GridControls.UnboundField();
        newcolumn.Header.Text = strColumnName;
        newcolumn.Key = strKey;
        newcolumn.Width = Unit.Pixel(intWidth);
        wdgDropDownValues.Columns.Insert(wdgDropDownValues.Columns.Count, newcolumn);
    }
    private void BindDropDownGrid(DataTable dtDropDownValues)
    {
        wdgDropDownValues.DataSource = dtDropDownValues;
        wdgDropDownValues.DataBind();
    }
}