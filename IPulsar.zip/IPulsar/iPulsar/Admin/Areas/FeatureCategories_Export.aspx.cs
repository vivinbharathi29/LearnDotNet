﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Documents.Excel;

namespace iPulsar.Admin.Areas
{
    public partial class FeatureCategories_Export : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            CreateWorksheetData();
        }
        private void CreateWorksheetData()
        {
            AdminFeatureCategoryBLL adBll = new AdminFeatureCategoryBLL();
            DataSet ds = new DataSet();
            ds = adBll.GetAllFeatureCategory();

            int intRowIndex = 0, intColIndex = 0;

            Workbook wbExport = new Workbook(WorkbookFormat.Excel2007);
            Worksheet wsExport = wbExport.Worksheets.Add("Feature Categories");

            //specify the default font family
            Infragistics.Documents.Excel.IWorkbookFont defaultFont = wbExport.Styles.NormalStyle.StyleFormat.Font;
            defaultFont.Name = "Calibri";
            defaultFont.Height = 11 * 20;

            intRowIndex = 0;
            intColIndex = 0;

            #region column headers
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Name", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Feature Class", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "State", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Naming Standards", 400.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "LTF", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Linked Component Category", 300.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Target SCM Category", 300.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            #endregion

            intRowIndex = 1;
            intColIndex = 0;
            System.Drawing.ColorConverter cc = new System.Drawing.ColorConverter();

            foreach (DataRow drData in ds.Tables[0].Rows)
            {
                intColIndex = 0;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["Name"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["FeatureClass"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["State"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["NamingStandards"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["LongTermForecast"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["ComponentCategory"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["TargetSCMCategory"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intRowIndex++;
            }

            string strFileName = "";
            strFileName = "Feature_Categories_" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString().PadLeft(2, '0').ToString() + DateTime.Now.Day.ToString().PadLeft(2, '0').ToString();
            Response.Clear();
            Response.AppendHeader("content-disposition", "attachment; filename=" + strFileName + ".xlsx");
            Response.ContentType = "application/octet-stream";
            wbExport.Save(Response.OutputStream);
            Response.End();
        }
    }
}
