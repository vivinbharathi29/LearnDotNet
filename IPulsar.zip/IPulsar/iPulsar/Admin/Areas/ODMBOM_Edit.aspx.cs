﻿using iPulsar.Old_App_Code.BLL.Admin;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.Areas
{
    public partial class ODMBOM_Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession(false);

            string mode;
            mode = Request.QueryString["mode"];

            if (!IsPostBack)
            {
                int ID = Convert.ToInt32(Request.QueryString["ID"]);

                if ((mode == "update"))
                {
                    LoadODMBOM(ID);
                    Page.Title = "Modify Existing ODM BOM Visibility";
                    GetPermission();
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New ODM BOM Visibility";
                    pnlHistory.Visible = false;
                }
            }
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ABTReport_Edit_Permission.ToString()))
            {
                Page.Title = "View ODM BOM Visibility";

                this.txtName.Enabled = false;
                rbState.Enabled = false;
                // Disable buttons based on permission - Task 16666
                this.btnSave.Enabled = false;
            }
        }

        private void LoadODMBOM(int ID)
        {
            ODMBOMBLL da = new ODMBOMBLL();
            DataSet ds;
            ds = da.GetSelectedODMBOM(ID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                txtName.Text = dr["Value"].ToString().Trim();
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                rbState.SelectedValue = dr["State"].ToString();
                ds.Dispose();
                pnlHistory.Visible = true;

            }

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strName = "";
            int intSetInactive = 1;
            int intId = 0;
            ODMBOMBLL da = new ODMBOMBLL();
            try
            {
                strName = txtName.Text.ToString();

                if (Request.QueryString["ID"] != null)
                {
                    intId = Convert.ToInt32(Request.QueryString["ID"].ToString());
                }
                else
                {
                    intId = -1;
                }

                if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                    intSetInactive = 0;
                else
                    intSetInactive = 1;

                intId = da.UpdateODMBOM(intId, strName, intSetInactive, UserInfo.GetCurrentUserName());

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadODMBOM", "CloseEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }

        }

    }
}