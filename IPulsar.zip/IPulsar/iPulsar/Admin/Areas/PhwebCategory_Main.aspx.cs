﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;

public partial class Admin_PhwebCategory_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() will make sure you are who you are 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession();

        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "PHweb Categories";
        Page.Title = "PHweb Categories";
        if (!IsPostBack)
        {
            Session["PhwebCategoryList"] = null;
        }

        gridPopulate();
        GetPermission();
    }

    private void gridPopulate()
    {
        try
        {
            if (Session["PhwebCategoryList"] == null)
            {
                DataSet ds;
                AdminPhwebCategoryBLL adBll = new AdminPhwebCategoryBLL();
                ds = adBll.GetAllPhwebCategory();
                Session["PhwebCategoryList"] = ds;
            }
            BindGridData();
            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void BindGridData()
    {
        DataSet ds;
        ds = (DataSet)Session["PhwebCategoryList"];
        wdgPhwebCategory.Rows.Clear();
        wdgPhwebCategory.DataSource = ds;
        wdgPhwebCategory.DataBind();

    }
    protected void wdgPhwebCategory_OnInitializeRow(object sender, RowEventArgs e)
    {
        string PhwebCategoryID = e.Row.DataKey[0].ToString();
        string sName = e.Row.Items.FindItemByKey("CategoryName").Value.ToString();
        e.Row.Items.FindItemByKey("CategoryName").Text = "<a onclick=\"return OpenPCEditPopUp('PhwebCategory_Edit.aspx?mode=update&CategoryID=" + PhwebCategoryID + "');\">" + sName + "</a>";
    }
    private bool DeleteRecord()
    {
        bool b = false;
        int PhwebCategoryID = 0;
        PhwebCategoryID = Convert.ToInt32(hdnPhwebCategoryID.Value);
        if (!Authenticate.IsSessionExpired())
        {
            AdminPhwebCategoryBLL avb = new AdminPhwebCategoryBLL();
            avb.DeletePhwebCategory(PhwebCategoryID);
            b = true;
            //by setting it to null will trigger the grid to rebind with new data
            Session["PhwebCategoryList"] = null;
        }

        return b;
    }
    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.PHwebProductPin_Edit_Permission.ToString()))
        {
            Page.Title = "View Phweb Category List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.PHwebProductPin_Delete_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }
    protected void btnDeletePhwebCategory_Click(object sender, EventArgs e)
    {
        try
        {
            DeleteRecord();
            gridPopulate();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnRefeshGrid_Click(object sender, EventArgs e)
    {
        gridPopulate();
    }
}

