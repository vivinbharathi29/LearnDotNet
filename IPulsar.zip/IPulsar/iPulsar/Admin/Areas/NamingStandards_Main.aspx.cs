﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Telerik.Web.UI;
using System.Web.Services;

public partial class Admin_Areas_NamingStandard_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();

        MainMasterPage master = (MainMasterPage)Page.Master;
        Page.Title = "Naming Standards";
        master.pageheader = "Naming Standards";

        if (!IsPostBack)
        {
            Session["NamingStandardTable"] = null;
        }

        PopulateData();
        GetPermission();
    }

    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.NamingStandard_Edit_Permission.ToString()))
        {
            Page.Title = "View Naming Standard List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;

        }
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.NamingStandard_Delete_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }

    private void PopulateData()
    {
        try
        {
            if (Session["NamingStandardTable"] == null)
            {
                AdminNamingStandardBAL da = new AdminNamingStandardBAL();
                DataSet dsNamingStandard = new DataSet();
                dsNamingStandard = da.GetNamingStandards(-1);
                Session["NamingStandardTable"] = dsNamingStandard.Tables[0];
            }
            BindGridData();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void BindGridData()
    {
        DataTable dt = Session["NamingStandardTable"] as DataTable;
        if (dt?.Rows?.Count > 0)
        {
            // wdgNamingStandard.ClearDataSource();
            wdgNamingStandard.Rows.Clear();
            wdgNamingStandard.DataSource = dt;
            wdgNamingStandard.DataBind();
        }
    }
    public string DeleteRecord()
    {
        int intNamingStandardID;
        intNamingStandardID = Convert.ToInt32(hdnNSID.Value);
        string strMsg = "";
        AdminNamingStandardBAL da = new AdminNamingStandardBAL();
        da.NamingStandardDelete(intNamingStandardID);
        //by setting it to null will trigger grid to rebind with new data
        Session["NamingStandardTable"] = null;

        return strMsg;
    }
    protected void btnDeleteNS_Click(object sender, EventArgs e)
    {
        DeleteRecord();
        PopulateData();
    }
    protected void wdgNamingStandard_InitializeRow(object sender, Infragistics.Web.UI.GridControls.RowEventArgs e)
    {
        string NamingStandardID = e.Row.DataKey[0].ToString();
        string sName = e.Row.Items.FindItemByKey("Description").Value.ToString();
        e.Row.Items.FindItemByKey("Description").Text = "<a onclick=\"return OpenNamingStandardFields('NamingStandards_Edit.aspx?mode=update&NamingStandardID=" + NamingStandardID + "');\">" + sName + "</a>";
    }
    protected void btnRefeshGrid_Click(object sender, EventArgs e)
    {
        PopulateData();
    }
}