﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class SystemAdmin_MLParams_Edit : System.Web.UI.Page
{
    int MLParamID;
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession(false);
        string mode;
        mode = Request.QueryString["mode"];
        MLParamID = Convert.ToInt32(Request.QueryString["MLParamID"]);
        Authenticate.ValidateSession();
        // Put user code to initialize the page here

        if (!IsPostBack)
        {
            if ((mode == "update"))
            {
                LoadMLParamData(MLParamID);
                Page.Title = "Modify Existing MLParams";
                GetPermission();
            }
            else if (mode == "create")
            {
                Page.Title = "Add New MLParams";
                pnlHistory.Visible = false;
            }
        }
    }
    private void LoadMLParamData(int MLParamID)
    {
        AdminMLParamsBLL da = new AdminMLParamsBLL();
        DataSet ds = new DataSet();
        ds = da.GetMLParams(MLParamID);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            txtName.Text = dr["OSFlag"].ToString();
            txtValue.Text = dr["MLNameValue"].ToString();
            lblTimeChanged.Text = dr["TimeChanged"].ToString().Trim();
            lblTimeCreated.Text = dr["TimeCreated"].ToString().Trim();
            lblCreator.Text = dr["Creator"].ToString().Trim();
            lblUpdater.Text = dr["Updater"].ToString().Trim();
            ds.Dispose();
            pnlHistory.Visible = true;
        }  
    }
    private void GetPermission()
    {  // check permission from resource file instead of enums - task 19440
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.MLParam_Edit_Permission.ToString()))
        {
            Page.Title = "View Feature Category";

            this.txtName.Enabled = false;
            this.btnSave.Enabled = false;
            this.lblEnter.Visible = false;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        AdminMLParamsBLL da = new AdminMLParamsBLL();
        try
        {
            UserInfo obj = new UserInfo();
            da.ModifyMLParam(MLParamID, txtName.Text, txtValue.Text, UserInfo.GetCurrentUserName().ToString());

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadMLParamedit", "CloseEditPopup(true)", true);
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
}

