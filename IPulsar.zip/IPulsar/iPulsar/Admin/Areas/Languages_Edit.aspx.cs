﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using Telerik.Web.UI;
using System.Web.Services;
namespace iPulsar.Admin.Areas
{
    public partial class Languages_Edit : System.Web.UI.Page
    {
        int LanguageID;
        bool bEdit;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession(false);

            string mode;
            mode = Request.QueryString["mode"];
            LanguageID = Convert.ToInt32(Request.QueryString["LanguageID"]);
            hdnLanguageID.Value = LanguageID.ToString();
            GetPermission();
            
            if (!IsPostBack)
            {
                if ((mode == "update"))
                {
                    LoadLanguage(LanguageID);
                    Page.Title = "Modify Language";
                
                   
                   
                   
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Language";
                    pnlHistory.Visible = false;                  
                    
                   
                }
               
            }
            if (!bEdit)
            { disablecontrols(); }
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Regions_Edit_Permission.ToString()))
            {
                bEdit = false;

            }
            else
            {
                bEdit = true;
            
            }
        }

       
        private void LoadLanguage(int LanguageID)
        {
            AdminRegionsBLL adBll = new AdminRegionsBLL();
            DataSet ds;

            ds = adBll.GetLanguageById(LanguageID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                txtName.Text = dr["Name"].ToString();
                txtAbbreviation.Text = dr["Abbreviation"].ToString();
                txtDash.Text = dr["Dash"].ToString();
                txtOverflowDash.Text = dr["OverflowDash"].ToString();
                txtSubstitute1.Text = dr["Substitute1"].ToString();
                txtSubstitute2.Text = dr["Substitute2"].ToString();  
                if (dr["State"].ToString().ToLower() == "true" || dr["State"].ToString() == "1")
                    rbState.SelectedValue = "1";
                else
                    rbState.SelectedValue = "0";
                txtSortOrder.Text = dr["OrderID"].ToString();
                if (dr["Translation"].ToString().ToLower() == "true" || dr["Translation"].ToString() == "1")
                    chkTranslation.Checked = true;
                else
                    chkTranslation.Checked = false;
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();                            
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }
        private void disablecontrols()
        {
            Page.Title = "View Master Language";
            //  this.txtHPCode.Enabled = false;
            this.btnSave.Enabled = false;
            this.rbState.Enabled = false;
            this.lblEnter.Visible = false;
            // this.txtDash.Enabled = false;
            txtName.Enabled = false;
            txtAbbreviation.Enabled = false;
            txtDash.Enabled = false;
            txtOverflowDash.Enabled = false;
            txtAbbreviation.Enabled = false;
            txtSubstitute1.Enabled = false;
            txtSubstitute2.Enabled = false;
            txtSortOrder.Enabled = false;
            chkTranslation.Enabled = false;
           
        }
       
             
        protected void btnSave_Click(object sender, EventArgs e)
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            try
            {
                string strLanguageName = txtName.Text.Trim();
                string strAbbreviation = txtAbbreviation.Text.Trim();
                string strDash = txtDash.Text.Trim();
                string strOverflowDash =txtOverflowDash.Text.Trim();
                string strSubstitute1 = txtSubstitute1.Text.Trim();
                string strSubstitute2 = txtSubstitute2.Text.Trim();
                int intState = 0;
                if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                    intState = 1;
                int intSortOrder = 100;//most record is using this value so default to 100;
                if (txtSortOrder.Text != "")
                    intSortOrder = Int32.Parse(txtSortOrder.Text.ToString());
                int intTranslation = 0;
                if (chkTranslation.Checked)
                    intTranslation = 1;
                LanguageID = da.UpdateLanguage(LanguageID, strLanguageName, strAbbreviation, strDash,
                                                strOverflowDash, strSubstitute1, strSubstitute2, intState,
                                                intSortOrder,intTranslation, UserInfo.GetCurrentUserName().ToString()
                                                );

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadLanguage", "CloseLanguageEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
   
        
    }
}



