﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;
using Infragistics.Web.UI.GridControls;

public partial class Admin_Areas_NamingStandardFields_Edit : System.Web.UI.Page
{
    int intCurrentNumber = 1;
    bool bConfiguredColumns = false;
    //private string FieldType = "Text box"; //o is Textbox and 1 is dropdown
    private string Mode
    {
        get
        {
            return Convert.ToString(Session["NamingStandard_Mode"]);
        }
        set { Session["NamingStandard_Mode"] = value; }
    }
    private string NamingStandardName
    {
        get
        {
            return Convert.ToString(Session["NamingStandard_NamingStandardName"]);
        }
        set { Session["NamingStandard_NamingStandardName"] = value; }
    }
    private int NamingStandardID
    {
        get
        {
            return Convert.ToInt32(Session["NamingStandard_NamingStandardID"]);
        }
        set { Session["NamingStandard_NamingStandardID"] = value; }
    }
    private int SortOrderID
    {
        get
        {
            return Convert.ToInt32(Session["NamingStandard_SortOrderID"]);
        }
        set { Session["NamingStandard_SortOrderID"] = value; }
    }
    private int FieldID
    {
        get
        {
            return Convert.ToInt32(Session["NamingStandard_FieldID"]);
        }
        set { Session["NamingStandard_FieldID"] = value; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession(false);

        if (!IsPostBack)
        {
            NamingStandardID = Convert.ToInt32(Request.QueryString.Get("NamingStandardID"));
            FieldID = Convert.ToInt32(Request.QueryString.Get("FieldID"));
            SortOrderID = Convert.ToInt32(Request.QueryString.Get("SortOrder"));
            NamingStandardName = Convert.ToString(Request.QueryString.Get("NamingStandardName"));
            Mode = Convert.ToString(Request.QueryString.Get("mode"));

            hdnFieldID.Value = FieldID.ToString();
            Session["DropDownValues"] = null;
            GetFieldInfo();

            Telerik.Web.UI.RadMenuItem item;

            item = new Telerik.Web.UI.RadMenuItem();
            item.Text = "Add Column";
            item.Value = "AddColumn";
            rmContextMenu.Items.Add(item);

            item = new Telerik.Web.UI.RadMenuItem();
            item.Text = "Add Column (Allow Special Char)";
            item.Value = "AddColumnSpecial";
            rmContextMenu.Items.Add(item);

            item = new Telerik.Web.UI.RadMenuItem();
            item.Text = "Delete Column";
            item.Value = "DeleteColumn";
            rmContextMenu.Items.Add(item);

            item = new Telerik.Web.UI.RadMenuItem();
            item.IsSeparator = true;
            rmContextMenu.Items.Add(item);

            item = new Telerik.Web.UI.RadMenuItem();
            item.Text = "Add Row";
            item.Value = "AddRow";
            rmContextMenu.Items.Add(item);

            item = new Telerik.Web.UI.RadMenuItem();
            item.Text = "Delete Row";
            item.Value = "DeleteRow";
            rmContextMenu.Items.Add(item);

            item = new Telerik.Web.UI.RadMenuItem();
            item.Text = "Set State";
            item.Value = "SetState";
            rmContextMenu.Items.Add(item);

            item = new Telerik.Web.UI.RadMenuItem();
            item.IsSeparator = true;
            rmContextMenu.Items.Add(item);

            item = new Telerik.Web.UI.RadMenuItem();
            item.Text = "Add Blank Value";
            item.Value = "AddBlank";
            rmContextMenu.Items.Add(item);

            hdnNamingStandardId.Value = Request.QueryString["NamingStandardID"];
        }
        else
        {
            //Moved out from !IsPostBack
            //get the naming standard id and the field id
            if (Request.QueryString.Get("NamingStandardID") != null && NamingStandardID == 0)
                NamingStandardID = Convert.ToInt32(Request.QueryString.Get("NamingStandardID"));
            if (Request.QueryString.Get("FieldID") != null && FieldID == 0)
                FieldID = Convert.ToInt32(Request.QueryString.Get("FieldID"));
            if (Request.QueryString.Get("SortOrder") != null && SortOrderID == 0)
                SortOrderID = Convert.ToInt32(Request.QueryString.Get("SortOrder"));
            if (Request.QueryString.Get("NamingStandardName") != null && string.IsNullOrEmpty(NamingStandardName))
                NamingStandardName = Convert.ToString(Request.QueryString.Get("NamingStandardName"));
            if (Request.QueryString.Get("mode") != null && string.IsNullOrEmpty(Mode))
                Mode = Convert.ToString(Request.QueryString.Get("mode"));

            //if session is null, we reload the session
            BindDropDownGrid();
        }

        GetPermission();
    }
    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.NamingStandard_Edit_Permission.ToString()))
        {
            Page.Title = "View Naming Standard Field";
            DisableControls();
        }
        else if (Convert.ToString(Mode) == "view")
        {
            Page.Title = "View Naming Standard Field";
            DisableControls();
        }
    }
    private void DisableControls()
    {
        txtTBFieldName.Enabled = false;
        txtTextboxLength.Enabled = false;
        txtInstructions.Enabled = false;
        chkFeature.Enabled = false;
        chkRequired.Enabled = false;
        chkRoot.Enabled = false;
        btnSave.Enabled = false;
        rmContextMenu.Enabled = false;
        lnkAddNewRow.Disabled = true;
        lnkAddNewRow.Attributes["Class"] = "disabled";
        hdnCanEdit.Value = "0";
        wdgDropDownValues.Enabled = false;
        rdbState.Enabled = false;
    }
    private void GetFieldInfo()
    {
        AdminNamingStandardBAL da = new AdminNamingStandardBAL();
        DataSet ds = new DataSet();
        ds = da.GetNamingStandardFieldByFieldID(FieldID);
        string strFieldName = "", strInstructions = "", strTextLength = "";
        int intFieldType = 0;
        bool bRequired = false, bUseInRoot = true, bUseInFeature = true;
        bool qsOnly = false;

        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            strFieldName = ds.Tables[0].Rows[0]["FieldName"].ToString();
            intFieldType = Convert.ToInt32(ds.Tables[0].Rows[0]["FieldType"].ToString());
            strTextLength = ds.Tables[0].Rows[0]["TextLength"].ToString();
            bRequired = Convert.ToBoolean(ds.Tables[0].Rows[0]["Required"].ToString());
            qsOnly = Convert.ToBoolean(ds.Tables[0].Rows[0]["QSOnly"].ToString());
            bUseInRoot = Convert.ToBoolean(ds.Tables[0].Rows[0]["UseInRoot"].ToString());
            bUseInFeature = Convert.ToBoolean(ds.Tables[0].Rows[0]["UseInFeature"].ToString());
            strInstructions = ds.Tables[0].Rows[0]["Instructions"].ToString();

            if (ds.Tables[0].Rows[0]["Active"].ToString() == "Inactive")
                rdbState.SelectedValue = "0";
            else if (ds.Tables[0].Rows[0]["Active"].ToString() == "Active")
                rdbState.SelectedValue = "1";
        }

        if (intFieldType == 2)
        {
            rdbFieldType.SelectedValue = "2";
            divDDFields.Attributes.Add("style", "display:block");
            wdgDropDownValues.Visible = true;
            txtTextboxLength.Text = "";
            txtTextboxLength.Enabled = false;
            Session["DropDownValues"] = ds.Tables[1];
            GetDropDownValues();
        }
        else
        {
            rdbFieldType.SelectedValue = "1";
            divDDFields.Attributes.Add("style", "display:none");
            txtTextboxLength.Text = strTextLength;
            txtTextboxLength.Enabled = true;
        }

        txtTBFieldName.Text = strFieldName;
        chkRequired.Checked = bRequired;
        chkQSOnly.Checked = qsOnly;
        txtInstructions.Text = strInstructions;
        chkRoot.Checked = bUseInRoot;
        chkFeature.Checked = bUseInFeature;

        if (FieldID > 0)
        {
            rdbFieldType.Enabled = false;
        }
    }
    protected void rdbFieldType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rdbFieldType.SelectedValue == "1")
        {
            pnlDDFields.Visible = false;
        }
        else if (rdbFieldType.SelectedValue == "2")
        {
            pnlDDFields.Visible = true;

            //bind the grid
            GetDropDownValues();
            //BindDropDownGrid();
        }
    }
    private void GetDropDownValues()
    {
        //reload session if session is expred.
        //ReloadDDVSession();

        //get from the database
        string strColName = String.Empty;
        DataTable dtDropDownValues = (DataTable)Session["DropDownValues"];
        lock (dtDropDownValues)
        {
            if (dtDropDownValues.Rows.Count == 0)
                wdgDropDownValues.Visible = false;
            else
            {
                wdgDropDownValues.Visible = true;
                while (wdgDropDownValues.Columns[0] != null)
                {
                    wdgDropDownValues.Columns.RemoveAt(0);
                }
                wdgDropDownValues.Rows.Clear();
                AddNewGridColumn("Status", "Status", 50, true);

                //Add a State column
                AddNewGridColumn("State", "State", 50, false);

                for (int i = 3; i < dtDropDownValues.Columns.Count; i++)
                {
                    //create datacolumn for the grid    
                    strColName = dtDropDownValues.Columns[i].ColumnName.ToString().Split('|')[4];

                    if (dtDropDownValues.Columns[i].ColumnName.ToString().Split('|')[0] == "1")
                        strColName = "Display Name " + strColName;
                    //else
                    //    strColName = char.ConvertFromUtf32(64 + Convert.ToInt32(dtDropDownValues.Columns[i].ColumnName.ToString().Split('|')[0]));
                    AddNewGridColumn(strColName, dtDropDownValues.Columns[i].ColumnName, 89, false);
                }

                BindDropDownGrid();
            }
        }
    }
    private void RemoveGridColumns()
    {
        for (int i = 0; i < wdgDropDownValues.Columns.Count; i++)
        {
            wdgDropDownValues.Columns.Clear();
        }
    }

    //reload session is call on postback
    private void ReloadDDVSession()
    {
        //when session is null and we need to reload the session with data that may have been modified and dislay on the grid
        //we don't want to reload from database. so we create datatable and set it back to the session
        if (Session["DropDownValues"] == null && wdgDropDownValues.Rows.Count > 0)
        {
            DataTable dt = new DataTable();
            DataColumn dcRunumber = new DataColumn("RowNumber");
            dt.Columns.Add(dcRunumber);
            //loop through columns to create datatable columns
            for (int i = 0; i < wdgDropDownValues.Columns.Count; i++)
            {
                DataColumn dc = new DataColumn(wdgDropDownValues.Columns[i].Key);
                dt.Columns.Add(dc);
            }
            //loop through grid row to add data to datatable
            for (int r = 0; r < wdgDropDownValues.Rows.Count; r++)
            {
                DataRow dr = dt.NewRow();
                for (int c = 0; c < dt.Columns.Count; c++)
                {
                    if (c == 0)
                        dr[c] = wdgDropDownValues.Rows[r].DataKey[0];
                    else
                        dr[c] = wdgDropDownValues.Rows[r].Items[c - 1].Value;
                }

                dt.Rows.Add(dr);
            }
            //set datatable back to session
            Session["DropDownValues"] = dt;
        }
    }

    private void BindDropDownGrid()
    {
        divDDFields.Attributes.Add("style", "display:block");
        DataTable dt = (DataTable)Session["DropDownValues"];

        wdgDropDownValues.ClearDataSource();
        if (dt != null)
        {
            lock (dt)
            {
                wdgDropDownValues.DataSource = dt;
                wdgDropDownValues.DataBind();
            }
        }
        else
        {
            wdgDropDownValues.DataSource = null;
            wdgDropDownValues.DataBind();
        }
    }
    private void AddNewGridColumn(string strColumnName, string strKey, int intWidth, bool bIsHidden)
    {
        bool bIsColumnPresent = false;

        for (int i = 0; i < wdgDropDownValues.Columns.Count; i++)
        {
            if (wdgDropDownValues.Columns[i].Key == strKey)
            {
                bIsColumnPresent = true;
                break;
            }
        }
        if (bIsColumnPresent == false)
        {
            Infragistics.Web.UI.GridControls.UnboundField newcolumn = new Infragistics.Web.UI.GridControls.UnboundField();
            newcolumn.Header.Text = strColumnName;
            newcolumn.Key = strKey;
            newcolumn.Width = Unit.Pixel(intWidth);
            newcolumn.Hidden = bIsHidden;
            newcolumn.Header.CssClass = "HeaderClass";
            wdgDropDownValues.Columns.Insert(wdgDropDownValues.Columns.Count, newcolumn);
        }
    }
    protected void wdgDropDownValues_InitializeRow(object sender, RowEventArgs e)
    {
        if (!bConfiguredColumns)
        {
            DataTable dt = (DataTable)this.wdgDropDownValues.DataSource;
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                string ColumnName = dt.Columns[i].ColumnName;
                e.Row.Items.FindItemByKey(ColumnName).Column.Width = Unit.Pixel(200);
            }
            bConfiguredColumns = true;
        }
    }
    private void ApplyColumnFormat()
    {
        //reload session if session is expred.
        //ReloadDDVSession();

        DataTable dt = (DataTable)Session["DropDownValues"];

        if (dt != null)
        {
            lock (dt)
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    string ColumnName = dt.Columns[i].ColumnName;
                    wdgDropDownValues.Rows[0].Items.FindItemByKey(ColumnName).Column.Width = Unit.Pixel(200);
                }
            }
        }
    }
    protected void btnAddColumn_Click(object sender, EventArgs e)
    {
        DataTable dt = (DataTable)Session["DropDownValues"];
        int intColumnKey = 0;
        string strColumnName = "";
        string strColumnkey = "";
        try
        {
            //reload session if session is expred.
            if (dt != null)
            {

                lock (dt)
                {
                    intColumnKey = Convert.ToInt32(wdgDropDownValues.Columns[wdgDropDownValues.Columns.Count - 1].Key.Split('|')[0]) + 1;
                    intCurrentNumber = 64 + intColumnKey;//starting from ascii value of 'A'   

                    if (hdnSpecialCharColumnName.Value != "")
                        strColumnName = hdnSpecialCharColumnName.Value;
                    else
                        strColumnName = char.ConvertFromUtf32(intCurrentNumber);
                    if (hdnSpecialCharColumnName.Value != "")
                        strColumnkey = intColumnKey.ToString() + "|0|0|1|" + strColumnName; //attach 2 more value to indicate if special char is allowed for that column and the column name
                    else
                        strColumnkey = intColumnKey.ToString() + "|0|0|0|" + strColumnName;

                    DataColumn dc = new DataColumn(strColumnkey);
                    dt.Columns.Add(dc);


                    Session["DropDownValues"] = dt;
                    AddNewGridColumn(strColumnName, strColumnkey, 100, false);
                    BindDropDownGrid();

                    lblError.Text = "";
                    lblError.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnAddRow_Click(object sender, EventArgs e)
    {
        if (rdbFieldType.SelectedValue == "2")
            txtTextboxLength.Enabled = false;
        else if (rdbFieldType.SelectedValue == "1")
            txtTextboxLength.Enabled = true;

        DataTable dt;
        try
        {
            //reload session if session is expred.
            //ReloadDDVSession();            

            wdgDropDownValues.Visible = true;
            if (Session["DropDownValues"] == null)
            {
                dt = new DataTable();
                DataColumn dc = new DataColumn("RowNumber");
                dt.Columns.Add(dc);

                DataColumn dcRow = new DataColumn("Status");
                dt.Columns.Add(dcRow);
                AddNewGridColumn("Status", "Status", 0, true);

                dcRow = new DataColumn("State");
                dt.Columns.Add(dcRow);
                AddNewGridColumn("State", "State", 50, false);

                DataColumn dc1 = new DataColumn(intCurrentNumber.ToString() + "|0|0|0|" + char.ConvertFromUtf32(64 + intCurrentNumber));
                dt.Columns.Add(dc1);
                AddNewGridColumn("Display Name " + char.ConvertFromUtf32(64 + intCurrentNumber), intCurrentNumber.ToString() + "|0|0|0|" + char.ConvertFromUtf32(64 + intCurrentNumber), 100, false);
            }
            else
            {
                dt = (DataTable)Session["DropDownValues"];
                lock (dt)
                {
                    if (dt.Rows.Count == 0)
                    {
                        //add atleast 1 column                   
                        AddNewGridColumn("Status", "Status", 0, true);

                        AddNewGridColumn("State", "State", 0, true);

                        DataColumn dc1 = new DataColumn(intCurrentNumber.ToString() + "|0|0|0|" + char.ConvertFromUtf32(64 + intCurrentNumber));
                        if (!dt.Columns.Contains(intCurrentNumber.ToString() + "|0|0|0|" + char.ConvertFromUtf32(64 + intCurrentNumber)))
                            dt.Columns.Add(dc1);
                        AddNewGridColumn("Display Name " + char.ConvertFromUtf32(64 + intCurrentNumber), intCurrentNumber.ToString() + "|0|0|0|" + char.ConvertFromUtf32(64 + intCurrentNumber), 100, false);
                    }
                }
            }

            DataRow dr = dt.NewRow();

            //get max value of RowNumber for new row
            int RowNumber;
            if (!int.TryParse(dt.Compute("max(RowNumber)", string.Empty).ToString(), out RowNumber))
                RowNumber = 0;

            dr["RowNumber"] = RowNumber + 1;
            dr["Status"] = "N";
            dt.Rows.Add(dr);

            Session["DropDownValues"] = dt;
            BindDropDownGrid();
            lblError.Text = "";
            lblError.Visible = false;
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnDeleteRow_Click(object sender, EventArgs e)
    {
        try
        {
            //reload session if session is expred.
            //ReloadDDVSession();

            if (Session["DropDownValues"] != null)
            {
                int dropdownvalueid = Convert.ToInt32(hdnDelDropDownValueID.Value.ToString());
                DataTable dt = (DataTable)Session["DropDownValues"];
                lock (dt)
                {
                    dt.PrimaryKey = new DataColumn[] { dt.Columns["RowNumber"] };
                    DataRow dr = dt.Rows.Find(dropdownvalueid);
                    dt.Rows.Remove(dr);
                    Session["DropDownValues"] = dt;
                    BindDropDownGrid();
                    AdminNamingStandardBAL da = new AdminNamingStandardBAL();
                    da.DeleteDropDownRows(dropdownvalueid, FieldID);
                }
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private bool ValidateRowValuesNotLinkedToFeatureOrRoot(int dropdownvalueid)
    {
        try
        {
            return true;
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
            return false;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            //if (!Authenticate.IsSessionExpired())
            //{
            string strFieldName = "", strInstructions = "";
            int intFieldType = 0, intTextLength = 0;
            int intRequired = 0;
            int intNewNamingStandard = 0;
            string sImportClicked = "";
            intFieldType = Convert.ToInt32(rdbFieldType.SelectedValue);
            strFieldName = txtTBFieldName.Text.Trim();
            if (txtTextboxLength.Text.Trim().Length != 0)
                int.TryParse(txtTextboxLength.Text.Trim(), out intTextLength);
            if (rdbFieldType.SelectedValue == "2")
                intTextLength = 0;
            if (chkRequired.Checked)
                intRequired = 1;
            else
                intRequired = 0;
            int qsOnly = chkQSOnly.Checked ? qsOnly = 1 : qsOnly = 0;
            strInstructions = txtInstructions.Text.Trim();
            int intUseInRoot = 1;
            int intUseInFeature = 1;
            if (!chkRoot.Checked)
                intUseInRoot = 0;
            if (!chkFeature.Checked)
                intUseInFeature = 0;
            int intFieldID = FieldID;
            sImportClicked = hdnImportClicked.Value;
            int intActive = Convert.ToInt32(rdbState.SelectedValue);

            AdminNamingStandardBAL da = new AdminNamingStandardBAL();

            intNewNamingStandard = da.NamingStandardField_Modify(NamingStandardID, NamingStandardName, ref intFieldID, intFieldType, strFieldName, intTextLength, intRequired, qsOnly, strInstructions, SortOrderID, intUseInRoot, intUseInFeature, UserInfo.GetCurrentUserName(), intActive);

            FieldID = intFieldID;
            hdnFieldID.Value = FieldID.ToString();
            int intRefreshMainPage = 0;
            if (intNewNamingStandard != NamingStandardID)
                intRefreshMainPage = 1;

            NamingStandardID = intNewNamingStandard;
            if (intFieldType == 2)
            {
                SaveDropDownValuesAndVariances();
            }

            lblError.Text = "";
            lblError.Visible = false;

            if (sImportClicked != "1")
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadnamingstandardfieldlist", "ReloadNamingStandardFieldList(" + NamingStandardID + "," + intRefreshMainPage + ")", true);
            }

            //refresh grid on Naming Standard Edit Screen
            Session["NamingStandard_FieldListDS"] = null;
        }
        catch (Exception ex)
        {
            ToggleDropDownValueSpace();
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void ToggleDropDownValueSpace()
    {
        if (rdbFieldType.SelectedValue == "1")
            divDDFields.Style.Add("display", "none");
        else
            divDDFields.Style.Add("display", "block");
    }
    private void SaveDropDownValuesAndVariances()
    {
        AdminNamingStandardBAL da = new AdminNamingStandardBAL();
        int intRowNumber = 0; string strDropDownValues;
        string strColumnInfo = "";


        //getting data from session
        DataTable dt = (DataTable)Session["DropDownValues"];
        if (dt != null)
        {
            //Save the columnInfo as some columns are allowed for special char now
            lock (dt)
            {
                foreach (DataColumn dc in dt.Columns)
                {
                    if (dc.ToString() != "Status" && dc.ToString() != "RowNumber" && dc.ToString() != "State")
                    {
                        if (strColumnInfo == "")
                        {
                            strColumnInfo = dc.ColumnName.Split('|')[0] + "|" + dc.ColumnName.Split('|')[3] + "|" + dc.ColumnName.Split('|')[4];
                        }
                        else
                        {
                            strColumnInfo += "," + dc.ColumnName.Split('|')[0] + "|" + dc.ColumnName.Split('|')[3] + "|" + dc.ColumnName.Split('|')[4];
                        }
                    }
                }
                da.NamingStandardFieldDropDownColumnsModify(FieldID, strColumnInfo, UserInfo.GetCurrentUserName());

                DataRow[] drs = dt.Select("Status in ('N', 'E')");
                foreach (DataRow dr in drs)
                {
                    if (dr["Status"].ToString() == "N" || dr["Status"].ToString() == "E") //  || ColumnAdded == true
                    {
                        strDropDownValues = "";
                        foreach (DataColumn dc in dt.Columns)
                        {
                            if (dc.ToString() != "Status" && dc.ToString() != "RowNumber" && dc.ToString() != "State")
                            {
                                if (strDropDownValues == "")
                                {
                                    strDropDownValues = dr[dc].ToString() + "!,!" + dc.ColumnName.Split('|')[0];
                                }
                                else
                                {
                                    strDropDownValues = strDropDownValues + "!;!" + dr[dc].ToString() + "!,!" + dc.ColumnName.Split('|')[0];
                                }
                            }
                        }
                        if (dr["Status"].ToString() == "N")
                        {
                            intRowNumber = -1;
                        }
                        else
                        {
                            intRowNumber = Convert.ToInt32(dr["RowNumber"]);
                        }
                        strDropDownValues = strDropDownValues.Replace("[BLANK]", "");
                        da.NamingStandardFieldDropDownValuesModify(intRowNumber, FieldID, strDropDownValues, UserInfo.GetCurrentUserName());
                    }
                }
            }
        }


    }
    protected void btnColumnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            //reload session if session is expred.
            //ReloadDDVSession();

            DataTable dt = (DataTable)Session["DropDownValues"];
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            int intColumnNumber = Convert.ToInt32(hdnColumnNumber.Value);
            string strColumnkey = "";
            da.DeleteDropDownColumn(FieldID, intColumnNumber);

            if (dt != null)
            {
                lock (dt)
                {
                    //Save the columnInfo as some columns are allowed for special char now
                    foreach (DataColumn dc in dt.Columns)
                    {
                        if (dc.ToString() != "Status" && dc.ToString() != "RowNumber" && dc.ToString() != "State")
                        {
                            if (dc.ColumnName.Split('|')[0] == intColumnNumber.ToString())
                            {
                                strColumnkey = intColumnNumber + "|0|0" + "|" + dc.ColumnName.Split('|')[3] + "|" + dc.ColumnName.Split('|')[4];
                                dt.Columns.Remove(strColumnkey);
                                break;
                            }
                        }
                    }
                }
            }

            Session["DropDownValues"] = dt;
            this.wdgDropDownValues.Columns.RemoveAt(this.wdgDropDownValues.Columns[strColumnkey].Index);
            BindDropDownGrid();
            lblError.Text = "";
            lblError.Visible = false;
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }

    [WebMethod(EnableSession = true)]
    public static string ValidateRowDropDownValuesLinkedToFeatureOrRoot(int intRowNumber, int intFieldID)
    {
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            DataSet dsValidate = new DataSet();

            dsValidate = da.ValidateRowDropDownValuesLinkedToFeatureOrRoot(intRowNumber, intFieldID);
            string islinked = dsValidate.Tables[0].Rows[0]["IsLinked"].ToString();
            return islinked;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod]
    public static string GetFormulaNameByColumnNumber(int intFieldID, int intColumnNumber)
    {
        try
        {
            string strFormulaName = "";
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            DataSet dsFormulaName = new DataSet();
            dsFormulaName = da.GetFormulaNameByColumnNumber(intFieldID, intColumnNumber);
            if (dsFormulaName.Tables.Count > 0)
            {
                foreach (DataRow dr in dsFormulaName.Tables[0].Rows)
                {
                    strFormulaName = strFormulaName == "" ? dr["Name"].ToString() : strFormulaName + "\n\n" + dr["Name"].ToString();
                }
            }
            return strFormulaName;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod]
    public static void UpdateFieldValueStatus(int FieldID, int RowNumber, int Status)
    {
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            da.UpdateFieldValueStatus(FieldID, RowNumber, Status);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    //we are updating the session everytime a field is edited
    [System.Web.Services.WebMethod]
    public static void UpdateSessionDDV(int RowIndex, int ColumnIndex, string sValue)
    {
        try
        {
            if (HttpContext.Current.Session["DropDownValues"] != null)
            {
                //get data from session
                DataTable dt = new DataTable();
                dt = (DataTable)HttpContext.Current.Session["DropDownValues"];
                lock (dt)
                {
                    //updating cell
                    DataRow dr = dt.Rows[RowIndex];
                    dr[ColumnIndex + 1] = sValue;

                    dt.AcceptChanges();
                }
            }
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}