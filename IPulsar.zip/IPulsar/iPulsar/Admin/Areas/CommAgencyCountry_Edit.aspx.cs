﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.Areas
{
    public partial class CommAgencyCountry_Edit : System.Web.UI.Page
    {
        int intCountryId;
        bool bEdit;
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession(false);

            string mode;
            mode = Request.QueryString["mode"];
            intCountryId = Convert.ToInt32(Request.QueryString["CountryID"]);
            hdnCountryID.Value = intCountryId.ToString();
            GetPermission();

            if (!IsPostBack)
            {
                if ((mode == "update"))
                {
                    LoadCertificateStatus();
                    GetCommAgencyCountryDefaults(intCountryId);
                    Page.Title = "Comm Agency Country Defaults";
                    
                }
                
            }
            if (!bEdit)
            { disablecontrols(); }
        }


        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.CommAgencyAdmin_Edit_Permission.ToString()))
            {
                bEdit = false;

            }
            else
            {
                bEdit = true;

            }
        }

        private void GetCommAgencyCountryDefaults(int intCountryID)
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            DataSet ds;

            ds = da.GetCommAgencyCountryDefaults(intCountryID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
               
                lblName.Text = dr["Name"].ToString();
                lblGEO.Text = dr["GEO"].ToString();
                if (dr["WWAN"].ToString().Trim() == "")
                {
                    ddlWLAN.ClearSelection();
                    ddlWWAN.Items[0].Selected = true;
                }
                else
                {
                    ddlWWAN.SelectedValue = dr["WWAN"].ToString().Trim();
                }
                if (dr["NFC"].ToString().Trim() == "")
                {
                    ddlNFC.ClearSelection();
                    ddlNFC.Items[0].Selected = true;
                }
                else
                {
                    ddlNFC.SelectedValue = dr["NFC"].ToString().Trim();
                }
                if (dr["WiGig"].ToString().Trim() == "")
                {
                    ddlWiGig.ClearSelection();
                    ddlWiGig.Items[0].Selected = true;
                }
                else
                {
                    ddlWiGig.SelectedValue = dr["WiGig"].ToString().Trim();
                }
                if (dr["WLAN"].ToString().Trim() == "")
                {
                    ddlWLAN.ClearSelection();
                    ddlWLAN.Items[0].Selected = true;
                }
                else
                {
                    ddlWLAN.SelectedValue = dr["WLAN"].ToString().Trim();
                }
                if (dr["BT"].ToString().Trim() == "")
                {
                    ddlBT.ClearSelection();
                    ddlBT.Items[0].Selected = true;
                }
                else
                {
                    ddlBT.SelectedValue = dr["BT"].ToString().Trim();
                }
                lblState.Text = dr["State"].ToString();                
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }

        private void disablecontrols()
        {
            Page.Title = "Comm Agency Country Defaults";
            this.btnSave.Enabled = false;
            
            this.lblEnter.Visible = false;
            

        }

        private void LoadCertificateStatus()
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            DataSet ds = new DataSet();

            try
            {
                ds = da.GetCertificateStatus();
                ddlWWAN.DataSource = ds.Tables[0];
                ddlWWAN.DataTextField = "Name";
                ddlWWAN.DataValueField = "Abbr";
                ddlWWAN.DataBind();
                ddlWWAN.Items.Insert(0, new ListItem("", " "));

                ddlNFC.DataSource = ds.Tables[0];
                ddlNFC.DataTextField = "Name";
                ddlNFC.DataValueField = "Abbr";
                ddlNFC.DataBind();
                ddlNFC.Items.Insert(0, new ListItem("", " "));

                ddlWiGig.DataSource = ds.Tables[0];
                ddlWiGig.DataTextField = "Name";
                ddlWiGig.DataValueField = "Abbr";
                ddlWiGig.DataBind();
                ddlWiGig.Items.Insert(0, new ListItem("", " "));

                ddlWLAN.DataSource = ds.Tables[0];
                ddlWLAN.DataTextField = "Name";
                ddlWLAN.DataValueField = "Abbr";
                ddlWLAN.DataBind();
                ddlWLAN.Items.Insert(0, new ListItem("", " "));

                ddlBT.DataSource = ds.Tables[0];
                ddlBT.DataTextField = "Name";
                ddlBT.DataValueField = "Abbr";
                ddlBT.DataBind();
                ddlBT.Items.Insert(0, new ListItem("", " "));

            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }


        protected void btnSave_Click(object sender, EventArgs e)
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            try
            {
                string strWWAN = ddlWWAN.SelectedValue.ToString(); ;
                string strNFC = ddlNFC.SelectedValue.ToString();
                string strWiGig = ddlWiGig.SelectedValue.ToString();
                string strWLAN = ddlWLAN.SelectedValue.ToString();
                string strBT = ddlBT.SelectedValue.ToString();

                intCountryId = da.UpdateCommAgencyCountryDefaults(intCountryId, strWWAN, strNFC, strWiGig, strWLAN, strBT, UserInfo.GetCurrentUserName().ToString()
                  );

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadCountry", "CloseCountryEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }


    }
}