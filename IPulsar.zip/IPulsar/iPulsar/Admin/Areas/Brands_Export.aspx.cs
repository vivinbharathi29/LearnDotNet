﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Documents.Excel;

namespace iPulsar.Admin.Areas
{
    public partial class Brands_Export : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            CreateWorksheetData();
        }
        private void CreateWorksheetData()
        {
            AdminBrandsBLL da = new AdminBrandsBLL();
            DataSet dsList = new DataSet();
            dsList = da.GetBrands(-1);

            int intRowIndex = 0, intColIndex = 0;

            Workbook wbExport = new Workbook(WorkbookFormat.Excel2007);
            Worksheet wsExport = wbExport.Worksheets.Add("Brands");

            //specify the default font family
            Infragistics.Documents.Excel.IWorkbookFont defaultFont = wbExport.Styles.NormalStyle.StyleFormat.Font;
            defaultFont.Name = "Calibri";
            defaultFont.Height = 11 * 20;

            intRowIndex = 0;
            intColIndex = 0;

            #region column headers
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "ID", 70.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Name", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Business Segment", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Abbreviation", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "RAS Segment", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Suffix", 150, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Street Name 1", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Street Name 2", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11, WrapText: false);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Street Name 3", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Show Series # in Logo Badge C Cover", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Show Series # in Brand Name", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "State", 110.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            #endregion

            intRowIndex = 1;
            intColIndex = 0;
            System.Drawing.ColorConverter cc = new System.Drawing.ColorConverter();
            foreach (DataRow drData in dsList.Tables[0].Rows)
            {
                intColIndex = 0;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["ID"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["Name"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["BusinessSegment"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["Abbreviation"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["RasSegment"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["Suffix"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["StreetName"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["StreetName2"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["StreetName3"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["ShowSeriesNumberInLogoBadge"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["ShowSeriesNumberInBrandname"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["State"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                intRowIndex++;
            }

            string strFileName = "";
            strFileName = "Brands_" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString().PadLeft(2, '0').ToString() + DateTime.Now.Day.ToString().PadLeft(2, '0').ToString();
            Response.Clear();
            Response.AppendHeader("content-disposition", "attachment; filename=" + strFileName + ".xlsx");
            Response.ContentType = "application/octet-stream";
            wbExport.Save(Response.OutputStream);
            Response.End();
        }
    }
}
