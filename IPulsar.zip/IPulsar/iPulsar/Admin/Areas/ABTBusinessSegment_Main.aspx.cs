﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;

public partial class Admin_ABTBusinessSegment_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() will make sure you are who you are 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession();

        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "ABT Business Segment";
        Page.Title = "ABT Business Segment";

        gridPopulate();
        GetPermission();
    }

    private void gridPopulate()
    {
        try
        {
            DataSet ds;
            AdminABTBusinessSegmentBLL adBll = new AdminABTBusinessSegmentBLL();
            ds = adBll.GetAllBusinessSegment();

            BindGridData(ds);
            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }

    private void BindGridData(DataSet ds)
    {
        wdgABTBusinessSegment.Rows.Clear();
        wdgABTBusinessSegment.DataSource = ds;
        wdgABTBusinessSegment.DataBind();
    }
    protected void wdgABTBusinessSegment_OnInitializeRow(object sender, RowEventArgs e)
    {
        string ABTBusinessSegmentID = e.Row.DataKey[0].ToString();
        string sName = e.Row.Items.FindItemByKey("SegmentName").Value.ToString();
        e.Row.Items.FindItemByKey("SegmentName").Text = "<a onclick=\"return OpenBSEditPopUp('ABTBusinessSegment_Edit.aspx?mode=update&SegmentID=" + ABTBusinessSegmentID + "');\">" + sName + "</a>";
    }
    private bool DeleteRecord()
    {
        bool b = false;
        int ABTBusinessSegmentID = 0;
        ABTBusinessSegmentID = Convert.ToInt32(hdnABTBusinessSegmentID.Value);
        //no long need to check for session expired
        AdminABTBusinessSegmentBLL avb = new AdminABTBusinessSegmentBLL();
        avb.DeleteBusinessSegment(ABTBusinessSegmentID);
        b = true;
        return b;
    }
    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ABTReport_Edit_Permission.ToString()))
        {
            Page.Title = "View ABT Business Segment List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }
    protected void btnDeleteABTBusinessSegment_Click(object sender, EventArgs e)
    {
        try
        {
            DeleteRecord();
            gridPopulate();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnRefeshGrid_Click(object sender, EventArgs e)
    {
        gridPopulate();
    }
}

