﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Telerik.Web.UI;
using System.Text;
using Infragistics.Web.UI.GridControls;

public partial class Admin_Areas_NamingStandard_Edit : System.Web.UI.Page
{
    public String ValidString = "";
    public String SaveSortOrder = "";
    private DataSet FieldList
    {
        get
        {
            return (DataSet)Session["NamingStandard_FieldListDS"];
        }
        set
        {
            Session["NamingStandard_FieldListDS"] = value;
        }
    }

    private int NamingStandardID
    {
        get
        {
            return Convert.ToInt32(Session["NamingStandard_NamingStandardID"]);
        }
        set { Session["NamingStandard_NamingStandardID"] = value; }

    }

    private string Mode
    {
        get
        {
            return Convert.ToString(Session["NamingStandard_Mode"]);
        }
        set
        {
            Session["NamingStandard_Mode"] = value;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Authenticate.ValidateSession(false);

            Page.Title = "Add Naming Standard";
            //master.HelpPageUrl = ""; // "~/Help/Admin/IRSAdminOnly/Help_ProductSegment_Main.aspx";

            if (!IsPostBack)
            {
                FieldList = null;
                NamingStandardID = 0;

                hdnCurrentUser.Value = UserInfo.GetCurrentUserName();
                hdnCurrentTime.Value = String.Format("{0:MMM d, yyyy h:mm tt}", DateTime.Now);
                lblError.Text = "";

                ValidString = Convert.ToString(GetGlobalResourceObject("RegularExpressions", "AllowedCharacters"));
                NamingStandardID = Convert.ToInt32(Request.QueryString.Get("NamingStandardID"));
                hdnNamingStandardID.Text = NamingStandardID.ToString();
                //we should only load first time so it will not save the same thing when save or clone
                LoadNamingStandard(NamingStandardID);
            }
            else
            {
                if (Request.QueryString.Get("NamingStandardID") != null && NamingStandardID == 0)
                    NamingStandardID = Convert.ToInt32(Request.QueryString.Get("NamingStandardID"));
            }

            GetFieldList(NamingStandardID);

            Mode = Convert.ToString(Request.QueryString.Get("mode"));
            if (Convert.ToString(Request.QueryString.Get("mode")) == "clone")
            {
                lnkAddnewField.Visible = false;
                btnCreateFormula.Visible = false;
                btnCreateReport.Visible = false;
                rcmNamingStandardFields.Visible = false;
            }
            else
            {
                lnkAddnewField.Visible = true;
                btnCreateFormula.Visible = true;
                btnCreateReport.Visible = true;
                rcmNamingStandardFields.Visible = true;
            }

            if (Convert.ToString(Request.QueryString.Get("mode")) == "create")
            {
                btnCreateReport.Visible = false;
            }

            if (Convert.ToString(Request.QueryString.Get("mode")) == "update")
            {
                Page.Title = "Modify Naming Standard";
            }

            GetPermission();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
            btnMainSave.Enabled = false;
            txtNamingStandard.Enabled = false;
            rdbState.Enabled = false;
        }
    }

    private void GetPermission()
    {
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        //if (!Role.IsCurrentUserInRole(Enumeration.Enum_NamingStandard_Role.NamingStandard_Editor.ToString()))
        // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.NamingStandard_Edit_Permission.ToString()))
        {
            Page.Title = "View Naming Standard";
            DisableControls();
        }
        else if (txtNamingStandard.Text == "ByPassing" && !Permission.IsCurrentUserHasPermission(Resources.Permissions.AlternativeNamingStandard_Edit_Permission.ToString()))
        {
            Page.Title = "View Naming Standard";
            DisableControls();
        }
    }
    private Boolean IsModeUpdate()
    {
        if (Convert.ToString(Mode) == "update")
            return true;
        else
            return false;
    }
    private Boolean IsModeCreate()
    {
        if (Convert.ToString(Mode) == "create")
            return true;
        else
            return false;
    }

    private void FillCurrentUserInfo()
    {
        lblTimeCreated.Text = String.Format("{0:MMM d, yyyy h:mm tt}", DateTime.Now);
        lblTimeChanged.Text = String.Format("{0:MMM d, yyyy h:mm tt}", DateTime.Now);
        lblCreator.Text = UserInfo.GetCurrentUserName();
        lblUpdater.Text = UserInfo.GetCurrentUserName();
    }

    private void LoadNamingStandard(int intNamingStandardID)
    {
        if (intNamingStandardID == -1)
        {
            FillCurrentUserInfo();
        }
        else
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();

            DataSet dsNamingStandard = new DataSet();
            dsNamingStandard = da.GetNamingStandards(intNamingStandardID);
            if (dsNamingStandard.Tables.Count > 0)
            {
                foreach (DataRow dr in dsNamingStandard.Tables[0].Rows)
                {
                    txtNamingStandard.Text = Convert.ToString(dr["Name"]);
                    if (dr["Active"].ToString() == "Inactive")
                        rdbState.SelectedValue = "0";
                    else if (dr["Active"].ToString() == "Active")
                        rdbState.SelectedValue = "1";
                    if (dr["ShorterName"].ToString() == "No")
                        chkShortName.Checked = false;
                    else if (dr["ShorterName"].ToString() == "Yes")
                        chkShortName.Checked = true;
                    if (Mode.Equals("clone"))
                    {
                        FillCurrentUserInfo();
                    }
                    else
                    {
                        lblTimeCreated.Text = String.Format("{0:MMM d, yyyy h:mm tt}", dr["Created"]);
                        lblTimeChanged.Text = String.Format("{0:MMM d, yyyy h:mm tt}", dr["Updated"]);
                        lblCreator.Text = Convert.ToString(dr["CreatedBy"]);
                        lblUpdater.Text = Convert.ToString(dr["UpdatedBy"]);
                    }

                }
            }

        }
    }
    private void LoadFieldList()
    {
        Grid_FieldList.DataSource = FieldList;
        Grid_FieldList.DataBind();
        hdnNextSortOrder.Value = (((DataSet)FieldList).Tables[0].Rows.Count + 1).ToString();
    }
    private void GetFieldList(int intNamingStandardID)
    {
        if (FieldList == null)
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            DataSet dsFieldList = new DataSet();
            dsFieldList = da.GetNamingStandardFields(intNamingStandardID);
            FieldList = dsFieldList;
        }

        LoadFieldList();
    }

    private void DisableControls()
    {
        btnMainSave.Enabled = false;
        txtNamingStandard.Enabled = false;
        rdbState.Enabled = false;
        rcmNamingStandardFields.Items.FindItemByValue("Add").Enabled = false;
        rcmNamingStandardFields.Items.FindItemByValue("Delete").Enabled = false;
        //lnkAddnewField.Visible = false;
        lnkAddnewField.Disabled = true;
        lnkAddnewField.Attributes["Class"] = "disabled";
        btnCreateFormula.Text = "View Formula";
    }
    private string GetFieldValues()
    {
        int intSortOrder = 0;
        intSortOrder = Grid_FieldList.MasterTableView.Items.Count;

        StringBuilder strFieldValues = new StringBuilder();
        strFieldValues.Append("<?xml version='1.0'?>");
        strFieldValues.Append("<FieldList>");
        foreach (GridItem gi in Grid_FieldList.Items)
        {
            strFieldValues.Append("<FieldValues>");

            strFieldValues.Append("<FieldID>" + Convert.ToInt32(Grid_FieldList.MasterTableView.Items[gi.ItemIndex].GetDataKeyValue("FieldID")) + "</FieldID>");

            if (Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["TypeofField"].Text.Trim() == "Text box")
                strFieldValues.Append("<FieldType>1</FieldType>");
            else
                strFieldValues.Append("<FieldType>2</FieldType>");

            strFieldValues.Append("<TextName>" + Tools.replaceXMLChars(Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["FieldName"].Text.Trim()) + "</TextName>");

            if (Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["TextBoxLength"].Text.Trim() == "&nbsp;")
                strFieldValues.Append("<TextLength>0</TextLength>");
            else
                strFieldValues.Append("<TextLength>" + Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["TextBoxLength"].Text.Trim() + "</TextLength>");

            if (Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["DropDownID"].Text.Trim() == "&nbsp;")
                strFieldValues.Append("<DropDownID>0</DropDownID>");
            else
                strFieldValues.Append("<DropDownID>" + Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["DropDownID"].Text.Trim() + "</DropDownID>");

            if (Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["Required"].Text.Trim() == "Yes")
                strFieldValues.Append("<Required>1</Required>");
            else if (Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["Required"].Text.Trim() == "No")
                strFieldValues.Append("<Required>0</Required>");

            if (Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["Instructions"].Text.Trim() == "&nbsp;")
                strFieldValues.Append("<Instructions></Instructions>");
            else
                strFieldValues.Append("<Instructions>" + Tools.replaceXMLChars(Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["Instructions"].Text.Trim()) + "</Instructions>");

            strFieldValues.Append("<SortOrder>" + Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["SortOrder"].Text.Trim() + "</SortOrder>");

            strFieldValues.Append("<Status>" + Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["Status"].Text.Trim() + "</Status>");

            strFieldValues.Append("</FieldValues>");
        }
        strFieldValues.Append("</FieldList>");


        return strFieldValues.ToString();
    }

    private void SortOrderRecal()
    {
        try
        {
            DataSet dsFieldList = FieldList;
            dsFieldList.Tables[0].PrimaryKey = new DataColumn[] { dsFieldList.Tables[0].Columns["FieldID"] };
            string strFieldID = "";
            foreach (GridDataItem di in Grid_FieldList.Items)
            {
                strFieldID = Convert.ToString(di.GetDataKeyValue("FieldID"));
                DataRow dr = dsFieldList.Tables[0].Rows.Find(strFieldID);
                dr["SortOrder"] = di.ItemIndex + 1;
                if (Convert.ToString(dr["Status"]) == "Existing")
                    dr["Status"] = "Update";
            }
            LoadFieldList();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private int NewFieldID()
    {
        int intFieldID = -1;
        if (((DataSet)FieldList).Tables[0].Rows.Count > 0)
            intFieldID = Convert.ToInt32(((DataSet)FieldList).Tables[0].Compute("max(FieldID)", "")) + 1;
        else
            intFieldID = 1;
        return intFieldID;
    }
    private int GetSortOrder()
    {
        int SortOrder = -1;
        if (((DataSet)FieldList).Tables[0].Rows.Count > 1)
            SortOrder = Convert.ToInt32(((DataSet)FieldList).Tables[0].Compute("max(SortOrder)", "")) + 1;
        else
            SortOrder = 1;
        return SortOrder;
    }
    private void DeleteFields(string strFieldID)
    {
        char[] delimiterChars = { ',' };
        String[] FieldIDList = strFieldID.Split(delimiterChars);
        DataSet dsFieldList = FieldList;
        dsFieldList.Tables[0].PrimaryKey = new DataColumn[] { dsFieldList.Tables[0].Columns["FieldID"] };
        foreach (string FieldID in FieldIDList)
        {
            DataRow dr = dsFieldList.Tables[0].Rows.Find(FieldID);
            dsFieldList.Tables[0].Rows.Remove(dr);
        }
    }

    private void EnableMainButtons()
    {
        btnMainSave.Enabled = true;
        // btnReturn.Enabled = true;

        foreach (GridDataItem gdi in Grid_FieldList.MasterTableView.Items)
        {
            gdi["EditItem"].Enabled = true;
        }
        lblError.Text = "";
        lblError.Visible = false;
    }
    private void DisableMainButtons()
    {
        btnMainSave.Enabled = false;
        //btnReturn.Enabled = false;      
        foreach (GridDataItem gdi in Grid_FieldList.MasterTableView.Items)
        {
            gdi["EditItem"].Enabled = false;
            gdi["EditItem"].Style.Add("cursor", "pointer");
        }

    }

    protected void btnMainSave_Click(object sender, EventArgs e)
    {
        AdminNamingStandardBAL da = new AdminNamingStandardBAL();
        int intNamingStandardID; string strName; int intActive; string strTimeCreated; string strTimeChanged; int intShorterName;
        //string strDeleteField = ""; string strNewDeleteField = "";
        string strModifyFields = "";
        intNamingStandardID = NamingStandardID;

        try
        {
            strName = txtNamingStandard.Text.Trim();
            intActive = Convert.ToInt32(rdbState.SelectedValue);
            strTimeCreated = lblTimeCreated.Text.Trim();
            strTimeChanged = DateTime.Now.ToString();
            intShorterName = Convert.ToInt32(chkShortName.Checked);

            strModifyFields = GetFieldSortOrder();

            //add or modify fields
            if (Mode.Equals("clone"))
            {
                int intCloningID = NamingStandardID;
                intNamingStandardID = -1;
                NamingStandardID = Convert.ToInt32(da.NamingStandardClone(intNamingStandardID, strName, intActive, UserInfo.GetCurrentUserName(), intShorterName, intCloningID));
            }
            else
            {
                NamingStandardID = Convert.ToInt32(da.NamingStandardModify(intNamingStandardID, strName, intActive, UserInfo.GetCurrentUserName(), intShorterName));
            }


            da.SortOrderRecal(NamingStandardID, strModifyFields);

            hdnNSModified.Value = "0";

            // close NamingStandardEdit page and refresh NamingStandardMain page only when "SAVE" button is clicked 
            if (SaveSortOrder != "1")
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadnamingstandard", "CloseNSEditPopup(true)", true);
            }

            //set it to null so parent list will reload after edit window is closed
            Session["NamingStandardTable"] = null;
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
            Session["NamingStandard_FieldListDS"] = null;
            LoadNamingStandard(intNamingStandardID);
        }
    }
    protected void GridFieldList_RowDrop(object sender, GridDragDropEventArgs e)
    {
        try
        {
            GridDataItem diRowDragged = e.DraggedItems.FirstOrDefault();
            DataSet dsFieldList = FieldList;
            DataTable dtFieldList = dsFieldList.Tables[0];
            dtFieldList.PrimaryKey = new DataColumn[] { dtFieldList.Columns["FieldID"] };
            int intFieldID = -1;
            int intDestIndex = -1;
            if (e.DestDataItem == null)
            {
                lblError.Text = "Please Drag the item within the grid.";
                lblError.Visible = true;
            }
            else if (diRowDragged.OwnerTableView.Name == "mtvFieldList")
            {
                intFieldID = Convert.ToInt32(diRowDragged.GetDataKeyValue("FieldID"));
                DataRow drField = dtFieldList.Rows.Find(intFieldID);
                intDestIndex = e.DestDataItem.ItemIndex;

                if (e.DropPosition == GridItemDropPosition.Above)
                {
                    if (e.DestDataItem.ItemIndex > e.DraggedItems[0].ItemIndex)
                        intDestIndex = intDestIndex - 1;
                }
                if (e.DropPosition == GridItemDropPosition.Below && e.DestDataItem.ItemIndex < e.DraggedItems[0].ItemIndex)
                {
                    intDestIndex = intDestIndex + 1;
                }

                DataRow drNewRow = dtFieldList.NewRow();
                drNewRow["FieldID"] = drField["FieldID"];
                drNewRow["FieldName"] = drField["FieldName"];
                drNewRow["FieldType"] = drField["FieldType"];
                drNewRow["Required"] = drField["Required"];
                drNewRow["Instructions"] = drField["Instructions"];
                drNewRow["DropDownValues"] = drField["DropDownValues"];
                drNewRow["UseInRoot"] = drField["UseInRoot"];
                drNewRow["UseInFeature"] = drField["UseInFeature"];
                drNewRow["Active"] = drField["Active"];
                drNewRow["SortOrder"] = drField["SortOrder"];
                drNewRow["TextLength"] = drField["TextLength"];
                drNewRow["Status"] = drField["Status"];
                dtFieldList.Rows.Remove(drField);
                dtFieldList.Rows.InsertAt(drNewRow, intDestIndex);
                FieldList = dsFieldList;
                LoadFieldList();
                SortOrderRecal();
                hdnNSModified.Value = "1";
                lblError.Text = "";
                lblError.Visible = false;
                //save the sort order immediately after drag drop
                SaveSortOrder = "1";
                btnMainSave_Click(sender, e);
            }
        }
        catch (Exception ex)
        {
            lblError.Visible = true;
            lblError.Text = ex.Message;
        }
    }
    private string GetFieldSortOrder()
    {
        int intSortOrder = 0;
        intSortOrder = Grid_FieldList.MasterTableView.Items.Count;

        StringBuilder strFieldValues = new StringBuilder();
        strFieldValues.Append("<?xml version='1.0'?>");
        strFieldValues.Append("<FieldList>");
        foreach (GridItem gi in Grid_FieldList.Items)
        {
            strFieldValues.Append("<FieldValues>");

            strFieldValues.Append("<FieldID>" + Convert.ToInt32(Grid_FieldList.MasterTableView.Items[gi.ItemIndex].GetDataKeyValue("FieldID")) + "</FieldID>");
            strFieldValues.Append("<SortOrder>" + Grid_FieldList.MasterTableView.Items[gi.ItemIndex]["SortOrder"].Text.Trim() + "</SortOrder>");
            strFieldValues.Append("</FieldValues>");
        }
        strFieldValues.Append("</FieldList>");


        return strFieldValues.ToString();
    }

    protected void btnRefreshFieldList_Click(object sender, EventArgs e)
    {
        int intNamingStandardId = 0;
        intNamingStandardId = Convert.ToInt32(hdnNamingStandardID.Text.Trim());
        GetFieldList(intNamingStandardId);
    }
    protected void Grid_FieldList_ItemDataBound(object sender, GridItemEventArgs e)
    {
        if (e.Item is GridDataItem)
        {
            GridDataItem gdi = (GridDataItem)e.Item;
            string strFieldID = gdi.GetDataKeyValue("FieldID").ToString();

            string strFieldType = gdi["TypeofField"].Text;
            if (Mode.Equals("clone"))
            {
                gdi["FieldName"].Text = gdi["FieldName"].Text;
            }
            else if (txtNamingStandard.Text == "ByPassing" && !Permission.IsCurrentUserHasPermission(Resources.Permissions.AlternativeNamingStandard_Edit_Permission.ToString()))
            {
                gdi["FieldName"].Text = "<a onclick=\"return OpenNSFieldEdit('NamingStandardFields_Edit.aspx?mode=view&NamingStandardID=" + hdnNamingStandardID.Text + "&FieldID=" + strFieldID + "' , '" + strFieldType + "');\">" + gdi["FieldName"].Text + "</a>";
            }
            else
            {
                gdi["FieldName"].Text = "<a onclick=\"return OpenNSFieldEdit('NamingStandardFields_Edit.aspx?mode=update&NamingStandardID=" + hdnNamingStandardID.Text + "&FieldID=" + strFieldID + "' , '" + strFieldType + "');\">" + gdi["FieldName"].Text + "</a>";
            }


        }
    }
    protected void btnDeleteField_Click(object sender, EventArgs e)
    {
        int intNamingStandardID = 0;
        intNamingStandardID = Convert.ToInt32(hdnNamingStandardID.Text.Trim());
        int intFieldID = 0;
        intFieldID = Convert.ToInt32(hdnFieldID.Value.Trim());

        AdminNamingStandardBAL da = new AdminNamingStandardBAL();
        try
        {
            da.NamingStandardFieldDelete(intNamingStandardID, intFieldID);
            FieldList = null;
            btnRefreshFieldList_Click(null, null);
        }
        catch (Exception ex)
        {
            lblError.Visible = true;
            lblError.Text = ex.Message;
        }

    }

}