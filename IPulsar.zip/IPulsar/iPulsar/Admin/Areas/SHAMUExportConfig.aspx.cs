﻿using System;
using System.Data;
using System.Web.Services;

public partial class Admin_SHAMU_Export_PDConfig : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() will make sure you are who you are 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        if (!IsPostBack)
        {
            LoadMOLListTree();   
       
        }
    }

    private int ODMID
    {
        get
        {
            if (ViewState["ODMID"] != null)
                return Int32.Parse(ViewState["ODMID"].ToString());
            else return 0;
        }
        set
        {
            ViewState["ODMID"] = value.ToString();
        }
    }


    protected void UWT_NodeBound(object sender, Infragistics.WebUI.UltraWebNavigator.WebTreeNodeEventArgs e)
    {
        if (e.Node.Level != 3)
        {
            if (e.Node.Checked)
                e.Node.Expand(true);
            e.Node.Checked = false;
        }
    }

    private void LoadMOLListTree()
    {
        string strErrmsg = "";
        
        PRLBLL da = new PRLBLL();
        DataSet ds = da.PRL_GetTree();
        try
        {
            ds.Relations.Add("pl_pf",
            ds.Tables[0].Columns["divisionID"],
            ds.Tables[1].Columns["divisionID"]);
            ds.Relations.Add("pf_p",
            ds.Tables[1].Columns["div_py"],
            ds.Tables[2].Columns["div_py"]);
            ds.Relations.Add("project_List",
            ds.Tables[2].Columns["projectID"],
            ds.Tables[3].Columns["projectID"]);
        }
        catch (System.Exception x)
        {
            strErrmsg = x.Message;
        }
        this.UWTMOL.Levels[0].RelationName = "pl_pf";
        this.UWTMOL.Levels[1].RelationName = "pf_p";
        this.UWTMOL.Levels[2].RelationName = "project_List";

        this.UWTMOL.Levels[0].LevelKeyField = "divisionID";
        this.UWTMOL.Levels[1].LevelKeyField = "PYID";
        this.UWTMOL.Levels[2].LevelKeyField = "projectID";
        this.UWTMOL.Levels[3].LevelKeyField = "PRLREvisionID";
        this.UWTMOL.Levels[0].CheckboxColumnName = "bhaschildren";
        this.UWTMOL.Levels[1].CheckboxColumnName = "bhaschildren";
        this.UWTMOL.Levels[2].CheckboxColumnName = "bhaschildren";
        this.UWTMOL.Levels[0].ColumnName = "Label";
        this.UWTMOL.Levels[1].ColumnName = "Label";
        this.UWTMOL.Levels[2].ColumnName = "Label";
        this.UWTMOL.Levels[3].ColumnName = "Label";
        this.UWTMOL.Levels[3].CheckboxColumnName = "ShamuInclude";

        UWTMOL.DataSource = ds.Tables[0].DefaultView;
        UWTMOL.DataBind();

        
    }

    [WebMethod(EnableSession = true)]
    public static string SaveConfiguredPRLs(string sPRLList)
    {
      
        PRLBLL da = new PRLBLL();
        
        string strReturnMsg = "";
        try
        {
            da.SHAMUExport_SaveSelectedPRLs(sPRLList);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strReturnMsg = ex.Message;
        }
        return strReturnMsg;
    }
}
