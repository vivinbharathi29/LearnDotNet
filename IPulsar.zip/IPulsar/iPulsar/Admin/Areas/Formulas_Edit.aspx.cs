﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;
using System.Web.Script.Services;
using Infragistics.Web.UI.GridControls;
using System.Text;

public partial class Admin_Areas_Formulas_Edit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        if (!IsPostBack)
        {
            hdnNSID.Value = Request.QueryString.Get("NSID").ToString();
            hdnIsShortName.Value = Request.QueryString.Get("IsShortName").ToString();
            GetPermission();
            LoadFormulaName();
        }
    }
    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.NamingStandard_Edit_Permission.ToString()))
        {
            Page.Title = "View Formula";
            DisableControls();
        }
    }
    private void DisableControls()
    {
        btnSave.Enabled = false;
        lnkImportFormula.Disabled = true;
        lnkImportFormula.Attributes["Class"] = "disabled";
        hdnCanEdit.Value = "0";

    }
    private void LoadFormulaName()
    {
        DataSet ds = new DataSet();
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            ds = da.GetAllFormulaName(Int32.Parse(hdnNSID.Value));
            ddlFormulaName.DataSource = ds;
            ddlFormulaName.DataTextField = "Name";
            ddlFormulaName.DataValueField = "FormulaNameID";
            ddlFormulaName.DataBind();

            ddlFormulaName.Items.Insert(0, new ListItem("Select a formula name", "0"));
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetAllNSFormulaNames(int intNamingStandardID)
    {
        DataSet ds = new DataSet();
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            ds = da.GetAllFormulaName(intNamingStandardID);

            List<Dictionary<string, string>> lstNSFormulaName = new List<Dictionary<string, string>>();
            Dictionary<string, string> dicNSFormulaName = null;
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                dicNSFormulaName = new Dictionary<string, string>();
                dicNSFormulaName.Add("NSFormulaNameID", ds.Tables[0].Rows[i]["FormulaNameID"].ToString());
                dicNSFormulaName.Add("NSFormulaName", ds.Tables[0].Rows[i]["Name"].ToString());

                lstNSFormulaName.Add(dicNSFormulaName);
            }
            return lstNSFormulaName;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetNSFields(int NamingStandardID, int FormulaNameID, int whichList, int intImportToFormulaNameID)
    {
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            DataSet ds = new DataSet();
            //ds = da.GetNamingStandardFields(NamingStandardID);
            ds = da.GetNamingStandardFieldsByFormulaNameID(NamingStandardID, FormulaNameID, intImportToFormulaNameID);

            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> Dictionary = null;

            for (int i = 0; i < ds.Tables[whichList].Rows.Count; i++)
            {
                Dictionary = new Dictionary<string, string>();
                Dictionary.Add("FieldID", ds.Tables[whichList].Rows[i]["FieldID"].ToString());
                Dictionary.Add("FieldValues", ds.Tables[whichList].Rows[i]["FixedLenghtFieldName"] + Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["FieldType"].ToString() + Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["Required"].ToString() +
                                                Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["FieldColumns"].ToString() + Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["FieldText"].ToString() +
                                                Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["FormulaID"].ToString() + Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["ColumnNumber"].ToString() +
                                                Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["AddSpace"].ToString() + Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["DD_Allowspecialchar"].ToString() +
                                                Char.ConvertFromUtf32(3) + ds.Tables[whichList].Rows[i]["DD_ColumnName"].ToString());  //total 10  separated values
                rows.Add(Dictionary);
            }
            if (whichList == 0)
            {
                Dictionary = new Dictionary<string, string>();
                Dictionary.Add("FieldID", "0");
                Dictionary.Add("FieldValues", "Text to add to formula" + Char.ConvertFromUtf32(3) + "Text box field" + Char.ConvertFromUtf32(3) + "No" + Char.ConvertFromUtf32(3) + "");
                rows.Add(Dictionary);
            }
            return rows;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetDropDownColumns(int intFieldID)
    {
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            DataSet ds = new DataSet();
            ds = da.NamingStandard_GetDropDownColumns(intFieldID);

            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                Dictionary.Add("ColumnValue", ds.Tables[0].Rows[i]["Value"].ToString());
                Dictionary.Add("ColumnText", ds.Tables[0].Rows[i]["Text"].ToString());
                rows.Add(Dictionary);
            }

            return rows;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static void SaveFormula(int intFormulaNameID, int intNamingStandardID, string strFieldList)
    {
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            da.SaveFormula(intFormulaNameID, intNamingStandardID, strFieldList, UserInfo.GetCurrentUserName());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }

    }
    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetFormulaNameByNamingStandardID(int intNamingStandardID)
    {
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            DataSet dsFormulaName = new DataSet();
            dsFormulaName = da.GetFormulaNameByNamingStandardID(intNamingStandardID);

            List<Dictionary<string, string>> lstFormulaName = new List<Dictionary<string, string>>();

            for (int i = 0; i < dsFormulaName.Tables[0].Rows.Count; i++)
            {
                Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                Dictionary.Add("FormulaNameID", dsFormulaName.Tables[0].Rows[i]["FormulaNameID"].ToString());
                Dictionary.Add("FormulaName", dsFormulaName.Tables[0].Rows[i]["Name"].ToString());
                lstFormulaName.Add(Dictionary);
            }
            return lstFormulaName;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod]
    public static string GetDropDownValueByColumnNumber(int intFieldID, int intColumnNumber)
    {
        string strDDValue = "";
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            strDDValue = da.GetDropDownValueByColumnNumber(intFieldID, intColumnNumber);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
        return strDDValue;
    }
    [WebMethod]
    public static int GetMaximumTextLength(int intFieldID)
    {
        DataSet dsField = new DataSet();

        int textBoxLength = 0;
        try
        {
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            dsField = da.GetNamingStandardFieldByFieldID(intFieldID);
            if (dsField.Tables[0].Rows.Count > 0)
            {
                textBoxLength = Convert.ToInt32(dsField.Tables[0].Rows[0]["TextLength"]);
            }
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }

        return textBoxLength;
    }

    [WebMethod]
    public static List<Dictionary<string, string>> GetMaximumFormulaNameLength(int intNamingStandardID, int intFormulaNameID, int intIsShortName)
    {
        try
        {
            List<Dictionary<string, string>> lst = new List<Dictionary<string, string>>();

            DataSet ds = new DataSet();
            AdminNamingStandardBAL da = new AdminNamingStandardBAL();
            ds = da.GetMaximumFormulaNameLength(intNamingStandardID, intFormulaNameID, intIsShortName);


            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                Dictionary<string, string> dict = new Dictionary<string, string>();
                dict.Add("MaxLength", ds.Tables[0].Rows[i]["MaxLength"].ToString());
                dict.Add("ComponentorFeature", ds.Tables[0].Rows[i]["ComponentorFeature"].ToString());
                lst.Add(dict);
            }
            return lst;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}