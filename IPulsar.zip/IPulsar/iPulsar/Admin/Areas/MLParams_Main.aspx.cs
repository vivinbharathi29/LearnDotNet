﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;
using System.Web.Services;


public partial class SystemAdmin_MLParams_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "MLParams Cross Reference for ATF";
        Page.Title = "MLParams Cross Reference for ATF";
        GetPermission();
    }

    private void GetPermission()
    {  // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.MLParam_Edit_Permission.ToString()))
        {
            Page.Title = "View MLParams List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }

        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Partner_Delete_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetMLParams()
    {
        try
        {
            List<Dictionary<string, object>> dicList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicMLParam = null;
            AdminMLParamsBLL da = new AdminMLParamsBLL();
            DataSet dsList = new DataSet();
            dsList = da.GetMLParams(-1);
            for (int i = 0; i < dsList.Tables[0].Rows.Count; i++)
            {
                dicMLParam = new Dictionary<string, object>();
                dicMLParam.Add("MLParamID", dsList.Tables[0].Rows[i]["MLParamID"].ToString());
                dicMLParam.Add("OSFlag", dsList.Tables[0].Rows[i]["OSFlag"].ToString());
                dicMLParam.Add("MLNameValue", dsList.Tables[0].Rows[i]["MLNameValue"].ToString());

                dicList.Add(dicMLParam);
            }
            return dicList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static List<string> GetUserPermission()
    {
        try
        {
            return Permission.GetUserPermissions(UserInfo.GetCurrentUserID());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static string RemoveMLParam(int ID)
    {
        string strReturnMsg = "MLParams successfully removed.";
        try
        {
            AdminMLParamsBLL da = new AdminMLParamsBLL();
            da.DeleteMLParam(ID);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strReturnMsg = ex.Message;
        }
        return strReturnMsg;
    }
}

