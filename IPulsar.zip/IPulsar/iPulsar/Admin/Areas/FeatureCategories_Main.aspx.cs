﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;
using System.Web.Services;


public partial class Admin_Areas_ModuleHWParentCategory_Main : System.Web.UI.Page
{
    //static DataTable dtAdminModuleParentHW;
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (string.Equals(Request.QueryString["isPopup"], "true", StringComparison.OrdinalIgnoreCase))
        {
            MasterPageFile = "~/MasterPages/MainMasterPopup.master";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession();

        Page.Title = "Feature Categories";
        lblHeader.Text = "Feature Categories";

        if (!IsPostBack)
        {
            Session["FeatureCategoryList"] = null;
            FillComponentcategoryEditor();
        }

        gridPopulate();
        GetPermission();
    }

    private void gridPopulate()
    {
        try
        {
            if (Session["FeatureCategoryList"] == null)
            {
                DataSet ds;
                AdminFeatureCategoryBLL adBll = new AdminFeatureCategoryBLL();
                ds = adBll.GetAllFeatureCategory();
                Session["FeatureCategoryList"] = ds;
            }

            BindGridData();
            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void BindGridData()
    {
        DataSet ds;
        ds = (DataSet)Session["FeatureCategoryList"];
        wdgFeatureCategory.Rows.Clear();
        lock (ds)
        {
            ds.Tables[0].PrimaryKey = new DataColumn[] { ds.Tables[0].Columns["FeatureCategoryId"] };
            wdgFeatureCategory.DataSource = ds;
            wdgFeatureCategory.DataBind();
        }
    }

    protected void wdgFeatureCategory_OnInitializeRow(object sender, RowEventArgs e)
    {
        string FeatureCategoryID = e.Row.DataKey[0].ToString();
        string sName = e.Row.Items.FindItemByKey("Name").Value.ToString();
        e.Row.Items.FindItemByKey("Name").Text = "<a onclick=\"return OpenFCEditPopUp('FeatureCategories_Edit.aspx?mode=update&CategoryID=" + FeatureCategoryID + "');\">" + sName + "</a>";
    }

    private bool DeleteRecord()
    {
        bool b = false;
        int intFeatureCategoryID = 0;
        intFeatureCategoryID = Convert.ToInt32(hdnFeatureCategoryID.Value);
        AdminFeatureCategoryBLL avb = new AdminFeatureCategoryBLL();
        avb.DeleteFeatureCategory(intFeatureCategoryID);
        b = true;
        //set to null so on postback it will rebind the grid with new data from database
        Session["FeatureCategoryList"] = null;

        return b;
    }

    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.FeatureCategory_Edit_Permission.ToString()))
        {
            Page.Title = "View Feature Category List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
            //disable the editing for component category linkage
            wdgFeatureCategory.Behaviors.EditingCore.Behaviors.CellEditing.ColumnSettings[3].ReadOnly = true;

        }
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.FeatureCategory_Delete_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }
    protected void btnDeleteFeatureCategory_Click(object sender, EventArgs e)
    {
        try
        {
            DeleteRecord();
            gridPopulate();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnRefeshGrid_Click(object sender, EventArgs e)
    {
        gridPopulate();
    }



    private void FillComponentcategoryEditor()
    {
        DataSet ds;
        AdminComponentCategoryBLL adBll = new AdminComponentCategoryBLL();
        try
        {
            ds = adBll.GetAllComponentCategory();
            DataView dv;
            dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "State = 'Active'";
            ComponentCategoryProvider.EditorControl.DataSource = dv;
            ComponentCategoryProvider.EditorControl.DataBind();
            Infragistics.Web.UI.ListControls.DropDownItem itemEmpty = new Infragistics.Web.UI.ListControls.DropDownItem();
            itemEmpty.Text = "";
            itemEmpty.Value = "0";
            ComponentCategoryProvider.EditorControl.Items.Insert(0, itemEmpty);
            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }


    }
    [WebMethod]
    public static string UpdateFeature_Component_CategoryLinkage(int intFeatureCategoryID, int intComponentCategoryID)
    {
        string strMsg = "";
        try
        {
            AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
            da.FeatureCategory_SaveComponentCategoryLink(intFeatureCategoryID, intComponentCategoryID, UserInfo.GetCurrentUserName().ToString());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strMsg = ex.Message;
        }
        return strMsg;
    }
}

