﻿using iPulsar.Old_App_Code.BLL.Admin;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.Areas
{
    public partial class InstallOption_Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession(false);

            string mode;
            mode = Request.QueryString["mode"];

            if (!IsPostBack)
            {
                int ID = Convert.ToInt32(Request.QueryString["IOID"]);
              

                if ((mode == "update"))
                {
                    // DMIString should not be editable - 17359
                    this.txtDMIString.Enabled = false;
                    LoadInstallOption(ID);
                    Page.Title = "Modify Existing Install Option";
                    GetPermission();
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Install Option";
                    pnlHistory.Visible = false;
                    GeneratedDMICode();
                }



            }
        }

        private void LoadInstallOption(int IOID)
        {
            InstallOptionBLL da = new InstallOptionBLL();
            DataSet ds;
            ds = da.GetSelectedInstallOption(IOID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {

                DataRow dr = ds.Tables[0].Rows[0];
                txtDMIString.Text = dr["DMIString"].ToString();
                txtDMICode.Text = dr["DMICode"].ToString();
                txtFieldDesc.Text = dr["Description"].ToString();
                chkChannelpartner.Checked = Convert.ToBoolean(dr["Channelpartner"].ToString());
                rbStandAlone.SelectedValue = dr["AllowStandAlone"].ToString();
                rbStatus.SelectedValue = dr["State"].ToString();
               
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                ds.Dispose();
                pnlHistory.Visible = true;
                if (txtDMIString.Text =="")
                    this.txtDMIString.Enabled = true;

            }



        }


        private void GeneratedDMICode()
        {
            InstallOptionBLL da = new InstallOptionBLL();
            DataSet ds;
            ds = da.GeneratedDMICode();
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {

                DataRow dr = ds.Tables[0].Rows[0];
                txtDMICode.Text = dr["DMICode"].ToString();
                hdnDMICodeNumber.Value = dr["DMICodeNumber"].ToString();
                ds.Dispose();
            }



        }



        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.AdminInstallOption_Edit_Permission.ToString()))
            {
                Page.Title = "View Install Option";
                this.txtDMIString.Enabled = false;
                this.txtDMICode.Enabled = false;
                this.txtFieldDesc.Enabled = false;
                this.btnSave.Enabled = false;
                this.rbStandAlone.Enabled = false;
                this.rbStatus.Enabled = false;
                this.lblEnter.Visible = false;
            }
        }



        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strDMICode = "";
            string strDMICodeNumber = "";
            string strDMIString = "";
            string strDescription = "";
            int intSetInactive = 1;
            int intAllowStandAlone = 0;
            int intInstallOptionId = 0;
            int intChannelpartner = 0;
            if (chkChannelpartner.Checked)
                intChannelpartner = 1;

            InstallOptionBLL da = new InstallOptionBLL();
            try
            {
                strDMICode = txtDMICode.Text.ToString();
                strDMIString = txtDMIString.Text.ToString();
                strDescription = txtFieldDesc.Text.ToString();
                intAllowStandAlone = Convert.ToInt32(rbStandAlone.SelectedValue);
                if (Request.QueryString["IOID"] != null)
                {
                    intInstallOptionId = Convert.ToInt32(Request.QueryString["IOID"].ToString());
                }
                else
                {
                    intInstallOptionId = -1;
                }
                strDMICodeNumber = hdnDMICodeNumber.Value.ToString();


                intSetInactive = Convert.ToInt32(rbStatus.SelectedValue);

                intInstallOptionId = da.UpdateInstallOption(intInstallOptionId, strDMICode, strDMICodeNumber, strDMIString, strDescription, intAllowStandAlone, intSetInactive, UserInfo.GetCurrentUserName(), intChannelpartner);



                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadInstallOption", "CloseIOEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        } 

    }
}