﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;
using System.Web.Services;

public partial class Admin_Areas_BrandFormula_DropDownValues : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
    }
    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetStreetNames(int BrandID)
    {
        try
        {
            List<Dictionary<string, object>> dicList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dic = null;
            AdminBrandsBLL da = new AdminBrandsBLL();
            DataSet dsList = new DataSet();
            dsList = da.GetBrands(BrandID);
            dic = new Dictionary<string, object>();
            dic.Add("StreetName1", dsList.Tables[0].Rows[0]["StreetName"].ToString());
            dic.Add("StreetName2", dsList.Tables[0].Rows[0]["StreetName2"].ToString());
            dic.Add("StreetName3", dsList.Tables[0].Rows[0]["StreetName3"].ToString());
            dicList.Add(dic);
            return dicList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}