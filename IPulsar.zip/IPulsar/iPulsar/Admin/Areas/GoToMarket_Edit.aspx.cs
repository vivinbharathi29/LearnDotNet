﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iPulsar.Old_App_Code.BLL.Admin;
using System.Data;

namespace iPulsar.Admin.Areas
{
    public partial class GoToMarket_Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession(false);

            string mode;
            mode = Request.QueryString["mode"];

            if (!IsPostBack)
            {
                int ID = Convert.ToInt32(Request.QueryString["GoToMarketId"]);
                GetGeoValues();

                if ((mode == "update"))
                {
                    LoadGoToMarket(ID);
                    GetPermission();
                }
                else if (mode == "create")
                {
                    pnlHistory.Visible = false;
                }
            }
        }
        private void LoadGoToMarket(int ID)
        {
            AdminGoToMarketBLL da = new AdminGoToMarketBLL();
            DataSet ds;
            ds = da.GetGoToMarket(ID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                txtName.Text = dr["GTMName"].ToString();

                rbStatus.ClearSelection();
                rbStatus.Items.FindByValue(Convert.ToBoolean(dr["State"]) ? "1" : "0").Selected = true;

                ddlGeo.ClearSelection();
                ddlGeo.Items.FindByValue(dr["GeoId"].ToString()).Selected = true;
                
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }
        private void GetGeoValues()
        {
            AdminGoToMarketBLL da = new AdminGoToMarketBLL();
            DataSet ds = new DataSet();
            ds = da.GetGeoValues();
            ddlGeo.DataSource = ds;
            ddlGeo.DataTextField = "Name";
            ddlGeo.DataValueField = "GEOID";
            ddlGeo.DataBind();
            ddlGeo.SelectedValue = "0";
        }
        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.GoToMarket_Edit_Permission.ToString()))
            {
                this.txtName.Enabled = false;
                ddlGeo.Enabled = false;
                rbStatus.Enabled = false;
                // Disable buttons based on permission - Task 16666
                this.btnSave.Enabled = false;
            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strName = "";
            int intStatus = 1;
            int intGeoID = 0;
            int intGoToMarketId = 0;
            AdminGoToMarketBLL da = new AdminGoToMarketBLL();
            try
            {
                strName = txtName.Text.ToString();
                intGeoID = Convert.ToInt32(ddlGeo.SelectedValue);
                if (Request.QueryString["GoToMarketID"] != null)
                {
                    intGoToMarketId = Convert.ToInt32(Request.QueryString["GoToMarketID"].ToString());
                }
                else
                {
                    intGoToMarketId = -1;
                }

                intStatus = Convert.ToInt32(rbStatus.SelectedValue);

                intGoToMarketId = da.UpdateGoToMarket(intGoToMarketId, strName, intStatus, intGeoID, UserInfo.GetCurrentUserName());
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadgotomarket", "CloseEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}


