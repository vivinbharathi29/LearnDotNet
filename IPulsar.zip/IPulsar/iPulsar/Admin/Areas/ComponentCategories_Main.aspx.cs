﻿using System;
using System.Data;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using Infragistics.Web.UI.GridControls;

public partial class Admin_Areas_ComponentCategories_Main : System.Web.UI.Page
{
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (string.Equals(Request.QueryString["isPopup"], "true", StringComparison.OrdinalIgnoreCase))
        {
            MasterPageFile = "~/MasterPages/MainMasterPopup.master";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession();

        Page.Title = "Component Categories";
        lblHeader.Text = "Component Categories";

        if (!IsPostBack)
        {
            Session["ComponentCategoryList"] = null;
        }

        gridPopulate();
        GetPermission();
    }

    private void gridPopulate()
    {
        try
        {
            if (Session["ComponentCategoryList"] == null)
            {
                DataSet ds;
                AdminComponentCategoryBLL adBll = new AdminComponentCategoryBLL();
                //getting all categories if future we decide to view specific category then GetAllComponentCategoryByType ortherwise GetAllComponentCategory for all categories.
                ds = adBll.GetAllComponentCategory();
                Session["ComponentCategoryList"] = ds;
            }

            BindGridData();
            lblError.Text = "";
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    private void BindGridData()
    {
        DataSet ds;
        ds = (DataSet)Session["ComponentCategoryList"];
        wdgComponentCategory.Rows.Clear();
        wdgComponentCategory.DataSource = ds;
        wdgComponentCategory.DataBind();
    }

    protected void wdgComponentCategory_OnInitializeRow(object sender, RowEventArgs e)
    {
        string ComponentCategoryID = e.Row.DataKey[0].ToString();
        string sName = e.Row.Items.FindItemByKey("CategoryName").Value.ToString();
        e.Row.Items.FindItemByKey("CategoryName").Text = "<a onclick=\"return OpenCCEditPopUp('ComponentCategories_Edit.aspx?mode=update&CategoryID=" + ComponentCategoryID + "');\">" + sName + "</a>";
    }

    [WebMethod(EnableSession = true)]
    public static string DeleteRecord(int intComponentCategoryID)
    {
        string strMessage;
        try
        {
            Authenticate.ValidateSession();
            AdminComponentCategoryBLL avb = new AdminComponentCategoryBLL();
            avb.DeleteComponentCategory(intComponentCategoryID, UserInfo.GetCurrentUserName());
            HttpContext.Current.Session["ComponentCategoryList"] = null;
            strMessage = "Successfully deleted Component Category.";
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strMessage = ex.Message;
        }
        return strMessage;
    }

    private void GetPermission()
    {   // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ComponentCategory_Edit_Permission.ToString()))
        {
            Page.Title = "View Component Category List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ComponentCategory_Delete_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }
    protected void btnRefeshGrid_Click(object sender, EventArgs e)
    {
        gridPopulate();
    }
}

