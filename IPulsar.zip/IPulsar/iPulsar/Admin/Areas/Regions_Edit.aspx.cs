﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using Telerik.Web.UI;
using System.Web.Services;
namespace iPulsar.Admin.Areas
{
    public partial class Regions_Edit : System.Web.UI.Page
    {
        int RegionID;
        int GeoID;
        bool bEdit;
        int intKeyboardLayoutID;
        string mode;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession(false);

            mode = Request.QueryString["mode"];
            RegionID = Convert.ToInt32(Request.QueryString["RegionID"]);
            hdnRegionID.Value = RegionID.ToString();
            GetPermission();

            if (!IsPostBack)
            {
                LoadPowerCordGEOs();
                if ((mode == "update" || mode == "clone"))
                {
                    LoadRegion(RegionID);
                    Page.Title = "Modify Localization";
                    //  LoadCountryList(RegionID);
                    LoadLanguageList(RegionID);
                    LoadGEO(GeoID);
                    loadBusSegGrid(RegionID);
                    LoadKeyboardLayout(intKeyboardLayoutID);

                    if (mode == "clone")
                    {
                        btnClone.Visible = false;
                        lbClone.Visible = true;
                        pnlHistory.Visible = false;
                    }
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Localization";
                    pnlHistory.Visible = false;
                    // LoadCountryList(0);
                    LoadLanguageList(0);
                    LoadGEO(0);
                    loadBusSegGrid(0);
                    LoadKeyboardLayout(0);
                    btnClone.Visible = false;
                }

            }
            if (!bEdit)
            { disablecontrols(); }
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Regions_Edit_Permission.ToString()))
            {
                bEdit = false;

            }
            else
            {
                bEdit = true;

            }
        }

        private void LoadPowerCordGEOs()
        {
            AdminRegionsBLL adBll = new AdminRegionsBLL();
            DataSet dsGEOList = new DataSet();
            try
            {
                dsGEOList = adBll.GePowerCordGEOs();

                ddlPowerCord.DataSource = dsGEOList.Tables[0];
                ddlPowerCord.DataTextField = "GEO";
                ddlPowerCord.DataValueField = "GEOID";
                ddlPowerCord.DataBind();
                ddlPowerCord.Items.Insert(0, new ListItem("", "0"));

                ddlDuckheadPowerCord.DataSource = dsGEOList.Tables[0];
                ddlDuckheadPowerCord.DataTextField = "GEO";
                ddlDuckheadPowerCord.DataValueField = "GEOID";
                ddlDuckheadPowerCord.DataBind();
                ddlDuckheadPowerCord.Items.Insert(0, new ListItem("", "0"));

                ddlDuckhead.DataSource = dsGEOList.Tables[0];
                ddlDuckhead.DataTextField = "GEO";
                ddlDuckhead.DataValueField = "GEOID";
                ddlDuckhead.DataBind();
                ddlDuckhead.Items.Insert(0, new ListItem("", "0"));
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void LoadRegion(int RegionID)
        {
            AdminRegionsBLL adBll = new AdminRegionsBLL();
            DataSet ds;

            ds = adBll.GetRegionById(RegionID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                txtName.Text = dr["Name"].ToString();
                txtHPCode.Text = dr["OptionConfig"].ToString();
                txtDash.Text = dr["Dash"].ToString();
                txtCountryCode.Text = dr["CountryCode"].ToString();
                txtGMCode.Text = dr["GMCode"].ToString();
                txtMUI.Text = dr["MUI"].ToString();
                txtkeyboard.Text = dr["keyboard"].ToString();
                //txtPowerCord.Text = dr["PowerCord"].ToString();
                txtcomment.Value = dr["Comments"].ToString();
                if (dr["State"].ToString().ToLower() == "true" || dr["State"].ToString() == "1")
                    rbState.SelectedValue = "1";
                else
                    rbState.SelectedValue = "0";
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                GeoID = Int32.Parse(dr["NewGeoID"].ToString());
                txtGPSyDesc.Value = dr["GPSy_Desc"].ToString();
                txtPHWebDesc.Text = dr["PHWeb_Desc"].ToString();
                txtDisplayName.Text = dr["DisplayName"].ToString();
                intKeyboardLayoutID = Int32.Parse(dr["KeyboardLayoutID"].ToString());
                ddlPowerCord.SelectedValue = dr["PowerCordGEOID"].ToString();
                ddlDuckheadPowerCord.SelectedValue = dr["DuckheadPowerCordGEOID"].ToString();
                ddlDuckhead.SelectedValue = dr["DuckheadGEOID"].ToString();
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }
        private void disablecontrols()
        {
            Page.Title = "View Localization";
            //  this.txtHPCode.Enabled = false;
            this.btnSave.Enabled = false;
            this.btnClone.Enabled = false;
            this.rbState.Enabled = false;
            this.lblEnter.Visible = false;
            // this.txtDash.Enabled = false;
            txtName.Enabled = false;
            txtHPCode.Enabled = false;
            txtDash.Enabled = false;
            txtCountryCode.Enabled = false;
            txtGMCode.Enabled = false;
            txtMUI.Enabled = false;
            txtkeyboard.Enabled = false;
            ddlPowerCord.Enabled = false;
            ddlDuckheadPowerCord.Enabled = false;
            ddlDuckhead.Enabled = false;
            txtcomment.Disabled = true;
            txtGPSyDesc.Disabled = true;
            txtPHWebDesc.Enabled = false;
            DDLGEO.Enabled = false;
            ddlKeyboardLayout.Enabled = false;
            rlbAvailableLanguages.Enabled = false;
            rlbSelectedLanguages.Enabled = false;
            //Image docs
            rlbAvailableImageDocs.Enabled = false;
            rlbSelectedImageDocs.Enabled = false;
            //Printed docs
            rlbAvailablePrintedDocs.Enabled = false;
            rlbSelectedPrintedDocs.Enabled = false;
            txtDisplayName.Enabled = false;
        }
        private void LoadLanguageList(int RegionID)
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            DataSet dsLanguageList = new DataSet();
            DataSet dsSelectedLanguageList = new DataSet();

            try
            {
                dsLanguageList = da.GetAllLanguages();
                //dsLanguageList.Tables[0].DefaultView.Sort = "Name Asc";
                DataView DV1 = dsLanguageList.Tables[0].DefaultView;
                DV1.RowFilter = "State=1";
                //OS language
                rlbAvailableLanguages.DataSource = DV1;
                rlbAvailableLanguages.DataTextField = "Name";
                rlbAvailableLanguages.DataValueField = "ID";
                rlbAvailableLanguages.DataBind();

                dsSelectedLanguageList = da.Region_ViewLanguages(RegionID, 0);
                rlbSelectedLanguages.DataSource = dsSelectedLanguageList.Tables[0];
                rlbSelectedLanguages.DataTextField = "Name";
                rlbSelectedLanguages.DataValueField = "ID";
                rlbSelectedLanguages.DataBind();
                RemoveDuplicateItemsfromSourceDL(rlbAvailableLanguages, rlbSelectedLanguages);

                //Image docs
                rlbAvailableImageDocs.DataSource = DV1;
                rlbAvailableImageDocs.DataTextField = "Name";
                rlbAvailableImageDocs.DataValueField = "ID";
                rlbAvailableImageDocs.DataBind();

                dsSelectedLanguageList = da.Region_ViewLanguages(RegionID, 1);
                rlbSelectedImageDocs.DataSource = dsSelectedLanguageList.Tables[0];
                rlbSelectedImageDocs.DataTextField = "Name";
                rlbSelectedImageDocs.DataValueField = "ID";
                rlbSelectedImageDocs.DataBind();
                RemoveDuplicateItemsfromSourceDL(rlbAvailableImageDocs, rlbSelectedImageDocs);

                //Printed docs
                rlbAvailablePrintedDocs.DataSource = DV1;
                rlbAvailablePrintedDocs.DataTextField = "Name";
                rlbAvailablePrintedDocs.DataValueField = "ID";
                rlbAvailablePrintedDocs.DataBind();

                dsSelectedLanguageList = da.Region_ViewLanguages(RegionID, 2);
                rlbSelectedPrintedDocs.DataSource = dsSelectedLanguageList.Tables[0];
                rlbSelectedPrintedDocs.DataTextField = "Name";
                rlbSelectedPrintedDocs.DataValueField = "ID";
                rlbSelectedPrintedDocs.DataBind();
                RemoveDuplicateItemsfromSourceDL(rlbAvailablePrintedDocs, rlbSelectedPrintedDocs);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        protected void rlbSelectedLanguages_ItemDataBound(object sender, Telerik.Web.UI.RadListBoxItemEventArgs e)
        {
            RadListBoxItem item = (RadListBoxItem)e.Item;
            DataRowView row = (DataRowView)item.DataItem;
            if (Convert.ToBoolean(row["DefaultOSlanguage"]))
            {
                item.Checked = true;
            }
        }
        private void LoadGEO(int intGeoID)
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsGEOList = new DataSet();
            DataSet dsSelectedGEO = new DataSet();

            try
            {
                dsGEOList = da.GetGEO();
                //dsProductLineList.Tables[0].DefaultView.Sort = "Name Asc";
                DDLGEO.DataSource = dsGEOList.Tables[0];
                DDLGEO.DataTextField = "Name";
                DDLGEO.DataValueField = "GEOID";
                DDLGEO.DataBind();
                DDLGEO.Items.Insert(0, new ListItem("Please Select a GEO", "0"));
                DDLGEO.SelectedValue = intGeoID.ToString();

            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        private void LoadKeyboardLayout(int intLayoutID)
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            DataSet dsKeyboardLayout = new DataSet();
            try
            {
                dsKeyboardLayout = da.GetKeyboardLayouts(intLayoutID);
                ddlKeyboardLayout.DataSource = dsKeyboardLayout.Tables[0];
                ddlKeyboardLayout.DataTextField = "Name";
                ddlKeyboardLayout.DataValueField = "ID";
                ddlKeyboardLayout.DataBind();
                ddlKeyboardLayout.Items.Insert(0, new ListItem("", "0"));
                ddlKeyboardLayout.SelectedValue = intLayoutID.ToString();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        private void RemoveDuplicateItemsfromSourceDL(RadListBox RLBSource, RadListBox RLBDest)
        {
            foreach (RadListBoxItem item2 in RLBSource.Items)
            {
                if (item2.Text == "English (US)(US)")
                    item2.Text = "English (US)(EN)";

            }

            foreach (RadListBoxItem item in RLBDest.Items)
            {
                if (item.Text == "English (US)(US)")
                    item.Text = "English (US)(EN)";
                foreach (RadListBoxItem item1 in RLBSource.Items)
                {
                    if (item.Value == item1.Value)
                    {
                        RLBSource.Delete(item1);
                        break;
                    }
                }

            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            AdminRegionsBLL da = new AdminRegionsBLL();
            try
            {
                string strRegionName = txtName.Text.Trim();
                string strDash = txtDash.Text.Trim();
                string strOptionConfig = txtHPCode.Text.Trim();
                int intState = 0;
                int intGeoID = Int32.Parse(DDLGEO.SelectedValue);
                int intKeyboardLayout = Int32.Parse(ddlKeyboardLayout.SelectedValue);
                string strCountryCode = txtCountryCode.Text.Trim();
                string strKeyboard = txtkeyboard.Text.Trim();
                int intPowerCordGEOID = Int32.Parse(ddlPowerCord.SelectedValue);
                int intDuckheadPowerCord = Int32.Parse(ddlDuckheadPowerCord.SelectedValue);
                int intDuckhead = Int32.Parse(ddlDuckhead.SelectedValue);
                string strMUI = txtMUI.Text.Trim();
                string strComments = txtcomment.Value.Trim();
                string strGMCode = txtGMCode.Text.Trim();
                if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                    intState = 1;

                //get the list of selected OSlanguages
                string strOSLanguage = "";
                string strOtherlanguages = "";
                int defaultCnt = 0;
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelectedLanguages.Items)
                {
                    if (selectedItem.Checked)
                    {
                        strOSLanguage += selectedItem.Value.Trim() + ",";
                        defaultCnt++;
                    }
                    else
                        strOtherlanguages += selectedItem.Value.Trim() + ",";

                }

                if (strOSLanguage.Trim().Length > 0)
                {
                    strOSLanguage = strOSLanguage.Substring(0, strOSLanguage.Trim().Length - 1);
                }

                //need to treat LA SP specially , sp: ID=4, LA: ID 17
                if (strOSLanguage != "4,17" && strOSLanguage != "17,4" && defaultCnt > 1)
                {
                    lblError.Text = "Please only select one default OS/Image language";
                    lblError.Visible = true;
                    return;

                }
                if (defaultCnt == 0)
                {
                    lblError.Text = "Please select default OS/Image language";
                    lblError.Visible = true;
                    return;

                }

                if (strOtherlanguages.Trim().Length > 0)
                {
                    strOtherlanguages = strOtherlanguages.Substring(0, strOtherlanguages.Trim().Length - 1);
                }

                //get the list of selected img docs
                string strDocKits = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelectedImageDocs.Items)
                {
                    strDocKits += selectedItem.Value.Trim() + ",";
                }

                if (strDocKits.Trim().Length > 0)
                {
                    strDocKits = strDocKits.Substring(0, strDocKits.Trim().Length - 1);
                }

                //get the list of selected printed docs
                string strPrintedDocs = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelectedPrintedDocs.Items)
                {
                    strPrintedDocs += selectedItem.Value.Trim() + ",";
                }

                if (strPrintedDocs.Trim().Length > 0)
                {
                    strPrintedDocs = strPrintedDocs.Substring(0, strPrintedDocs.Trim().Length - 1);
                }
                //two fields carried from irs
                string strGPSy_Desc = txtGPSyDesc.Value.Trim();
                string strPHWeb_Desc = txtPHWebDesc.Text.Trim();
                //selected business segments
                string strBusSegIDs = hdnSelectedBusSegs.Value;
                string strAMOs = hdnSelectedAMO.Value;
                string strSCMs = hdnSelectedSCM.Value;
                string strDisplayName = txtDisplayName.Text.Trim();

                if (mode == "clone")
                {
                    RegionID = -1;
                }
                RegionID = da.UpdateRegion(RegionID, strRegionName, strOptionConfig, strDash,
                strCountryCode, strKeyboard, strOSLanguage, strOtherlanguages,
                strDocKits, intState, strMUI, strPrintedDocs, strComments,
                strGMCode, intGeoID, strGPSy_Desc, strPHWeb_Desc,
                strBusSegIDs, strAMOs, strSCMs, UserInfo.GetCurrentUserName().ToString(), strDisplayName, intKeyboardLayout,
                intPowerCordGEOID, intDuckheadPowerCord, intDuckhead
              );

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadRegion", "CloseRegionEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        private void loadBusSegGrid(int intRegionID)
        {


            AdminRegionsBLL da = new AdminRegionsBLL();
            DataSet dsRegionList = new DataSet();
            dsRegionList = da.Region_ViewBusinessSegments(intRegionID);

            this.Wdg_BusSeg.DataSource = dsRegionList;
            this.Wdg_BusSeg.DataBind();

        }

        protected void Wdg_BusSeg_InitializeRow(object sender, Infragistics.Web.UI.GridControls.RowEventArgs e)
        {
            CheckBox cb = (CheckBox)e.Row.Items.FindItemByKey("Check").FindControl("CheckBox1");
            CheckBox cb2 = (CheckBox)e.Row.Items.FindItemByKey("CheckAMO").FindControl("CheckBox2");
            CheckBox cb3 = (CheckBox)e.Row.Items.FindItemByKey("CheckSCM").FindControl("CheckBox3");
            if (e.Row.Items.FindItemByKey("Selected").Value.ToString() == "1")
            {
                cb.Checked = true;

            }
            else
            {
                cb.Checked = false;
            }

            if (e.Row.Items.FindItemByKey("AMO").Value.ToString() == "1")
            {
                cb2.Checked = true;

            }
            else
            {
                cb2.Checked = false;
            }
            if (e.Row.Items.FindItemByKey("SCM").Value.ToString() == "1")
            {
                cb3.Checked = true;

            }
            else
            {
                cb3.Checked = false;
            }
            if (!bEdit)
            {
                cb.Enabled = false;
                cb2.Enabled = false;
                cb3.Enabled = false;

            }


        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> LoadBusSegs(int RegionID)
        {
            try
            {
                List<Dictionary<string, object>> dicRegionsList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicRegion = null;

                AdminRegionsBLL da = new AdminRegionsBLL();
                DataSet dsRegionList = new DataSet();
                dsRegionList = da.Region_ViewBusinessSegments(RegionID);

                //fields:SELECT ID, old_Business, Consumer, Commercial, GMCode, Tablet, SMB, GeoID, Geo, Name, Dash, OptionConfig, CountryCode, Keyboard, KWL, PowerCord, OSLanguage, OtherLanguage, DocKits, DisplayOrder, DisplayName, Active, Transitioning, MUI, RestoreMedia, ImageLanguage, PrintedDocs, Comments, AndroidMobilityConsumer '
                for (int i = 0; i < dsRegionList.Tables[0].Rows.Count; i++)
                {
                    dicRegion = new Dictionary<string, object>();
                    dicRegion.Add("Selected", dsRegionList.Tables[0].Rows[i]["Selected"].ToString());
                    dicRegion.Add("BusinessSegmentID", dsRegionList.Tables[0].Rows[i]["BusinessSegmentID"].ToString());
                    dicRegion.Add("Name", dsRegionList.Tables[0].Rows[i]["Name"].ToString());
                    dicRegion.Add("AMO", dsRegionList.Tables[0].Rows[i]["AMO"].ToString());
                    dicRegion.Add("SCM", dsRegionList.Tables[0].Rows[i]["SCM"].ToString());

                    dicRegionsList.Add(dicRegion);

                }
                return dicRegionsList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        protected void btnClone_Click(object sender, EventArgs e)
        {
            Response.Redirect("/IPulsar/Admin/Areas/Regions_Edit.aspx?mode=clone&RegionID=" + RegionID);
        }
    }
}



