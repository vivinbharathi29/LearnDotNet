﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class Admin_GPSyLogins_Edit : System.Web.UI.Page
{
    int uID;
    string mode;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() need to be a first line on every page to validate 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        if (Request.QueryString["mode"] != null)
            mode = Request.QueryString["mode"].ToLower();

        if (Request.QueryString["UserID"] != null)
            uID = Convert.ToInt32(Request.QueryString["UserID"]);

        // Put user code to initialize the page here
        if (!IsPostBack)
        {
            if (mode == "update")
            {
                Page.Title = "View/Modify GPSy Login Name";
                pnlHistory.Visible = true;
                EditSection.Visible = true;
                AddNewSection.Visible = false;
                LoadData(uID);
            }
            else if (mode == "add")
            {
                Page.Title = "Add New GPSy Login Name";
                pnlHistory.Visible = false;
                EditSection.Visible = false;
                AddNewSection.Visible = true;
                LoadUserList();
            }

        }        
        GetPermission();
    }
    private void GetPermission()
    {
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        //if (!Role.IsCurrentUserInRole(Enumeration.Enum_FeatureCategory_Role.FeatureCategory_Editor.ToString()))
        // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.GPSyLoginName_Edit_Permission.ToString()))
        {
            Page.Title = "View GPSy Login Name";
            this.ddlUsers.Enabled = false;
            this.tbUserName.Enabled = false;
            this.txtLoginName.Enabled = false;
            this.btnSave.Enabled = false;            
            this.rbState.Enabled = false;
            this.lblEnter.Visible = false;  
        }
    }
    private void LoadData(int ID)
    {
        AdminGPSyNameBLL adBll = new AdminGPSyNameBLL();
        DataSet ds = null;
        try
        {
            ds = adBll.ViewGPSyName(uID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                tbUserName.Text =  dr["UserName"].ToString().Trim();
                txtLoginName.Text = dr["GPSyName"].ToString().Trim();
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                rbState.SelectedValue = dr["State"].ToString();
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
        finally
        {
            ds.Dispose();
        }

    }

    private void LoadUserList()
    {
        AdminGPSyNameBLL adBll = new AdminGPSyNameBLL();
        DataSet ds = null;

        try 
        {
            ds = adBll.GetUsers();
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataView dv;
                dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "FullName is not null";
                dv.Sort = "FullName ASC";
                ddlUsers.DataSource = dv;
                ddlUsers.DataBind();

                ListItem it1 = new ListItem();
                it1.Value = "0";
                it1.Text = "Select User";
                ddlUsers.Items.Insert(0, it1);
            }        
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
        finally
        {
            ds.Dispose();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string strName = "";
        int Disabled = 1;
        
        AdminGPSyNameBLL da = new AdminGPSyNameBLL();

        try
        {
            if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                Disabled = 0;
            else
                Disabled = 1;

            strName = txtLoginName.Text.Trim();
            string CurrentUserName = UserInfo.GetCurrentUserName();

            switch (mode)
            {
                case "update":
                    da.UpdateGPSyName(CurrentUserName, strName, Disabled, uID);
                    break;
                case "add":
                    int selectedUID = Convert.ToInt32(ddlUsers.SelectedValue);
                    da.AddGPSyName(CurrentUserName, strName, Disabled, selectedUID);
                    break;
                default:
                    break;
            }

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadgpsyloginname", "CloseGPSyEditPopup(true)", true);

            //set it to null so parent list will reload after edit window is closed
            Session["GPSyLoginNameList"] = null;
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }    
}

