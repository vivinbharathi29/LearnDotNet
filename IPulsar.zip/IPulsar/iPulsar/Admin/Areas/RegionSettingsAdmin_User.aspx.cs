﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

 public partial class RegionSettingsAdmin_User : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        int intRegionSettingID = 0;
        if (Request.QueryString["RegionSettingID"] != null)
            intRegionSettingID = Convert.ToInt32(Request.QueryString["RegionSettingID"]);
        if (!IsPostBack)
        {
            hdnRegionSettingID.Value = Convert.ToString(intRegionSettingID);
            LoadRegionSettingData(intRegionSettingID);
        }
        GetPermission();
    }
    private void GetPermission()
    {
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.RegionSettings_Edit_Permission.ToString()))
        {
            Page.Title = "View Region Setting User";
            rlbAvailable.Enabled = false;
            rlbSelected.Enabled = false;
            this.btnSave.Enabled = false;
        }
    }
     private void LoadRegionSettingData(int intRegionSettingID)
    {
        AdminRegionSettingsAdminBLL da = new AdminRegionSettingsAdminBLL();
        DataSet ds = new DataSet();
        ds = da.GetRegionSettingByID(intRegionSettingID);
         if (ds.Tables[0].Rows.Count > 0)
         {
             lblBusinessSegment.Text = Convert.ToString(ds.Tables[0].Rows[0]["BusinessSegmentName"]);
             lblGEO.Text = Convert.ToString(ds.Tables[0].Rows[0]["GeoShortName"]);
         }
         rlbAvailable.DataSource = ds.Tables[1];
         rlbAvailable.DataValueField = "UserId";
         rlbAvailable.DataTextField = "FullName";
         rlbAvailable.DataBind();

         rlbSelected.DataSource = ds.Tables[2];
         rlbSelected.DataValueField = "UserId";
         rlbSelected.DataTextField = "FullName";
         rlbSelected.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string selectedIDs = "";
        int intRegionSettingID = 0;
        foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelected.Items)
        {
            selectedIDs += selectedItem.Value.Trim() + ",";
        }
        if (selectedIDs.Trim().Length > 0)
            selectedIDs = selectedIDs.Substring(0, selectedIDs.Length - 1);

        intRegionSettingID = Convert.ToInt32(hdnRegionSettingID.Value);
        AdminRegionSettingsAdminBLL da = new AdminRegionSettingsAdminBLL();
        da.AddRegionSettingUsers(intRegionSettingID, selectedIDs, UserInfo.GetCurrentUserName());

        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeuserandreloadregionsettings", "CloseEditPopup(true)", true);
    }
}
