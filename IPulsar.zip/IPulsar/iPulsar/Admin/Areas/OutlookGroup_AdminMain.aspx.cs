﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;
using System.Web.Services;


public partial class SystemAdmin_OutlookGroup_AdminMain : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "Outlook Groups";
        Page.Title = "Outlook Groups";
        GetPermission();
    }

    private void GetPermission()
    {  // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SCMXEditor_Edit_Permission.ToString()))
        {
            Page.Title = "View Outlook Groups";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }

        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SCMXEditor_Edit_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetOutlookGroup()
    {
        try
        {
            List<Dictionary<string, object>> dicList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicOutlookGroup = null;
            AdminScmxPcsPcrBLL da = new AdminScmxPcsPcrBLL();
            DataSet dsList = new DataSet();
            dsList = da.GetOutlookGroup(0);
            for (int i = 0; i < dsList.Tables[0].Rows.Count; i++)
            {
                dicOutlookGroup = new Dictionary<string, object>();
                dicOutlookGroup.Add("ID", dsList.Tables[0].Rows[i]["ID"].ToString());
                dicOutlookGroup.Add("Description", dsList.Tables[0].Rows[i]["Description"].ToString());
                dicOutlookGroup.Add("Email", dsList.Tables[0].Rows[i]["Email"].ToString());

                dicList.Add(dicOutlookGroup);
            }
            return dicList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static List<string> GetUserPermission()
    {
        try
        {
            return Permission.GetUserPermissions(UserInfo.GetCurrentUserID());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static string RemoveOutlookGroup(int ID)
    {
        string strReturnMsg = "Outlook group successfully removed.";
        try
        {
            AdminScmxPcsPcrBLL da = new AdminScmxPcsPcrBLL();
            da.DeleteOutlookGroup(ID, UserInfo.GetCurrentUserName().ToString());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strReturnMsg = ex.Message;
        }
        return strReturnMsg;
    }
}

