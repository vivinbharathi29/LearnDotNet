﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;


namespace iPulsar.Admin.Areas
{
    public partial class Regions_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Authenticate.ValidateSession() will make sure you are who you are 
            //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
            //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
            Authenticate.ValidateSession();

            MainMasterPage master = (MainMasterPage)Page.Master;
            Page.Title = "Localizations";
            master.pageheader = "Localizations";
            GetPermission();
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Regions_Edit_Permission.ToString()))
            {
                Page.Title = "View Localizations";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
                rmContextMenu.Items.FindItemByValue("Clone").Enabled = false;
                txtEditRight.Value = "0";

            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Regions_Delete_Permission.ToString()))
            {
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
                txtEditRight.Value = "0";
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllRegions(string sortASC = null)
        {
            try
            {
                List<Dictionary<string, object>> dicRegionsList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicRegion = null;
                int BusinesssegmentID = 0;
                int RegionID = 0;
                int StatusID = 0;
                AdminRegionsBLL da = new AdminRegionsBLL();
                DataSet dsRegionList = new DataSet();
                dsRegionList = da.GetAllRegions(BusinesssegmentID, RegionID, StatusID);

                DataView view = dsRegionList.Tables[0].DefaultView;
                if (sortASC == "No")
                {
                    view.Sort = "ID DESC";
                }

                //fields:SELECT ID, old_Business, Consumer, Commercial, GMCode, Tablet, SMB, GeoID, Geo, Name, Dash, OptionConfig, CountryCode, Keyboard, KWL, PowerCord, OSLanguage, OtherLanguage, DocKits, DisplayOrder, DisplayName, Active, Transitioning, MUI, RestoreMedia, ImageLanguage, PrintedDocs, Comments, AndroidMobilityConsumer '

                foreach (DataRowView rowView in view)
                {
                    dicRegion = new Dictionary<string, object>();
                    dicRegion.Add("RegionID", rowView["ID"].ToString());
                    dicRegion.Add("Name", rowView["Name"].ToString());
                    dicRegion.Add("OptionConfig", rowView["OptionConfig"].ToString());
                    dicRegion.Add("Dash", rowView["Dash"].ToString());
                    dicRegion.Add("GEO", rowView["GEO"].ToString());
                    dicRegion.Add("BusSeg", rowView["BusSeg"].ToString());
                    dicRegion.Add("Active", rowView["Active"].ToString());
                    dicRegion.Add("CountryCode", rowView["CountryCode"].ToString());
                    dicRegion.Add("GMCode", rowView["GMCode"].ToString());
                    string strLanguage = rowView["OSLanguage"].ToString();
                    string strOtherLanguage = "";
                    if (rowView["OtherLanguage"] != null)
                    {
                        strOtherLanguage = rowView["OtherLanguage"].ToString();

                    }
                    dicRegion.Add("OSLanguage", strLanguage);
                    dicRegion.Add("OtherLanguage", strOtherLanguage);
                    dicRegion.Add("MUI", rowView["MUI"].ToString());
                    dicRegion.Add("Keyboard", rowView["Keyboard"].ToString());
                    dicRegion.Add("KeyboardLayout", rowView["KeyboardLayout"].ToString());
                    dicRegion.Add("PowerCord", rowView["PowerCord"].ToString());
                    dicRegion.Add("DuckheadPowerCord", rowView["DuckheadPowerCord"].ToString());
                    dicRegion.Add("Duckhead", rowView["Duckhead"].ToString());
                    dicRegion.Add("DocKits", rowView["DocKits"].ToString());
                    dicRegion.Add("PrintedDocs", rowView["PrintedDocs"].ToString());
                    dicRegion.Add("Comments", rowView["Comments"].ToString());
                    dicRegion.Add("bused", rowView["bused"].ToString());
                    dicRegionsList.Add(dicRegion);

                }
                return dicRegionsList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static string DeleteRegion(int intRegionID)
        {
            string strReturnMsg = "Region is successfully removed.";
            try
            {
                AdminRegionsBLL da = new AdminRegionsBLL();
                da.DeleteRegion(intRegionID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }

    }
}


