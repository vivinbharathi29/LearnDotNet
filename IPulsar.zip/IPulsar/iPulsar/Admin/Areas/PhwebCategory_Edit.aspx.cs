﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class Admin_PhwebCategory_Edit : System.Web.UI.Page
{
    int PhwebCategoryID;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Authenticate.ValidateSession() will make sure you are who you are 
        //it will give you fresh permision to HttpContext.Current.Session["UserPermissions"] 
        //when you need to use HttpContext.Current.Session["UserPermissions"] all you have to do is call permission.IsCurrentUserHasPermission
        Authenticate.ValidateSession(false);

        string mode;        
        mode = Request.QueryString["mode"];
        PhwebCategoryID = Convert.ToInt32(Request.QueryString["CategoryID"]);
        
        // Put user code to initialize the page here
        if (!IsPostBack)
        {
            if ((mode == "update"))
            {
                LoadCategoryData(PhwebCategoryID);                
                Page.Title = "Modify Phweb category";               
            }
            else if (mode == "create")
            {
                Page.Title = "Add New Phweb category";
                pnlHistory.Visible = false;                
            }
            LoadCategoryData(PhwebCategoryID);
        }        
        GetPermission();
    }
    private void GetPermission()
    {
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        //if (!Role.IsCurrentUserInRole(Enumeration.Enum_FeatureCategory_Role.FeatureCategory_Editor.ToString()))
        // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.PHwebProductPin_Edit_Permission.ToString()))
        {
            Page.Title = "View Phweb Category";
            this.txtCategoryName.Enabled = false;
            this.btnSave.Enabled = false;            
            this.rbState.Enabled = false;
            this.lblEnter.Visible = false;  
        }
    }
    private void LoadCategoryData(int intCategoryID)
    {
        AdminPhwebCategoryBLL adBll = new AdminPhwebCategoryBLL();
        DataSet ds;

        ds = adBll.GetPhwebCategoryById(intCategoryID);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            txtCategoryName.Text = dr["CategoryName"].ToString().Trim();
            lblTimeChanged.Text = dr["Updated"].ToString().Trim();
            lblTimeCreated.Text = dr["Created"].ToString().Trim();
            lblCreator.Text = dr["CreatedBy"].ToString().Trim();
            lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
            rbState.SelectedValue = dr["State"].ToString();
            ds.Dispose();
            pnlHistory.Visible = true;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string strName = "";
        string strAbbreviation = "";
        int State = 1;
        int intId = 0;
        AdminPhwebCategoryBLL da = new AdminPhwebCategoryBLL();
        try
        {
            if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                State = 1;
            else
                State = 0;

            strName = txtCategoryName.Text.Trim();
            
            //da.UpdatePhwebCategory(PhwebCategoryID, strName, strAbbreviation, State, UserInfo.GetCurrentUserName().ToString());
            intId = da.UpdatePhwebCategory(PhwebCategoryID, strName, strAbbreviation, State, UserInfo.GetCurrentUserName());

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadbusinesssegment", "ClosePCEditPopup(true)", true);

            //set it to null so parent list will reload after edit window is closed
            Session["PhwebCategoryList"] = null; 
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }    
}

