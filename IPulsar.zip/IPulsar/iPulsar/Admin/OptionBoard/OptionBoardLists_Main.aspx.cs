﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin
{
    public partial class OptionBoardLists_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            MainMasterPage master = (MainMasterPage)Page.Master;
            master.pageheader = "Option Board Lists";
            Page.Title = "Option Board Lists";
            if (!IsPostBack)
            {
                FillTablesDropDown();
            }

            GetPermission();
        }

        private void FillTablesDropDown()
        {
            DDLManageDropdownLists.Items.Add(new ListItem("Connector Name", "obconnector"));
            DDLManageDropdownLists.Items.Add(new ListItem("Expansion Slot Type", "obexpansionslot"));
            DDLManageDropdownLists.DataBind();
        }

        private void GetPermission()
        {   // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
            {
                Page.Title = "View Option Board List";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
            }
        }


        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> FillGrid(string TableName)
        {
            try
            {
                List<Dictionary<string, object>> dictList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dict = null;
                OptionBoardListsBLL objBLL = new OptionBoardListsBLL();
                DataSet ds = new DataSet();

                ds = objBLL.GetSelectedDropdownListDetails(TableName);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dict = new Dictionary<string, object>();
                    dict.Add("ID", ds.Tables[0].Rows[i]["ID"].ToString());
                    dict.Add("Value", ds.Tables[0].Rows[i]["Value"].ToString());
                    dict.Add("State", ds.Tables[0].Rows[i]["State"].ToString());
                    dictList.Add(dict);
                }
                return dictList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}