﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Admin.SCM
{
    public partial class SCMCategory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            MainMasterPage master = (MainMasterPage)Page.Master;
            Page.Title = "SCM Categories";
            master.pageheader = "SCM Categories";
            GetPermission();
        }

        private void GetPermission()
        {// check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SCMCategory_Edit_Permission.ToString()))
            {
                Page.Title = "View SCM Category List";
                lnkAdd.Disabled = true;
				lnkAdd.Attributes["Class"] = "disabled";
				rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SCMCategory_Delete_Permission.ToString()))
            {
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
            }
        }    
              
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllSCMCategories()
        {
            try
            {
                List<Dictionary<string, object>> dicSCMcategorysList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicSCMcategory = null;
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                DataSet dsSCMCategoryList = new DataSet();
                dsSCMCategoryList = da.GetAllSCMCategory();
                for (int i = 0; i < dsSCMCategoryList.Tables[0].Rows.Count; i++)
                {
                    dicSCMcategory = new Dictionary<string, object>();
                    dicSCMcategory.Add("SCMCategoryID", dsSCMCategoryList.Tables[0].Rows[i]["SCMCategoryID"].ToString());
                    dicSCMcategory.Add("Name", dsSCMCategoryList.Tables[0].Rows[i]["Name"].ToString());
                    dicSCMcategory.Add("Abbreviation", dsSCMCategoryList.Tables[0].Rows[i]["Abbreviation"].ToString());
                    dicSCMcategory.Add("State", dsSCMCategoryList.Tables[0].Rows[i]["State"].ToString());
                    dicSCMcategory.Add("PhWebName", dsSCMCategoryList.Tables[0].Rows[i]["PhWebName"].ToString());
                    dicSCMcategory.Add("ProductLines", dsSCMCategoryList.Tables[0].Rows[i]["ProductLines"].ToString());
                    dicSCMcategory.Add("ConfigRules", dsSCMCategoryList.Tables[0].Rows[i]["ConfigRules"].ToString());
                    dicSCMcategory.Add("CatMin", dsSCMCategoryList.Tables[0].Rows[i]["CatMin"].ToString());
                    dicSCMcategory.Add("CatMax", dsSCMCategoryList.Tables[0].Rows[i]["CatMax"].ToString());
                    dicSCMcategory.Add("SortOrder", Convert.ToInt32(dsSCMCategoryList.Tables[0].Rows[i]["SortOrder"].ToString()));
                    dicSCMcategory.Add("ParentCategoryName", dsSCMCategoryList.Tables[0].Rows[i]["ParentCategoryName"].ToString());
                    if (dsSCMCategoryList.Tables[0].Rows[i]["GEOName"].ToString() == "NA")
                        dicSCMcategory.Add("GEOName", "Americas");
                    else
                        dicSCMcategory.Add("GEOName", dsSCMCategoryList.Tables[0].Rows[i]["GEOName"].ToString());
                    dicSCMcategorysList.Add(dicSCMcategory);
                }
                return dicSCMcategorysList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static string DeleteSCMCategory(int intSCMCategoryID)
        {
            string strReturnMsg = "SCM Category successfully removed.";
            try
            {
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                da.DeleteSCMCategory(intSCMCategoryID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }
    }
}