﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;
using System.Collections.Specialized;
using System.Configuration;
using System.Web.UI.HtmlControls;
using Infragistics.Web.UI.GridControls;

namespace iPulsar.Admin.SCM
{
    public partial class AddOtherLocalizations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            if (!IsPostBack)
            {
                string strparentID = Tools.GetQueryStringValue(this.Page, "parentID");

                if (strparentID != "")
                {
                    parentID = Int32.Parse(strparentID);
                    txtparentID.Value = strparentID;
                }

                LoadGridData();
            }
            BindGrid();
        }
        private int parentID
        {
            get
            {
                if (ViewState["parentID"] != null)
                    return Int32.Parse(ViewState["parentID"].ToString());
                else return 0;
            }
            set
            {
                ViewState["parentID"] = value.ToString();
            }
        }
        private int TotalIDCount
        {
            get
            {
                if (ViewState["TotalIDCount"] != null)
                    return Int32.Parse(ViewState["TotalIDCount"].ToString());
                else return 0;
            }
            set
            {
                ViewState["TotalIDCount"] = value.ToString();
            }
        }
        private void LoadGridData()
        {


            lblError.Visible = false;
            try
            {
                if (Session["Dataset_SharedAVAddOthercountries"] != null)
                    Session["Dataset_SharedAVAddOthercountries"] = null;
                AdminSharedAVBLL da = new AdminSharedAVBLL();
                DataSet dsRegionlist = new DataSet();
                dsRegionlist = da.GetOtherCountries(parentID);
                string strRegionID = "";
                string strALLRegionIDs = "";
                string strbAvail = "";
                for (int i = 0; i < dsRegionlist.Tables[0].Rows.Count; i++)
                {
                    strbAvail = dsRegionlist.Tables[0].Rows[i]["bAVail"].ToString();
                    strRegionID = dsRegionlist.Tables[0].Rows[i]["ID"].ToString();
                    if (strbAvail == "1" || strbAvail.ToLower() == "true")
                        strALLRegionIDs += "," + strRegionID + ",";

                }
                txtALLRegionIDs.Value = strALLRegionIDs;
                TotalIDCount = dsRegionlist.Tables[0].Rows.Count;
                Session["Dataset_SharedAVAddOthercountries"] = dsRegionlist;
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        protected void BindGrid()
        {

            lblError.Visible = false;
            try
            {
                if (Session["Dataset_SharedAVAddOthercountries"] != null)
                {
                    DataSet ds = (DataSet)Session["Dataset_SharedAVAddOthercountries"];
                    lock (ds)
                    {
                        ds.Tables[0].PrimaryKey = new DataColumn[] { ds.Tables[0].Columns["ID"] };
                        this.Webdatagrid1.DataSource = ds;
                        Webdatagrid1.DataBind();
                    }
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;

            }
        }
        protected void Webdatagrid1_InitializeRow(object sender, Infragistics.Web.UI.GridControls.RowEventArgs e)
        {
            CheckBox cb = (CheckBox)e.Row.Items.FindItemByKey("Check").FindControl("CheckBox1");
            string RegionIDs = "," + txtselectedRegionIDs.Value + ",";
            if (RegionIDs.IndexOf(e.Row.Items.FindItemByKey("ID").Value.ToString()) != -1)
                cb.Checked = true;
            else
                cb.Checked = false;
            if (e.Row.Items.FindItemByKey("bAvail").Value.ToString() == "0")
            {
                cb.Checked = true;
                cb.Enabled = false;
            }


        }
        protected void WebDataGrid1_DataFiltered(object sender, FilteredEventArgs e)
        {

            WebDataGrid grid = sender as WebDataGrid;
            // grid.Behaviors.Paging.Enabled = false;
            int FilteredRowcount = grid.Rows.Count;
            string strRegionID = "";
            string strFilteredRegionIDs = "";


            if (TotalIDCount == FilteredRowcount) //filter removed situation
                txtFilteredRegionIDs.Value = "";
            else
            {
                for (int i = 0; i < FilteredRowcount; i++)
                {
                    strRegionID = grid.Rows[i].Items.FindItemByKey("ID").Value.ToString();
                    strFilteredRegionIDs += "," + strRegionID + ",";

                }
                txtFilteredRegionIDs.Value = strFilteredRegionIDs;
            }
        }

        [WebMethod(EnableSession = true)]
        public static string CreateOtherLocalizations(int parentID, string strRegionIDs)
        {
            AdminSharedAVBLL da = new AdminSharedAVBLL();
            string strReturnMsg = "";
            strRegionIDs = strRegionIDs.Replace(",,", " ").Replace(",", " ").Trim().Replace(" ", ",");
            try
            {
                da.ADMIN_SharedAV_CreateOtherLocalizations(parentID, strRegionIDs, UserInfo.GetCurrentUserName());
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }

    }
}




