﻿using System;
using System.Collections.Generic;

using System.Web.UI;
using Infragistics.Documents.Excel;

namespace iPulsar.Admin.SCM
{
    public partial class SharedAV_ImportConfigRules : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            if (!IsPostBack)
            {

                Page.Title = "Import Shared AV Configuration Rules";

            }
        }

        protected void btnLoadModifySave_Click(object sender, EventArgs e)
        {
            if (!fuExistingWorkbook.HasFile)
                return;

            Workbook existingworkbook;
            try
            {
                // Reads the Workbook from the selected file
                existingworkbook = Workbook.Load(fuExistingWorkbook.FileContent);
            }
            catch (Exception ex)
            {
                lblError.Text = "Can Not read file.  " + ex.Message;
                lblError.Visible = true;
                return;
            }
            string AVdetailID = "";
            string sAVNumber = "";
            string sDescription = "";
            string sConfigRules = "";
            string sComments = "";
            bool bvakidFile = false;
            bool bflag = false; // this flag is set to true when there is no data at all in the spreadsheet
            if (existingworkbook.Worksheets[0].Rows[0].Cells[0].Value != null)
            {
                if (existingworkbook.Worksheets[0].Rows[0].Cells[0].Value.ToString().Trim() == "AV ID"
                    && existingworkbook.Worksheets[0].Rows[0].Cells[1].Value.ToString().Trim() == "AV Number"
                    && existingworkbook.Worksheets[0].Rows[0].Cells[2].Value.ToString().Trim() == "GPG Description"
                    && existingworkbook.Worksheets[0].Rows[0].Cells[3].Value.ToString().Trim() == "Configuration Rules"
                    && existingworkbook.Worksheets[0].Rows[0].Cells[4].Value.ToString().Trim() == "Comments"
                    )
                    bvakidFile = true;
            }

            // get total number of rows with data (not considering blank rows in between scenario)
            int intRowcount = 1;
            while (existingworkbook.Worksheets[0].Rows[intRowcount].Cells[0].Value != null || existingworkbook.Worksheets[0].Rows[intRowcount].Cells[1].Value != null)
            {
                intRowcount++;
            }

            if (intRowcount == 1)
            {
                bflag = true;
            }


            string strAvdetailList_xml = "";
            //after it is constructed, it will be something like below:
            //<?xml version="1.0"?>  
            //<AVDetailList>
            //'	<AVDetail>
            //		<AVDetailID>xxxx</AVDetailID> 
            //		<AVNo>xxxx</AVNo>
            //		<GpGDescription>xxxx</GpGDescription>
            //		<ConfigRules>xxxx</ConfigRules>
            //		<Comments>xxxx</Comments>
            //'	</AVDetail>
            //'	<AVDetail>
            //		<AVDetailID>xxxx</AVDetailID> 
            //		<AVNo>xxxx</AVNo>
            //		<GpGDescription>xxxx</GpGDescription>
            //		<ConfigRules>xxxx</ConfigRules>
            //		<Comments>xxxx</Comments>
            //'	</AVDetail>
            //</AVDetailList>

            strAvdetailList_xml = "<?xml version='1.0'  encoding='iso-8859-1'?>";
            strAvdetailList_xml += "<AVDetailList>";
            ////   strAvdetailList_xml += strModulePropertyList;
            //   strAvdetailList_xml += "<AVDetail>";






            if (bvakidFile)
            {
                try
                {
                    lblError.Text = "";

                    if (bflag)
                    {
                        lblError.Text = "Please check if the spreadsheet has data before importing.";
                        lblError.Visible = true;
                    }

                    else
                    {
                        for (int intRowIndex = 1; intRowIndex < intRowcount; intRowIndex++)
                        {
                            if (existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[0].Value != null
                                && existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[1].Value != null
                                && existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[2].Value != null)
                            {
                                AVdetailID = existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[0].Value.ToString();
                                sAVNumber = existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[1].Value.ToString();
                                sDescription = existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[2].Value.ToString();
                                if (existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[3].Value != null)
                                    sConfigRules = existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[3].Value.ToString();
                                else
                                    sConfigRules = "";
                                if (existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[4].Value != null)
                                    sComments = existingworkbook.Worksheets[0].Rows[intRowIndex].Cells[4].Value.ToString();
                                else
                                    sComments = "";

                                if (sAVNumber != "" && sDescription != "" && AVdetailID != "")
                                {
                                    strAvdetailList_xml += "<AVDetail>";
                                    strAvdetailList_xml += "<AVDetailID>" + AVdetailID + "</AVDetailID>";
                                    strAvdetailList_xml += "<AVNo>" + Tools.replaceXMLChars(sAVNumber) + "</AVNo>";
                                    strAvdetailList_xml += "<GpGDescription>" + Tools.replaceXMLChars(sDescription) + "</GpGDescription>";
                                    strAvdetailList_xml += "<ConfigRules>" + Tools.replaceXMLChars(sConfigRules) + "</ConfigRules>";
                                    strAvdetailList_xml += "<Comments>" + Tools.replaceXMLChars(sComments) + "</Comments>";
                                    strAvdetailList_xml += "</AVDetail>";

                                }
                            }
                        }
                        strAvdetailList_xml += "</AVDetailList>";
                        AdminSharedAVBLL savbll = new AdminSharedAVBLL();
                        savbll.ADMIN_SharedAV_ImportConfigRules(strAvdetailList_xml, UserInfo.GetCurrentUserName());
                        hdnImported.Value = "1";
                    }
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message;
                    lblError.Visible = true;
                }
            }

            else
            {
                lblError.Text = "Selected File is not in correct format";
                lblError.Visible = true;
            }
        }
    }
}