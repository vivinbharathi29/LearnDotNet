﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Documents.Excel;

namespace iPulsar.Admin.SCM
{
    public partial class SharedAV_Export : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            CreateWorksheetData();
        }
        private void CreateWorksheetData()
        {
            
            AdminSharedAVBLL da = new AdminSharedAVBLL();
            DataSet ds = new DataSet();
            ds = da.GetAllSharedAVs();
            int intRowIndex = 0, intColIndex = 0;

            Workbook wbExport = new Workbook(WorkbookFormat.Excel2007);
            Worksheet wsExport = wbExport.Worksheets.Add("Shared AVs");

            //specify the default font family
            Infragistics.Documents.Excel.IWorkbookFont defaultFont = wbExport.Styles.NormalStyle.StyleFormat.Font;
            defaultFont.Name = "Calibri";
            defaultFont.Height = 11 * 20;

            intRowIndex = 0;
            intColIndex = 0;

            #region column headers
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Feature ID", 100.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "AV Number", 100.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "GPG Description", 150.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Marketing Short Description", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Marketing Long Description", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "SCM Category", 100.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Product Line", 50.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Currently Shared AV Y/N", 50.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Missing Load to PHweb", 80.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "SCM(s) Where Used", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "RTP/MR Date", 80.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "PA:AD (Intro Date)", 80.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Select Availability (SA) Date", 80.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "General Availability (GA) Date", 80.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "End of Manufacturing (EM) Date", 80.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Configuration Rules", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;           
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Comments", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Created By", 80.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Last Updated By", 80.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            #endregion
            
            intRowIndex = 1;
            intColIndex = 0;
            System.Drawing.ColorConverter cc = new System.Drawing.ColorConverter();

            foreach (DataRow drData in ds.Tables[0].Rows)
            {
                intColIndex = 0;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["FeatureID"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["AvNo"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["GPGDescription"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["MarketingDescription"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["MarketingDescriptionPMG"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["SCMCategory"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["ProductLine"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["CurrentlyShared"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["MissingLoadToPHwebYN"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["SCMsWhereUsed"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, Convert.ToString(drData["RTPDate"]) != "" ? String.Format("{0:MM/dd/yyyy}", drData["RTPDate"]) : "", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, Convert.ToString(drData["PhwebDate"]) != "" ? String.Format("{0:MM/dd/yyyy}", drData["PhwebDate"]) : "", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, Convert.ToString(drData["CPLBlindDt"]) != "" ? String.Format("{0:MM/dd/yyyy}", drData["CPLBlindDt"]) : "", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex,Convert.ToString(drData["GeneralAvailDt"]) != "" ? String.Format("{0:MM/dd/yyyy}", drData["GeneralAvailDt"]) : "", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, Convert.ToString(drData["RASDiscontinueDt"]) != "" ? String.Format("{0:MM/dd/yyyy}", drData["RASDiscontinueDt"]) : "", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["ConfigRules"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["Comments"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["CreatedBy"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["UpdatedBy"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;

                intRowIndex++;
            }

            string strFileName = "";
            strFileName = "SharedAVs_" + DateTime.Now.Month.ToString().PadLeft(2, '0').ToString() + DateTime.Now.Day.ToString().PadLeft(2, '0').ToString();
            Response.Clear();
            Response.AppendHeader("content-disposition", "attachment; filename=" + strFileName + ".xlsx");
            Response.ContentType = "application/octet-stream";
            wbExport.Save(Response.OutputStream);
            Response.End();
        }
    }
}
