﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Admin.SCM
{
    public partial class ManufacturingSites_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            MainMasterPage master = (MainMasterPage)Page.Master;
            Page.Title = "Manufacturing Sites";
            master.pageheader = "Manufacturing Sites";
            GetPermission();
        }
        private void GetPermission()
        {// check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ManufacturingSites_Edit_Permission.ToString()))
            {
                Page.Title = "View Manufacturing Site List";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;

            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ManufacturingSites_Delete_Permission.ToString()))
            {
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllManufacturingSites()
        {
            try
            {
                List<Dictionary<string, object>> dicSiteList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicSite = null;
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                DataSet dsSiteList = new DataSet();
                dsSiteList = da.GetAllManufacturingSites();
                for (int i = 0; i < dsSiteList.Tables[0].Rows.Count; i++)
                {
                    dicSite = new Dictionary<string, object>();
                    dicSite.Add("SiteID", dsSiteList.Tables[0].Rows[i]["SiteID"].ToString());
                    dicSite.Add("Name", dsSiteList.Tables[0].Rows[i]["Name"].ToString());
                    dicSite.Add("Code", dsSiteList.Tables[0].Rows[i]["Code"].ToString());
                    dicSite.Add("BusinessSegment", dsSiteList.Tables[0].Rows[i]["BusinessSegment"].ToString());
                    dicSite.Add("GEO", dsSiteList.Tables[0].Rows[i]["GEO"].ToString());
                    dicSite.Add("State", dsSiteList.Tables[0].Rows[i]["State"].ToString());
                    dicSiteList.Add(dicSite);

                }
                return dicSiteList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        
        [WebMethod(EnableSession = true)]
        public static string DeleteManufacturingSites(int intSiteID)
        {
            string strReturnMsg = "Manufacturing Site successfully removed. These changes will not be reflected in IRS unless also updated in IRS Admin \\ Platform AV List \\ Region Data \\ Manufacturing Sites";
            try
            {
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                da.DeleteManufacturingSite(intSiteID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }
    }
}