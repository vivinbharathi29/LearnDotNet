﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;
using Telerik.Web.UI;

namespace iPulsar.Admin.SCM
{
    public partial class SharedAV_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            MainMasterPage master = (MainMasterPage)Page.Master;
            Page.Title = "Shared AVs";
            master.pageheader = "Shared AVs";
            hdnCurrentUserID.Value = Convert.ToString(UserInfo.GetCurrentUserID());
            if (Request.QueryString["FromTodayPage"] != null)
            {
                hdnFromTodayPage.Value = "1";
                if (Request.QueryString["AvDetailID"] != null)
                    hdnAVDetailIDFromTP.Value = Request.QueryString["AvDetailID"];
                if (Request.QueryString["CurrentUserID"] != null)
                    hdnCurrentUserID.Value = Request.QueryString["CurrentUserID"];
                if (Request.QueryString["ReasonType"] != null)
                    hdnReasonType.Value = Request.QueryString["ReasonType"]; //"0" is missing phweb action "1" is av added to scm
            }
            GetPermission();
            LoadProductLine();

            hdnExportExcelPulsarLink.Value = $"{HttpContext.Current.Request.Url.Scheme}://{HttpContext.Current.Request.Url.Host}/Pulsar/Report";
        }

        private void GetPermission()
        {  // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SharedAV_Edit_Permission.ToString()))
            {
                Page.Title = "Shared AVs";

                //Harris, Valerie (5/10/1016) - PBI 12538/Task 20310 - Disable Add New Shared AV link 
                lnkAddNewSharedAV.Disabled = true;
                lnkAddNewSharedAV.Attributes["Class"] = "disabled";

                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
                lnkAddExistingAV.Disabled = true;
                lnkAddExistingAV.Attributes["Class"] = "disabled";
                lnkExportRPN.Disabled = true;
                lnkExportRPN.Attributes["Class"] = "disabled";
                lnkImportAVData.Disabled = true;
                lnkImportAVData.Attributes["Class"] = "disabled";
                lnkAddNewLocalizedSharedAV.Disabled = true;
                lnkAddNewLocalizedSharedAV.Attributes["Class"] = "disabled";
                DDLSetAVSelection.Enabled = false;
                DDLTo.Enabled = false;
                btnSet.Disabled = true;
                lnkAddMultipleAvsToSCM.Disabled = true;
                lnkAddMultipleAvsToSCM.Attributes["Class"] = "disabled";
                lnkExportConfigRules.Disabled = true;
                lnkExportConfigRules.Attributes["Class"] = "disabled";
                lnkImportConfigRules.Disabled = true;
                lnkImportConfigRules.Attributes["Class"] = "disabled";
            }
            else
            {
                txtCanUnShare.Value = "1"; //permission to un-share a shared av                
            }
            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.SharedAV_Delete_Permission.ToString()))
            {
                txtCanDelete.Value = "1";
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllSharedAVs()
        {
            try
            {
                List<Dictionary<string, object>> dicSharedAVsList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicSharedAV = null;
                AdminSharedAVBLL da = new AdminSharedAVBLL();
                DataSet dsSharedAVList = new DataSet();
                dsSharedAVList = da.GetAllSharedAVs();
                for (int i = 0; i < dsSharedAVList.Tables[0].Rows.Count; i++)
                {
                    dicSharedAV = new Dictionary<string, object>();
                    dicSharedAV.Add("AvDetailID", dsSharedAVList.Tables[0].Rows[i]["AvDetailID"].ToString());
                    dicSharedAV.Add("AvNo", dsSharedAVList.Tables[0].Rows[i]["AvNo"].ToString());
                    dicSharedAV.Add("GPGDescription", dsSharedAVList.Tables[0].Rows[i]["GPGDescription"].ToString());
                    dicSharedAV.Add("MarketingDescription", dsSharedAVList.Tables[0].Rows[i]["MarketingDescription"].ToString());
                    dicSharedAV.Add("MarketingDescriptionPMG", dsSharedAVList.Tables[0].Rows[i]["MarketingDescriptionPMG"].ToString());
                    dicSharedAV.Add("ProductLine", dsSharedAVList.Tables[0].Rows[i]["ProductLine"].ToString());
                    dicSharedAV.Add("RTPDate", dsSharedAVList.Tables[0].Rows[i]["RTPDate"].ToString());
                    dicSharedAV.Add("PhwebDate", dsSharedAVList.Tables[0].Rows[i]["PhwebDate"].ToString());
                    dicSharedAV.Add("CPLBlindDt", dsSharedAVList.Tables[0].Rows[i]["CPLBlindDt"].ToString());
                    dicSharedAV.Add("GeneralAvailDt", dsSharedAVList.Tables[0].Rows[i]["GeneralAvailDt"].ToString());
                    dicSharedAV.Add("RASDiscontinueDt", dsSharedAVList.Tables[0].Rows[i]["RASDiscontinueDt"].ToString());
                    dicSharedAV.Add("SCMCategory", dsSharedAVList.Tables[0].Rows[i]["SCMCategory"].ToString());
                    dicSharedAV.Add("ConfigRules", dsSharedAVList.Tables[0].Rows[i]["ConfigRules"].ToString());
                    dicSharedAV.Add("Comments", dsSharedAVList.Tables[0].Rows[i]["Comments"].ToString());
                    dicSharedAV.Add("CurrentlyShared", dsSharedAVList.Tables[0].Rows[i]["CurrentlyShared"].ToString());
                    dicSharedAV.Add("MissingLoadToPHwebYN", dsSharedAVList.Tables[0].Rows[i]["MissingLoadToPHwebYN"].ToString());
                    dicSharedAV.Add("SCMsWhereUsed", dsSharedAVList.Tables[0].Rows[i]["SCMsWhereUsed"].ToString());
                    dicSharedAV.Add("SCMwithLoadtoPHwebAction", dsSharedAVList.Tables[0].Rows[i]["SCMwithLoadtoPHwebAction"].ToString());
                    dicSharedAV.Add("CreatedBy", dsSharedAVList.Tables[0].Rows[i]["CreatedBy"].ToString());
                    dicSharedAV.Add("UpdatedBy", dsSharedAVList.Tables[0].Rows[i]["UpdatedBy"].ToString());
                    dicSharedAV.Add("bused", dsSharedAVList.Tables[0].Rows[i]["bused"].ToString());
                    dicSharedAV.Add("NoOfSCMsUsed", dsSharedAVList.Tables[0].Rows[i]["NoOfSCMsUsed"].ToString());
                    if (Convert.ToBoolean(dsSharedAVList.Tables[0].Rows[i]["SendEmailNotification"]) == true)
                        dicSharedAV.Add("SendEmailNotification", 1);
                    else
                        dicSharedAV.Add("SendEmailNotification", 0);
                    dicSharedAV.Add("SCMWhereActive", dsSharedAVList.Tables[0].Rows[i]["SCMsWhereActive"].ToString());
                    dicSharedAV.Add("FeatureID", dsSharedAVList.Tables[0].Rows[i]["FeatureID"].ToString());
                    dicSharedAV.Add("parentID", dsSharedAVList.Tables[0].Rows[i]["parentID"].ToString());
                    dicSharedAVsList.Add(dicSharedAV);
                }

                return dicSharedAVsList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static string DeleteSharedAV(int intSharedAVID)
        {
            string strReturnMsg = "Shared AV successfully removed.";
            try
            {
                AdminSharedAVBLL da = new AdminSharedAVBLL();
                da.DeleteSharedAV(intSharedAVID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }
        [WebMethod(EnableSession = true)]
        public static string UnShareSharedAV(int intSharedAVID)
        {
            string strReturnMsg = "Shared AV successfully marked as un-shared.";
            try
            {
                AdminSharedAVBLL da = new AdminSharedAVBLL();
                da.UnShareSharedAV(intSharedAVID, UserInfo.GetCurrentUserName().ToString());
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }


        // Get Product Line List
        [WebMethod]
        public static List<Dictionary<string, string>> GetProductLineList()
        {
            try
            {
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                DataSet ds = new DataSet();
                ds = da.GetProductLines();

                DataView dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "State = 'Active'";
                List<Dictionary<string, string>> dicProductLineList = new List<Dictionary<string, string>>();

                for (int i = 0; i < dv.Count; i++)
                {
                    Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("ProductLineID", dv[i]["ProductLineID"].ToString());
                    Dictionary.Add("ProductLine", dv[i]["ProductLine"].ToString());
                    dicProductLineList.Add(Dictionary);
                }
                return dicProductLineList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        // Get SCM Category List
        [WebMethod]
        public static List<Dictionary<string, string>> GetSCMCategoryList()
        {
            try
            {
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                DataSet ds = new DataSet();
                ds = da.GetAllSCMCategory();

                DataView dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "State = 'Active' AND Abbreviation <> 'BUNIT'";
                List<Dictionary<string, string>> dicSCMCategoryList = new List<Dictionary<string, string>>();

                for (int i = 0; i < dv.Count; i++)
                {
                    Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("SCMCategoryID", dv[i]["SCMCategoryID"].ToString());
                    Dictionary.Add("Name", dv[i]["Name"].ToString());
                    dicSCMCategoryList.Add(Dictionary);
                }
                return dicSCMCategoryList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        // Load Product Line List on page load
        private void LoadProductLine()
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet ds = new DataSet();
            ds = da.GetProductLines();

            DataView dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "State = 'Active'";
            DDLTo.DataSource = dv;
            DDLTo.DataBind();

            ListItem it1 = new ListItem();
            it1.Value = "0";
            it1.Text = "Select a Product Line";
            DDLTo.Items.Insert(0, it1);

            DataRow dr = ds.Tables[0].Rows[0];
        }


        // Save ProductLine or SCMCategory
        [WebMethod(EnableSession = true)]
        public static void UpdateProductLineSCMCategory(int intUserID, int intID, string strAvDetailIDs, int intIsProductLine)
        {
            try
            {
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                da.UpdateProductLineSCMCategory(intUserID, intID, strAvDetailIDs, intIsProductLine);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }

        }


        // Set Dates
        [WebMethod(EnableSession = true)]
        public static void UpdateDates(int intUserID, string strAvDetailIDs, string strselectedDate, int intSelection)
        {
            try
            {
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                string strDate = string.Format("{0:MM/dd/yyyy}", strselectedDate);
                da.SetDates(intUserID, strAvDetailIDs, strDate, intSelection);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}

