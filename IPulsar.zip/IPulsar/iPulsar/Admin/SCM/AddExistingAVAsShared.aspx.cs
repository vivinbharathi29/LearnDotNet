﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Admin.SCM
{
    public partial class AddExistingAVAsShared : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            if (!IsPostBack)
            {
                GetProductLineList();
                GetSCMCategoryList();
            }
        }
        private void GetProductLineList()
        {
            AdminSCMCategoryBLL adBll = new AdminSCMCategoryBLL();
            DataSet ds;

            ds = adBll.GetProductLines();
            ddlProductLine.DataSource = ds;
            ddlProductLine.DataTextField = "ProductLineFullName";
            ddlProductLine.DataValueField = "ProductLineID";
            ddlProductLine.DataBind();

            ddlProductLine.Items.Insert(0, new ListItem("Select a Product Line", "0"));
        }
        private void GetSCMCategoryList()
        {
            AdminSCMCategoryBLL adBll = new AdminSCMCategoryBLL();
            DataSet ds;
            DataView dv = null;

            ds = adBll.GetAllSCMCategory();
            dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "Abbreviation <> 'BUNIT'";

            ddlSCMCategory.DataSource = dv;
            ddlSCMCategory.DataTextField = "Name";
            ddlSCMCategory.DataValueField = "SCMCategoryID";
            ddlSCMCategory.DataBind();

            ddlSCMCategory.Items.Insert(0, new ListItem("Select a SCM Category", "0"));
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllNonSharedAVs(int ProductLineID, int SCMCategoryID, string AVNo, string MktDesc)
        {
            try
            {
                List<Dictionary<string, object>> dicNonSharedAVsList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicNonSharedAV = null;
                AdminSharedAVBLL da = new AdminSharedAVBLL();
                DataSet dsSharedAVList = new DataSet();
                dsSharedAVList = da.GetAllNonSharedAVs(ProductLineID, SCMCategoryID, AVNo, MktDesc);
                for (int i = 0; i < dsSharedAVList.Tables[0].Rows.Count; i++)
                {
                    dicNonSharedAV = new Dictionary<string, object>();
                    dicNonSharedAV.Add("AvDetailID", dsSharedAVList.Tables[0].Rows[i]["AvDetailID"].ToString());
                    dicNonSharedAV.Add("AvNo", dsSharedAVList.Tables[0].Rows[i]["AvNo"].ToString());
                    dicNonSharedAV.Add("GPGDescription", dsSharedAVList.Tables[0].Rows[i]["GPGDescription"].ToString());
                    dicNonSharedAV.Add("MarketingDescription", dsSharedAVList.Tables[0].Rows[i]["MarketingDescription"].ToString());
                    dicNonSharedAV.Add("MarketingDescriptionPMG", dsSharedAVList.Tables[0].Rows[i]["MarketingDescriptionPMG"].ToString());
                    dicNonSharedAV.Add("ProductLine", dsSharedAVList.Tables[0].Rows[i]["ProductLine"].ToString());
                    dicNonSharedAV.Add("SCMCategory", dsSharedAVList.Tables[0].Rows[i]["SCMCategory"].ToString());

                    dicNonSharedAVsList.Add(dicNonSharedAV);
                }

                return dicNonSharedAVsList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static string AddExistingAVsToShared(string AVDetailIDs)
        {
            string strReturnMsg = "";
            try
            {
                AdminSharedAVBLL da= new AdminSharedAVBLL();
                da.AddExistingAVsAsShared(AVDetailIDs);
            }
            catch (Exception ex)
            {
                strReturnMsg = ex.Message;
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            }
            return strReturnMsg;
        }
    }
}