﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using Telerik.Web.UI;

namespace iPulsar.Admin.SCM
{
    public partial class SharedAV_Edit : System.Web.UI.Page
    {
        int AVDetailID;
        int ProductLineID = 0;
        int SCMCategoryID = 0;
        string SCMcategoryName = "";
        string ProductLine = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            string mode;
            mode = Request.QueryString["mode"];
            AVDetailID = Convert.ToInt32(Request.QueryString["AVDetailID"]);
            Authenticate.ValidateSession();
            if (!IsPostBack)
            {
                if ((mode == "update"))
                {
                    LoadSharedAV(AVDetailID);
                    Page.Title = "Modify Shared AV";
                    LoadProductLine(ProductLineID, ProductLine);
                    LoadSCMCategory(SCMCategoryID, SCMcategoryName);
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Shared AV";
                    pnlHistory.Visible = false;
                    LoadProductLine(0, "");
                    LoadSCMCategory(0, "");
                }

            }
            GetPermission();
            string currentuserid = Convert.ToString(UserInfo.GetCurrentUserID());
            hdnCurrentUserID.Value = currentuserid;
        }

        private void GetPermission()
        {// check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SharedAV_Edit_Permission.ToString()))
            {
                Page.Title = "View Shared AV";
                this.txtAvNo.Enabled = false;
                this.btnSave.Enabled = false;
                this.lblEnter.Visible = false;
                this.DDLSCMCategory.Enabled = false;
                this.DDLProductLine.Enabled = false;
                this.txtConfigRules.Enabled = false;
                this.txtComments.Enabled = false;
                this.txtRTPDate.Enabled = false;
                this.txtPAADDate.Enabled = false;
                this.txtBlindDate.Enabled = false;
                this.txtGeneralAvailDt.Enabled = false;
                this.txtMarketingDiscDate.Enabled = false;
            }
            else if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SharedAVProductLine_Edit_Permission.ToString()))
            {
                this.DDLProductLine.Enabled = false;

            }
        }

        private void LoadSharedAV(int AVDetailID)
        {
            chkRequireNotification.Checked = true;
            AdminSharedAVBLL adBll = new AdminSharedAVBLL();
            DataSet ds;

            ds = adBll.GetSharedAVById(AVDetailID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                txtAvNo.Text = dr["AvNo"].ToString();
                lblGPGDescription.Text = dr["GPGDescription"].ToString();
                lblMarketingShortDescription.Text = dr["MarketingDescription"].ToString();
                lblMarketingLongDescription.Text = dr["MarketingDescriptionPMG"].ToString();
                ProductLineID = Convert.ToInt32(dr["ProductLineID"].ToString());
                ProductLine = dr["ProductLine"].ToString();
                SCMCategoryID = Convert.ToInt32(dr["SCMCategoryID"].ToString());
                SCMcategoryName = dr["SCMCategory"].ToString();
                if (dr["RTPDate"].ToString() != "")
                    txtRTPDate.SelectedDate = Convert.ToDateTime(dr["RTPDate"].ToString());

                if (dr["PhwebDate"].ToString() != "")
                    txtPAADDate.SelectedDate = Convert.ToDateTime(dr["PhwebDate"].ToString());

                if (dr["CPLBlindDt"].ToString() != "")
                    txtBlindDate.SelectedDate = Convert.ToDateTime(dr["CPLBlindDt"].ToString());

                if (dr["GeneralAvailDt"].ToString() != "")
                    txtGeneralAvailDt.SelectedDate = Convert.ToDateTime(dr["GeneralAvailDt"].ToString());

                hdnPAADDt.Value = dr["PhwebDate"].ToString();
                hdnCplBlindDt.Value = dr["CPLBlindDt"].ToString();
                hdnGeneralAvDt.Value = dr["GeneralAvailDt"].ToString();
                if (dr["RASDiscontinueDt"].ToString() != "")
                    txtMarketingDiscDate.SelectedDate = Convert.ToDateTime(dr["RASDiscontinueDt"].ToString());
                if (dr["RequireNotification"].ToString().ToLower() != "true")
                    chkRequireNotification.Checked = false;
                txtConfigRules.Text = dr["ConfigRules"].ToString();
                txtComments.Text = dr["Comments"].ToString();
                lblCurrentlySharedYN.Text = dr["CurrentlyShared"].ToString();
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                hdnAvNo.Value = dr["AvNo"].ToString();
                hdnSCMCategoryID.Value = dr["SCMCategoryID"].ToString();
                lblFeatureID.Text = dr["FeatureID"].ToString().Trim();
                hdnFeatureID.Value = dr["FeatureID"].ToString().Trim();
                hdnAvDetailID.Value = dr["AvDetailID"].ToString().Trim();
                hdnParentId.Value = dr["ParentId"].ToString().Trim();
                hdnIsDesktop.Value = dr["isDesktop"].ToString().ToLower().Trim();
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }
        private void LoadProductLine(int intProductLineID, string strProductLine)
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet ds = new DataSet();
            ds = da.GetProductLines();

            try
            {
                DataView dv;
                dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "State = 'Active'";
                DDLProductLine.DataSource = dv;
                DDLProductLine.DataBind();

                ListItem it1 = new ListItem();
                it1.Value = "0";
                it1.Text = "";
                DDLProductLine.Items.Insert(0, it1);

                DataRow dr = ds.Tables[0].Rows[0];

                if (DDLProductLine.Items.FindByValue(intProductLineID.ToString()) != null)
                {
                    DDLProductLine.SelectedValue = intProductLineID.ToString();
                }
                else //if the category bacame inactive, add it to the list
                {
                    ListItem it2 = new ListItem();
                    it1.Value = ProductLineID.ToString();
                    it1.Text = strProductLine;
                    DDLProductLine.Items.Insert(0, it2);
                    DDLProductLine.SelectedValue = intProductLineID.ToString();
                }

                lblError.Text = "";
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void LoadSCMCategory(int intSCMCategoryID, string strSCMCategory)
        {
            DataSet ds;
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            try
            {
                ds = da.GetAllSCMCategory();
                DataView dv;
                dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "State = 'Active' AND Abbreviation <> 'BUNIT'";
                DDLSCMCategory.DataSource = dv;
                DDLSCMCategory.DataBind();

                ListItem it1 = new ListItem();
                it1.Value = "0";
                it1.Text = "";
                DDLSCMCategory.Items.Insert(0, it1);

                DataRow dr = ds.Tables[0].Rows[0];

                if (DDLSCMCategory.Items.FindByValue(intSCMCategoryID.ToString()) != null)
                {
                    DDLSCMCategory.SelectedValue = intSCMCategoryID.ToString();
                }
                else //if the category bacame inactive, add it to the list
                {
                    ListItem it2 = new ListItem();
                    it1.Value = intSCMCategoryID.ToString();
                    it1.Text = strSCMCategory;
                    DDLSCMCategory.Items.Insert(0, it2);
                    DDLSCMCategory.SelectedValue = intSCMCategoryID.ToString();
                }

                lblError.Text = "";
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strAvNo = "";
            string strConfigRules = "";
            string strComments = "";
            int intSelectedSCMCategoryID = 0;
            int intSelectedProductLineID = 0;
            string strRTPDt = string.Format("{0:MM/dd/yyyy}", txtRTPDate.SelectedDate);
            string strPhwebDate = string.Format("{0:MM/dd/yyyy}", txtPAADDate.SelectedDate);
            string strCPLBlindDt = string.Format("{0:MM/dd/yyyy}", txtBlindDate.SelectedDate);
            string strGeneralAvailDt = string.Format("{0:MM/dd/yyyy}", txtGeneralAvailDt.SelectedDate);
            string strRASDiscontinueDt = string.Format("{0:MM/dd/yyyy}", txtMarketingDiscDate.SelectedDate);
            int featureID = Convert.ToInt32(hdnFeatureID.Value);
            bool isDesktop = hdnIsDesktop.Value == "0" ? false : true;

            int RequireNotification = 0;
            if (chkRequireNotification.Checked)
                RequireNotification = 1;
            AdminSharedAVBLL da = new AdminSharedAVBLL();
            try
            {

                strAvNo = txtAvNo.Text.Trim().ToUpper();

                intSelectedProductLineID = Convert.ToInt32(DDLProductLine.SelectedValue);
                intSelectedSCMCategoryID = Convert.ToInt32(DDLSCMCategory.SelectedValue);

                strConfigRules = txtConfigRules.Text.Trim();
                strComments = txtComments.Text.Trim();

                AVDetailID = da.UpdateSharedAV(AVDetailID, strAvNo, intSelectedSCMCategoryID,
                    intSelectedProductLineID, strRTPDt, strPhwebDate, strCPLBlindDt, strGeneralAvailDt,
                    strRASDiscontinueDt, RequireNotification,
                   strConfigRules, strComments, UserInfo.GetCurrentUserName().ToString(), featureID, isDesktop);

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadSharedAV", "CloseSharedAVEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}

