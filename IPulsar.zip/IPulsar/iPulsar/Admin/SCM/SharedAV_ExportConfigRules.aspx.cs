﻿
using System;
using System.Data;
using Infragistics.Documents.Excel;
namespace iPulsar.Admin.SCM
{
    public partial class SharedAV_ExportConfigRules : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string strAVdetailIDs = "";
            Authenticate.ValidateSession();
            if (Request.QueryString["MultipleAvDetailIDs"] != null)
            {
                strAVdetailIDs = Request.QueryString["MultipleAvDetailIDs"].ToString();
              
            }
            CreateWorksheetData(strAVdetailIDs);
        }
        private void CreateWorksheetData(string strAVdetailIDs)
        {

            AdminSharedAVBLL da = new AdminSharedAVBLL();
            DataSet ds = new DataSet();
            ds = da.GetSelectedSharedAVs(strAVdetailIDs);                    
         
            int intRowIndex = 0, intColIndex = 0;

            Workbook wbExport = new Workbook(WorkbookFormat.Excel2007);
            Worksheet wsExport = wbExport.Worksheets.Add("Shared AVs");

            //specify the default font family
            Infragistics.Documents.Excel.IWorkbookFont defaultFont = wbExport.Styles.NormalStyle.StyleFormat.Font;
            defaultFont.Name = "Calibri";
            defaultFont.Height = 11 * 20;

            intRowIndex = 0;
            intColIndex = 0;

            #region column headers
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "AV ID", 100.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "AV Number", 100.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "GPG Description", 150.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Configuration Rules", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            intColIndex++;
            ExcelTools.CreateColumnHeader(wsExport, intRowIndex, intColIndex, "Comments", 200.0, FillColor: "#000000", ForeColor: "#ffffff", HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
            
            #endregion

            intRowIndex = 1;
            intColIndex = 0;
            System.Drawing.ColorConverter cc = new System.Drawing.ColorConverter();

            foreach (DataRow drData in ds.Tables[0].Rows)
            {
                intColIndex = 0;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["AVdetailID"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["AvNo"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["GPGDescription"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;               
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["ConfigRules"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                intColIndex++;
                ExcelTools.AddDataCell(wsExport, intRowIndex, intColIndex, drData["Comments"].ToString(), HorizontalAlignment: HorizontalCellAlignment.Left, VerticalAlignment: VerticalCellAlignment.Top, FontSize: 11);
                
                intRowIndex++;
            }

            string strFileName = "";
            strFileName = "SharedAVs_ConfigRules_" + DateTime.Now.Month.ToString().PadLeft(2, '0').ToString() + DateTime.Now.Day.ToString().PadLeft(2, '0').ToString();
            Response.Clear();
            Response.AppendHeader("content-disposition", "attachment; filename=" + strFileName + ".xlsx");
            Response.ContentType = "application/octet-stream";
            wbExport.Save(Response.OutputStream);
            Response.End();
        }
    }
}
