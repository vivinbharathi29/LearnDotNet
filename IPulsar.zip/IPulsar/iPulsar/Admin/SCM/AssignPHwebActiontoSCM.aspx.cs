﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Admin.SCM
{
    public partial class AssignPHwebActiontoSCM : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            int intAvDetailID = 0;
            if (Request.QueryString["AvDetailID"] != null)
                intAvDetailID = Convert.ToInt32(Request.QueryString["AvDetailID"]);
            hdnAvDetailID.Value = intAvDetailID.ToString();
            if (!IsPostBack)
                GetAvailAllSCMs(intAvDetailID);
        }
        private void GetAvailAllSCMs(int intAvDetailID)
        {
            AdminSharedAVBLL da = new AdminSharedAVBLL();
            DataSet dsSCMs = new DataSet();
            dsSCMs = da.GetSCMSToAssignLoadtoPHweb(intAvDetailID);

            DDLAvailSCMS.DataSource = dsSCMs.Tables[0];
            DDLAvailSCMS.DataTextField = "SCM";
            DDLAvailSCMS.DataValueField = "ProductBrandId";
            DDLAvailSCMS.DataBind();

        }
        [WebMethod]
        public static string AssignPHwebs(int AvDetailID, int ProductBrandID)
        {
            string strMsg = "";
            AdminSharedAVBLL da = new AdminSharedAVBLL();
            try
            {
                da.AssignLoadtoPHwebtoSCM(AvDetailID, ProductBrandID, UserInfo.GetCurrentUserName().ToString());
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strMsg = ex.Message;
            }
            return strMsg;
        }
    }
}