﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using Telerik.Web.UI;

namespace iPulsar.Admin.SCM
{
    public partial class SCMCategory_Edit : System.Web.UI.Page
    {
        int SCMCategoryID;
        int LinkedPhwebcategoryID = 0;
        int ParentCategoryID = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            string mode;
            mode = Request.QueryString["mode"];
            SCMCategoryID = Convert.ToInt32(Request.QueryString["SCMCategoryID"]);
            Authenticate.ValidateSession();
            if (!IsPostBack)
            {
                if ((mode == "update"))
                {
                    LoadOperatingSystem();
                    LoadSCMCategory(SCMCategoryID);
                    Page.Title = "Modify SCM Category";
                    LoadProductLine(SCMCategoryID);
                    LoadPhWebCategory(LinkedPhwebcategoryID);
                    LoadParentCategory(ParentCategoryID);
                }
                else if (mode == "create")
                {
                    Page.Title = "Add New SCM Category";
                    pnlHistory.Visible = false;
                    LoadGEOs();
                    LoadOperatingSystem();
                    LoadProductLine(0);
                    LoadPhWebCategory(0);
                    LoadParentCategory(0);
                    lblGEOMsg.Style.Add("display", "none");
                }

            }
            GetPermission();
        }

        private void GetPermission()
        {// check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SCMCategory_Edit_Permission.ToString()))
            {
                Page.Title = "View SCM Category";
                this.txtCategoryName.Enabled = false;
                this.btnSave.Enabled = false;
                this.rbState.Enabled = false;
                this.lblEnter.Visible = false;
                this.txtAbbreviation.Enabled = false;
                this.DDLPhWebCategory.Enabled = false;

            }
        }

        private void LoadOperatingSystem()
        {
            //GetOperatingSystemList
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsOperatingSystem = new DataSet();

            dsOperatingSystem = da.GetOperatingSystemList();

            DataView dvOperatingSystem = dsOperatingSystem.Tables[0].DefaultView;
            dvOperatingSystem.RowFilter = "SupplyChain = 'Yes'";

            ddlOperatingSystem.DataSource = dvOperatingSystem;
            ddlOperatingSystem.DataTextField = "Name";
            ddlOperatingSystem.DataValueField = "ID";
            ddlOperatingSystem.DataBind();

            ddlOperatingSystem.Items.Insert(0, new ListItem("Select an Operating System", "0"));
        }

        private void LoadSCMCategory(int SCMCategoryID)
        {
            AdminSCMCategoryBLL adBll = new AdminSCMCategoryBLL();
            DataSet ds;

            ds = adBll.GetSCMCategoryById(SCMCategoryID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                txtCategoryName.Text = dr["Name"].ToString();
                txtAbbreviation.Text = dr["Abbreviation"].ToString();
                LinkedPhwebcategoryID = Convert.ToInt32(dr["PhwebcategoryID"].ToString());
                ParentCategoryID = Convert.ToInt32(dr["ParentCategoryID"].ToString());
                txtConfigRules.Text = dr["ConfigRules"].ToString();
                txtMin.Text = dr["CatMin"].ToString();
                txtMax.Text = dr["CatMax"].ToString();
                rbState.SelectedValue = dr["State"].ToString();
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                if (dr["InheritProductLine"].ToString() == "1" || dr["InheritProductLine"].ToString().ToLower() == "true")
                    chkPL.Checked = true;
                DataSet dsParentCategoryGEOList = new DataSet();
                if (ParentCategoryID > 0)
                {
                    dsParentCategoryGEOList = adBll.GetGEOForParentCategory(ParentCategoryID);

                    ddlGEO.Enabled = true;
                    ddlGEO.DataSource = dsParentCategoryGEOList;
                    ddlGEO.DataTextField = "GEOName";
                    ddlGEO.DataValueField = "GEOID";
                    ddlGEO.DataBind();
                    ddlGEO.Items.Insert(0, new ListItem("Select a GEO", "0"));


                    if (ddlGEO.Items.FindByValue(dr["GEOID"].ToString()) != null)
                        ddlGEO.SelectedValue = dr["GEOID"].ToString();
                    else
                    {
                        ddlGEO.Items.Add(new ListItem(dr["GEOName"].ToString(), dr["GEOID"].ToString()));
                        ddlGEO.SelectedValue = dr["GEOID"].ToString();
                    }
                    lblGEOMsg.Style.Add("display", "inline");
                }
                else
                {
                    ddlGEO.Items.Insert(0, new ListItem("Select a GEO", "0"));


                    ddlGEO.SelectedValue = "0";
                    ddlGEO.Enabled = false;
                    lblGEOMsg.Style.Add("display", "none");
                }
                if (ddlOperatingSystem.Items.FindByValue(dr["OSID"].ToString()) != null)
                    ddlOperatingSystem.SelectedValue = dr["OSID"].ToString();
                else
                {
                    ddlOperatingSystem.Items.Insert(0, new ListItem(dr["OSName"].ToString(), dr["OSID"].ToString()));
                    ddlOperatingSystem.SelectedValue = dr["OSID"].ToString();
                }
                if (dr["ShowOSID"].ToString() == "1")
                {
                    trOperatingSystem.Style.Add("display", "table-row");
                    lblGEOMsg.Style.Add("display", "none");
                }
                else
                {
                    trOperatingSystem.Style.Add("display", "none");
                }
                if (dr["Name"].ToString().ToUpper().IndexOf("OPERATING SYSTEM") > -1)
                    lblInfo.Visible = true;
                else
                    lblInfo.Visible = false;
                ds.Dispose();
                pnlHistory.Visible = true;
            }
        }
        private void LoadGEOs()
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsGEO = new DataSet();
            dsGEO = da.GetGEOForSubCategory();
            ddlGEO.DataSource = dsGEO;
            ddlGEO.DataTextField = "GEOName";
            ddlGEO.DataValueField = "GEOID";
            ddlGEO.DataBind();

            ddlGEO.Items.Insert(0, new ListItem("Select a GEO", "0"));
            //lblGEOMsg.Style.Add("display", "none");

        }
        private void LoadProductLine(int SCMCategoryID)
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsProductLineList = new DataSet();
            DataSet dsSelectedProductLine = new DataSet();


            try
            {
                dsProductLineList = da.GetProductLines();
                rlbAvailable.DataSource = dsProductLineList.Tables[0];
                rlbAvailable.DataTextField = "ProductLineFullName";
                rlbAvailable.DataValueField = "ProductLineID";
                rlbAvailable.DataBind();

                dsSelectedProductLine = da.SCMCategory_ViewProductLine(SCMCategoryID);
                rlbSelected.DataSource = dsSelectedProductLine.Tables[0];
                rlbSelected.DataTextField = "ProductLineFullName";
                rlbSelected.DataValueField = "ProductLineID";
                rlbSelected.DataBind();
                RemoveDuplicateItemsfromSourceDL(rlbAvailable, rlbSelected);

            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        private void LoadPhWebCategory(int intLinkedPhwebcategoryID)
        {
            DataSet ds;
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            try
            {
                ds = da.GetAllPhWebCategories();
                DataView dv;
                dv = ds.Tables[0].DefaultView;
                DDLPhWebCategory.DataSource = dv;
                DDLPhWebCategory.DataBind();

                ListItem it1 = new ListItem();
                it1.Value = "0";
                it1.Text = "";
                DDLPhWebCategory.Items.Insert(0, it1);

                DataRow dr = ds.Tables[0].Rows[0];
                string prevPhWebCategory = "";
                prevPhWebCategory = intLinkedPhwebcategoryID.ToString();
                if (DDLPhWebCategory.Items.FindByValue(prevPhWebCategory.ToString()) != null)
                {
                    DDLPhWebCategory.SelectedValue = intLinkedPhwebcategoryID.ToString();
                }


                lblError.Text = "";
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void LoadParentCategory(int intParentcategoryID)
        {
            DataSet ds;
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            try
            {
                ds = da.GetAllSCMCategory();
                DataView dv;
                dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "ParentCategoryID = 0";
                DDLParentCategory.DataSource = dv;
                DDLParentCategory.DataBind();

                ListItem it1 = new ListItem();
                it1.Value = "0";
                it1.Text = "";
                DDLParentCategory.Items.Insert(0, it1);

                DataRow dr = ds.Tables[0].Rows[0];
                string prevParentCategory = "";
                prevParentCategory = intParentcategoryID.ToString();
                if (DDLParentCategory.Items.FindByValue(prevParentCategory.ToString()) != null)
                {
                    DDLParentCategory.SelectedValue = intParentcategoryID.ToString();
                }

                lblError.Text = "";
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
        private void RemoveDuplicateItemsfromSourceDL(RadListBox RLBSource, RadListBox RLBDest)
        {

            foreach (RadListBoxItem item in RLBDest.Items)
            {

                foreach (RadListBoxItem item1 in RLBSource.Items)
                {
                    if (item.Value == item1.Value)
                    {
                        RLBSource.Delete(item1);
                        break;
                    }
                }

            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strSCMCategoryName = "";
            string strAbbreviation = "";
            string /*strPhWebName = "",*/ strConfigRules = "";
            int intMin = -1, intMax = -1;
            int intSetInactive = 1;
            int intchkPL = 0;
            int linkedPhwebcategory = 0;
            int intParentcategoryID = 0;
            int intGEOID = 0;
            int intOSID = 0;
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            try
            {

                strSCMCategoryName = txtCategoryName.Text.Trim();
                strAbbreviation = txtAbbreviation.Text.Trim();
                linkedPhwebcategory = Convert.ToInt32(DDLPhWebCategory.SelectedValue);
                intParentcategoryID = Convert.ToInt32(DDLParentCategory.SelectedValue);
                intGEOID = Convert.ToInt32(ddlGEO.SelectedValue);
                intOSID = Convert.ToInt32(ddlOperatingSystem.SelectedValue);
                if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                    intSetInactive = 0;
                else
                    intSetInactive = 1;

                strConfigRules = txtConfigRules.Text.Trim();
                if (txtMin.Text.Trim().Length > 0)
                    intMin = Convert.ToInt32(txtMin.Text.Trim());
                if (txtMax.Text.Trim().Length > 0)
                    intMax = Convert.ToInt32(txtMax.Text.Trim());
                //get the list of selected product lines
                string selectedIDs = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelected.Items)
                {
                    selectedIDs += selectedItem.Value.Trim() + ",";
                }

                if (chkPL.Checked)
                    intchkPL = 1;
                if (intchkPL == 1)
                    selectedIDs = "";

                if (selectedIDs.Trim().Length > 0)
                {
                    selectedIDs = selectedIDs.Substring(0, selectedIDs.Trim().Length - 1);
                }


                SCMCategoryID = da.UpdateSCMCategory(SCMCategoryID, strSCMCategoryName, strAbbreviation, linkedPhwebcategory,
                    UserInfo.GetCurrentUserName().ToString(), intSetInactive, intchkPL, selectedIDs, strConfigRules, intMin, intMax, intParentcategoryID, intGEOID, intOSID);

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadSCMcategory", "CloseSCMCategoryEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        [System.Web.Services.WebMethod]
        public static List<Dictionary<string, string>> GetGEOForParentCategory(int intParentCategoryID)
        {
            try
            {
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                DataSet dsGEOs = new DataSet();

                dsGEOs = da.GetGEOForParentCategory(intParentCategoryID);

                List<Dictionary<string, string>> dicFeatureCategory = new List<Dictionary<string, string>>();

                for (int i = 0; i < dsGEOs.Tables[0].Rows.Count; i++)
                {
                    Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("GEOID", dsGEOs.Tables[0].Rows[i]["GEOID"].ToString());
                    Dictionary.Add("GEOName", dsGEOs.Tables[0].Rows[i]["GEOName"].ToString());
                    dicFeatureCategory.Add(Dictionary);
                }
                return dicFeatureCategory;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}



