﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using Telerik.Web.UI;

namespace iPulsar.Admin.SCM
{
    public partial class ManufacturingSites_Edit : System.Web.UI.Page
    {
        int SiteID;

        protected void Page_Load(object sender, EventArgs e)
        {
            string mode;
            mode = Request.QueryString["mode"];
            SiteID = Convert.ToInt32(Request.QueryString["SiteID"]);
            Authenticate.ValidateSession();
            if (!IsPostBack)
            {
                if ((mode == "update"))
                {
                    LoadManufacturingSites(SiteID);
                    Page.Title = "Modify Manufacturing Site";
                    LoadGEO(SiteID);
                    LoadBusSeg(SiteID);
                    LoadSiteMangers(SiteID);

                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Manufacturing Site";
                    pnlHistory.Visible = false;
                    LoadGEO(0);
                    LoadBusSeg(0);
                    LoadSiteMangers(0);

                }

            }
            GetPermission();

        }

        private void GetPermission()
        {// check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ManufacturingSites_Edit_Permission.ToString()))
            {
                Page.Title = "View Manufacturing Site";
                this.txtSiteName.Enabled = false;
                this.btnSave.Enabled = false;
                this.txtCode.Enabled = false;
                this.lblEnter.Visible = false;
                rlbBSAvailable.Enabled = false;
                rlbBSSelected.Enabled = false;
                rlbGEOAvailable.Enabled = false;
                rlbGEOSelected.Enabled = false;
                rlbSMavialable.Enabled = false;
                rlbSMSelected.Enabled = false;
                rbState.Enabled = false;


            }
        }

        private void LoadManufacturingSites(int SiteID)
        {
            AdminSCMCategoryBLL adBll = new AdminSCMCategoryBLL();
            DataSet ds;

            try
            {
                ds = adBll.GetManufacturingSiteById(SiteID);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[0];
                    txtSiteName.Text = dr["Name"].ToString();
                    txtCode.Text = dr["Code"].ToString();

                    rbState.SelectedValue = dr["State"].ToString();
                    lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                    lblTimeCreated.Text = dr["Created"].ToString().Trim();
                    lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                    lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                    ds.Dispose();
                    pnlHistory.Visible = true;
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void LoadGEO(int SiteID)
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsGEOList = new DataSet();
            DataSet dsSelectedGEO = new DataSet();

            try
            {
                dsGEOList = da.GetGEO();
                rlbGEOAvailable.DataSource = dsGEOList.Tables[0];
                rlbGEOAvailable.DataTextField = "Name";
                rlbGEOAvailable.DataValueField = "GEOID";
                rlbGEOAvailable.DataBind();

                dsSelectedGEO = da.ManufactruingSite_ViewGEO(SiteID);
                rlbGEOSelected.DataSource = dsSelectedGEO.Tables[0];
                rlbGEOSelected.DataTextField = "Name";
                rlbGEOSelected.DataValueField = "GEOID";
                rlbGEOSelected.DataBind();
                RemoveDuplicateItemsfromSourceDL(rlbGEOAvailable, rlbGEOSelected);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void LoadBusSeg(int SiteID)
        {
            AdminBusinessSegmentsBLL da = new AdminBusinessSegmentsBLL();
            DataSet dsBusSegList = new DataSet();
            DataSet dsSelectedBS = new DataSet();

            try
            {
                dsBusSegList = da.GetAllBusinessSegments();
                rlbBSAvailable.DataSource = dsBusSegList.Tables[0];
                rlbBSAvailable.DataTextField = "SegmentName";
                rlbBSAvailable.DataValueField = "BusinessSegmentID";
                rlbBSAvailable.DataBind();

                dsSelectedBS = da.ManufactruingSite_ViewBusSeg(SiteID);
                rlbBSSelected.DataSource = dsSelectedBS.Tables[0];
                rlbBSSelected.DataTextField = "BusinessSegmentname";
                rlbBSSelected.DataValueField = "BusinessSegmentID";
                rlbBSSelected.DataBind();
                RemoveDuplicateItemsfromSourceDL(rlbBSAvailable, rlbBSSelected);

            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void LoadSiteMangers(int SiteID)
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsSMList = new DataSet();
            DataSet dsSelectedSM = new DataSet();

            try
            {
                dsSMList = da.GetAvail_Sitemanagers();
                rlbSMavialable.DataSource = dsSMList.Tables[0];
                rlbSMavialable.DataTextField = "UserInfo";
                rlbSMavialable.DataValueField = "UserID";
                rlbSMavialable.DataBind();

                dsSelectedSM = da.GetSelected_Sitemanagers(SiteID);
                rlbSMSelected.DataSource = dsSelectedSM.Tables[0];
                rlbSMSelected.DataTextField = "UserInfo";
                rlbSMSelected.DataValueField = "UserID";
                rlbSMSelected.DataBind();
                RemoveDuplicateItemsfromSourceDL(rlbSMavialable, rlbSMSelected);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void RemoveDuplicateItemsfromSourceDL(RadListBox RLBSource, RadListBox RLBDest)
        {

            foreach (RadListBoxItem item in RLBDest.Items)
            {

                foreach (RadListBoxItem item1 in RLBSource.Items)
                {
                    if (item.Value == item1.Value)
                    {
                        RLBSource.Delete(item1);
                        break;
                    }
                }

            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strSiteName = "";
            string strCode = "";
            int intSetInactive = 1;

            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            try
            {

                strSiteName = txtSiteName.Text.Trim();
                strCode = txtCode.Text.Trim();

                if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                    intSetInactive = 0;
                else
                    intSetInactive = 1;

                string selectedGEOIDs = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbGEOSelected.Items)
                {
                    selectedGEOIDs += selectedItem.Value.Trim() + ",";
                }

                string selectedBSIDs = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbBSSelected.Items)
                {
                    selectedBSIDs += selectedItem.Value.Trim() + ",";
                }

                string selectedSMIDs = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSMSelected.Items)
                {
                    selectedSMIDs += selectedItem.Value.Trim() + ",";
                }

                if (selectedGEOIDs.Trim().Length > 0)
                {
                    selectedGEOIDs = selectedGEOIDs.Substring(0, selectedGEOIDs.Trim().Length - 1);
                }

                if (selectedBSIDs.Trim().Length > 0)
                {
                    selectedBSIDs = selectedBSIDs.Substring(0, selectedBSIDs.Trim().Length - 1);
                }

                if (selectedSMIDs.Trim().Length > 0)
                {
                    selectedSMIDs = selectedSMIDs.Substring(0, selectedSMIDs.Trim().Length - 1);
                }


                SiteID = da.UpdateManufacturingSite(SiteID, strSiteName, strCode,
                    UserInfo.GetCurrentUserName().ToString(), intSetInactive, selectedGEOIDs, selectedBSIDs, selectedSMIDs);

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadManufacturingSites", "CloseManufacturingSitesEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}