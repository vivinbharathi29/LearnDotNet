﻿using System;
using System.Data;
using System.Web.Services;

namespace iPulsar.Admin.SCM
{
    public partial class AddAvsToSCM : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            int intAvDetailID = 0;//NoOfSCMsUsed
            string strAVdetailID = "";
            if (Request.QueryString["AvDetailID"] != null)
            {
                intAvDetailID = Convert.ToInt32(Request.QueryString["AvDetailID"]);
                hdnAvDetailID.Value = intAvDetailID.ToString();
            }

            if (Request.QueryString["MultipleAvDetailIDs"] != null)
            {
                strAVdetailID = Request.QueryString["MultipleAvDetailIDs"].ToString();
                hdnAvDetailID.Value = strAVdetailID;
            }

            if (!IsPostBack)
                GetAllSCMs(intAvDetailID);
        }
        private void GetAllSCMs(int intAvDetailID)
        {
            AdminSharedAVBLL da = new AdminSharedAVBLL();
            DataSet dsSCMs = new DataSet();
            dsSCMs = da.GetAllSCMs(intAvDetailID);

            lstAvailSCMs.DataSource = dsSCMs;
            lstAvailSCMs.DataTextField = "SCM";
            lstAvailSCMs.DataValueField = "CombinedProductBrandId";
            lstAvailSCMs.DataBind();
        }
        [WebMethod]
        public static string AddAvsToSCMs(string strAvDetailIDs, string ProductBrandIDs)
        {
            string strMsg = "";
            AdminSharedAVBLL da = new AdminSharedAVBLL();
            try
            {
                da.AddAvsToSCMs(strAvDetailIDs, ProductBrandIDs, "", UserInfo.GetCurrentUserName().ToString(), out strMsg);
            }
            catch (Exception ex)
            {
                strMsg = ex.Message;
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            }
            return strMsg;
        }
    }
}