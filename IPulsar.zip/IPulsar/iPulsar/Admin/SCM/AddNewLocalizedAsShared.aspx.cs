﻿using iPulsar.Old_App_Code.BLL.FeatureCategories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Admin.SCM
{
    public partial class AddNewLocalizedAsShared : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            if (!IsPostBack)
            {
                ListLocalizedFeatureCategory();
                Updater.Value = UserInfo.GetCurrentUserName();
            }
        }

        private void ListLocalizedFeatureCategory()
        {
            FeatureCategoriesBLL obj = new FeatureCategoriesBLL();
            ddlCategories.DataSource = obj.ListLocalizedFeatureCategory();
            ddlCategories.DataTextField = "Name";
            ddlCategories.DataValueField = "FeatureCategoryId";
            ddlCategories.DataBind();
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetSCMCategoryList()
        {
            try
            {
                AdminSCMCategoryBLL adBll = new AdminSCMCategoryBLL();
                DataSet ds;
                DataView dv = null;

                ds = adBll.GetAllSCMCategory();
                dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "Abbreviation <> 'BUNIT' and parentcategoryid = 0";

                List<Dictionary<string, object>> dicSCMCategoryList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicSCMCategory = null;

                foreach (DataRowView rowView in dv)
                {
                    DataRow row = rowView.Row;
                    dicSCMCategory = new Dictionary<string, object>();
                    dicSCMCategory.Add("SCMCategoryID", row["SCMCategoryID"].ToString());
                    dicSCMCategory.Add("Name", row["Name"].ToString());

                    dicSCMCategoryList.Add(dicSCMCategory);
                }

                return dicSCMCategoryList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetFeatureList(int FeatureCategoryId)
        {
            try
            {
                List<Dictionary<string, object>> dicFeatureList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicFeature = null;

                FeaturesBLL obj = new FeaturesBLL();
                DataSet dsFeatureList = new DataSet();

                dsFeatureList = obj.GetFeaturesByFeatureCategoryID(FeatureCategoryId);

                for (int i = 0; i < dsFeatureList.Tables[0].Rows.Count; i++)
                {
                    dicFeature = new Dictionary<string, object>();
                    dicFeature.Add("FeatureID", dsFeatureList.Tables[0].Rows[i]["FeatureID"].ToString());
                    dicFeature.Add("FeatureName", dsFeatureList.Tables[0].Rows[i]["FeatureName"].ToString());
                    dicFeature.Add("GPGPHweb40_NB", dsFeatureList.Tables[0].Rows[i]["GPGPHweb40_NB"].ToString());
                    dicFeature.Add("GPGPHweb40_DT", dsFeatureList.Tables[0].Rows[i]["GPGPHweb40_DT"].ToString());
                    dicFeature.Add("SCMCategoryID", dsFeatureList.Tables[0].Rows[i]["SCMCategoryID"].ToString());
                    dicFeature.Add("DeliveryType", dsFeatureList.Tables[0].Rows[i]["DeliveryType"].ToString());

                    dicFeatureList.Add(dicFeature);
                }

                return dicFeatureList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetCountryList()
        {
            try
            {
                List<Dictionary<string, object>> dicCountryList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicCountry = null;

                AdminRegionsBLL obj = new AdminRegionsBLL();
                DataSet dsCountryList = new DataSet();

                dsCountryList = obj.GetAllConfigCode();

                for (int i = 0; i < dsCountryList.Tables[0].Rows.Count; i++)
                {
                    dicCountry = new Dictionary<string, object>();

                    dicCountry.Add("OptionConfig", dsCountryList.Tables[0].Rows[i]["OptionConfig"].ToString());
                    dicCountry.Add("CountryCode", dsCountryList.Tables[0].Rows[i]["CountryCode"].ToString());
                    dicCountryList.Add(dicCountry);
                }

                return dicCountryList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static string AddNewLocalizedAvAsShared(int FeatureID, int SCMCategoryID, string OptionConfig, string CountryCode, string updater, int ParentID)
        {
            try
            {
                //throw new System.ArgumentException("Parameter cannot be null", "original");
                int NewParentID = 0;
                AdminSharedAVBLL da = new AdminSharedAVBLL();
                da.AddNewLocalizedAvAsShared(FeatureID, SCMCategoryID, OptionConfig, CountryCode, updater, ParentID, out NewParentID);
                return NewParentID.ToString();
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw new Exception(ex.Message, ex.InnerException);
            }
        }
    }
}