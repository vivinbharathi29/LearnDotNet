﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;

namespace iPulsar.Admin.SCM
{
    public partial class Supplier_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            MainMasterPage master = (MainMasterPage)Page.Master;
            Page.Title = "Suppliers";
            master.pageheader = "Suppliers";
            GetPermission();
        }
        private void GetPermission()
        {  // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SupplierCode_Edit_Permission.ToString()))
            {
                Page.Title = "View Supplier List";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SupplierCode_Delete_Permission.ToString()))
            {
                rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
            }
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllSupplier()
        {
            try
            {
                List<Dictionary<string, object>> dicSupplierList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicSupplier = null;
                AdminSupplierBLL da = new AdminSupplierBLL();
                DataSet dsSupplierList = new DataSet();
                dsSupplierList = da.GetAllSupplierCode();
                for (int i = 0; i < dsSupplierList.Tables[0].Rows.Count; i++)
                {
                    dicSupplier = new Dictionary<string, object>();
                    dicSupplier.Add("SupplierID", dsSupplierList.Tables[0].Rows[i]["SupplierID"].ToString());
                    dicSupplier.Add("ProductLine", dsSupplierList.Tables[0].Rows[i]["ProductLine"].ToString());
                    dicSupplier.Add("Code", dsSupplierList.Tables[0].Rows[i]["Code"].ToString());
                    dicSupplier.Add("GeoName", dsSupplierList.Tables[0].Rows[i]["GEOName"].ToString());
                    dicSupplier.Add("BusinessSegmentName", dsSupplierList.Tables[0].Rows[i]["BusinessSegmentName"].ToString());
                    dicSupplier.Add("MFG_Code", dsSupplierList.Tables[0].Rows[i]["MFG_Code"].ToString());
                    dicSupplier.Add("COM_Code", dsSupplierList.Tables[0].Rows[i]["COM_Code"].ToString());
                    dicSupplier.Add("MKT_Code", dsSupplierList.Tables[0].Rows[i]["MKT_Code"].ToString());
                    dicSupplier.Add("SER_Code", dsSupplierList.Tables[0].Rows[i]["SER_Code"].ToString());
                    dicSupplier.Add("SRTimeCode", dsSupplierList.Tables[0].Rows[i]["SRTimeCode"].ToString());
                    dicSupplier.Add("SupplierSequence", dsSupplierList.Tables[0].Rows[i]["SupplierSequence"].ToString());
                    dicSupplier.Add("SRTimeNumber", dsSupplierList.Tables[0].Rows[i]["SRTimeNumber"].ToString());
                    dicSupplier.Add("State", dsSupplierList.Tables[0].Rows[i]["State"].ToString());

                    dicSupplierList.Add(dicSupplier);
                }
                return dicSupplierList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static string DeleteSupplier(int intSupplierID)
        {
            string strReturnMsg = "Supplier successfully removed.";
            try
            {
                AdminSupplierBLL da = new AdminSupplierBLL();
                da.DeleteSupplier(intSupplierID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }
    }
}