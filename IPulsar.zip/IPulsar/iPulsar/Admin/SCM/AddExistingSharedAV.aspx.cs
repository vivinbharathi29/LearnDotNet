﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Admin.SCM
{
    public partial class AddExistingSharedAV : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            if (!IsPostBack)
            {
                if (Request.QueryString["PVID"] != null)
                    hdnProductVersionID.Value = Request.QueryString["PVID"].ToString();
                if (Request.QueryString["BID"] != null)
                    hdnProductBrandID.Value = Request.QueryString["BID"].ToString();
                GetProductLineList();
                GetSCMCategoryList();
            }
        }
        private void GetProductLineList()
        {
            AdminSCMCategoryBLL adBll = new AdminSCMCategoryBLL();
            DataSet ds;

            ds = adBll.GetProductLines();
            ddlProductLine.DataSource = ds;
            ddlProductLine.DataTextField = "ProductLineFullName";
            ddlProductLine.DataValueField = "ProductLineID";
            ddlProductLine.DataBind();

            ddlProductLine.Items.Insert(0, new ListItem("Select a Product Line", "0"));
        }
        private void GetSCMCategoryList()
        {
            AdminSCMCategoryBLL adBll = new AdminSCMCategoryBLL();
            DataSet ds;
            DataView dv = null;

            ds = adBll.GetAllSCMCategory();
            dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "Abbreviation <> 'BUNIT'";

            ddlSCMCategory.DataSource = dv;
            ddlSCMCategory.DataTextField = "Name";
            ddlSCMCategory.DataValueField = "SCMCategoryID";
            ddlSCMCategory.DataBind();

            ddlSCMCategory.Items.Insert(0, new ListItem("Select a SCM Category", "0"));
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllSharedAVsForProductBrand(int ProductBrandID, int ProductLineID, int SCMCategoryID, string AVNo, string MktDesc)
        {
            try
            {
                List<Dictionary<string, object>> dicSharedAVsList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicSharedAV = null;
                AdminSharedAVBLL da = new AdminSharedAVBLL();
                DataSet dsSharedAVList = new DataSet();
                dsSharedAVList = da.GetAllSharedAVsForProductBrand(ProductBrandID, ProductLineID, SCMCategoryID, AVNo, MktDesc);
                for (int i = 0; i < dsSharedAVList.Tables[0].Rows.Count; i++)
                {
                    dicSharedAV = new Dictionary<string, object>();
                    dicSharedAV.Add("AvDetailID", dsSharedAVList.Tables[0].Rows[i]["AvDetailID"].ToString());
                    dicSharedAV.Add("AvNo", dsSharedAVList.Tables[0].Rows[i]["AvNo"].ToString());
                    dicSharedAV.Add("GPGDescription", dsSharedAVList.Tables[0].Rows[i]["GPGDescription"].ToString());
                    dicSharedAV.Add("MarketingDescription", dsSharedAVList.Tables[0].Rows[i]["MarketingDescription"].ToString());
                    dicSharedAV.Add("MarketingDescriptionPMG", dsSharedAVList.Tables[0].Rows[i]["MarketingDescriptionPMG"].ToString());
                    dicSharedAV.Add("ProductLine", dsSharedAVList.Tables[0].Rows[i]["ProductLine"].ToString());
                    dicSharedAV.Add("SCMCategory", dsSharedAVList.Tables[0].Rows[i]["SCMCategory"].ToString());
                    dicSharedAV.Add("Comments", dsSharedAVList.Tables[0].Rows[i]["Comments"].ToString());

                    dicSharedAVsList.Add(dicSharedAV);
                }

                return dicSharedAVsList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod]
        public static string AddAvsToSCMs(string AvDetailIDs, string ProductBrandIDs, string Releases)
        {
            string strMsg = "";
            AdminSharedAVBLL da = new AdminSharedAVBLL();

            try
            {
                da.AddAvsToSCMs(AvDetailIDs, ProductBrandIDs, Releases, UserInfo.GetCurrentUserName().ToString(), out strMsg);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strMsg = ex.Message;
            }
            return strMsg;
        }
        [WebMethod]
        public static List<Dictionary<string, string>> GetProductReleases(int ProductID)
        {
            try
            {
                ProductBLL da = new ProductBLL();

                List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
                Dictionary<string, string> Dictionary = null;

                DataSet ds = da.GetProductRelease(ProductID);

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("Release", ds.Tables[0].Rows[i]["ReleaseName"].ToString());
                    Dictionary.Add("ReleaseID", ds.Tables[0].Rows[i]["ReleaseID"].ToString());
                    rows.Add(Dictionary);
                }
                return rows;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}