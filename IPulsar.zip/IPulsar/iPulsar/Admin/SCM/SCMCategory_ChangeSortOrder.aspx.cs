﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace iPulsar.Admin.SCM
{
    public partial class SCMCategory_ChangeSortOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            if (!IsPostBack)
                LoadSCMCategories();
        }
        private void LoadSCMCategories()
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsSCMCategoryList = new DataSet();
            dsSCMCategoryList = da.GetAllSCMCategory();
            DataView dvSCMCategory = dsSCMCategoryList.Tables[0].DefaultView;
            dvSCMCategory.Sort = "SortOrder asc";
            lstSCMCategories.DataSource = dvSCMCategory;
            lstSCMCategories.DataTextField = "Name";
            lstSCMCategories.DataValueField = "SCMCategoryID";
            lstSCMCategories.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            StringBuilder strSCMCatetgories = new StringBuilder();
            if (lstSCMCategories.Items.Count > 0)
            {
                strSCMCatetgories.Append("<SCMCategories>");
                foreach (Telerik.Web.UI.RadListBoxItem scmcategory in lstSCMCategories.Items)
                {
                    //selectedIDs += selectedItem.Value.Trim() + ",";
                    strSCMCatetgories.Append("<SCMCategory>");
                    strSCMCatetgories.Append("<SCMCatID>" + scmcategory.Value + "</SCMCatID>");
                    strSCMCatetgories.Append("<SortOrder>" + (scmcategory.Index + 1).ToString() + "</SortOrder>");
                    strSCMCatetgories.Append("</SCMCategory>");
                }
                strSCMCatetgories.Append("</SCMCategories>");
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                da.UpdateSCMCategorySortOrder(strSCMCatetgories.ToString());

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadSCMcategoryfromsortorder", "CloseSCMSortOrderPopup(true)", true);
            }
        }
    }
}