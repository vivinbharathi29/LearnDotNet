﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Admin.SCM
{
    public partial class Supplier_Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            int intSupplierID = -1;
            if (Request.QueryString["SupplierID"] != null)
                intSupplierID = Convert.ToInt32(Request.QueryString["SupplierID"]);
            hdnSupplierID.Value = intSupplierID.ToString();
            if (!IsPostBack)
            {
                LoadProductLine();
                LoadGEO();
                LoadBusinessSegment(intSupplierID);
                LoadSupplierDetail(intSupplierID);
            }
            GetPermission();
        }
        private void GetPermission()
        {  // check permission from resource file instead of enums - task 19440
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.SupplierCode_Edit_Permission.ToString()))
            {
                Page.Title = "View Supplier";
                this.ddlProductLine.Enabled = false;
                this.txtSupplierCode.Enabled = false;
                this.ddlGEO.Enabled = false;
                rlbAvailable.Enabled = false;
                rlbSelected.Enabled = false;
                txtManufacturingCode.Enabled = false;
                txtComCode.Enabled = false;
                txtMktCode.Enabled = false;
                txtSerCode.Enabled = false;
                txtSRTimeCode.Enabled = false;
                txtSupplierSequence.Enabled = false;
                txtSRTimeNumber.Enabled = false;
                this.btnSave.Enabled = false;
                this.rbState.Enabled = false;                
            }
        }
        private void LoadProductLine()
        {
            AdminSupplierBLL da = new AdminSupplierBLL();
            DataSet dsProductLine = new DataSet();
            dsProductLine = da.GetProductLine();

            ddlProductLine.DataSource = dsProductLine;
            ddlProductLine.DataTextField = "ProductLine";
            ddlProductLine.DataValueField = "ProductLineID";

            ddlProductLine.DataBind();
            ddlProductLine.Items.Insert(0, new ListItem("Select a ProductLine", "0"));
        }
        private void LoadGEO()
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsGEO = new DataSet();

            dsGEO = da.GetGEO();
            ddlGEO.DataSource = dsGEO;
            ddlGEO.DataTextField = "Name";
            ddlGEO.DataValueField = "GEOID";

            ddlGEO.DataBind();
            ddlGEO.Items.Insert(0, new ListItem("Select a GEO", "0"));            
        }

        private void LoadBusinessSegment(int intSupplierCode)
        {
            AdminSupplierBLL da = new AdminSupplierBLL();
            DataSet dsBusinessSegment = new DataSet();
            dsBusinessSegment = da.GetBusinessSegment(intSupplierCode);

            rlbAvailable.DataSource = dsBusinessSegment.Tables[0];
            rlbAvailable.DataTextField = "Name";
            rlbAvailable.DataValueField = "BusinessSegmentID";
            rlbAvailable.DataBind();

            if (dsBusinessSegment.Tables[1] != null)
            {
                rlbSelected.DataSource = dsBusinessSegment.Tables[1];
                rlbSelected.DataTextField = "Name";
                rlbSelected.DataValueField = "BusinessSegmentID";
                rlbSelected.DataBind();
            }
        }
        private void LoadSupplierDetail(int intSupplierID)
        {
            AdminSupplierBLL da = new AdminSupplierBLL();
            DataSet dsSupplierDetail = new DataSet();
            dsSupplierDetail = da.GetSuplierDetailByID(intSupplierID);

            if (intSupplierID > 0)
            {
                if (dsSupplierDetail.Tables.Count > 0 && dsSupplierDetail.Tables[0].Rows.Count > 0)
                {
                    ddlProductLine.SelectedValue = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["ProductLineID"]);
                    hdnOldProductLineID.Value = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["ProductLineID"]);
                    txtSupplierCode.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["Code"]);
                    ddlGEO.SelectedValue = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["GeoID"]);
                    txtManufacturingCode.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["MFG_Code"]);
                    txtComCode.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["Com_Code"]);
                    txtMktCode.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["MKT_Code"]);
                    txtSerCode.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["SER_Code"]);
                    txtSRTimeCode.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["SupplierResponseTimeCode"]);
                    txtSupplierSequence.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["SupplierSequence"]);
                    hdnOldSupplierSequence.Value = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["SupplierSequence"]);
                    txtSRTimeNumber.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["SupplierResponseTimeNumber"]);
                    if (dsSupplierDetail.Tables[0].Rows[0]["State"].ToString() == "Inactive")
                    {
                        rbState.SelectedValue = "0";
                    }
                    else if (dsSupplierDetail.Tables[0].Rows[0]["State"].ToString() == "Active")
                    {
                        rbState.SelectedValue = "1";
                    }
                    lblCreator.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["CreatedBy"]);
                    lblTimeCreated.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["Created"]);
                    lblUpdater.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["UpdatedBy"]);
                    lblTimeChanged.Text = Convert.ToString(dsSupplierDetail.Tables[0].Rows[0]["Updated"]);
                    pnlHistory.Visible = true;
                }
            }
            else
            {
                lblCreator.Text = UserInfo.GetCurrentUserName();
                lblUpdater.Text = UserInfo.GetCurrentUserName();
                pnlHistory.Visible = false;
            }
        }
        [WebMethod]
        public static int GetLastSequenceNumber(int intProductLineID)
        {
            try
            {
                AdminSupplierBLL da = new AdminSupplierBLL();
                int intSequenceNumber = 1;
                if (intProductLineID > 0)
                {
                    intSequenceNumber = da.GetLastSequenceNumber(intProductLineID);
                }
                return intSequenceNumber;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        public void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Authenticate.IsSessionExpired())
                {
                    AdminSupplierBLL da = new AdminSupplierBLL();
                    int intSupplierID = 0, intProductLineID = 0, intGEOID = 0, intSupplierSequence = 0, intIsActive = 0;
                    string strSupplierCode = "", strBusinessSegmentIDs = "", strManufacturingCode = "", strCOMCode = "", strMKTCode = "", strSERCode = "", strSRTimeCode = "", strSRTimeNumber = "";
                    intSupplierID = Convert.ToInt32(hdnSupplierID.Value);
                    intProductLineID = Convert.ToInt32(ddlProductLine.SelectedValue);
                    intGEOID = Convert.ToInt32(ddlGEO.SelectedValue);
                    intSupplierSequence = Convert.ToInt32(txtSupplierSequence.Text.Trim());
                    intIsActive = Convert.ToInt32(rbState.SelectedValue);

                    strSupplierCode = Convert.ToString(txtSupplierCode.Text.Trim());
                    strManufacturingCode = Convert.ToString(txtManufacturingCode.Text.Trim());
                    strCOMCode = Convert.ToString(txtComCode.Text.Trim());
                    strMKTCode = Convert.ToString(txtMktCode.Text.Trim());
                    strSERCode = Convert.ToString(txtSerCode.Text.Trim());
                    strSRTimeCode = Convert.ToString(txtSRTimeCode.Text.Trim());
                    strSRTimeNumber = Convert.ToString(txtSRTimeNumber.Text.Trim());

                    foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbSelected.Items)
                    {
                        strBusinessSegmentIDs += selectedItem.Value.Trim() + ",";
                    }
                    if (strBusinessSegmentIDs.Trim().Length > 0)
                    {
                        strBusinessSegmentIDs = strBusinessSegmentIDs.Substring(0, strBusinessSegmentIDs.Trim().Length - 1);
                    }

                    da.ModifySupplierInfo(intSupplierID, intProductLineID, strSupplierCode, intGEOID, strBusinessSegmentIDs, strManufacturingCode, strCOMCode, strMKTCode, strSERCode, strSRTimeCode, intSupplierSequence, strSRTimeNumber, intIsActive, UserInfo.GetCurrentUserName());
                    lblError.Text = "";
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadSuppliers", "CloseSupplierEditPopup(true)", true);
                }
                else
                {
                    throw new Exception("Your session has expired.");
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}