﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;
using System.Web.Services;


public partial class Admin_System_Admin_Partners_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "Partners";
        Page.Title = "Partners";
        GetPermission();
    }

    private void GetPermission()
    {  // check permission from resource file instead of enums - task 19440
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Partner_Edit_Permission.ToString()))
        {
            Page.Title = "View Partner List";
            lnkAdd.Disabled = true;
            lnkAdd.Attributes["Class"] = "disabled";
            rmContextMenu.Items.FindItemByValue("Add").Enabled = false;
        }

        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Partner_Delete_Permission.ToString()))
        {
            rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetPartners()
    {
        try
        {
            List<Dictionary<string, object>> dicList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicUser = null;
            AdminPartnersBLL da = new AdminPartnersBLL();
            DataSet dsList = new DataSet();
            dsList = da.GetPartners(-1);
            for (int i = 0; i < dsList.Tables[0].Rows.Count; i++)
            {
                dicUser = new Dictionary<string, object>();
                dicUser.Add("PartnerID", dsList.Tables[0].Rows[i]["PartnerID"].ToString());
                dicUser.Add("Name", dsList.Tables[0].Rows[i]["Name"].ToString());
                dicUser.Add("WebSite", dsList.Tables[0].Rows[i]["WebSite"].ToString());
                dicUser.Add("PartnerType", dsList.Tables[0].Rows[i]["PartnerType"].ToString());
                dicUser.Add("State", dsList.Tables[0].Rows[i]["State"].ToString());

                dicList.Add(dicUser);
            }
            return dicList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static List<string> GetUserPermission()
    {
        try
        {
            List<string> per = new List<string>();
            per = Permission.GetUserPermissions(UserInfo.GetCurrentUserID());
            return per;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static string RemovePartner(int intPartnerID)
    {
        string strReturnMsg = "Partner successfully removed.";
        try
        {
            AdminPartnersBLL da = new AdminPartnersBLL();
            da.DeletePartner(intPartnerID);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strReturnMsg = ex.Message;
        }
        return strReturnMsg;
    }
}

