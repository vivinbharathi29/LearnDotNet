﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using System.Text;
using Telerik.Web.UI;

namespace iPulsar.Admin.System_Admin
{
    public partial class Vendor_Edit : System.Web.UI.Page
    {
        int VendorID;

        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession(false);
            string mode;
            mode = Request.QueryString["mode"];
            VendorID = Convert.ToInt32(Request.QueryString["VendorID"]);

            if (!IsPostBack)
            {
                if ((mode == "update"))
                {
                    LoadVendors(VendorID);
                    Page.Title = "Modify Vendor";
                    LoadCategoryType();
                    LoadCategoryTypes(VendorID);

                }
                else if (mode == "create")
                {
                    Page.Title = "Add New Vendor";
                    pnlHistory.Visible = false;
                    LoadCategoryType();

                }

            }
            GetPermission();

        }
        // check permission from resource file instead of enums - task 19440
        private void GetPermission()
        {
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ComponentCategory_Edit_Permission.ToString()))
            {
                Page.Title = "View Vendors";
                this.txtVendor.Enabled = false;
                this.btnSave.Enabled = false;
                this.txtWebsite.Enabled = false;
                this.lblEnter.Visible = false;
                rlbCTavialable.Enabled = false;
                rlbCTSelected.Enabled = false;
                rbState.Enabled = false;


            }
        }

        private void LoadVendors(int VendorID)
        {
            AdminSCMCategoryBLL adBll = new AdminSCMCategoryBLL();
            DataSet ds;

            try
            {
                ds = adBll.GetVendorById(VendorID);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[0];
                    txtVendor.Text = dr["Name"].ToString();
                    txtWebsite.Text = dr["Website"].ToString();

                    rbState.SelectedValue = dr["State"].ToString();
                    lblTimeChanged.Text = dr["Updated"].ToString().Trim();
                    lblTimeCreated.Text = dr["Created"].ToString().Trim();
                    lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                    lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                    ds.Dispose();
                    pnlHistory.Visible = true;
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void LoadCategoryType()
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsCategoryType = new DataSet();
            try
            {
                dsCategoryType = da.GetAvail_CategoryTypes();
                rlbCTavialable.DataSource = dsCategoryType.Tables[0];
                rlbCTavialable.DataTextField = "Name";
                rlbCTavialable.DataValueField = "FeatureClassID";
                rlbCTavialable.DataBind();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void LoadCategoryTypes(int VendorID)

        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsSelectedCategoryType = new DataSet();
            dsSelectedCategoryType = da.GetSelected_CategoryType(VendorID);
            rlbCTSelected.DataSource = dsSelectedCategoryType.Tables[0];
            rlbCTSelected.DataTextField = "Name";
            rlbCTSelected.DataValueField = "FeatureClassID";
            rlbCTSelected.DataBind();
            RemoveDuplicateItemsfromSourceDL(rlbCTavialable, rlbCTSelected);
        }


        private void RemoveDuplicateItemsfromSourceDL(RadListBox RLBSource, RadListBox RLBDest)
        {
            foreach (RadListBoxItem item in RLBDest.Items)
            {
                foreach (RadListBoxItem item1 in RLBSource.Items)
                {
                    if (item.Value == item1.Value)
                    {
                        RLBSource.Delete(item1);
                        break;
                    }
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strVendorName = "";
            string strWebsite = "";
            int intSetInactive = 1;

            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            try
            {

                strVendorName = txtVendor.Text.Trim();
                strWebsite = txtWebsite.Text.Trim();

                if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                    intSetInactive = 0;
                else
                    intSetInactive = 1;

                string selectedCategoryTypeIDs = "";
                foreach (Telerik.Web.UI.RadListBoxItem selectedItem in rlbCTSelected.Items)
                {
                    selectedCategoryTypeIDs += selectedItem.Value.Trim() + ",";
                }


                if (selectedCategoryTypeIDs.Trim().Length > 0)
                {
                    selectedCategoryTypeIDs = selectedCategoryTypeIDs.Substring(0, selectedCategoryTypeIDs.Trim().Length - 1);
                }


                VendorID = da.UpdateVendors(VendorID, strVendorName, strWebsite,
                    UserInfo.GetCurrentUserName().ToString(), intSetInactive, selectedCategoryTypeIDs);

                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadVendors", "CloseVendorsEditPopup(true)", true);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }
}