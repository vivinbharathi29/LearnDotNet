﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;


namespace iPulsar.Admin.System_Admin
{
    public partial class UserAccessRequest : System.Web.UI.Page
    {
        int intUserID;
        int intTeamID;
        int intRequesterID;
        int rolecount = 0;


        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession(false);

            UserInfo objuserInfo = UserInfo.GetCurrentUserInfo();
            intRequesterID = objuserInfo.ID; // currently logged in userid which will be the requesterid 
            intTeamID = Convert.ToInt32(Request.QueryString["TeamID"]);
            intUserID = Convert.ToInt32(Request.QueryString["UserID"]); // userID depends from where the requesting is coming ( Request Access or Request Similar Access)
            hdnFromContextMenu.Value = Request.QueryString["FromContextMenu"];
            hdnIsODM.Value = UserInfo.GetCurrentUserIsODM().ToString();
            hdnTeamID.Value = intTeamID.ToString();

            if (!IsPostBack)
            {
                Page.Title = "Request Access";
                LoadTeamAndUserRoles(intTeamID, intUserID);

            }

            // get count of existing roles
            for (int i = 0; i < wdgRoles.Rows.Count; i++)
            {
                if (wdgRoles.Rows[i].Items.FindItemByKey("HasRole").Value.ToString() == "True")
                {
                    rolecount++;
                }
            }
            hdnexistingRoleCount.Value = rolecount.ToString();
        }


        private void LoadTeamAndUserRoles(int intTeamID, int intUserID)
        {
            try
            {
                AdminAddUserToTeamBLL adBll = new AdminAddUserToTeamBLL();
                DataSet ds;
                ds = adBll.LoadTeamAndUserRoles(intTeamID, intUserID);
                if (ds.Tables[0].Rows.Count > 0 )
                {   if (hdnFromContextMenu.Value == "1")
                        lblTitle.Text = "User's Roles for Team: ";
                    else
                        lblTitle.Text = "Roles for Team: ";
                    lblTeamName.Text = ds.Tables[0].Rows[0]["TeamName"].ToString();
                    divRolesList.Visible = true;
                    DataTable dtRoles = ds.Tables[0];
                    wdgRoles.DataSource = dtRoles;
                    wdgRoles.DataBind();
                }
                else
                {
                    divRolesList.Visible = false;
                }
                
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                AdminAddUserToTeamBLL adBll2 = new AdminAddUserToTeamBLL();
                string strRoles = "";
                string strNoRoles = "";

                for (int i = 0; i < wdgRoles.Rows.Count; i++)
                {
                    if (wdgRoles.Rows[i].Items.FindItemByKey("HasRole").Value.ToString() == "True")
                    {
                        strRoles = strRoles == "" ? wdgRoles.Rows[i].DataKey[0].ToString() : strRoles + "," + wdgRoles.Rows[i].DataKey[0].ToString();
                    }

                    else
                    {
                        strNoRoles = strNoRoles == "" ? wdgRoles.Rows[i].DataKey[0].ToString() : strNoRoles + "," + wdgRoles.Rows[i].DataKey[0].ToString();
                    }
                }

                adBll2.UserAccessRequest(strRoles, intTeamID, intRequesterID, strNoRoles);
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "CloseUserAccessRequest", "CloseUserAccessRequest(true," + hdnIsODM.Value + "," + hdnTeamID.Value + ")", true);                   
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }
    }

}


