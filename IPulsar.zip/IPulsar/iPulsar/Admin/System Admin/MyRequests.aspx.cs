﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

public partial class UserAndRoles_MyRequests : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        UserInfo objuserInfo = UserInfo.GetCurrentUserInfo();
        lblHeader.Text = objuserInfo.FirstNameLastName + " User Requests";
        lblMessage.Text = "Please contact a Team Owner to process your request. Team owners can be seen by selecting a Team.";
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetMyRequests()
    {
        try
        {
            List<Dictionary<string, object>> dicMyRequestsList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicOwner = null;
            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            DataSet dsRequestsList = new DataSet();
            UserInfo objuserInfo = UserInfo.GetCurrentUserInfo();
            dsRequestsList = da.GetMyRequests(objuserInfo.ID.ToString());
            for (int i = 0; i < dsRequestsList.Tables[0].Rows.Count; i++)
            {
                dicOwner = new Dictionary<string, object>();
                dicOwner.Add("TeamName", dsRequestsList.Tables[0].Rows[i]["TeamName"].ToString());
                dicOwner.Add("TeamID", dsRequestsList.Tables[0].Rows[i]["TeamID"].ToString());
                dicOwner.Add("RoleName", dsRequestsList.Tables[0].Rows[i]["RoleName"].ToString());
                dicOwner.Add("RoleID", dsRequestsList.Tables[0].Rows[i]["RoleID"].ToString());
                dicOwner.Add("Description", dsRequestsList.Tables[0].Rows[i]["Description"].ToString());
                dicOwner.Add("RequestType", dsRequestsList.Tables[0].Rows[i]["RequestType"].ToString());
                dicOwner.Add("Created", dsRequestsList.Tables[0].Rows[i]["Created"].ToString());
                dicMyRequestsList.Add(dicOwner);
            }
            return dicMyRequestsList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}