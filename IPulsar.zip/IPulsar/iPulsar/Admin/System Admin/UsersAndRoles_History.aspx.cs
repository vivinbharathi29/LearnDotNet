﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

//******************************************************************
//File Description:     REQUIRED FOR USER AND ROLES CHANGE HISTORY PAGE
//Created:              2016, 03/18/2016 Harris, Valerie - PBI 7063 / Task 18067 
//******************************************************************
public partial class UsersAndRoles_History : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        Page.Title = "User Change History";

        // add user name next to the header when Change History is viewed from the context menu(user specifc) - Bug 19873 - task 19957 (5)
        if (Request.QueryString["UserName"] != null)
        {
            string UserName = Convert.ToString(Request.QueryString["UserName"]);
            master.pageheader = "User Change History: " + UserName;
        }
        else
        {
            master.pageheader = "User Change History";
        }
    }

    private void LoadActivityLogType()
    {
        AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
        DataSet dsActivityLogTypes = new DataSet();
        dsActivityLogTypes = da.GetAllActivityLogTypes();

        DataView dvActivityLogType = dsActivityLogTypes.Tables[0].DefaultView;
        dvActivityLogType.RowFilter = "State = 'Active'";

        ddlActivityLogType.DataSource = dvActivityLogType.ToTable();
        ddlActivityLogType.DataTextField = "Name";
        ddlActivityLogType.DataValueField = "ActivityLogTypeID";
        ddlActivityLogType.DataBind();

        ddlActivityLogType.Items.Insert(0, new ListItem("All Actions", "0"));
        ddlActivityLogType.Items.Insert(0, new ListItem("Select a Action", "-1"));

        string strSelectedALTID = "-1";
        strSelectedALTID = Cookie.GetDBCookie("UsersAndRoles_ActivityLogTypeID");

        ddlActivityLogType.SelectedValue = strSelectedALTID;
    }

    private void LoadBusinessFunctions()
    {
        AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
        DataSet dsBusinessFunctions = new DataSet();
        dsBusinessFunctions = da.GetAllBusinessFunctions();

        DataView dvBusinessFunction = dsBusinessFunctions.Tables[0].DefaultView;
        dvBusinessFunction.RowFilter = "State = 'Active'";

        ddlBusinessFunction.DataSource = dvBusinessFunction.ToTable();
        ddlBusinessFunction.DataTextField = "Name";
        ddlBusinessFunction.DataValueField = "BusinessFunctionID";
        ddlBusinessFunction.DataBind();

        ddlBusinessFunction.Items.Insert(0, new ListItem("All Business Functions", "0"));
        ddlBusinessFunction.Items.Insert(0, new ListItem("Select a Business Function", "-1"));

        string strSelectedBFID = "-1";
        strSelectedBFID = Cookie.GetDBCookie("UsersAndRoles_BusinessFunctionID");

        ddlBusinessFunction.SelectedValue = strSelectedBFID;
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetAllActivityLogTypes()
    {
        try
        {
            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            DataSet dsActivityLogTypes = new DataSet();
            dsActivityLogTypes = da.GetAllActivityLogTypes();

            List<Dictionary<string, object>> dicActivityLogTypes = new List<Dictionary<string, object>>();
            DataRow[] drActivityLogTypes = dsActivityLogTypes.Tables[0].Select("State = 'Active'", "Name");

            for (int i = 0; i < dsActivityLogTypes.Tables[0].Rows.Count; i++)
            {
                Dictionary<string, object> Dictionary = new Dictionary<string, object>();
                Dictionary.Add("ActivityLogTypeID", dsActivityLogTypes.Tables[0].Rows[i]["ActivityLogTypeID"].ToString());
                Dictionary.Add("Name", dsActivityLogTypes.Tables[0].Rows[i]["Name"].ToString());
                Dictionary.Add("PreSelected", dsActivityLogTypes.Tables[0].Rows[i]["PreSelected"].ToString());
                dicActivityLogTypes.Add(Dictionary);
            }
            return dicActivityLogTypes;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetAllBusinessFunctions()
    {
        try
        {
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            DataSet dsBusinessFunctions = new DataSet();
            dsBusinessFunctions = da.GetAllBusinessFunctions();

            List<Dictionary<string, object>> dicBusinessFunctions = new List<Dictionary<string, object>>();
            DataRow[] drBusinessFunctions = dsBusinessFunctions.Tables[0].Select("State = 'Active'", "Name");

            for (int i = 0; i < dsBusinessFunctions.Tables[0].Rows.Count; i++)
            {
                Dictionary<string, object> Dictionary = new Dictionary<string, object>();
                Dictionary.Add("BusinessFunctionID", dsBusinessFunctions.Tables[0].Rows[i]["BusinessFunctionID"].ToString());
                Dictionary.Add("Name", dsBusinessFunctions.Tables[0].Rows[i]["Name"].ToString());
                Dictionary.Add("PreSelected", dsBusinessFunctions.Tables[0].Rows[i]["PreSelected"].ToString());
                dicBusinessFunctions.Add(Dictionary);
            }
            return dicBusinessFunctions;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetTeamByBusinessFunction(int BusinessFunctionID)
    {
        try
        {
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            DataSet dsTeam = new DataSet();
            dsTeam = da.GetTeamByBusinessFunctionID(BusinessFunctionID);

            List<Dictionary<string, object>> dicTeams = new List<Dictionary<string, object>>();
            DataRow[] drTeams = dsTeam.Tables[0].Select("State = 'Active'", "Name");

            for (int i = 0; i < drTeams.Length; i++)
            {
                Dictionary<string, object> Dictionary = new Dictionary<string, object>();
                Dictionary.Add("TeamID", drTeams[i]["TeamID"].ToString());
                Dictionary.Add("Name", drTeams[i]["Name"].ToString());
                Dictionary.Add("PreSelected", drTeams[i]["PreSelected"].ToString());
                dicTeams.Add(Dictionary);
            }
            return dicTeams;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static int GetBusinessFunctionByTeamID(int TeamID)
    {
        try
        {
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            return da.GetBusinessFunctionByTeamID(TeamID);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetRolesByBusinessFunction(int BusinessFunctionID)
    {
        try
        {
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            DataSet dsRoles = new DataSet();
            dsRoles = da.GetRolesByBusinessFunctionID(BusinessFunctionID);

            List<Dictionary<string, object>> dicRoles = new List<Dictionary<string, object>>();
            DataRow[] drRoles = dsRoles.Tables[0].Select("State = 'Active'", "Name");

            for (int i = 0; i < drRoles.Length; i++)
            {
                Dictionary<string, object> Dictionary = new Dictionary<string, object>();
                Dictionary.Add("RoleID", drRoles[i]["RoleID"].ToString());
                Dictionary.Add("Name", drRoles[i]["Name"].ToString());
                Dictionary.Add("PreSelected", drRoles[i]["PreSelected"].ToString());
                dicRoles.Add(Dictionary);
            }
            return dicRoles;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetRolesByTeamID(int TeamID)
    {
        try
        {
            AdminTeamsBLL da = new AdminTeamsBLL();
            DataSet dsRoles = new DataSet();
            dsRoles = da.GetRolesByTeamID(TeamID);

            List<Dictionary<string, object>> dicRoles = new List<Dictionary<string, object>>();
            DataRow[] drRoles = dsRoles.Tables[1].Select("State = 'Active'", "Name");

            for (int i = 0; i < drRoles.Length; i++)
            {
                Dictionary<string, object> Dictionary = new Dictionary<string, object>();
                Dictionary.Add("RoleID", drRoles[i]["RoleID"].ToString());
                Dictionary.Add("Name", drRoles[i]["Name"].ToString());
                Dictionary.Add("PreSelected", drRoles[i]["PreSelected"].ToString());
                dicRoles.Add(Dictionary);
            }
            return dicRoles;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetActivityLog(int ActivityLogTypeID, int UserID, int BusinessFunctionID, int TeamID, int RoleID)
    {
        try
        {
            List<Dictionary<string, object>> dicActivityLogList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicActivityLog = null;
            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            DataSet dsActivityLogList = new DataSet();
            dsActivityLogList = da.GetActivityLogList(ActivityLogTypeID, UserID, BusinessFunctionID, TeamID, RoleID);
            for (int i = 0; i < dsActivityLogList.Tables[0].Rows.Count; i++)
            {
                dicActivityLog = new Dictionary<string, object>();
                dicActivityLog.Add("ActivityLogID", dsActivityLogList.Tables[0].Rows[i]["ActivityLogID"].ToString());
                dicActivityLog.Add("UserId", dsActivityLogList.Tables[0].Rows[i]["UserId"].ToString());
                dicActivityLog.Add("UserName", dsActivityLogList.Tables[0].Rows[i]["UserName"].ToString());
                dicActivityLog.Add("Name", dsActivityLogList.Tables[0].Rows[i]["Name"].ToString());
                dicActivityLog.Add("Comment", dsActivityLogList.Tables[0].Rows[i]["Comment"].ToString());
                dicActivityLog.Add("CreatedOn", dsActivityLogList.Tables[0].Rows[i]["CreatedOn"].ToString());
                dicActivityLog.Add("CreatedBy", dsActivityLogList.Tables[0].Rows[i]["CreatedBy"].ToString());
                dicActivityLog.Add("UpdatedOn", dsActivityLogList.Tables[0].Rows[i]["UpdatedOn"].ToString());
                dicActivityLog.Add("UpdatedBy", dsActivityLogList.Tables[0].Rows[i]["UpdatedBy"].ToString());
                dicActivityLog.Add("ImpersonatedUserName", dsActivityLogList.Tables[0].Rows[i]["ImpersonatedUserName"].ToString());
                dicActivityLog.Add("BusinessFunctionName", dsActivityLogList.Tables[0].Rows[i]["BusinessFunctionName"].ToString());
                dicActivityLog.Add("TeamName", dsActivityLogList.Tables[0].Rows[i]["TeamName"].ToString());
                dicActivityLog.Add("RoleName", dsActivityLogList.Tables[0].Rows[i]["RoleName"].ToString());

                dicActivityLogList.Add(dicActivityLog);
            }
            return dicActivityLogList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<string> GetUserPermission()
    {
        try
        {
            return Permission.GetUserPermissions(UserInfo.GetCurrentUserID());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static void SaveSelectedValue(string strName, string strValue)
    {
        try
        {
            Cookie.SetDBCookie(strName, strValue);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static string GetCookieValue_BusinessFunction()
    {
        try
        {
            return Cookie.GetDBCookie("UsersAndRoles_BusinessFunctionID");
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }


    [WebMethod(EnableSession = true)]
    public static string GetCookieValue_ActivityLogType()
    {
        try
        {
            return Cookie.GetDBCookie("UsersAndRoles_ActivityLogTypeID");
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}
