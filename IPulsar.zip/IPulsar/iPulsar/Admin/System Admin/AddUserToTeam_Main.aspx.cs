﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Web.UI.GridControls;
using System.Web.Services;

public partial class Admin_System_Admin_AddUserToTeam_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        master.pageheader = "Add User To Team (" + Request.QueryString["TeamName"] + ")";
        Page.Title = "Add User To Team (" + Request.QueryString["TeamName"] + ")";
        hdnTeamID.Value  = Request.QueryString["TeamID"];
        if (IsPostBack)
        {
            lblError.Text = "";
        }
    }
    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetUsersNotInTeam(int TeamID)
    {
        try
        {
            List<Dictionary<string, object>> dicUsersList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicUser = null;
            AdminAddUserToTeamBLL adBll = new AdminAddUserToTeamBLL();
            DataSet dsUserList = new DataSet();
            dsUserList = adBll.GetUsersNotInTeam(TeamID);
            for (int i = 0; i < dsUserList.Tables[0].Rows.Count; i++)
            {
                dicUser = new Dictionary<string, object>();
                dicUser.Add("UserId", dsUserList.Tables[0].Rows[i]["UserId"].ToString());
                dicUser.Add("LastName", dsUserList.Tables[0].Rows[i]["LastName"].ToString());
                dicUser.Add("FirstName", dsUserList.Tables[0].Rows[i]["FirstName"].ToString());
                dicUser.Add("NtDomain", dsUserList.Tables[0].Rows[i]["NtDomain"].ToString());
                dicUser.Add("NtName", dsUserList.Tables[0].Rows[i]["NtName"].ToString());
                dicUser.Add("Email", dsUserList.Tables[0].Rows[i]["Email"].ToString());
                dicUser.Add("Phone", dsUserList.Tables[0].Rows[i]["Phone"].ToString());
                dicUser.Add("State", dsUserList.Tables[0].Rows[i]["State"].ToString());
                dicUser.Add("NameExtension", dsUserList.Tables[0].Rows[i]["NameExtension"].ToString());
                dicUser.Add("IsHpTeam", dsUserList.Tables[0].Rows[i]["IsHpTeam"].ToString());
                dicUsersList.Add(dicUser);
            }
            return dicUsersList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static int IsUserExists(int UserID, string Email)
    {
        try
        {
            AdminAddUserToTeamBLL da = new AdminAddUserToTeamBLL();
            return da.IsUserInSystem(UserID, Email);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    protected void btnUserAndRoles_Click(object sender, EventArgs e)
    {
        Response.Redirect("UsersAndRoles_Main.aspx");
    }
}

