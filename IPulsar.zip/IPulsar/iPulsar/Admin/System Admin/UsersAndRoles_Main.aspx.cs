﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UsersAndRoles_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        Page.Title = "Users and Roles";
        master.pageheader = "Users and Roles";

        // get currently logged in user id
        UserInfo objuserInfo = UserInfo.GetCurrentUserInfo();
        hdnCurrentLoggedInUserID.Value = objuserInfo.ID.ToString();
    }

    private void LoadBusinessFunctions()
    {
        AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
        DataSet dsBusinessFunctions = da.GetAllBusinessFunctions();

        DataView dvBusinessFunction = dsBusinessFunctions.Tables[0].DefaultView;
        dvBusinessFunction.RowFilter = "State = 'Active'";

        ddlBusinessFunction.DataSource = dvBusinessFunction.ToTable();
        ddlBusinessFunction.DataTextField = "Name";
        ddlBusinessFunction.DataValueField = "BusinessFunctionID";
        ddlBusinessFunction.DataBind();

        ddlBusinessFunction.Items.Insert(0, new ListItem("All Business Functions", "0"));
        ddlBusinessFunction.Items.Insert(0, new ListItem("Select a Business Function", "-1"));
        ddlBusinessFunction.SelectedValue = Cookie.GetDBCookie("UsersAndRoles_BusinessFunctionID");
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetAllBusinessFunctions()
    {
        try
        {
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            DataSet dsBusinessFunctions = da.GetAllBusinessFunctions();

            List<Dictionary<string, object>> dicBusinessFunctions = new List<Dictionary<string, object>>();
            DataRow[] drBusinessFunctions = dsBusinessFunctions.Tables[0].Select("State = 'Active'", "Name");

            for (int i = 0; i < dsBusinessFunctions.Tables[0].Rows.Count; i++)
            {
                Dictionary<string, object> Dictionary = new Dictionary<string, object>();
                Dictionary.Add("BusinessFunctionID", dsBusinessFunctions.Tables[0].Rows[i]["BusinessFunctionID"].ToString());
                Dictionary.Add("Name", dsBusinessFunctions.Tables[0].Rows[i]["Name"].ToString());
                Dictionary.Add("PreSelected", dsBusinessFunctions.Tables[0].Rows[i]["PreSelected"].ToString());
                dicBusinessFunctions.Add(Dictionary);
            }
            return dicBusinessFunctions;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetTeamByBusinessFunction(int BusinessFunctionID)
    {
        try
        {
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            DataSet dsTeam = da.GetTeamByBusinessFunctionID(BusinessFunctionID);

            List<Dictionary<string, object>> dicTeams = new List<Dictionary<string, object>>();
            DataRow[] drTeams;

            UserInfo u = UserInfo.GetCurrentUserInfo();
            if (u.PartnerId != 1)
                drTeams = dsTeam.Tables[0].Select("State = 'Active' AND PartnerId=" + u.PartnerId.ToString(), "Name");
            else if (Permission.IsCurrentUserHasPermission(Resources.Permissions.System_Role_Permission.ToString()))
                drTeams = dsTeam.Tables[0].Select("State = 'Active' or Name like '%System Team Roster%'", "Name");
            else
                drTeams = dsTeam.Tables[0].Select("State = 'Active' and Name Not like '%System Team Roster%'", "Name");

            for (int i = 0; i < drTeams.Length; i++)
            {
                Dictionary<string, object> Dictionary = new Dictionary<string, object>();
                Dictionary.Add("TeamID", drTeams[i]["TeamID"].ToString());
                Dictionary.Add("Name", drTeams[i]["Name"].ToString());
                Dictionary.Add("PreSelected", drTeams[i]["PreSelected"].ToString());
                dicTeams.Add(Dictionary);
            }
            return dicTeams;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static int GetBusinessFunctionByTeamID(int TeamID)
    {
        try
        {
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            return da.GetBusinessFunctionByTeamID(TeamID);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetRolesByBusinessFunction(int BusinessFunctionID)
    {
        try
        {
            AdminBusinessFunctionsBAL da = new AdminBusinessFunctionsBAL();
            DataSet dsRoles = da.GetRolesByBusinessFunctionID(BusinessFunctionID);

            List<Dictionary<string, object>> dicRoles = new List<Dictionary<string, object>>();
            DataRow[] drRoles = dsRoles.Tables[0].Select("State = 'Active'", "Name");

            for (int i = 0; i < drRoles.Length; i++)
            {
                Dictionary<string, object> Dictionary = new Dictionary<string, object>();
                Dictionary.Add("RoleID", drRoles[i]["RoleID"].ToString());
                Dictionary.Add("Name", drRoles[i]["Name"].ToString());
                Dictionary.Add("PreSelected", drRoles[i]["PreSelected"].ToString());
                dicRoles.Add(Dictionary);
            }
            return dicRoles;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetRolesByTeamID(int TeamID)
    {
        try
        {
            AdminTeamsBLL da = new AdminTeamsBLL();
            DataSet dsRoles = da.GetRolesByTeamID(TeamID);

            List<Dictionary<string, object>> dicRoles = new List<Dictionary<string, object>>();
            DataRow[] drRoles = dsRoles.Tables[1].Select("State = 'Active'", "Name");

            for (int i = 0; i < drRoles.Length; i++)
            {
                Dictionary<string, object> Dictionary = new Dictionary<string, object>();
                Dictionary.Add("RoleID", drRoles[i]["RoleID"].ToString());
                Dictionary.Add("Name", drRoles[i]["Name"].ToString());
                Dictionary.Add("PreSelected", drRoles[i]["PreSelected"].ToString());
                dicRoles.Add(Dictionary);
            }
            return dicRoles;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetUsers(int BusinessFunctionID, int RoleID, int TeamID, int ShowInactiveUsers, int ShowTeamOwners)
    //Malichi - 03/04/16 - Product Backlog Item 15984:User Admin; Add Team Owner column to Users and Roles
    {
        try
        {
            List<Dictionary<string, object>> dicUsersList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicUser = null;
            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            DataSet dsUserList = da.GetUserList(BusinessFunctionID, RoleID, TeamID, ShowInactiveUsers, ShowTeamOwners);

            for (int i = 0; i < dsUserList.Tables[0].Rows.Count; i++)
            {
                dicUser = new Dictionary<string, object>();
                dicUser.Add("UserID_TeamID", dsUserList.Tables[0].Rows[i]["UserID_TeamID"].ToString());
                dicUser.Add("UserID", dsUserList.Tables[0].Rows[i]["UserID"].ToString());
                dicUser.Add("LastName", dsUserList.Tables[0].Rows[i]["LastName"].ToString());
                dicUser.Add("FirstName", dsUserList.Tables[0].Rows[i]["FirstName"].ToString());
                dicUser.Add("DomainNTName", dsUserList.Tables[0].Rows[i]["DomainNTName"].ToString());
                dicUser.Add("Email", dsUserList.Tables[0].Rows[i]["Email"].ToString());
                dicUser.Add("Phone", dsUserList.Tables[0].Rows[i]["Phone"].ToString());
                dicUser.Add("LastActivity", dsUserList.Tables[0].Rows[i]["LastActivity"].ToString());
                dicUser.Add("UserRoles", dsUserList.Tables[0].Rows[i]["UserRoles"].ToString());
                dicUser.Add("State", dsUserList.Tables[0].Rows[i]["State"].ToString());
                dicUser.Add("NameExtension", dsUserList.Tables[0].Rows[i]["NameExtension"].ToString());
                dicUser.Add("TeamName", dsUserList.Tables[0].Rows[i]["TeamName"].ToString());
                dicUser.Add("TeamOwner", dsUserList.Tables[0].Rows[i]["TeamOwner"].ToString());
                dicUser.Add("TeamID", dsUserList.Tables[0].Rows[i]["TeamID"].ToString());

                dicUsersList.Add(dicUser);
            }
            return dicUsersList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static int GetMyRequestsCount()
    {
        try
        {
            int iCount = 0;
            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            DataSet dsRequestsList = new DataSet();
            UserInfo objuserInfo = UserInfo.GetCurrentUserInfo();
            dsRequestsList = da.GetMyRequests(objuserInfo.ID.ToString());
            iCount = dsRequestsList.Tables[0].Rows.Count;
            return iCount;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static string RemoveUser(int intUserID, int intTeamID)
    {
        try
        {
            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            da.RemoveUser(intUserID, intTeamID);
            return "User successfully removed.";
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            return ex.Message;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<string> GetUserPermission()
    {
        try
        {
            return Permission.GetUserPermissions(UserInfo.GetCurrentUserID());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static void SaveSelectedValue(string strName, string strValue)
    {
        try
        {
            Cookie.SetDBCookie(strName, strValue);

        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static int IsTeamOwner(int intTeamID)
    {
        try
        {
            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            return da.IsUserTeamOwner(intTeamID);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static string GetCookieValue()
    {
        try
        {
            return Cookie.GetDBCookie("UsersAndRoles_BusinessFunctionID");
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    protected void btnAddNewUser_Click(object sender, EventArgs E)
    {
        Response.Redirect("AddUserToTeam_Main.aspx?TeamID=" + Cookie.GetDBCookie("UsersAndRoles_TeamID") + "&TeamName=" + Cookie.GetDBCookie("UsersAndRoles_TeamName"));
    }
}
