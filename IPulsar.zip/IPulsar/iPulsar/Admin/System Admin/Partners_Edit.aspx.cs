﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class Admin_System_Admin_Partners_Edit : System.Web.UI.Page
{
    int PartnerID;
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession(false);
        string mode;
        mode = Request.QueryString["mode"];
        PartnerID = Convert.ToInt32(Request.QueryString["PartnerID"]);
        Authenticate.ValidateSession();
        // Put user code to initialize the page here

        if (!IsPostBack)
        {
            LoadPartnerTypes();
            if ((mode == "update"))
            {
                LoadPartnerData(PartnerID);
                Page.Title = "Modify Existing Partner";
                GetPermission();
            }
            else if (mode == "create")
            {
                Page.Title = "Add New Partner";
                pnlHistory.Visible = false;
            }
        }
    }
    private void LoadPartnerTypes()
    {
        AdminPartnersBLL da = new AdminPartnersBLL();
        DataSet ds = new DataSet();
        ds = da.GetPartnerTypes();
        ddlPartnerType.DataSource = ds;
        ddlPartnerType.DataTextField = "PartnerType";
        ddlPartnerType.DataValueField = "PartnerTypeID";
        ddlPartnerType.DataBind();
        ddlPartnerType.Items.Insert(0, new ListItem("", "10"));
        ddlPartnerType.SelectedValue = "10";
    }
    private void LoadPartnerData(int PartnerID)
    {
        AdminPartnersBLL da = new AdminPartnersBLL();
        DataSet ds = new DataSet();
        ds = da.GetPartners(PartnerID);
        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            lblTimeChanged.Text = dr["Updated"].ToString().Trim();
            lblTimeCreated.Text = dr["Created"].ToString().Trim();
            lblCreator.Text = dr["CreatedBy"].ToString().Trim();
            lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
            rbState.SelectedValue = dr["StateValue"].ToString();
            txtName.Text = dr["Name"].ToString();
            txtWebSite.Text = dr["WebSite"].ToString();
            ddlPartnerType.SelectedValue = dr["PartnerTypeID"].ToString().Trim();
            ds.Dispose();
            pnlHistory.Visible = true;
        }  
    }
    private void GetPermission()
    {  // check permission from resource file instead of enums - task 19440
        //*******************************************************************************************************
        //******************************You can either check role or permission *********************************
        //*******************************************************************************************************
        if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.Partner_Edit_Permission.ToString()))
        {
            Page.Title = "View Feature Category";

            this.txtName.Enabled = false;
            this.txtWebSite.Enabled = false;
            this.btnSave.Enabled = false;
            this.rbState.Enabled = false;
            this.lblEnter.Visible = false;
            this.rbState.Enabled = false;
            this.ddlPartnerType.Enabled = false;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        int intSetInactive = 0;
        AdminPartnersBLL da = new AdminPartnersBLL();
        try
        {
            if ((Convert.ToInt32(rbState.SelectedValue)) == 1)
                intSetInactive = 0;
            else
                intSetInactive = 1;

            UserInfo obj = new UserInfo();
            da.ModifyPartner(PartnerID, txtName.Text, txtWebSite.Text, UserInfo.GetCurrentUserName().ToString(), Convert.ToInt32(ddlPartnerType.SelectedItem.Value), intSetInactive);

            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "closeandreloadpartneredit", "CloseEditPopup(true)", true);
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
}

