﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;


public partial class UserAndRoles_TeamOwners : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();

        // get currently logged in user id
        UserInfo objuserInfo = UserInfo.GetCurrentUserInfo();
        hdnCurrentLoggedInUserID.Value = objuserInfo.ID.ToString();

        //get selected Team ID
        hdnTeamID.Value = Request.QueryString["TeamID"].ToString();

        //get selected Team Name
        lblHeader.Text = Request.QueryString["TeamName"].ToString();
        hdnTeamName.Value = Request.QueryString["TeamName"].ToString();
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetTeamOwner(int TeamID)
    {
        try
        {
            List<Dictionary<string, object>> dicTeamOwnersList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicOwner = null;
            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            DataSet dsOwnerList = new DataSet();
            dsOwnerList = da.GetTeamOwners(TeamID);
            for (int i = 0; i < dsOwnerList.Tables[0].Rows.Count; i++)
            {
                dicOwner = new Dictionary<string, object>();
                dicOwner.Add("UserId", dsOwnerList.Tables[0].Rows[i]["UserId"].ToString());
                dicOwner.Add("TeamOwner", dsOwnerList.Tables[0].Rows[i]["TeamOwner"].ToString());
                dicOwner.Add("Email", dsOwnerList.Tables[0].Rows[i]["Email"].ToString());
                dicOwner.Add("Phone", dsOwnerList.Tables[0].Rows[i]["Phone"].ToString());

                dicTeamOwnersList.Add(dicOwner);
            }
            return dicTeamOwnersList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}