﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_System_Admin_AddUserToTeam_Main_Edit : System.Web.UI.Page
{
    int intUserID;
    int intTeamID;
    int _fromTodayPage;
    bool _canEdit = false;
    bool bSystemAdmin = false;
    int _isTeamOwner = 0;

    string strFirstName = "", strLastName = "", strFullName = "", strNTName = "", strNTDomain = "", strEmail = "", strPhone = "", strCity = "", strState = "", strCountry = "", strPartnerName = "";
    int intPartnerID = 0, intIsActiveInGAL = 0;

    void Page_PreInit(object sender, EventArgs e)
    {
        var preferredLayoutCookieName = "PreferredLayout2";
        var preferredLayoutName = "pulsar2";

        if (Request.Cookies.Get(preferredLayoutCookieName) == null || string.Equals(Request.Cookies.Get(preferredLayoutCookieName).Value, preferredLayoutName, StringComparison.OrdinalIgnoreCase))
        {
            if (Request.QueryString["isPopup"] == "true")
            {
                MasterPageFile = "~/MasterPages/MainMasterPopup.master";
            }
            else
            {
                MasterPageFile = "~/MasterPages/MainMasterPageNoTitleBar.master";
            }
        }
        else
        {
            MasterPageFile = "~/MasterPages/MainMasterPopup.master";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession(false);
        intUserID = Convert.ToInt32(Request.QueryString["UserID"]);
        intTeamID = Convert.ToInt32(Request.QueryString["TeamID"]);

        //Bug 18990 / Task 19029 - Define System Admin and Team Owner Variables: ---
        bSystemAdmin = GetSystemAdminStatus();
        _isTeamOwner = GetTeamOwnerStatus(intTeamID);

        _fromTodayPage = Request.QueryString["FromTodayPage"] == null ? 0 : Convert.ToInt32(Request.QueryString["FromTodayPage"]);

        if (_fromTodayPage == 0)
        {
            //Bug 18990 / Task 19029 - Harris, Valerie - Define CanEdit variable w/o using querystring: ---
            if (bSystemAdmin || _isTeamOwner == 1)
                _canEdit = true;
            else
                _canEdit = false;
        }
        else
        {
            //Bug 20527 / Task 20528 - Harris, Valerie - Allow Standard Users to Add Users from Today page: ---
            _canEdit = true;
            trOwner.Visible = false;
            trActive.Visible = false;
        }

        if (intUserID == 0)
        {
            if (Request.QueryString["FirstName"] != null)
                strFirstName = Convert.ToString(Request.QueryString["FirstName"]);
            if (Request.QueryString["LastName"] != null)
                strLastName = Convert.ToString(Request.QueryString["LastName"]);
            if (Request.QueryString["FullName"] != null)
                strFullName = Convert.ToString(Request.QueryString["FullName"]);
            if (Request.QueryString["NTName"] != null)
                strNTName = Convert.ToString(Request.QueryString["NTName"]);
            if (Request.QueryString["NTDomain"] != null)
                strNTDomain = Convert.ToString(Request.QueryString["NTDomain"]);
            if (Request.QueryString["City"] != null)
                strCity = Convert.ToString(Request.QueryString["City"]);
            if (Request.QueryString["State"] != null)
                strState = Convert.ToString(Request.QueryString["State"]);
            if (Request.QueryString["Country"] != null)
                strCountry = Convert.ToString(Request.QueryString["Country"]);
            if (Request.QueryString["EmailID"] != null)
                strEmail = Convert.ToString(Request.QueryString["EmailID"]);
            if (Request.QueryString["Phone"] != null)
                strPhone = Convert.ToString(Request.QueryString["Phone"]);
            if (Request.QueryString["IsActiveInGAL"] != null)
                intIsActiveInGAL = Convert.ToInt32(Request.QueryString["IsActiveInGAL"]);
            if (Request.QueryString["PartnerID"] != null)
                strPartnerName = Convert.ToString(Request.QueryString["PartnerID"]);
            AdminAddUserToTeamBLL da = new AdminAddUserToTeamBLL();
            intPartnerID = da.GetPartnerIDByName(strPartnerName);
        }
        if (!IsPostBack)
        {
            Page.Title = "Add Roles";
            hdnTeamID.Value = intTeamID.ToString();
            hdnUserID.Value = intUserID.ToString();
            LoadAllPartners();
            LoadAllDomains();
            LoadUserInfo(intUserID);
            LoadTeamAndUserRoles(intTeamID, intUserID);

            if (!_canEdit)
                DisableControls(intUserID);

            if (intTeamID == 0)
            {
                cbOwner.Disabled = true;
                int state = GetTeamOwnerCheckboxStatus(intUserID);

                if (state == 1)
                    cbOwner.Checked = true;
                if (state == 2)
                {
                    hdnTeamOwnerCheckboxStatus.Value = state.ToString();
                }
                if (state == 0)
                    cbOwner.Checked = false;
            }
        }
    }

    private void DisableControls(int intUserID)
    {

        if (UserInfo.GetCurrentUserID() != intUserID)//user is editing his/her information
        {
            btnSave.Enabled = false;
            lblEnter.Text = "View Information";
            trFirstName.Visible = false;
            trLastName.Visible = false;
            txtName.Visible = false;
            lblName.Visible = true;
            ddlPartners.Enabled = false;
            ddlDomains.Enabled = false;
            lblEmail.Visible = true;
            lblPhone.Visible = true;
            lblNTName.Visible = true;
            txtEmail.Visible = false;
            txtPhone.Visible = false;
            txtNTName.Visible = false;

            chkIsActive.Enabled = false;
            //this function is called after 'LoadUserInfo' so i can check the partnerID value to figure out if it's editing a HP or ODM user
            if (!_canEdit && ddlPartners.SelectedValue != "1" && UserInfo.GetCurrentUserIsODM() != 1) //if i can't edit but i'm an HP user and i'm editing an odm
            {
                //then i can enable the active flag and the save button
                btnSave.Enabled = true;
                chkIsActive.Enabled = true;
            }
        }
        cbOwner.Disabled = true;
        wdgRoles.Columns[0].Hidden = true;
    }

    private void LoadAllPartners()
    {
        AdminAddUserToTeamBLL da = new AdminAddUserToTeamBLL();
        DataSet dsPartners = da.GetAllPartners();

        ddlPartners.DataSource = dsPartners;
        ddlPartners.DataTextField = "Name";
        ddlPartners.DataValueField = "PartnerID";
        ddlPartners.DataBind();

        ddlPartners.Items.Insert(0, new ListItem("Select a Partner", "0"));
    }
    private void LoadAllDomains()
    {
        AdminAddUserToTeamBLL da = new AdminAddUserToTeamBLL();
        DataSet dsDomains = da.GetAllDomains();

        ddlDomains.DataSource = dsDomains;
        ddlDomains.DataTextField = "NTDomain";
        ddlDomains.DataValueField = "NTDomain";
        ddlDomains.DataBind();

        ddlDomains.Items.Insert(0, new ListItem("Select a Domain", "0"));
    }
    private void LoadUserInfo(int intUserID)
    {
        AdminAddUserToTeamBLL adBll = new AdminAddUserToTeamBLL();
        DataSet ds;
        if (intUserID > 0)
        {
            ds = adBll.GetUsers(intUserID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                lblName.Text = dr["FullName"].ToString().Trim();
                txtName.Text = dr["FullName"].ToString().Trim();
                if (dr["FullName"].ToString().Trim().IndexOf('(') == -1)
                {
                    lblName.Text = dr["FullName"].ToString().Trim() + " " + dr["NameExtension"].ToString().Trim();
                    txtName.Text = dr["FullName"].ToString().Trim() + " " + dr["NameExtension"].ToString().Trim();
                }
                txtFirstName.Text = dr["FirstName"].ToString().Trim();
                txtLastName.Text = dr["LastName"].ToString().Trim();
                lblEmail.Text = dr["Email"].ToString().Trim();
                lblPhone.Text = dr["Phone"].ToString().Trim();
                txtEmail.Text = dr["Email"].ToString().Trim();
                hdnEmail.Value = dr["Email"].ToString().Trim();
                txtPhone.Text = dr["Phone"].ToString().Trim();
                lblNTName.Text = dr["NtName"].ToString().Trim();
                txtNTName.Text = dr["NtName"].ToString().Trim();
                hdnNTName.Value = dr["NtName"].ToString().Trim();
                hdnActiveInGAL.Value = ((bool)dr["IsActiveInGAL"]) ? "1" : "0";

                if (Convert.ToInt32(dr["PartnerID"]) > 0)
                    ddlPartners.SelectedValue = dr["PartnerID"].ToString();
                if (dr["PartnerID"].ToString() == "1")
                {
                    ddlDomains.Enabled = true;
                    txtNTName.Enabled = true;
                    txtFirstName.Enabled = false;
                    txtLastName.Enabled = false;
                }

                foreach (ListItem item in ddlDomains.Items)
                {
                    if (string.Equals(item.Value.Trim(), dr["NtDomain"].ToString().Trim(), StringComparison.InvariantCultureIgnoreCase))
                        item.Selected = true;
                }
                lblLastActivity.Text = dr["LastActivity"].ToString().Trim();
                lblCreator.Text = dr["CreatedBy"].ToString().Trim();
                lblUpdater.Text = dr["UpdatedBy"].ToString().Trim();
                lblTimeCreated.Text = dr["Created"].ToString().Trim();
                lblTimeChanged.Text = dr["Updated"].ToString().Trim();

                if (dr["State"].ToString().Trim() == "Active")
                    chkIsActive.Checked = true;
                else
                    chkIsActive.Checked = false;
                ds.Dispose();
            }
        }
        else
        {
            txtFirstName.Text = strFirstName;
            lblName.Text = strFullName;
            txtName.Text = strFullName;
            txtLastName.Text = strLastName;
            txtEmail.Text = strEmail;
            txtPhone.Text = strPhone;
            if (strPhone.Trim() == "0")
                txtPhone.Text = "";
            txtNTName.Text = strNTName;
            ddlPartners.SelectedValue = intPartnerID.ToString();
            foreach (ListItem item in ddlDomains.Items)
            {
                if (string.Equals(item.Value.Trim(), strNTDomain.Trim(), StringComparison.InvariantCultureIgnoreCase))
                {
                    item.Selected = true;
                }
            }


            if (intPartnerID == 1)
            {
                ddlDomains.Enabled = true;
                txtNTName.Enabled = true;
                txtFirstName.Enabled = false;
                txtLastName.Enabled = false;
            }
            hdnCity.Value = strCity;
            hdnState.Value = strState;
            hdnCountry.Value = strCountry;
            hdnActiveInGAL.Value = intIsActiveInGAL.ToString();
            chkIsActive.Checked = true;
            lblLastActivity.Visible = false;
            LastActivity.Visible = false;
            lblCreator.Visible = false;
            CreatedBy.Visible = false;
            lblTimeCreated.Visible = false;
            Creator.Visible = false;
            lblUpdater.Visible = false;
            UpdatedBy.Visible = false;
            lblTimeChanged.Visible = false;
            Updater.Visible = false;
        }
    }
    private void LoadTeamAndUserRoles(int intTeamID, int intUserID)
    {
        try
        {
            AdminAddUserToTeamBLL adBll = new AdminAddUserToTeamBLL();
            DataSet ds;
            ds = adBll.LoadTeamAndUserRoles(intTeamID, intUserID);
            if (ds.Tables[0].Rows.Count > 0 && _fromTodayPage == 0)
            {
                divRolesList.Visible = true;
                DataTable dtRoles = ds.Tables[0];
                wdgRoles.DataSource = dtRoles;
                wdgRoles.DataBind();
                lblError.Text = "";
            }
            else
            {
                divRolesList.Visible = false;
            }
            DataRow dr = ds.Tables[1].Rows[0];
            if (dr["IsOwner"].ToString().Trim() == "1")
            {
                cbOwner.Checked = true;
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            AdminAddUserToTeamBLL adBll2 = new AdminAddUserToTeamBLL();
            string strFirstName = "", strLastName = "", strFullName = "", strNTName = "", strDomain = "", strEmail = "", strPhone = "", strRoles = "";
            string strNameExtension = "", strCity = "", strState = "", strCountry = "";
            int intIsActiveInGAL = 0;
            int intIsOwner = 0, intPartnerID = 0, intState = 0;
            strFirstName = txtFirstName.Text.Trim();
            strLastName = txtLastName.Text.Trim();
            strNTName = txtNTName.Text.Trim();
            strEmail = txtEmail.Text.Trim();
            strPhone = txtPhone.Text.Trim();
            intState = Convert.ToInt32(chkIsActive.Checked);
            intPartnerID = Convert.ToInt32(ddlPartners.SelectedValue);
            if (ddlPartners.SelectedItem.Text != "HP")
            {
                strNameExtension = ddlPartners.SelectedItem.Text;
                strFullName = strLastName + ", " + strFirstName + " (" + ddlPartners.SelectedItem.Text + ")";
            }

            if (intPartnerID == 1)
                strDomain = ddlDomains.SelectedValue;
            else
                strDomain = ddlPartners.SelectedItem.Text;

            if (intUserID == 0)
            {
                if (ddlPartners.SelectedItem.Text == "HP")
                    strFullName = strLastName + ", " + strFirstName;
                strCity = hdnCity.Value;
                strState = hdnState.Value;
                strCountry = hdnCountry.Value;

                //should retrieve info from gal if hp users, but for now at least it make more sense to assume it as valid if it's an HP user
                if (intPartnerID == 1)
                    intIsActiveInGAL = 1;
                else
                    intIsActiveInGAL = 0;

                if (chkIsActive.Checked) //if user is not active or i'm deactivating it no need to check
                {
                    if (adBll2.IsEmailAvailable(strEmail) > 0)
                    {
                        lblError.Text = "There is already an active user with the same email address.";
                        lblError.Visible = true;
                        return;
                    }

                    if (intPartnerID == 1 && adBll2.IsNtNameUnique(strDomain, strNTName) > 0) //if it's active check if email is duplicated (user reactivated OR email might have been changed)
                    {
                        lblError.Text = "There is already an active user with the same ntName";
                        lblError.Visible = true;
                        return;
                    }

                }

            }
            else //existing user
            {
                if (ddlPartners.SelectedItem.Text == "HP")
                    strFullName = strLastName + ", " + strFirstName;

                intIsActiveInGAL = Convert.ToInt32(hdnActiveInGAL.Value); //existing user, keep whatever value was in the IsActiveIngal column

                //check against data in the db
                DataSet ds = adBll2.GetUsers(intUserID);
                string prevNtName, prevDomain, prevEmail;
                bool prevStatus;

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[0];
                    prevEmail = dr["Email"] as string;
                    prevNtName = dr["NtName"] as string;
                    prevDomain = dr["NtDomain"] as string;
                    prevStatus = (dr["State"].ToString().Trim() == "Active");
                }
                else
                {
                    lblError.Text = "User not found";
                    lblError.Visible = true;
                    return;
                }


                if (chkIsActive.Checked) //if user is not active or i'm deactivating it no need to check
                {
                    if (ddlPartners.SelectedItem.Text == "HP")
                        intIsActiveInGAL = 1; //DP

                    int emailCount = adBll2.IsEmailAvailable(strEmail);
                    int ntNameCount = adBll2.IsNtNameUnique(strDomain, strNTName);

                    if ((strEmail.ToLower() != prevEmail.ToLower() && emailCount > 0) ||
                      (!prevStatus && emailCount > 1)) //if it's active check if email is duplicated (user reactivated OR email might have been changed)
                    {
                        lblError.Text = "There is already an active user with the same email address.";
                        lblError.Visible = true;
                        return;
                    }

                    if (intPartnerID == 1 &&
                        ((strNTName.ToLower() != prevNtName.ToLower() && ntNameCount > 0) ||
                        (!prevStatus && ntNameCount > 1))) //if it's active check if ntdomain is duplicated 
                    {
                        lblError.Text = "There is already an active user with the same ntName";
                        lblError.Visible = true;
                        return;
                    }
                }
            }

            if (cbOwner.Checked)
            {
                intIsOwner = 1;
            }
            for (int i = 0; i < wdgRoles.Rows.Count; i++)
            {
                if (wdgRoles.Rows[i].Items.FindItemByKey("HasRole").Value.ToString() == "True")
                {
                    strRoles = strRoles == "" ? wdgRoles.Rows[i].DataKey[0].ToString() : strRoles + "," + wdgRoles.Rows[i].DataKey[0].ToString();
                }
            }
            adBll2.UserRolesAndTeamOwnerStatusModify(strFirstName, strLastName, strFullName, strNTName, strDomain, strEmail, strPhone, intPartnerID, strRoles, intUserID, intTeamID, intIsOwner, intState, strCity, strState, strCountry, intIsActiveInGAL);
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "CloseAddUserToTeamEdit", "CloseAddUserToTeamEditPopup2(true)", true);
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
            lblError.Visible = true;
        }
    }

    [WebMethod]
    public static List<Dictionary<string, string>> GetOtherRoles(int TeamID, int UserID)
    {
        try
        {
            List<Dictionary<string, string>> lstGeneratedNames = new List<Dictionary<string, string>>();
            AdminAddUserToTeamBLL adBll = new AdminAddUserToTeamBLL();
            DataSet dsRoles = adBll.LoadTeamAndUserRoles(TeamID, UserID);
            DataTable dtOtherRoles = dsRoles.Tables[2];

            for (int i = 0; i < dtOtherRoles.Rows.Count; i++)
            {
                Dictionary<string, string> dcFormulaName = new Dictionary<string, string>();
                dcFormulaName.Add("RoleID", dtOtherRoles.Rows[i]["RoleID"].ToString());
                dcFormulaName.Add("RoleInformation", dtOtherRoles.Rows[i]["TeamName"].ToString() + "|" + dtOtherRoles.Rows[i]["RoleName"].ToString() + "|" + dtOtherRoles.Rows[i]["Description"].ToString());
                lstGeneratedNames.Add(dcFormulaName);
            }
            return lstGeneratedNames;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    private enum isUnique
    {
        Unique = 0,
        Email = 1,
        NtName = 2,
        Both = 3
    }

    [WebMethod]
    public static string IsEmailAndNTNameUnique(string Domain, string NtName, string Email)
    {
        try
        {
            AdminAddUserToTeamBLL adBll = new AdminAddUserToTeamBLL();

            int emailCount = adBll.IsEmailAvailable(Email);
            int ntNameCount = adBll.IsNtNameUnique(Domain, NtName);

            if (emailCount == 0 && ntNameCount == 0)
                return isUnique.Unique.ToString();
            else if (emailCount != 0 && ntNameCount == 0)
                return isUnique.Email.ToString();
            else if (ntNameCount > 0 && emailCount == 0)
                return isUnique.NtName.ToString();
            else
                return isUnique.Both.ToString();
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    ///*************************************************************************
    //*Function:    :GetTeamOwnerStatus
    //*History:     :03/31/2016 Harris, Valerie - Bug 18990 / Task 19029 
    //*************************************************************************
    public static int GetTeamOwnerStatus(int intTeamID)
    {
        AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
        return da.IsUserTeamOwner(intTeamID);
    }


    ///*************************************************************************
    //*Function:    :GetSystemAdminStatus
    //*History:     :03/31/2016 Harris, Valerie - Bug 18990 / Task 19029 
    //*************************************************************************
    public static bool GetSystemAdminStatus()
    {
        List<string> userPermission = Permission.GetUserPermissions(UserInfo.GetCurrentUserID());
        for (int i = 0; i < userPermission.Count; i++)
        {
            if (userPermission[i] == "System.Admin")
                return true;
        }

        return false;
    }


    // Get the state of TeamOwner checkbox - PBI 20541 - task 20985
    // 0 - Unchecked : 
    // 1 - Checked :
    // 2 - Partial :
    public static int GetTeamOwnerCheckboxStatus(int intUserID)
    {
        AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
        return da.GetTeamOwnerCheckboxStatus(intUserID);
    }
}

