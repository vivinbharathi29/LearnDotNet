﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;


public partial class UsersAndRoles_Requests : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();
        MainMasterPage master = (MainMasterPage)Page.Master;
        Page.Title = "Users and Roles Requests";
        master.pageheader = "Users and Roles Requests";

        // get currently logged in user id
        UserInfo objuserInfo = UserInfo.GetCurrentUserInfo();
        hdnCurrentLoggedInUserID.Value = objuserInfo.ID.ToString();
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> GetUserRequest(int PendingRequest, int UserID)
    {
        try
        {
            List<Dictionary<string, object>> dicUserRequestsList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicRequest = null;
            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            DataSet dsRequestList = new DataSet();
            dsRequestList = da.GetUserAccessRequests(PendingRequest, UserID);
            for (int i = 0; i < dsRequestList.Tables[0].Rows.Count; i++)
            {
                dicRequest = new Dictionary<string, object>();
                dicRequest.Add("RequestRoleID", dsRequestList.Tables[0].Rows[i]["RequestRoleID"].ToString());
                dicRequest.Add("Team", dsRequestList.Tables[0].Rows[i]["Team"].ToString());
                dicRequest.Add("User", dsRequestList.Tables[0].Rows[i]["User"].ToString());
                dicRequest.Add("Role", dsRequestList.Tables[0].Rows[i]["Role"].ToString());
                dicRequest.Add("Request", dsRequestList.Tables[0].Rows[i]["Request"].ToString());
                dicRequest.Add("DateRequested", dsRequestList.Tables[0].Rows[i]["DateRequested"].ToString());
                dicRequest.Add("ModifiedBy", dsRequestList.Tables[0].Rows[i]["ModifiedBy"].ToString());
                dicRequest.Add("Rejected", dsRequestList.Tables[0].Rows[i]["Rejected"].ToString());
                dicRequest.Add("Pending", dsRequestList.Tables[0].Rows[i]["Pending"].ToString());
                dicRequest.Add("TeamId", dsRequestList.Tables[0].Rows[i]["TeamId"].ToString());
                dicRequest.Add("TeamOwnerId", dsRequestList.Tables[0].Rows[i]["TeamOwnerId"].ToString());
                dicRequest.Add("Reject", dsRequestList.Tables[0].Rows[i]["Reject"].ToString());

                dicUserRequestsList.Add(dicRequest);
            }
            return dicUserRequestsList;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }


    [WebMethod(EnableSession = true)]
    public static string ApproveDisapproveSelectedRequests(int intCurrentlyLoggedinUserID, string strRequestRoleIDs, int intIsReject, string strDisapproveReason)
    {
        AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
        string strReturnMsg = "";
        try
        {
            da.ApproveDisapproveSelectedRequests(intCurrentlyLoggedinUserID, strRequestRoleIDs, intIsReject, strDisapproveReason);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strReturnMsg = ex.Message;
        }
        return strReturnMsg;
    }

    [WebMethod(EnableSession = true)]
    public static string SendEmail(string RequestedUserName, string TeamName, int CurrentLoggedInTeamOwnerId, string UserAddRoles, string UserRemoveRoles, int Approve, string DisapproveReason)
    {
        AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
        string strReturnMsg = "";
        try
        {
            da.SendEmail(RequestedUserName, TeamName, CurrentLoggedInTeamOwnerId, UserAddRoles, UserRemoveRoles, Approve, DisapproveReason);
        }
        catch (Exception ex)
        {
            strReturnMsg = ex.Message;
        }
        return strReturnMsg;
    }

    [WebMethod(EnableSession = true)]
    public static List<string> GetUserPermission()
    {
        try
        {
            return Permission.GetUserPermissions(UserInfo.GetCurrentUserID());
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<string> TeamOwnerWithRequests()
    {
        try
        {
            List<string> status = new List<string>();

            AdminUsersAndRolesBLL da = new AdminUsersAndRolesBLL();
            status.Add(Convert.ToString(da.IsTeamOwnerWithRequests()));

            return status;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}
