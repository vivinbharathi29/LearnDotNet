﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;

namespace iPulsar.Admin.System_Admin
{
    public partial class Vendor_Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            MainMasterPage master = (MainMasterPage)Page.Master;
            Page.Title = "Vendors";
            master.pageheader = "Vendors";
            GetPermission();
        }
        // check permission from resource file instead of enums - task 19440
        private void GetPermission()
        {
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ComponentCategory_Edit_Permission.ToString()))
            {
                Page.Title = "View Vendors List";
                lnkAdd.Disabled = true;
                lnkAdd.Attributes["Class"] = "disabled";
                rmContextMenu.Items.FindItemByValue("Add").Enabled = false;

            }
            if (!Permission.IsCurrentUserHasPermission(Resources.Permissions.ComponentCategory_Delete_Permission.ToString()))
            {
                //Harris, Valerie (5/10/1016) - PBI 12538/Task 20310 - Resolve object reference error
                if (rmContextMenu.Items.FindItemByValue("Delete") != null)
                {
                    rmContextMenu.Items.FindItemByValue("Delete").Enabled = false;
                }
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAllVendors()
        {
            try
            {
                List<Dictionary<string, object>> dicVendorList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicVendor = null;
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                DataSet dsVendorList = new DataSet();
                dsVendorList = da.GetAllVendors();
                for (int i = 0; i < dsVendorList.Tables[0].Rows.Count; i++)
                {
                    dicVendor = new Dictionary<string, object>();
                    dicVendor.Add("VendorID", dsVendorList.Tables[0].Rows[i]["VendorID"].ToString());
                    dicVendor.Add("Name", dsVendorList.Tables[0].Rows[i]["Name"].ToString());
                    dicVendor.Add("Website", dsVendorList.Tables[0].Rows[i]["Website"].ToString());
                    dicVendor.Add("CategoryTypes", dsVendorList.Tables[0].Rows[i]["CategoryTypes"].ToString());
                    dicVendor.Add("State", dsVendorList.Tables[0].Rows[i]["State"].ToString());
                    dicVendorList.Add(dicVendor);

                }
                return dicVendorList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static string DeleteVendors(int intVendorID)
        {
            string strReturnMsg = "Vendor successfully removed.";
            try
            {
                AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
                da.DeleteManufacturingSite(intVendorID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }
    }
}