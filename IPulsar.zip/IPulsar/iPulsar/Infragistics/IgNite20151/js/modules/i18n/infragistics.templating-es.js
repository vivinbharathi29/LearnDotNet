﻿/*!@license
* Infragistics.Web.ClientUI templating localization resources 15.1.20151.2352
*
* Copyright (c) 2011-2015 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/

/*global jQuery */
(function ($) {
    $.ig = $.ig || {};

    if (!$.ig.Templating) {
	    $.ig.Templating = {};

	    $.extend($.ig.Templating, {
		    locale: {
			    undefinedArgument: 'Se ha producido un error al intentar recuperar las propiedades del origen de datos: '
		    }
	    });
    }
})(jQuery);