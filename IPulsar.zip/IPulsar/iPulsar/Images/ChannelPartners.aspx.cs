﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Telerik.Web.UI;
using System.Collections.Generic;

namespace iPulsar.Images
{
    public partial class ChannelPartners : System.Web.UI.Page
    {
        string defaultTier = "";
        string selTier = "";
        int imageId = 0;
        int regionId = 0;
   
        string [] PreSelChannelPartner= new string[] { };

        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession(false);

            defaultTier = Convert.ToString(Request.QueryString["SelectedTier"]);
            selTier = Convert.ToString(Request.QueryString["SelectedPartners"]);
            imageId = Convert.ToInt32(Request.QueryString["ImageID"]);
            regionId = Convert.ToInt32(Request.QueryString["RegionID"]);

            if (!IsPostBack)
            {
                LoadChannelPartners();
            }
        }
        private void LoadChannelPartners()
        {
            ImagesBLL da = new ImagesBLL();
            DataSet dsChannelPartners = new DataSet();
            try
            {
                dsChannelPartners = da.GetChannelPartnersPerImageRegion(imageId, regionId);
                
                gvChannelPartners.DataSource = dsChannelPartners.Tables[0];
                gvChannelPartners.DataBind();


            }
            catch(Exception ex)
            {
                lblError.Visible = true;
                lblError.Text = ex.Message;
            }
            finally
            {
                dsChannelPartners.Dispose();
            }
        }

        protected void gvChannelPartners_RowDataBound(Object sender, GridViewRowEventArgs e)
        {
            //get the list of selected partners.
            if (selTier != "" && selTier != null)
            {
                PreSelChannelPartner = selTier.Split(',');
            }

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string  strTierId = e.Row.Cells[4].Text;
                string  strPartnerId = e.Row.Cells[3].Text;

                DropDownList ddlTiers = (DropDownList)e.Row.FindControl("ddlTier");
                CheckBox ckbx = (CheckBox)e.Row.FindControl("CheckBox1");

                List<int> tier = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
                foreach (var t in tier)
                {
                    ddlTiers.Items.Add(t.ToString());                
                }

                // add empty value to be the default selection if no value was selected for the channel partner
                ddlTiers.Items.Insert(0, new ListItem("", "0"));

                int idSel = ddlTiers.Items.IndexOf(ddlTiers.Items.FindByValue(defaultTier));
                ddlTiers.SelectedIndex = idSel;

                //get selected channel partners
                if (PreSelChannelPartner.Length > 0)
                {
                    foreach (string s in PreSelChannelPartner)
                    {
                        int index = s.IndexOf('_');
                        string selPartnerId = s.Substring(0, index);
                        string selPartnerTier = s.Substring(s.LastIndexOf('_') + 1);

                        if (strPartnerId == selPartnerId.Trim())
                        {
                            int idSelected = ddlTiers.Items.IndexOf(ddlTiers.Items.FindByValue(selPartnerTier.Trim()));
                            ddlTiers.SelectedIndex = idSelected;
                            ckbx.Checked = true;
                        }
                    }

                }

            }

        }
    }
}