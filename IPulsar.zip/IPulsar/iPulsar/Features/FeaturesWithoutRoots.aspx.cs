﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Web.UI;


namespace iPulsar.Features
{
    public partial class FeaturesWithoutRoots : System.Web.UI.Page

    {

        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();
            if (!IsPostBack)
            {
                Page.Title = "Features Without Roots";
                lblHeader.Text = "Features Without Roots";
                // check permission from resource file instead of enums - task 19440
                if (Permission.IsCurrentUserHasPermission(Resources.Permissions.Feature_Edit_Permission.ToString()))
                {
                    txtFeatureedit.Value = "1";

                }

            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetComponentCategories()
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();

                List<Dictionary<string, object>> dicComCat = new List<Dictionary<string, object>>();
                Dictionary<string, object> Dictionary = null;

                DataSet ds = da.Feature_ViewComponentCatgorieswithInactiveOwners();

                int count = ds.Tables[0].Rows.Count;
                for (int i = 0; i < count; i++)
                {
                    Dictionary = new Dictionary<string, object>();
                    Dictionary.Add("ComponentCategoryID", ds.Tables[0].Rows[i]["ComponentCategoryID"].ToString());
                    Dictionary.Add("ComponentCategoryName", ds.Tables[0].Rows[i]["ComponentCategoryName"].ToString());
                    Dictionary.Add("ComponentType", ds.Tables[0].Rows[i]["ComponentType"].ToString());
                    Dictionary.Add("Owners", ds.Tables[0].Rows[i]["Owners"].ToString());

                    dicComCat.Add(Dictionary);
                }
                return dicComCat;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetFeatureswithoutRoots(string FeatureEdit)
        {
            try
            {
                string strOwners = "";
                string strEachOwner = "";
                string strEmail = "";
                string strPhone = "";
                string strOwnerName = "";
                string strFinalownerName = "";
                FeaturesBLL da = new FeaturesBLL();

                List<Dictionary<string, object>> dicFeatureswithoutRoots = new List<Dictionary<string, object>>();
                Dictionary<string, object> Dictionary = null;

                DataSet ds = da.Feature_ViewFeaturesWithoutRoots();

                int count = ds.Tables[0].Rows.Count;
                for (int i = 0; i < count; i++)
                {
                    Dictionary = new Dictionary<string, object>();
                    Dictionary.Add("FeatureID", ds.Tables[0].Rows[i]["FeatureID"].ToString());
                    Dictionary.Add("FeatureName", ds.Tables[0].Rows[i]["FeatureName"].ToString());
                    Dictionary.Add("FeatureCategoryName", ds.Tables[0].Rows[i]["FeatureCategoryName"].ToString());
                    Dictionary.Add("ComponentCategoryName", ds.Tables[0].Rows[i]["ComponentCategoryName"].ToString());
                    Dictionary.Add("CreatedBy", ds.Tables[0].Rows[i]["CreatedBy"].ToString());
                    Dictionary.Add("RequestStatus", ds.Tables[0].Rows[i]["RequestStatus"].ToString());
                    Dictionary.Add("RequestDate", ds.Tables[0].Rows[i]["RequestDate"].ToString());
                    //owners column returns useranme:email:phone; useranme2:email2:phone2, need to parse the info and construct the corerct format for UI
                    strOwners = ds.Tables[0].Rows[i]["Owners"].ToString();
                    strFinalownerName = "";
                    if (strOwners != "")
                    {
                        string[] Owners = strOwners.Split(';');
                        for (int i2 = 0; i2 < Owners.Length; i2++)
                        {
                            string[] EachOwner = Owners[i2].ToString().Split(':');
                            strOwnerName = EachOwner[0].ToString();
                            strEmail = EachOwner[1].ToString();
                            strPhone = EachOwner[2].ToString();
                            if (FeatureEdit == "1")
                                strEachOwner = "<a href='mailto:" + strEmail + "'>" + strOwnerName + "</a>" + "&nbsp;" + strPhone;
                            else
                                strEachOwner = strOwnerName + "&nbsp;" + strPhone;
                            if (strFinalownerName == "")
                                strFinalownerName = strEachOwner;
                            else
                                strFinalownerName += "<br/>" + strEachOwner;
                        }
                    }
                    Dictionary.Add("Owners", strFinalownerName);

                    dicFeatureswithoutRoots.Add(Dictionary);
                }
                return dicFeatureswithoutRoots;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static string SendLinkRequest(string strFeatureIDs)
        {
            FeaturesBLL da = new FeaturesBLL();
            string strReturnMsg = "";
            try
            {
                da.Feature_ResendRootlinkRequest(strFeatureIDs);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strReturnMsg = ex.Message;
            }
            return strReturnMsg;
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetOwnerEmails(string strFeatureIDs)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();

                List<Dictionary<string, object>> dicFeatureswithoutRoots = new List<Dictionary<string, object>>();
                Dictionary<string, object> Dictionary = null;

                DataSet ds = da.Feature_GetOwnerEmails(strFeatureIDs);

                int count = ds.Tables[0].Rows.Count;
                for (int i = 0; i < count; i++)
                {
                    Dictionary = new Dictionary<string, object>();
                    Dictionary.Add("Email", ds.Tables[0].Rows[i]["Email"].ToString());

                    dicFeatureswithoutRoots.Add(Dictionary);
                }
                return dicFeatureswithoutRoots;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}

