﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iPulsar.Features
{
    public partial class OverrideRequestHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["FeatureID"] != null)
                hdnFeatureID.Value = Request.QueryString["FeatureID"];
        }


        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetFeatureNamingOverrideRequestHistory(int FeatureID)
        {
            try
            {
                List<Dictionary<string, object>> dicGetFeatureNamingOverrideRequestsList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dicFeatures = null;
                FeaturesBLL obj = new FeaturesBLL();

                DataSet ds = new DataSet();
                ds = obj.GetOverrideHistory(FeatureID);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dicFeatures = new Dictionary<string, object>();
                    dicFeatures.Add("FeatureID", ds.Tables[0].Rows[i]["FeatureID"].ToString());
                    dicFeatures.Add("Reason", ds.Tables[0].Rows[i]["Reason"].ToString());
                    dicFeatures.Add("RequestedBy", ds.Tables[0].Rows[i]["RequestedBy"].ToString());
                    dicFeatures.Add("DateRequested", ds.Tables[0].Rows[i]["DateRequested"].ToString());
                    dicFeatures.Add("EditedBy", ds.Tables[0].Rows[i]["EditedBy"].ToString());
                    dicFeatures.Add("DateCompleted", ds.Tables[0].Rows[i]["DateCompleted"].ToString());
                    dicGetFeatureNamingOverrideRequestsList.Add(dicFeatures);
                }

                return dicGetFeatureNamingOverrideRequestsList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}