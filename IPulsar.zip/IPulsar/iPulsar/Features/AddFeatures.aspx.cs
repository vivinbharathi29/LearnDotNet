﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Features
{
    public partial class AddFeatures : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            if (!IsPostBack)
            {
                int intParentFeatureID = 0;
                string strChildFeatureList = "";
                int intPlatformID = 0;
                if (Request.QueryString["ParentFeatureID"] != null)
                    intParentFeatureID = Convert.ToInt32(Request.QueryString["ParentFeatureID"]);
                if (Request.QueryString["ChildFeatureList"] != null)
                    strChildFeatureList = Convert.ToString(Request.QueryString["ChildFeatureList"]);
                if (Request.QueryString["PlatformID"] != null)
                    intPlatformID = Convert.ToInt32(Request.QueryString["PlatformID"]);
                if (Request.QueryString["FeatureFullName"] != null)
                    lblComboFeatureFullName.Text = Convert.ToString(Request.QueryString["FeatureFullName"]);
                hdnParentFeatureID.Value = intParentFeatureID.ToString();
                hdnChildFeatureList.Value = strChildFeatureList;
                hdnPlatformID.Value = intPlatformID.ToString();
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, string>> GetFeatureClass()
        {
            try
            {
                FeaturesBLL ft = new FeaturesBLL();
                DataSet ds = ft.GetFeatureClass();

                List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
                Dictionary<string, string> Dictionary = null;

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("FeatureClassID", ds.Tables[0].Rows[i]["FeatureClassID"].ToString());
                    Dictionary.Add("FeatureClassName", ds.Tables[0].Rows[i]["FeatureClassName"].ToString());
                    rows.Add(Dictionary);
                }

                return rows;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, string>> GetCategory(int Id)
        {
            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> Dictionary = null;
            FeaturesBLL ft = new FeaturesBLL();
            DataSet ds = ft.GetFeatureCategoryByFeatureClassID(Id);
            DataView dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "State ='Active' and Name NOT LIKE 'AMO:%'";

            for (int i = 0; i < dv.Count; i++)
            {
                Dictionary = new Dictionary<string, string>();
                Dictionary.Add("FeatureCategoryID", dv[i]["FeatureCategoryID"].ToString());
                Dictionary.Add("Name", dv[i]["DropDownName"].ToString());
                rows.Add(Dictionary);
            }
            return rows;
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, string>> GetFeatureNamingDropdownValue(int Id)
        {
            try
            {
                FeaturesBLL ft = new FeaturesBLL();
                DataSet ds = ft.GetFeatureNamingDropdownValue(Id);

                List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
                Dictionary<string, string> Dictionary = null;

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("Id", ds.Tables[0].Rows[i]["FieldId"].ToString() + Char.ConvertFromUtf32(3) + ds.Tables[0].Rows[i]["DropDownValueID"].ToString());
                    Dictionary.Add("Name", ds.Tables[0].Rows[i]["NSName"].ToString() + " - " + ds.Tables[0].Rows[i]["FieldName"].ToString() + " - " + ds.Tables[0].Rows[i]["Value"].ToString());
                    rows.Add(Dictionary);
                }

                return rows;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> FeatureSearch(int ParentFeatureID, int FeatureCategoryID, string SearchTxt, int FeatureClassId, string DropDownIds)
        {
            try
            {
                FeaturesBLL ft = new FeaturesBLL();
                DataSet ds = ft.FeatureSearch(FeatureCategoryID, SearchTxt, FeatureClassId, DropDownIds.Replace("'", ""), UserInfo.GetCurrentUserID(), 0, 0);
                DataView dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "IsCombo<>1 and IsCategoryActive=1 and DeliveryType<>'AMO' and FeatureID <> " + ParentFeatureID;

                List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                Dictionary<string, object> Dictionary = null;

                for (int i = 0; i < dv.Count; i++)
                {
                    Dictionary = new Dictionary<string, object>();
                    Dictionary.Add("FeatureID", dv[i]["FeatureID"].ToString());
                    Dictionary.Add("FeatureName", dv[i]["FeatureName"].ToString().Replace(",", " "));
                    Dictionary.Add("Status", dv[i]["Status"].ToString());

                    rows.Add(Dictionary);
                }

                return rows;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> FeatureSearchFromPRL(int PlatformID, int ParentFeatureID, int FeatureCategoryID, string SearchTxt, int FeatureClassId, string DropDownIds)
        {
            try
            {
                FeaturesBLL ft = new FeaturesBLL();
                DataSet ds = ft.PRL_SearchBUintegratedfeatures(PlatformID, FeatureCategoryID, SearchTxt, FeatureClassId, DropDownIds.Replace("'", ""), UserInfo.GetCurrentUserID(), 0);
                DataView dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "IsCombo<>1 and IsCategoryActive=1 and DeliveryType<>'AMO' and FeatureID <> " + ParentFeatureID;

                List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                Dictionary<string, object> Dictionary = null;

                for (int i = 0; i < dv.Count; i++)
                {
                    Dictionary = new Dictionary<string, object>();
                    Dictionary.Add("FeatureID", dv[i]["FeatureID"].ToString());
                    Dictionary.Add("FeatureName", dv[i]["FeatureName"].ToString().Replace(",", " "));
                    Dictionary.Add("Status", dv[i]["Status"].ToString());

                    rows.Add(Dictionary);
                }

                return rows;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}