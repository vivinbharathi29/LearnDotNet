﻿namespace iPulsar.Features
{
    public enum FeatureDeliveryType
    {
        SRP = 1,
        Tech_AV = 2,
        AMO = 3,
        New_AMO = 4
    }
}