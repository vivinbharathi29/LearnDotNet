﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Features
{
    public partial class AMOFeatureViewChangeHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            int intFeatureID = 0;
            if (Request.QueryString["FeatureID"] != null)
                intFeatureID = Convert.ToInt32(Request.QueryString["FeatureID"]);
            hdnFeatureID.Value = intFeatureID.ToString();
            GetAMOFeatureName();
        }
        private void GetAMOFeatureName()
        {
            FeaturesBLL da = new FeaturesBLL();
            DataSet dsFeatureProperty = new DataSet();
            int intFeatureID = 0;
            intFeatureID = Convert.ToInt32(hdnFeatureID.Value);
            dsFeatureProperty = da.GetFeatureProperties(intFeatureID);
            if (dsFeatureProperty.Tables.Count > 0)
            {
                if (dsFeatureProperty.Tables[0].Rows.Count > 0)
                {
                    lblTitle.Text = "Change History Log: " + dsFeatureProperty.Tables[0].Rows[0]["FeatureName"].ToString();
                }
            }
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetAMOChangeHistory(int FeatureID)
        {
            List<Dictionary<string, object>> dicChangeHistoryList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicChangeHistory = null;
            DataSet dsChangeHistory = new DataSet();
            AMOFeatureBLL da = new AMOFeatureBLL();
            try
            {
                string strSearchFilter = "AND AO.FeatureID =" + FeatureID + "|";
                dsChangeHistory = da.GetAMOChangeHistory(strSearchFilter);
                for (int i = 0; i < dsChangeHistory.Tables[0].Rows.Count; i++)
                {
                    dicChangeHistory = new Dictionary<string, object>();
                    dicChangeHistory.Add("ChangeHistoryID", dsChangeHistory.Tables[0].Rows[i]["ChangeHistoryID"].ToString());
                    dicChangeHistory.Add("ChangeType", dsChangeHistory.Tables[0].Rows[i]["ChangeType"].ToString());
                    dicChangeHistory.Add("AMOCategory", dsChangeHistory.Tables[0].Rows[i]["AMOCategory"].ToString());
                    dicChangeHistory.Add("HPPartNo", dsChangeHistory.Tables[0].Rows[i]["HPPartNo"].ToString());
                    dicChangeHistory.Add("ShortDescription", dsChangeHistory.Tables[0].Rows[i]["ShortDescription"].ToString());
                    dicChangeHistory.Add("ChangeDescription", dsChangeHistory.Tables[0].Rows[i]["ChangeDescription"].ToString());
                    dicChangeHistory.Add("Reason", dsChangeHistory.Tables[0].Rows[i]["Reason"].ToString());
                    dicChangeHistory.Add("TimeChanged", dsChangeHistory.Tables[0].Rows[i]["TimeChanged"].ToString());
                    dicChangeHistory.Add("Updater", dsChangeHistory.Tables[0].Rows[i]["Updater"].ToString());

                    dicChangeHistoryList.Add(dicChangeHistory);
                }
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
            return dicChangeHistoryList;
        }
    }
}