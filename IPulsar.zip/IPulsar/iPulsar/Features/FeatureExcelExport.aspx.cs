﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Infragistics.Documents.Excel;

namespace iPulsar.Features
{
    public partial class FeatureExcelExport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            int FeatureClassId = 0, FeatureCategoryId = 0, LongNameOnlyField = 0, DeliveryTypeID = 0;
            string DropdownIds = "", SearchText = "";
            if (Request.QueryString["FeatureClassId"] != null)
                FeatureClassId = Convert.ToInt32(Request.QueryString["FeatureClassId"]);
            if (Request.QueryString["FeatureCategoryId"] != null)
                FeatureCategoryId = Convert.ToInt32(Request.QueryString["FeatureCategoryId"]);
            if (Request.QueryString["DropdownIds"] != null)
                DropdownIds = Request.QueryString["DropdownIds"].ToString();
            if (Request.QueryString["SearchText"] != null)
                SearchText = Request.QueryString["SearchText"].ToString();
            if (Request.QueryString["LongNameOnlyField"] != null)
                LongNameOnlyField = Convert.ToInt32(Request.QueryString["LongNameOnlyField"]);
            if (Request.QueryString["DeliveryTypeID"] != null)
                DeliveryTypeID = Convert.ToInt32(Request.QueryString["DeliveryTypeID"]);
            
            GetReportData(FeatureClassId, FeatureCategoryId, DropdownIds, SearchText, LongNameOnlyField, DeliveryTypeID);
        }

        private void GetReportData(int FeatureClassId, int FeatureCategoryId, string DropdownIds, string SearchText, int LongNameOnlyField, int DeliveryTypeID)
        {
            FeaturesBLL ft = new FeaturesBLL();
            DataSet ds = ft.FeatureExcelExport(FeatureClassId, FeatureCategoryId, DropdownIds.Replace("'", ""), SearchText, UserInfo.GetCurrentUserID(), LongNameOnlyField, DeliveryTypeID);
            DataTable dt = ds.Tables[0];
           
            //    dt.DefaultView.RowFilter = "DeliveryType <> 'AMO'";
           
            //filter in sp as the we are passing the dt, not the dv here so filter here will not work
            //we can change the code to use dv, since this one has its own sp, we just change teh sp
            
            
            string strNSName = "Feature Exported Report";

            CreateExcelReport(strNSName, dt);
        }

        private void CreateExcelReport(string strName, DataTable dt)
        {
            Workbook wbNSReport = new Workbook(WorkbookFormat.Excel2007);
            //specify the default font family
            Infragistics.Documents.Excel.IWorkbookFont defaultFont = wbNSReport.Styles.NormalStyle.StyleFormat.Font;
            defaultFont.Name = "Arial";
            defaultFont.Height = 9 * 20;

            Worksheet wsReport = wbNSReport.Worksheets.Add("Feature Exported Report");

            int intRowIndex = 0, intColumnIndex = 0;
            //add the headers
            wsReport.Rows[intRowIndex].Height = Convert.ToInt32(20 * 20.0);
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                if (dt.Columns[i].Caption == "FeatureName" || dt.Columns[i].Caption == "FeatureID" 
                    || dt.Columns[i].Caption == "FeatureCategoryName" || dt.Columns[i].Caption == "NamingStandard" 
                    || dt.Columns[i].Caption == "FeatureClassName" || dt.Columns[i].Caption == "DeliveryType" 
                    || dt.Columns[i].Caption == "Status" 
                    || dt.Columns[i].Caption == "ComponentLinkage" 
                    || dt.Columns[i].Caption == "RootID"
                    || dt.Columns[i].Caption == "FormulaNames" || dt.Columns[i].Caption == "GeneratedNames"
                    || dt.Columns[i].Caption == "NamingFields" || dt.Columns[i].Caption == "Updated"
                    || dt.Columns[i].Caption == "CodeName" || dt.Columns[i].Caption == "Creator"
                    || dt.Columns[i].Caption == "UpdatedBy"                    
                    )
                {
                    wsReport.Rows[intRowIndex].Cells[intColumnIndex].Value = dt.Columns[i].Caption.Replace("Feature", "Feature ").Replace("Category", "Category ").Replace("Naming", "Naming ").Replace("Class", "Class ").Replace("Delivery", "Delivery ").Replace("Component", "Component ").Replace("Formula", "Formula ").Replace("Generated", "Generated ");
                    wsReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.Alignment = HorizontalCellAlignment.Center;
                    wsReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                    wsReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.Fill = CellFill.CreateSolidFill(System.Drawing.ColorTranslator.FromHtml("#5B9BD5"));
                    //wsReport.Rows[intRowIndex].Cells[intColumnIndex].CellFormat.WrapText = ExcelDefaultableBoolean.True;
                    
                    //format the width if the columns
                    if (dt.Columns[i].Caption == "FeatureName")
                        wsReport.Columns[intColumnIndex].SetWidth(300, WorksheetColumnWidthUnit.Point);
                    if (dt.Columns[i].Caption == "FeatureID")
                        wsReport.Columns[intColumnIndex].SetWidth(50, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "FeatureCategoryName")
                        wsReport.Columns[intColumnIndex].SetWidth(200, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "NamingStandard")
                        wsReport.Columns[intColumnIndex].SetWidth(150, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "FeatureClassName")
                        wsReport.Columns[intColumnIndex].SetWidth(200, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "DeliveryType")
                        wsReport.Columns[intColumnIndex].SetWidth(75, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "Status")
                        wsReport.Columns[intColumnIndex].SetWidth(50, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "ComponentLinkage")
                        wsReport.Columns[intColumnIndex].SetWidth(100, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "RootID")
                        wsReport.Columns[intColumnIndex].SetWidth(50, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "FormulaNames")
                        wsReport.Columns[intColumnIndex].SetWidth(300, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "GeneratedNames")
                        wsReport.Columns[intColumnIndex].SetWidth(300, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "CodeName")
                    {   wsReport.Columns[intColumnIndex].SetWidth(75, WorksheetColumnWidthUnit.Point);
                        wsReport.Rows[intRowIndex].Cells[intColumnIndex].Value = "Code Name";
                    }
                    else if (dt.Columns[i].Caption == "Creator")
                        wsReport.Columns[intColumnIndex].SetWidth(75, WorksheetColumnWidthUnit.Point);
                    else if (dt.Columns[i].Caption == "NamingFields")
                    {
                        wsReport.Columns[intColumnIndex].SetWidth(300, WorksheetColumnWidthUnit.Point);
                        wsReport.Rows[intRowIndex].Cells[intColumnIndex].Value = "Naming Standard Fields Used in Long Name Only";
                    }
                    else if (dt.Columns[i].Caption == "Updated")
                    {
                        wsReport.Columns[intColumnIndex].SetWidth(75, WorksheetColumnWidthUnit.Point);
                        wsReport.Rows[intRowIndex].Cells[intColumnIndex].Value = "Time Updated";
                    }
                    else if (dt.Columns[i].Caption == "UpdatedBy")
                    {
                        wsReport.Columns[intColumnIndex].SetWidth(75, WorksheetColumnWidthUnit.Point);
                        wsReport.Rows[intRowIndex].Cells[intColumnIndex].Value = "Updated By";
                    }
                    intColumnIndex++;
                }
            }

            intRowIndex++;
            //add rows to the naming standard field 
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //string[] arr = dt.Rows[i]["FormulaNames"].ToString().Replace("; ", ";").Split(';');
                //for (int j = 0; j < arr.Length-1; j++)
                //{
                //    wsReport.Rows[intRowIndex].Height = Convert.ToInt32(16 * 20.0);
                //    intRowIndex++;
                //}

                //intFieldID = Convert.ToInt32(dtNamingStandardFields.Rows[i]["FieldID"].ToString());
                wsReport.Rows[intRowIndex].Cells[0].Value = dt.Rows[i]["FeatureName"].ToString();
                wsReport.Rows[intRowIndex].Cells[0].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[1].Value = dt.Rows[i]["FeatureID"].ToString();
                wsReport.Rows[intRowIndex].Cells[1].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[2].Value = dt.Rows[i]["FeatureClassName"].ToString();
                wsReport.Rows[intRowIndex].Cells[2].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[3].Value = dt.Rows[i]["FeatureCategoryName"].ToString();
                wsReport.Rows[intRowIndex].Cells[3].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[4].Value = dt.Rows[i]["NamingStandard"].ToString();
                wsReport.Rows[intRowIndex].Cells[4].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[5].Value = dt.Rows[i]["CodeName"].ToString();
                wsReport.Rows[intRowIndex].Cells[5].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[6].Value = dt.Rows[i]["Creator"].ToString();
                wsReport.Rows[intRowIndex].Cells[6].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[7].Value = dt.Rows[i]["DeliveryType"].ToString();
                wsReport.Rows[intRowIndex].Cells[7].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[8].Value = dt.Rows[i]["Status"].ToString();
                wsReport.Rows[intRowIndex].Cells[8].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[9].Value = dt.Rows[i]["ComponentLinkage"].ToString();
                wsReport.Rows[intRowIndex].Cells[9].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[10].Value = dt.Rows[i]["RootID"].ToString();
                wsReport.Rows[intRowIndex].Cells[10].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[11].Value = dt.Rows[i]["FormulaNames"].ToString().Replace("; ", "\n");
                wsReport.Rows[intRowIndex].Cells[12].Value = dt.Rows[i]["GeneratedNames"].ToString().Replace("; ", "\n");
                wsReport.Rows[intRowIndex].Cells[13].Value = dt.Rows[i]["NamingFields"].ToString().Replace("; ", "\n");
                wsReport.Rows[intRowIndex].Cells[13].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
                wsReport.Rows[intRowIndex].Cells[14].Value = dt.Rows[i]["Updated"].ToString();
                wsReport.Rows[intRowIndex].Cells[14].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;              
                wsReport.Rows[intRowIndex].Cells[15].Value = dt.Rows[i]["UpdatedBy"].ToString();
                wsReport.Rows[intRowIndex].Cells[15].CellFormat.VerticalAlignment = VerticalCellAlignment.Center;
              

                intRowIndex++;
            }

            //save the excel report
            Response.Clear();
            Response.AppendHeader("content-disposition", "attachment; filename= " + strName + ".xlsx");
            Response.ContentType = "application/octet-stream";
            wbNSReport.Save(Response.OutputStream);
            Response.End();
        }

    }
}