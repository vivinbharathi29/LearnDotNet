﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Features
{
    public partial class FeatureCreate : System.Web.UI.Page
    {
        int intPlatformID = 0;
        int intProductVersionID = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();


            if (!IsPostBack)
            {
                //int intRevisionID = 0;
                string strFeatureType = ""; //either HW type or SW type from PRL
                //------------ COMBINED AV FUNCTIONALITY (CREATE FEATURE)-----------------------
                hdnFromCreateAVPage.Value = Request.QueryString["FromCreateAVPage"] != null ? Convert.ToString(Request.QueryString["FromCreateAVPage"]) : "";
                hdnFromPlatformTab.Value = Request.QueryString["PlatformTab"] != null ? Convert.ToString(Request.QueryString["PlatformTab"]) : "";
                if (Request.QueryString["PlatformID"] != null)
                    intPlatformID = Convert.ToInt32(Request.QueryString["PlatformID"]);
                hdnPlatformID.Value = intPlatformID.ToString();
                if (Request.QueryString["ProductVersionID"] != null)
                    intProductVersionID = Convert.ToInt32(Request.QueryString["ProductVersionID"]);
                hdnProductVersionID.Value = intProductVersionID.ToString();
                //if (Request.QueryString["RevisionIDs"] != null)
                //    intRevisionID = Convert.ToInt32(Request.QueryString["RevisionIDs"]);
                //hdnRevisionIDs.Value = intRevisionID.ToString();
                if (Request.QueryString["FeatureType"] != null)
                    strFeatureType = Convert.ToString(Request.QueryString["FeatureType"]);
                hdnFeatureType.Value = strFeatureType;
                LoadFeatureClass();
            }
        }
        private void LoadFeatureClass()
        {
            AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
            DataSet dsFeatureClass = new DataSet();
            dsFeatureClass = da.GetAllFeatureClass();
            DataView dvFeatureClass = dsFeatureClass.Tables[0].DefaultView;

            if (Convert.ToInt32(hdnPlatformID.Value) == 0)
                dvFeatureClass.RowFilter = "Name <> 'Base Unit'";

            if (hdnFeatureType.Value == "HW")//display only Hardware and Base unit                
                dvFeatureClass.RowFilter = "Name = 'Hardware'";
            else if (hdnFeatureType.Value == "SW") //display only software, firmware and documentation
                dvFeatureClass.RowFilter = "Name <> 'Hardware' and Name <> 'Base Unit'";

            ddlFeatureClass.DataSource = dvFeatureClass;
            ddlFeatureClass.DataTextField = "Name";
            ddlFeatureClass.DataValueField = "FeatureClassID";
            ddlFeatureClass.DataBind();

            ddlFeatureClass.Items.Insert(0, new ListItem("Select a Feature Class", "0"));

            if (Convert.ToInt32(hdnPlatformID.Value) > 0)
            {
                for (int i = 0; i < ddlFeatureClass.Items.Count; i++)
                {
                    if (ddlFeatureClass.Items[i].Text == "Base Unit")
                        ddlFeatureClass.Items[i].Selected = true;
                }
                ddlFeatureClass.Enabled = false;
                LoadFeatureCategory();
            }
            else
            {
                trReleases.Visible = false;
            }
        }
        private void LoadFeatureCategory()
        {
            FeaturesBLL da = new FeaturesBLL();
            DataSet dsFeatureCategory = new DataSet();

            int intFeatureClassID = 0;
            intFeatureClassID = Convert.ToInt32(ddlFeatureClass.SelectedValue);

            dsFeatureCategory = da.GetFeatureCategoryByFeatureClassID(intFeatureClassID);

            ddlFeatureCategory.DataSource = dsFeatureCategory;
            ddlFeatureCategory.DataTextField = "Name";
            ddlFeatureCategory.DataValueField = "FeatureCategoryID";
            ddlFeatureCategory.DataBind();

            ddlFeatureCategory.Items.Insert(0, new ListItem("Select a Feature Category", "0"));
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, string>> GetNamingStandard(int intFeatureCategoryID)
        {
            try
            {
                // check permission from resource file instead of enums - task 19440
                bool bAlternativeNamingStandard_edit = false;
                if (Permission.IsCurrentUserHasPermission(Resources.Permissions.AlternativeNamingStandard_Edit_Permission))
                {
                    bAlternativeNamingStandard_edit = true;
                }
                AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
                DataSet dsNamingStandard = new DataSet();
                dsNamingStandard = da.FeatureCategory_NamingStandardList(intFeatureCategoryID, bAlternativeNamingStandard_edit);
                DataView dv1 = dsNamingStandard.Tables[1].DefaultView;
                //only load the bypassing naming standard if user is in that role
                if (!bAlternativeNamingStandard_edit)
                {
                    dv1.RowFilter = "Name not like 'ByPassing%' and Name not like '%Legacy%'";
                }

                List<Dictionary<string, string>> dicNamingStandard = new List<Dictionary<string, string>>();

                for (int i = 0; i < dv1.Count; i++)
                {
                    Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("NamingStandardID", dv1[i]["NamingStandardID"].ToString());
                    Dictionary.Add("Name", dv1[i]["Name"].ToString());
                    dicNamingStandard.Add(Dictionary);
                }
                return dicNamingStandard;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, string>> GetFeatureCategory(int intFeatureClassID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                DataSet dsFeatureCategory = new DataSet();

                dsFeatureCategory = da.GetFeatureCategoryByFeatureClassID(intFeatureClassID);
                DataView dv = dsFeatureCategory.Tables[0].DefaultView;
                dv.RowFilter = "State='Active' and Name NOT LIKE 'AMO:%'";
                List<Dictionary<string, string>> dicFeatureCategory = new List<Dictionary<string, string>>();

                for (int i = 0; i < dv.Count; i++)
                {
                    Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("FeatureCategoryID", dv[i]["FeatureCategoryID"].ToString());
                    Dictionary.Add("Name", dv[i]["Name"].ToString());
                    dicFeatureCategory.Add(Dictionary);
                }
                return dicFeatureCategory;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static List<Dictionary<string, string>> GetProductReleases(int ProductID)
        {
            try
            {
                ProductBLL da = new ProductBLL();

                List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
                Dictionary<string, string> Dictionary = null;

                DataSet ds = da.GetProductRelease(ProductID);

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("Release", ds.Tables[0].Rows[i]["ReleaseName"].ToString());
                    Dictionary.Add("ReleaseID", ds.Tables[0].Rows[i]["ReleaseID"].ToString());
                    Dictionary.Add("RTPDate", ds.Tables[0].Rows[i]["RTPDate"].ToString());
                    Dictionary.Add("EMDate", ds.Tables[0].Rows[i]["EMDate"].ToString());
                    rows.Add(Dictionary);
                }
                return rows;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static List<Dictionary<string, string>> GetDeliveryType()
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                DataSet dsDeliveryType = da.GetAllDeliveryType();
                DataView dvDeliveryType = dsDeliveryType.Tables[0].DefaultView;
                dvDeliveryType.RowFilter = "Name <> 'AMO'";
                if (dvDeliveryType.Count == 0)
                {
                    throw new Exception("Cannot get Delivery Type");
                }

                List<Dictionary<string, string>> deliveryTypes = new List<Dictionary<string, string>>();
                Dictionary<string, string> deliveryType = null;
                for (int i = 0; i < dvDeliveryType.Count; i++)
                {
                    deliveryType = new Dictionary<string, string>();
                    deliveryType.Add("DeliveryTypeID", dvDeliveryType[i]["DeliveryTypeID"].ToString());
                    deliveryType.Add("DeliveryTypeName", dvDeliveryType[i]["Name"].ToString());
                    deliveryTypes.Add(deliveryType);
                }
                return deliveryTypes;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }
}