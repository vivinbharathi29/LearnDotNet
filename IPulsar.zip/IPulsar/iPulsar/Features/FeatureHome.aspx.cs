﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;

public partial class FeatureHome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Authenticate.ValidateSession();

        string app = string.Empty;
        string searchText = string.Empty;
        searchText = Request.QueryString["SearchText"];
        app = Request.QueryString["app"];

        hdnirswebserver.Value = ApplicationSetting.GetValue("System.IRS.Url");

        FeatureDocumentaion.NavigateUrl = $"{HttpContext.Current.Request.Url.Scheme}://{HttpContext.Current.Request.Url.Host}/Excalibur/support/Preview.asp?ID=29";

        HtmlGenericControl body = (HtmlGenericControl)Page.Master.FindControl("MainBody");
        body.Style.Add("overflow", "hidden");
        string strRemberFilter = Cookie.GetDBCookie("Feature-RememberFilter");
        if (strRemberFilter != "0")
            strRemberFilter = "1";
        hdnRememberFilter.Value = strRemberFilter;
        if (strRemberFilter == "1")
        {
            var lstCookieSet = Cookie.GetDBCookie("Feature-Filter").Split('~');
            if (lstCookieSet.Length > 1)
            {
                hdnFeatureClassID.Value = lstCookieSet[0];
                hdnFeatureCategoryID.Value = lstCookieSet[1];
                hdnNaming.Value = lstCookieSet[2];
                if (app != null && searchText != null)
                {
                    FeatureSearchPulsarPlus(app, searchText);
                }
                else
                {
                    hdnTextSearch.Value = lstCookieSet[3];
                }
                hdnLongNameOnlyField.Value = lstCookieSet[4];
                hdnPageSize.Value = lstCookieSet[5];
                hdnPageNumber.Value = lstCookieSet[6] == "" ? "0" : lstCookieSet[6];
            }
            string strGridFilters = Cookie.GetDBCookie("Feature-GridFilter");
            hdnFilters.Value = strGridFilters;
        }
        else
        {
            if (app != null && searchText != null)
            {
                FeatureSearchPulsarPlus(app, searchText);
            }
        }
    }

    #region PulsarPlusQueryString
    /// <summary>
    /// Sets the query string value passed from the pulsarplus.
    /// </summary>
    /// <param name="app">The app identifier.</param>
    /// <param name="searchText">The searchText identifier.</param>
    /// <returns>
    /// </returns>
    private void FeatureSearchPulsarPlus(string app, string searchText)
    {
        if (app != null && searchText != null)
        {
            if (app.ToLowerInvariant() == "pulsarplus")
            {
                hdnTextSearch.Value = Request.QueryString["SearchText"];
                searchField.Value = Request.QueryString["SearchText"];
            }
        }
    }
    #endregion



    [WebMethod(EnableSession = true)]
    public static int GetHiddenFeatureCountForUser(int FeatureCategoryID, string SearchTxt, int FeatureClassId, string DropDownIds, int LongNameOnlyField)
    {
        try
        {
            FeaturesBLL ft = new FeaturesBLL();
            int intIsFeatureHiddenForUser = 0;
            intIsFeatureHiddenForUser = ft.GetHiddenFeatureCountForUser(FeatureCategoryID, SearchTxt, FeatureClassId, DropDownIds.Replace("'", ""), UserInfo.GetCurrentUserID(), LongNameOnlyField);
            return intIsFeatureHiddenForUser;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static void SaveFilter(int FeatureCategoryID, string SearchTxt, int FeatureClassId, string DropDownIds, int LongNameOnlyField, int PageSize, int PageNumber)
    {
        try
        {
            Cookie.SetDBCookie("Feature-Filter", string.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}", FeatureClassId, FeatureCategoryID, DropDownIds.Replace("'", ""), SearchTxt, LongNameOnlyField, PageSize, PageNumber));
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static void SaveGridFilter(string GridFilters)
    {
        try
        {
            Cookie.SetDBCookie("Feature-GridFilter", GridFilters);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
    [WebMethod(EnableSession = true)]
    public static void SaveRememberFilter(string RememberFilter)
    {
        try
        {
            Cookie.SetDBCookie("Feature-RememberFilter", RememberFilter);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, object>> FeatureSearch(int FeatureCategoryID, string SearchTxt, int FeatureClassId, string DropDownIds, int LongNameOnlyField, int DeliveryTypeID)
    {
        try
        {
            FeaturesBLL ft = new FeaturesBLL();
            DataSet ds = ft.FeatureSearch(FeatureCategoryID, SearchTxt, FeatureClassId, DropDownIds.Replace("'", ""), UserInfo.GetCurrentUserID(), LongNameOnlyField, DeliveryTypeID);
            DataView dv = ds.Tables[0].DefaultView;

            if (UserInfo.GetCurrentUserIsODM() == 1)
            {
                dv.RowFilter = "Partnerviewable=1";
            }

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> Dictionary = null;

            for (int i = 0; i < dv.Count; i++)
            {
                Dictionary = new Dictionary<string, object>();
                Dictionary.Add("FeatureID", dv[i]["FeatureID"].ToString());
                Dictionary.Add("FeatureName", dv[i]["FeatureName"].ToString());
                Dictionary.Add("FeatureClassName", dv[i]["FeatureClassName"].ToString());
                Dictionary.Add("FeatureCategoryName", dv[i]["FeatureCategoryName"].ToString());
                Dictionary.Add("NamingStandard", dv[i]["NamingStandard"].ToString());
                Dictionary.Add("CodeName", dv[i]["CodeName"].ToString());
                Dictionary.Add("Creator", dv[i]["Creator"].ToString());
                Dictionary.Add("DeliveryType", dv[i]["DeliveryType"].ToString());
                Dictionary.Add("Status", dv[i]["Status"].ToString());
                if (Convert.ToInt32(dv[i]["RootID"]) > 0)
                    Dictionary.Add("ComponentLinkage", dv[i]["ComponentLinkage"].ToString() + " (" + dv[i]["RootID"].ToString() + ")");
                else
                    Dictionary.Add("ComponentLinkage", dv[i]["ComponentLinkage"].ToString());
                Dictionary.Add("Visibility", dv[i]["Visibility"].ToString());
                if (dv[i]["Override"].ToString()=="1")
                    Dictionary.Add("Override","Y");
                else
                    Dictionary.Add("Override", "N");                
                Dictionary.Add("bused", dv[i]["bUsed"].ToString());
                Dictionary.Add("RootID", dv[i]["RootID"].ToString());
                rows.Add(Dictionary);
            }
            return rows;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetCategory(int Id)
    {
        try
        {
            FeaturesBLL ft = new FeaturesBLL();
            DataSet ds = ft.GetFeatureCategoryByFeatureClassID(Id);
            DataView dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "Name NOT LIKE 'AMO:%'";

            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> Dictionary = null;

            for (int i = 0; i < dv.Count; i++)
            {
                Dictionary = new Dictionary<string, string>();
                Dictionary.Add("FeatureCategoryID", dv[i]["FeatureCategoryID"].ToString());
                Dictionary.Add("Name", dv[i]["DropDownName"].ToString());
                rows.Add(Dictionary);
            }

            return rows;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetFeatureClass()
    {
        try
        {
            FeaturesBLL ft = new FeaturesBLL();
            DataSet ds = ft.GetFeatureClass();

            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> Dictionary = null;

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                Dictionary = new Dictionary<string, string>();
                Dictionary.Add("FeatureClassID", ds.Tables[0].Rows[i]["FeatureClassID"].ToString());
                Dictionary.Add("FeatureClassName", ds.Tables[0].Rows[i]["FeatureClassName"].ToString());
                rows.Add(Dictionary);
            }

            return rows;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<Dictionary<string, string>> GetFeatureNamingDropdownValue(int Id)
    {
        try
        {
            FeaturesBLL ft = new FeaturesBLL();
            DataSet ds = ft.GetFeatureNamingDropdownValue(Id);

            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> Dictionary = null;

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                Dictionary = new Dictionary<string, string>();
                Dictionary.Add("Id", ds.Tables[0].Rows[i]["FieldId"].ToString() + Char.ConvertFromUtf32(3) + ds.Tables[0].Rows[i]["DropDownValueID"].ToString());
                Dictionary.Add("Name", ds.Tables[0].Rows[i]["NSName"].ToString() + " - " + ds.Tables[0].Rows[i]["FieldName"].ToString() + " - " + ds.Tables[0].Rows[i]["Value"].ToString());
                rows.Add(Dictionary);
            }

            return rows;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static List<string> GetUserPermission()
    {
        try
        {
            List<string> per = new List<string>();
            per = Permission.GetUserPermissions(UserInfo.GetCurrentUserID());
            return per;
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    [WebMethod(EnableSession = true)]
    public static void Delete(int Id)
    {
        try
        {
            FeaturesBLL da = new FeaturesBLL();
            da.DeleteFeature(Id);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }

    // Use different method to delete AMo feature - task 21353
    [WebMethod(EnableSession = true)]
    public static string DeleteAMOFeature(int Id)
    {
        string strMsg = "";
        try
        {
            AMOFeatureBLL m = new AMOFeatureBLL();
            m.DeleteFeature(Id);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            strMsg = ex.Message;
        }
        return strMsg;
    }

    [WebMethod(EnableSession = true)]
    public static void SetStatus(int Id, int StatusId)
    {
        try
        {
            FeaturesBLL da = new FeaturesBLL();
            da.SetStatus(Id, StatusId);
        }
        catch (Exception ex)
        {
            Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
            throw;
        }
    }
}