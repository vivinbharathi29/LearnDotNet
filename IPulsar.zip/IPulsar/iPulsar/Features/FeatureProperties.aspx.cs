﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Web.UI.WebControls;
using iPulsar.Old_App_Code.BLL.Admin;
using Newtonsoft.Json;

namespace iPulsar.Features
{
    public partial class FeatureProperties : System.Web.UI.Page
    {
        int intFeatureID = 0, intFeatureClassID = 0, intFeatureCategoryID = 0, intNamingStandardID = 0, _deliveryTypeID = 0;
        bool bFeatureEditRight = false, bViewOnly = false;//, bFeatureViewOnly = false;
        bool bAlternativeNamingStandard_edit = false;
        bool bFeatureChinaBPIdentifier_Edit = false;
        int intIsUsed = 0, intFromPRL = 0, intFormulaChanged = 0;
        string strFeatureCategoryName = ""; string strFeatureType = ""; string strFeatureClassName = "";
        bool bInstallOption_Edit = false;
        int intOSID = 0;
        string strOSName = "";
        int PanelLocationA = 0, PanelLocationB = 0, KeyboardLocationA = 0, KeyboardLocationB = 0;
        bool _allowReference;
        private static bool _isFromAVPage;

        void Page_PreInit(object sender, EventArgs e)
        {
            if (string.Equals(Request.QueryString["Layout"], "pulsar2", StringComparison.OrdinalIgnoreCase))
            {
                MasterPageFile = "~/MasterPages/MainMasterPageNoTitleBar.master";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            Authenticate.ValidateSession();

            if (!IsPostBack)
            {
                int intPlatformID = 0;
                int intProductVersionID = 0;
                hdnModuleID.Value = "0";
                hdnIsByPassingFeature.Value = "0";
                if (Request.QueryString.Get("FeatureID") != null)
                    intFeatureID = Convert.ToInt32(Request.QueryString.Get("FeatureID"));
                if (Request.QueryString.Get("FeatureClassID") != null)
                    intFeatureClassID = Convert.ToInt32(Request.QueryString.Get("FeatureClassID"));
                if (Request.QueryString.Get("FeatureCategoryID") != null)
                    intFeatureCategoryID = Convert.ToInt32(Request.QueryString.Get("FeatureCategoryID"));
                if (Request.QueryString.Get("NamingStandardID") != null)
                {
                    intNamingStandardID = Convert.ToInt32(Request.QueryString.Get("NamingStandardID"));
                    if (intNamingStandardID == 1005)
                    {
                        hdnIsByPassingFeature.Value = "1";
                    }
                }
                if (Request.QueryString.Get("ModuleID") != null)
                {
                    //ModuleID = Convert.ToInt32(Request.QueryString.Get("ModuleID"));
                    hdnModuleID.Value = Request.QueryString.Get("ModuleID");
                }
                if (Request.QueryString.Get("FromModule") != null)
                {
                    hdnFromModule.Value = Request.QueryString.Get("FromModule");
                }
                if (Request.QueryString.Get("ViewOnly") != null)
                {
                    bViewOnly = Convert.ToBoolean(Request.QueryString.Get("ViewOnly"));
                }
                if (Request.QueryString.Get("PlatformID") != null)
                {
                    intPlatformID = Convert.ToInt32(Request.QueryString.Get("PlatformID"));
                }
                if (Request.QueryString.Get("PVID") != null)
                {
                    intProductVersionID = Convert.ToInt32(Request.QueryString.Get("PVID"));
                }
                if (Request.QueryString.Get("DeliveryTypeID") != null)
                {
                    _deliveryTypeID = Convert.ToInt32(Request.QueryString.Get("DeliveryTypeID"));
                }
                if (Request.QueryString.Get("FromPRL") != null)
                {
                    intFromPRL = Convert.ToInt32(Request.QueryString.Get("FromPRL"));

                    //set this so we can avoid find parent.$("#ddlNSF").igCombo("values"); from feature home when we call from outside
                    hdnViewFrom.Value = "PRL";
                }
                else
                {
                    // ******************************** Check to see where the page is calling from *************************************//
                    hdnViewFrom.Value = Request.QueryString["ViewFrom"] != null ? Convert.ToString(Request.QueryString["ViewFrom"]) : "";
                    // *****************************************************************************************************************//
                    if (hdnViewFrom.Value == "SharedAV")
                    {
                        hdnAvDetailID.Value = Request.QueryString["AvDetailID"] != null ? Convert.ToString(Request.QueryString["AvDetailID"]) : "";
                    }
                }

                if (Request.QueryString["FeatureType"] != null)
                    strFeatureType = Convert.ToString(Request.QueryString["FeatureType"]);

                if (Request.QueryString["AltNamingTodayPage"] != null)
                    hdnAltNamingTodayPage.Value = Convert.ToString(Request.QueryString["AltNamingTodayPage"]);

                if (Request.QueryString["ReleaseIDs"] != null)
                    hdnReleaseIDs.Value = Convert.ToString(Request.QueryString["ReleaseIDs"]);

                hdnProductVersionID.Value = intProductVersionID.ToString();
                hdnPlatformID.Value = intPlatformID.ToString();

                //------------ COMBINED AV FUNCTIONALITY (CREATE FEATURE)-----------------------
                hdnFromCreateAVPage.Value = Request.QueryString["FromCreateAVPage"] != null ? Convert.ToString(Request.QueryString["FromCreateAVPage"]) : "";
                _isFromAVPage = hdnFromCreateAVPage.Value == "FromCreateAV";
                hdnFromPlatformTab.Value = Request.QueryString["PlatformTab"] != null ? Convert.ToString(Request.QueryString["PlatformTab"]) : "";
                if (Request.QueryString["FeatureClassName"] != null)
                    strFeatureClassName = Convert.ToString(Request.QueryString["FeatureClassName"]);
                hdnFeatureClassName.Value = strFeatureClassName;

                if (Request.QueryString["IsDesktop"] != null)
                    hdnSelectIsDesktop.Value = Request.QueryString["IsDesktop"];

                hdnFeatureID.Value = intFeatureID.ToString();
                //for features with limitted access, check if it is viewable to the user
                hdnIsViewabletoUser.Value = "0";
                if (intFeatureID > 0)
                {
                    FeaturesBLL da = new FeaturesBLL();
                    DataSet dsIsViewabletoUser = new DataSet();
                    dsIsViewabletoUser = da.Feature_IsViewabletoUser(intFeatureID, UserInfo.GetCurrentUserID());
                    DataView dvIsViewabletoUser = dsIsViewabletoUser.Tables[0].DefaultView;
                    if (dvIsViewabletoUser.Count > 0)
                    {
                        if (dvIsViewabletoUser[0]["ISViewable"].ToString() == "1" || dvIsViewabletoUser[0]["ISViewable"].ToString().ToLower() == "true")
                            hdnIsViewabletoUser.Value = "1";
                        else
                            hdnIsViewabletoUser.Value = "0";
                    }
                }
                else
                {
                    hdnIsViewabletoUser.Value = "1";
                    hdnIsNewFeature.Value = "1";
                }

                if (hdnIsViewabletoUser.Value == "1")
                {
                    GetPermission();  //call this before loading the combo as we need to remove certain items depending on user right
                    //should call LoadFeatureProperties() first then LoadDeliveryType(), otherwise DeliveryType setting will be wrong
                    LoadFeatureProperties();
                    LoadDeliveryType(intFeatureID);
                    LoadFeatureClass();
                    LoadFeatureCategory();
                    LoadNamingStandard();
                    LoadSMIBIOSAdd_ReMove();
                    LoadODM_HP_Permission();
                    LoadOSList();
                    LoadFeatureLocationValues();
                    LoadAMOFeatureInfo(intFeatureID);
                    DisableControls();
                }

                if (Request.QueryString["bFeatureViewOnly"] != null && Convert.ToBoolean(Request.QueryString["bFeatureViewOnly"]) == true)
                {
                    btnCancel2.Visible = false;
                    btnClone2.Visible = false;
                    btnDelete2.Visible = false;
                    btnNext.Visible = false;
                    btnSave2.Visible = false;
                    btnViewChangeLog.Visible = false;
                }
                // Hide Clone button for BaseUnit features - task 16516
                if (intFeatureClassID == 5)
                {
                    btnClone2.Visible = false;
                }
            }
            if (Convert.ToInt32(hdnFeatureID.Value) == -1)
            {
                lblTitle.Text = "Create Feature";
                btnClone2.Enabled = false;
                trFeatureID.Visible = false;
            }
            else
            {
                lblTitle.Text = "Modify Feature";
                trFeatureID.Visible = true;
                lblFeatureID.Text = intFeatureID.ToString();
            }
        }
        // check permission from resource file instead of enums - task 19440
        private void GetPermission()
        {
            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.Feature_Edit_Permission.ToString()))
            {
                bFeatureEditRight = true;
            }
            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.AlternativeNamingStandard_Edit_Permission.ToString()))
            {
                bAlternativeNamingStandard_edit = true;
                hdnAlternateNSEdit.Value = "1";
            }
            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.FeatureChinaGPIdentifier_Edit_Permission.ToString()))
            {
                bFeatureChinaBPIdentifier_Edit = true;
            }
            //if user is ODM, view only
            if (UserInfo.GetCurrentUserIsODM() == 1)
            {

                bFeatureEditRight = false;
                bAlternativeNamingStandard_edit = false;
                bFeatureChinaBPIdentifier_Edit = false;
            }



            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.InstallOption_Edit_Permission.ToString()))
            {
                hdnInstallOption.Value = "0";
                bInstallOption_Edit = true;
            }
            else
            {
                hdnInstallOption.Value = "1";
            }

        }
        private void DisableControls()
        {
            ddlDeliveryType.Enabled = true;
            lblUsedMsg.Text = "";
            lblUsedFCMsg.Text = "";
            //Active = 1, Disabled = 2, Draft = 3,New Usage Item = 4
            ListItem disabledItem = rblStatus.Items.FindByValue("2");
            ListItem draftItem = rblStatus.Items.FindByValue("3");
            ListItem noNewUsageItem = rblStatus.Items.FindByValue("4");

            if (intFeatureID == -1)
            {
                //create new Feature
                rblStatus.SelectedValue = "1";
                disabledItem.Enabled = false;
                noNewUsageItem.Enabled = false;
                lblDisabledStatus.Visible = false;
            }
            else if (intFeatureID > 0)
            {
                if (rblStatus.SelectedValue == "1")
                {
                    draftItem.Enabled = false;

                    if (!_allowReference)
                    {
                        rblStatus.SelectedValue = "4";
                        disabledItem.Enabled = false;
                        btnClone2.Enabled = false;
                    }
                }
                else if (rblStatus.SelectedValue == "2")
                {
                    ddlFeatureClass.Enabled = false;
                    ddlFeatureCategory.Enabled = false;
                    ddlNamingStandard.Enabled = false;
                    ddlDeliveryType.Enabled = false;
                    txtCodeName.Enabled = false;
                    txtRuleID.Enabled = false;
                    txtChinaIdentifier.Enabled = false;
                    chkRootRequire1.Disabled = true;
                    chkComboFeature1.Disabled = true;
                    txtNotes.Enabled = false;
                    lnkComboFeatures.Disabled = true;
                    draftItem.Enabled = false;
                    noNewUsageItem.Enabled = false;
                }
                else if (rblStatus.SelectedValue == "3")
                {
                    draftItem.Enabled = true;
                    disabledItem.Enabled = false;
                    noNewUsageItem.Enabled = false;
                }

                if (hdnIsUsed.Value == "0")
                {
                    lblDisabledStatus.Visible = false;
                }
                else
                {
                    //Disabled and show lable if feature is InUsed
                    lblDisabledStatus.Visible = true;
                    disabledItem.Enabled = false;
                }
            }

            foreach (ListItem item in rblStatus.Items)
            {
                item.Attributes["data-originalstatus"] = item.Enabled ? "true" : "false";
            }

            if (intIsUsed != 0) //if is used in PRL or SCM
            {
                ddlDeliveryType.Enabled = false;
                ddlFeatureClass.Enabled = false;
                lblUsedMsg.Text = "Cannot change feature delivery type if it is in use.";
                lblUsedFCMsg.Text = "Cannot change the feature class if it is in use.";
                lblWhereUsed.Text = "This feature is used in PRL. Click the Where Used link for detail.";
                lnkWhereUsed.Visible = true;
                btnDelete2.Enabled = false; //can not delete Features used in PRL or SCM
                btnDelete2.ToolTip = "Feature cannot be deleted if used in PRL or SCM";
            }

            //disable saving button if user does not have edit right: or the page is open for ViewOnly
            if (!bFeatureEditRight || bViewOnly)
            {
                btnClone2.Enabled = false;
                btnDelete2.Enabled = false;
                lnkComboFeatures.Disabled = true;
            }
            //will need to check if a feature is in published scmx later
            if (!bFeatureChinaBPIdentifier_Edit)
                txtChinaIdentifier.Enabled = false;

            if ((!bFeatureEditRight && !bFeatureChinaBPIdentifier_Edit) || bViewOnly)
                btnSave2.Enabled = false;

            // enable save button if user has InstallOption.Edit permission
            if (bInstallOption_Edit)
            {
                btnSave2.Enabled = true;
            }

            if (bInstallOption_Edit && !bFeatureEditRight)
            {
                hdnInstallOptiontrueandFeatureEditfalse.Value = "1";
            }
        }
        private void LoadDeliveryType(int featureId)
        {
            bool shouldShowNewAmo = false;  //default not showing "New AMO", including when _isFromAVPage==true
            if (featureId < 0 || (featureId > 0 && _deliveryTypeID == 4))
            {
                //only show New AMO selection when creating/cloning(func ReloadDeliveryType()) new feature
                shouldShowNewAmo = true;
            }
            FeaturesBLL da = new FeaturesBLL();
            DataSet dsDeliveryType = da.GetAllDeliveryType();
            DataView dvDeliveryType = dsDeliveryType.Tables[0].DefaultView;
            //default not showing "AMO" selection
            dvDeliveryType.RowFilter = shouldShowNewAmo ? "Name <> 'AMO'" : "Name NOT IN ('AMO', 'New AMO')" ;
            ddlDeliveryType.DataSource = dvDeliveryType;
            ddlDeliveryType.DataTextField = "Name";
            ddlDeliveryType.DataValueField = "DeliveryTypeID";
            ddlDeliveryType.DataBind();
            ddlDeliveryType.SelectedValue = _deliveryTypeID.ToString();
        }

        private void LoadFeatureClass()
        {
            AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
            DataSet dsFeatureClass = new DataSet();
            dsFeatureClass = da.GetAllFeatureClass();
            DataView dvFeatureClass = dsFeatureClass.Tables[0].DefaultView;

            if (intFeatureClassID != 5)
            {
                if (Convert.ToInt32(hdnPlatformID.Value) == 0 && (Convert.ToInt32(hdnAliasID.Value) == 0))
                    dvFeatureClass.RowFilter = "Name <> 'Base Unit'";
            }
            if (intFromPRL == 1)
            {
                if (strFeatureType == "HW")//display only Hardware and Base unit                
                    dvFeatureClass.RowFilter = "Name = 'Hardware'";
                else if (strFeatureType == "SW") //display only software, firmware and documentation
                    dvFeatureClass.RowFilter = "Name <> 'Hardware' and Name <> 'Base Unit'";
            }

            ddlFeatureClass.DataSource = dvFeatureClass;
            ddlFeatureClass.DataTextField = "Name";
            ddlFeatureClass.DataValueField = "FeatureClassID";
            ddlFeatureClass.DataBind();

            ddlFeatureClass.Items.Insert(0, new ListItem("Select a Feature Class", "0"));

            ddlFeatureClass.SelectedValue = intFeatureClassID.ToString();
            if (Convert.ToInt32(hdnPlatformID.Value) > 0 || (Convert.ToInt32(hdnAliasID.Value) > 0))
                ddlFeatureClass.Enabled = false;
        }
        private void LoadFeatureCategory()
        {
            FeaturesBLL da = new FeaturesBLL();
            DataSet dsFeatureCategory = new DataSet();

            dsFeatureCategory = da.GetFeatureCategoryByFeatureClassID(intFeatureClassID);
            DataView dv;
            dv = dsFeatureCategory.Tables[0].DefaultView;
            dv.RowFilter = "State = 'Active' and Name NOT LIKE 'AMO:%'";
            ddlFeatureCategory.DataSource = dv;
            ddlFeatureCategory.DataTextField = "Name";
            ddlFeatureCategory.DataValueField = "FeatureCategoryID";
            ddlFeatureCategory.DataBind();
            ddlFeatureCategory.Items.Insert(0, new ListItem("Select a Feature Category", "0"));

            if (ddlFeatureCategory.Items.FindByValue(intFeatureCategoryID.ToString()) != null)
            {
                ddlFeatureCategory.SelectedValue = intFeatureCategoryID.ToString();
            }
            else
            {
                ListItem it1 = new ListItem();
                it1.Value = intFeatureCategoryID.ToString();
                it1.Text = strFeatureCategoryName;
                ddlFeatureCategory.Items.Insert(0, it1);
                it1.Selected = true;
            };
        }


        private void LoadOSList()
        {
            AdminOperatingSystemsBLL da = new AdminOperatingSystemsBLL();
            DataSet dsOS = new DataSet();

            dsOS = da.GetAllOS();

            DataView dv;
            dv = dsOS.Tables[0].DefaultView;
            dv.RowFilter = "SupplyChain='Yes'";
            ddlOS.DataSource = dv;
            ddlOS.DataTextField = "Name";
            ddlOS.DataValueField = "ID";
            ddlOS.DataBind();
            ddlOS.Items.Insert(0, new ListItem("Select an Operating System", "0"));

            if (ddlOS.Items.FindByValue(intOSID.ToString()) != null)
            {
                ddlOS.SelectedValue = intOSID.ToString();
            }
            else
            {
                ListItem it1 = new ListItem();
                it1.Value = intOSID.ToString();
                it1.Text = strOSName;
                ddlOS.Items.Insert(0, it1);
                it1.Selected = true;
            };
        }
        private void LoadFeatureLocationValues()
        {
            FeaturesBLL da = new FeaturesBLL();
            DataSet dsLocationValues = new DataSet();
            dsLocationValues = da.Feature_GetLocationValues();
            DataView dv;
            dv = dsLocationValues.Tables[0].DefaultView;
            DDLPLA.DataSource = dv;
            DDLPLA.DataTextField = "Name";
            DDLPLA.DataValueField = "FeatureLocationID";
            DDLPLA.DataBind();
            DDLPLA.Items.Insert(0, new ListItem("", "0"));
            if (DDLPLA.Items.FindByValue(PanelLocationA.ToString()) != null)
            {
                DDLPLA.SelectedValue = PanelLocationA.ToString();
            }

            DDLPLB.DataSource = dv;
            DDLPLB.DataTextField = "Name";
            DDLPLB.DataValueField = "FeatureLocationID";
            DDLPLB.DataBind();
            DDLPLB.Items.Insert(0, new ListItem("", "0"));
            if (DDLPLB.Items.FindByValue(PanelLocationB.ToString()) != null)
            {
                DDLPLB.SelectedValue = PanelLocationB.ToString();
            }

            DDLKLA.DataSource = dv;
            DDLKLA.DataTextField = "Name";
            DDLKLA.DataValueField = "FeatureLocationID";
            DDLKLA.DataBind();
            DDLKLA.Items.Insert(0, new ListItem("", "0"));
            if (DDLKLA.Items.FindByValue(KeyboardLocationA.ToString()) != null)
            {
                DDLKLA.SelectedValue = KeyboardLocationA.ToString();
            }

            DDLKLB.DataSource = dv;
            DDLKLB.DataTextField = "Name";
            DDLKLB.DataValueField = "FeatureLocationID";
            DDLKLB.DataBind();
            DDLKLB.Items.Insert(0, new ListItem("", "0"));
            if (DDLKLB.Items.FindByValue(KeyboardLocationB.ToString()) != null)
            {
                DDLKLB.SelectedValue = KeyboardLocationB.ToString();
            }
        }
        private void LoadNamingStandard()
        {
            AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
            DataSet dsNamingStandard = new DataSet();
            bool hasDisabledItem = false;
            if (intFeatureID > 0 || bAlternativeNamingStandard_edit)
            {
                hasDisabledItem = true;
            }
            dsNamingStandard = da.FeatureCategory_NamingStandardList(intFeatureCategoryID, hasDisabledItem); 
            if (!bAlternativeNamingStandard_edit)
            {
                dsNamingStandard.Tables[1].DefaultView.RowFilter = string.Format("Disabled is null or (Disabled is not null and NamingStandardID = {0})" , intNamingStandardID);
            } 
            ddlNamingStandard.DataSource = dsNamingStandard.Tables[1].DefaultView;
            ddlNamingStandard.DataTextField = "Name";
            ddlNamingStandard.DataValueField = "NamingStandardID";
            ddlNamingStandard.DataBind();

            ddlNamingStandard.Items.Insert(0, new ListItem("Select a Naming Standard", "0"));
            ddlNamingStandard.SelectedValue = intNamingStandardID.ToString();

            if (intFeatureID <= 0 || (!bAlternativeNamingStandard_edit && ddlNamingStandard.SelectedItem.Text != "ByPassing"))
            {
                for (int i = 0; i < ddlNamingStandard.Items.Count; i++)
                {
                    if (ddlNamingStandard.Items[i].Text.IndexOf("ByPassing") > -1)
                    {
                        ddlNamingStandard.Items.Remove(ddlNamingStandard.Items[i]);
                    }
                }
            }

            bool removeLegacyNS = ddlNamingStandard.SelectedItem.Text.IndexOf("legacy", 0, StringComparison.OrdinalIgnoreCase) == -1;
            if (!bAlternativeNamingStandard_edit && removeLegacyNS)
            {
                for (int i = 0; i < ddlNamingStandard.Items.Count; i++)
                {
                    if (ddlNamingStandard.Items[i].Text.IndexOf("legacy", 0, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        ddlNamingStandard.Items.Remove(ddlNamingStandard.Items[i]);
                    }
                }
            }

            //add data attribute
            DataView dvNamingStandard = dsNamingStandard.Tables[1].DefaultView;
            for (int i = 1; i < ddlNamingStandard.Items.Count; i++)
            {
                dvNamingStandard.RowFilter = string.Format("NamingStandardId = {0}", ddlNamingStandard.Items[i].Value);
                if (dvNamingStandard.Count > 0)
                {
                    ddlNamingStandard.Items[i].Attributes.Add("data-disabled", string.IsNullOrEmpty(dvNamingStandard[0]["Disabled"].ToString()) ? "1" : "0");
                }
                else
                {
                    ddlNamingStandard.Items[i].Attributes.Add("data-disabled", "1");
                }
            }
        }
        private void LoadLinkedCompCategory(int intFeatureCategoryID)
        {
            FeaturesBLL da = new FeaturesBLL();
            int intLinkedCategoryID = da.GetLinkedCompCategory(intFeatureCategoryID);
            hdnLinkedToRoot.Value = intLinkedCategoryID.ToString();
        }

        private void LoadAMOFeatureInfo(int featureID)
        {
            if (_deliveryTypeID != 4 || featureID < 0)
            {
                LoadAMOBusinessSegment(0);
                return;
            }

            FeaturesBLL featureBal = new FeaturesBLL();
            DataSet dsAmoInfo = featureBal.GetAmoFeatureInfo(featureID);
            if (dsAmoInfo.Tables.Count == 0 || dsAmoInfo.Tables[0].Rows.Count == 0)
            {
                throw new Exception("Cannot load the information for AMO tab now. Please try again later.");
            }

            int tmpBSId = 0;
            int.TryParse(dsAmoInfo.Tables[0].Rows[0]["BusinessSegmentId"].ToString(), out tmpBSId);
            rblLocalized.SelectedValue = dsAmoInfo.Tables[0].Rows[0]["IsLocalized"].ToString();
            rblSeriesFlag.SelectedValue = dsAmoInfo.Tables[0].Rows[0]["SerialFlag"].ToString();
            txtPrevProduct.Text = dsAmoInfo.Tables[0].Rows[0]["PreviousProduct"].ToString();
            txtWarranty.Text = dsAmoInfo.Tables[0].Rows[0]["WarrantyCode"].ToString();
            hidFootnotes.Value = dsAmoInfo.Tables[0].Rows[0]["Footnotes"].ToString();
            LoadAMOBusinessSegment(tmpBSId);
        }

        private void LoadAMOBusinessSegment(int? amoBusinessSegmentID)
        {
            FeaturesBLL featureBal = new FeaturesBLL();
            DataSet dsAmoBs = featureBal.GetAmoBusinessSegments();
            if (dsAmoBs.Tables.Count == 0 || dsAmoBs.Tables[0].Rows.Count == 0)
            {
                ddlAmoBS.Items.Insert(0, new ListItem("There is no Business Operation of Business Segment is AMO", "0"));
            }
            else
            {
                ddlAmoBS.DataSource = dsAmoBs.Tables[0].DefaultView;
                ddlAmoBS.DataTextField = "Name";
                ddlAmoBS.DataValueField = "BusinessSegmentID";
                ddlAmoBS.DataBind();
                ddlAmoBS.Items.Insert(0, new ListItem("Select a Business Segment", "0"));
                if (amoBusinessSegmentID.HasValue && ddlAmoBS.Items.FindByValue(amoBusinessSegmentID.Value.ToString()) != null)
                {
                    ddlAmoBS.SelectedValue = amoBusinessSegmentID.Value.ToString();
                }
            }
        }

        [WebMethod]
        public static int PushTrulylinkedComponentRootID(int featureID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                return da.PushTrulylinkedComponentRootID(featureID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static string GetLinkedCompCategory(int featureCategoryID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                int intLinkedCategoryID = 0;
                intLinkedCategoryID = da.GetLinkedCompCategory(featureCategoryID);
                return intLinkedCategoryID.ToString();
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        private void LoadSMIBIOSAdd_ReMove()
        {
            FeaturesBLL da = new FeaturesBLL();
            DataSet dsSMIBIOSAdd = new DataSet();
            DataSet dsSMBIOSRemove = new DataSet();

            if (intFeatureID != 0)
            {
                dsSMIBIOSAdd = da.Feature_GetSMBIOSAdd(intFeatureID);
                DataView dv1 = dsSMIBIOSAdd.Tables[0].DefaultView;
                dv1.RowFilter = "bSelected=0";
                SMIBIOSAddbox1View.DataSource = dv1;
                SMIBIOSAddbox1View.DataTextField = "Description";
                SMIBIOSAddbox1View.DataValueField = "Id";
                SMIBIOSAddbox1View.DataBind();
                dv1.RowFilter = "bSelected=1";
                SMIBIOSAddbox2View.DataSource = dv1;
                SMIBIOSAddbox2View.DataTextField = "Description";
                SMIBIOSAddbox2View.DataValueField = "Id";
                SMIBIOSAddbox2View.DataBind();

                dsSMBIOSRemove = da.Feature_GetSMBIOSRemove(intFeatureID);
                DataView dv2 = dsSMBIOSRemove.Tables[0].DefaultView;
                dv2.RowFilter = "bSelected=0";
                SMIBIOSRemovebox1View.DataSource = dv2;
                SMIBIOSRemovebox1View.DataTextField = "Description";
                SMIBIOSRemovebox1View.DataValueField = "Id";
                SMIBIOSRemovebox1View.DataBind();

                dv2.RowFilter = "bSelected=1";
                SMIBIOSRemovebox2View.DataSource = dv2;
                SMIBIOSRemovebox2View.DataTextField = "Description";
                SMIBIOSRemovebox2View.DataValueField = "Id";
                SMIBIOSRemovebox2View.DataBind();
            }
            else
            {
                // Load IRS Data
                if (hdnModuleID.Value != "0")
                {
                    dsSMIBIOSAdd = da.Feature_GetSMBIOSAdd(intFeatureID, Convert.ToInt32(hdnModuleID.Value));
                    DataView dv1 = dsSMIBIOSAdd.Tables[0].DefaultView;
                    dv1.RowFilter = "bSelected=0";
                    SMIBIOSAddbox1View.DataSource = dv1;
                    SMIBIOSAddbox1View.DataTextField = "Description";
                    SMIBIOSAddbox1View.DataValueField = "Id";
                    SMIBIOSAddbox1View.DataBind();
                    dv1.RowFilter = "bSelected=1";
                    SMIBIOSAddbox2View.DataSource = dv1;
                    SMIBIOSAddbox2View.DataTextField = "Description";
                    SMIBIOSAddbox2View.DataValueField = "Id";
                    SMIBIOSAddbox2View.DataBind();

                    dsSMBIOSRemove = da.Feature_GetSMBIOSRemove(intFeatureID, Convert.ToInt32(hdnModuleID.Value));
                    DataView dv2 = dsSMBIOSRemove.Tables[0].DefaultView;
                    dv2.RowFilter = "bSelected=0";
                    SMIBIOSRemovebox1View.DataSource = dv2;
                    SMIBIOSRemovebox1View.DataTextField = "Description";
                    SMIBIOSRemovebox1View.DataValueField = "Id";
                    SMIBIOSRemovebox1View.DataBind();

                    dv2.RowFilter = "bSelected=1";
                    SMIBIOSRemovebox2View.DataSource = dv2;
                    SMIBIOSRemovebox2View.DataTextField = "Description";
                    SMIBIOSRemovebox2View.DataValueField = "Id";
                    SMIBIOSRemovebox2View.DataBind();
                }
            }
        }

        private void LoadODM_HP_Permission()
        {
            FeaturesBLL da = new FeaturesBLL();
            DataSet dsODMPermission = new DataSet();
            DataSet dsHPpermission = new DataSet();

            dsODMPermission = da.Feature_GetPartners(intFeatureID);
            DataView dv1 = dsODMPermission.Tables[0].DefaultView;
            dv1.RowFilter = "bSelected=0";
            ODMPermissionbox1View.DataSource = dv1;
            ODMPermissionbox1View.DataTextField = "PartnerName";
            ODMPermissionbox1View.DataValueField = "PartnerId";
            ODMPermissionbox1View.DataBind();
            dv1.RowFilter = "bSelected=1";
            ODMPermissionbox2View.DataSource = dv1;
            ODMPermissionbox2View.DataTextField = "PartnerName";
            ODMPermissionbox2View.DataValueField = "PartnerId";
            ODMPermissionbox2View.DataBind();

            dsHPpermission = da.Feature_GetTeams(intFeatureID);
            DataView dv2 = dsHPpermission.Tables[0].DefaultView;
            dv2.RowFilter = "bSelected=0";
            HPPermissionbox1View.DataSource = dv2;
            HPPermissionbox1View.DataTextField = "TeamName";
            HPPermissionbox1View.DataValueField = "TeamId";
            HPPermissionbox1View.DataBind();

            dv2.RowFilter = "bSelected=1";
            HPPermissionbox2View.DataSource = dv2;
            HPPermissionbox2View.DataTextField = "TeamName";
            HPPermissionbox2View.DataValueField = "TeamId";
            HPPermissionbox2View.DataBind();
        }


        private void LoadFeatureProperties()
        {
            DataSet ds = new DataSet();

            // Moved these controls outside
            lblRootIDLeft.Visible = false;
            lnkComponentRootID.Visible = false;
            lnkChangeRootLink.Visible = false;
            lnkChangeNewRootLink.Visible = false;
            lblRootIDRight.Visible = false;

            if (intFeatureID > -1)
            {
                FeaturesBLL da = new FeaturesBLL();
                ds = da.GetFeatureProperties(intFeatureID);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    intFeatureClassID = Convert.ToInt32(ds.Tables[0].Rows[0]["FeatureClassID"]);
                    intFeatureCategoryID = Convert.ToInt32(ds.Tables[0].Rows[0]["FeatureCategoryID"]);
                    strFeatureCategoryName = ds.Tables[0].Rows[0]["FeatureCategoryName"].ToString();
                    intNamingStandardID = Convert.ToInt32(ds.Tables[0].Rows[0]["NamingStandardID"]);
                    _deliveryTypeID = Convert.ToInt32(ds.Tables[0].Rows[0]["DeliveryType"]);
                    txtCodeName.Text = Convert.ToString(ds.Tables[0].Rows[0]["CodeName"]);
                    txtRuleID.Text = Convert.ToString(ds.Tables[0].Rows[0]["RuleID"]);
                    rblStatus.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["FeatureStatus"]);
                    hdnStatusID.Value = Convert.ToString(ds.Tables[0].Rows[0]["FeatureStatus"]);
                    txtChinaIdentifier.Text = Convert.ToString(ds.Tables[0].Rows[0]["ChinaGPIdentifier"]);
                    chkRootRequire1.Checked = Convert.ToBoolean(ds.Tables[0].Rows[0]["RequiresRoot"]);
                    txtCreatedBy.Text = ds.Tables[0].Rows[0]["CreatedBy"].ToString();
                    txtUpdatedBy.Text = ds.Tables[0].Rows[0]["UpdatedBy"].ToString();
                    txtNotes.Text = ds.Tables[0].Rows[0]["FeatureNotes"].ToString();
                    intIsUsed = Convert.ToInt32(ds.Tables[0].Rows[0]["IsUsed"]);
                    hdnIsUsed.Value = intIsUsed.ToString();
                    chkComboFeature1.Checked = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsCombo"]);
                    txtTimeCreated.Text = String.Format("{0:MMM d, yyyy h:mm tt}", ds.Tables[0].Rows[0]["TimeCreated"]);
                    txtTimeUpdated.Text = String.Format("{0:MMM d, yyyy h:mm tt}", ds.Tables[0].Rows[0]["TimeUpdated"]);
                    hdnPlatformID.Value = Convert.ToString(ds.Tables[0].Rows[0]["PlatformID"]);
                    hdnOverrideRequest.Value = Convert.ToString(ds.Tables[0].Rows[0]["OverrideRequest"]);
                    txtOverrideRequestReason.InnerText = hdnOverrideRequest.Value != "0" ? Convert.ToString(ds.Tables[0].Rows[0]["OverrideReason"]) : "";
                    intOSID = Convert.ToInt32(ds.Tables[0].Rows[0]["OSID"]);
                    PanelLocationA = Convert.ToInt32(ds.Tables[0].Rows[0]["PanelLocationA"]);
                    PanelLocationB = Convert.ToInt32(ds.Tables[0].Rows[0]["PanelLocationB"]);
                    KeyboardLocationA = Convert.ToInt32(ds.Tables[0].Rows[0]["KeyboardLocationA"]);
                    KeyboardLocationB = Convert.ToInt32(ds.Tables[0].Rows[0]["KeyboardLocationB"]);
                    intFormulaChanged = Convert.ToInt32(ds.Tables[0].Rows[0]["FormulaChanged"]);
                    hdnFormulaChanged.Value = intFormulaChanged.ToString();
                    string allowReferenceValue = ds.Tables[0].Rows[0]["AllowReference"].ToString();
                    bool.TryParse(allowReferenceValue, out _allowReference);

                    strOSName = ds.Tables[0].Rows[0]["OSName"].ToString();
                    if (Convert.ToInt32(ds.Tables[0].Rows[0]["ComponentRootID"]) > 0)
                    {
                        //trComponentRootID.Visible = true;
                        lnkComponentRootID.Text = ds.Tables[0].Rows[0]["ComponentRootID"].ToString();
                        lnkComponentRootID.NavigateUrl = "/Pulsar/Component/Root/" + ds.Tables[0].Rows[0]["ComponentRootID"].ToString();
                        lnkComponentRootID.Target = "_blank";
                        lblRootIDLeft.Visible = true;
                        lnkComponentRootID.Visible = true;
                        lblRootIDRight.Visible = true;
                        //component owner can see the change root link
                        DataSet ds2 = da.feature_ChangeLinkedRootPermission(intFeatureID);
                        if (ds2.Tables[0].Rows.Count > 0)
                        {
                            lnkChangeRootLink.Visible = true;
                            lnkChangeNewRootLink.Visible = true;
                        }

                        string autoLinkage = ds.Tables[0].Rows[0]["AutoLinkage"].ToString();
                        lblLinkageMsg.Text = autoLinkage == "1" ? "Truly Linked" : "Linked";
                    }
                    else if (Convert.ToInt32(ds.Tables[0].Rows[0]["ComponentRootID"]) == 0)
                        lblLinkageMsg.Text = "Link Requested";
                    else if (Convert.ToInt32(ds.Tables[0].Rows[0]["ComponentRootID"]) == -1)
                        lblLinkageMsg.Text = "Link Rejected";
                    else if (Convert.ToInt32(ds.Tables[0].Rows[0]["ComponentRootID"]) == -2)
                        lblLinkageMsg.Text = "Link Pending";
                    //if required root
                    if (Convert.ToBoolean(ds.Tables[0].Rows[0]["RequiresRoot"]))
                        hdnLinkage.Value = "1";
                    //if a combo feature show the list of child features
                    if (Convert.ToBoolean(ds.Tables[0].Rows[0]["IsCombo"]))
                    {
                        hdnLinkage.Value = "2";
                    }
                    if (Convert.ToInt32(ds.Tables[0].Rows[0]["IsChildFeature"]) > 0)
                    {
                        chkComboFeature1.Disabled = true;
                        lnkComboFeatures.Disabled = true;
                    }
                    else
                    {
                        chkComboFeature1.Disabled = false;
                        lnkComboFeatures.Disabled = false;
                    }
                    //if a base unit feature then display the platform name else, hide it
                    if (Convert.ToInt32(ds.Tables[0].Rows[0]["AliasID"]) == 0)
                    {
                        lblPlatformName.Visible = false;
                        txtPlatformName.Visible = false;
                    }
                    else
                    {
                        FeaturesBLL daPlatformName = new FeaturesBLL();
                        txtPlatformName.Text = daPlatformName.GetPlatformName(Convert.ToInt32(hdnPlatformID.Value));
                        hdnAliasID.Value = Convert.ToString(ds.Tables[0].Rows[0]["AliasID"]);
                        chkRootRequire1.Checked = false;
                        chkRootRequire1.Disabled = true;
                    }
                    if (Convert.ToBoolean(ds.Tables[0].Rows[0]["PartnerViewable"]))
                    {
                        chkLimittedView.Checked = true;
                    }
                    if (intNamingStandardID == 1005)
                    {
                        hdnIsByPassingFeature.Value = "1";
                    }
                }

            }
            else
            {
                // Load IRS Data
                if (hdnModuleID.Value != "0")
                {
                    FeaturesBLL da = new FeaturesBLL();
                    ds = da.GetIRSModuleProperties(Convert.ToInt32(hdnModuleID.Value));
                    if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        txtCodeName.Text = Convert.ToString(ds.Tables[0].Rows[0]["CodeName"]);
                        txtRuleID.Text = Convert.ToString(ds.Tables[0].Rows[0]["RuleID"]);
                        txtChinaIdentifier.Text = Convert.ToString(ds.Tables[0].Rows[0]["ChinaGPIdentifier"]);
                        ddlDeliveryType.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["DeliveryType"]);
                    }
                }
                //if a base unit feature then display the platform name else, hide it
                if (Convert.ToInt32(hdnPlatformID.Value) > 0)
                {
                    lblPlatformName.Visible = true;
                    txtPlatformName.Visible = true;
                    FeaturesBLL da = new FeaturesBLL();
                    txtPlatformName.Text = da.GetPlatformName(Convert.ToInt32(hdnPlatformID.Value));
                    chkRootRequire1.Checked = false;
                    chkRootRequire1.Disabled = true;
                }
                else
                {
                    lblPlatformName.Visible = false;
                    txtPlatformName.Visible = false;
                }
                txtTimeCreated.Text = String.Format("{0:MMM d, yyyy h:mm tt}", DateTime.Now);
                txtTimeUpdated.Text = String.Format("{0:MMM d, yyyy h:mm tt}", DateTime.Now);
                txtCreatedBy.Text = UserInfo.GetCurrentUserName();
                txtUpdatedBy.Text = UserInfo.GetCurrentUserName();
                hdnAliasID.Value = "0";
            }
            LoadLinkedCompCategory(intFeatureCategoryID);
            //disable the Root Requires checkbox if the feature category is not linked to a root
            if (hdnLinkedToRoot.Value == "0")
            {
                chkRootRequire1.Checked = false;
                chkRootRequire1.Disabled = true;
            }
            else
            {
                if (!(Convert.ToInt32(hdnPlatformID.Value) > 0))
                {
                    chkRootRequire1.Disabled = false;
                    //remove the logic to check this by default when creating a feature, bug 119906
                    // if (intFeatureID == -1)
                    //      chkRootRequire1.Checked = true;
                }
            }

            // Load Business Segment
            FeaturesBLL das = new FeaturesBLL();
            DataSet bs = new DataSet();

            bs = das.Feature_GetBusinessSegment(intFeatureID);

            DataView bv1 = bs.Tables[0].DefaultView;
            bv1.RowFilter = "Selected=0";
            BSbox1View.DataSource = bv1;
            BSbox1View.DataTextField = "SegmentName";
            BSbox1View.DataValueField = "BusinessSegmentID";
            BSbox1View.DataBind();

            DataView bv2 = bs.Tables[0].DefaultView;
            bv1.RowFilter = "Selected=1";
            BSbox2View.DataSource = bv2;
            BSbox2View.DataTextField = "SegmentName";
            BSbox2View.DataValueField = "BusinessSegmentID";
            BSbox2View.DataBind();
        }

        protected void wdgChildFeatures_InitializeRow(object sender, Infragistics.Web.UI.GridControls.RowEventArgs e)
        {
            string strFeatureID = e.Row.DataKey[0].ToString();
            string sName = e.Row.Items.FindItemByKey("FeatureName").Value.ToString();
            e.Row.Items.FindItemByKey("FeatureName").Text = "<a onclick=\"return OpenFeatureProperties('FeatureProperties.aspx?FeatureID=" + strFeatureID + "');\">" + sName + "</a>";
        }

        [WebMethod]
        public static List<Dictionary<string, string>> GetNamingStandardFields(int namingStandardID, int featureID)
        {
            try
            {
                List<Dictionary<string, string>> lst = new List<Dictionary<string, string>>();
                FeaturesBLL da = new FeaturesBLL();
                DataTable dtNSFields = da.GetNamingStandardFields(namingStandardID, featureID).Tables[0];
                DataRow[] drFeatureFields = dtNSFields.Select("UseInFeature='Yes'", "SortOrder");
                for (int i = 0; i < drFeatureFields.Length; i++)
                {
                    Dictionary<string, string> dcNamingStandardField = new Dictionary<string, string>();
                    dcNamingStandardField.Add("FieldID", drFeatureFields[i]["FieldID"].ToString());
                    dcNamingStandardField.Add("FieldValues", drFeatureFields[i]["FieldName"].ToString()
                        + "|" + drFeatureFields[i]["FieldType"].ToString()
                        + "|" + drFeatureFields[i]["Required"].ToString()
                        + "|" + drFeatureFields[i]["Instructions"].ToString()
                        + "|" + drFeatureFields[i]["FieldValuesWithRowNumber"].ToString()
                        + "|" + drFeatureFields[i]["TextLength"].ToString()
                        + "|" + drFeatureFields[i]["ValueInFeature"].ToString().Replace("|", "cshorc").Replace("~", "cshtld")
                        + "|" + drFeatureFields[i]["LongNameOnly"].ToString()
                        + "|" + drFeatureFields[i]["Active"].ToString()
                        + "|" + drFeatureFields[i]["AllowSpecialChar"].ToString()
                        );
                    lst.Add(dcNamingStandardField);
                }

                return lst;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod]
        public static List<Dictionary<string, string>> GetAllGeneratedNames(int featureID, int namingStandardID, int featureCategoryID)
        {
            try
            {
                List<Dictionary<string, string>> lstGeneratedNames = new List<Dictionary<string, string>>();

                FeaturesBLL da = new FeaturesBLL();
                DataTable dtGeneratedNames = da.GetAllGeneratedNames(featureID, namingStandardID, featureCategoryID).Tables[0];
                for (int i = 0; i < dtGeneratedNames.Rows.Count; i++)
                {
                    Dictionary<string, string> dcFormulaName = new Dictionary<string, string>();
                    dcFormulaName.Add("FormulaNameID", dtGeneratedNames.Rows[i]["FormulaNameID"].ToString());
                    dcFormulaName.Add("FormulaValues", dtGeneratedNames.Rows[i]["FormulaName"].ToString()
                                    + "|" + dtGeneratedNames.Rows[i]["GeneratedName"].ToString().Replace("|", "cshorc")
                                    + "|" + dtGeneratedNames.Rows[i]["UsedCharacters"].ToString()
                                    + "|" + dtGeneratedNames.Rows[i]["MaxLength"].ToString()
                                    + "|" + dtGeneratedNames.Rows[i]["FormulaFields"].ToString()
                                    + "|" + dtGeneratedNames.Rows[i]["DropDownValues"].ToString().Replace("|", "cshorc")
                                    + "|" + Convert.ToInt32(dtGeneratedNames.Rows[i]["IsShortName"]).ToString()
                                    + "|" + dtGeneratedNames.Rows[i]["FormulaConstant"].ToString()
                                    + "|" + dtGeneratedNames.Rows[i]["OverrideName"].ToString());
                    lstGeneratedNames.Add(dcFormulaName);
                }
                return lstGeneratedNames;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static List<Dictionary<string, string>> GetNamingStandard(int featureCategoryID)
        {
            AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
            bool isAlternativeNamingStandardEditor = false;
            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.AlternativeNamingStandard_Edit_Permission))
            {
                isAlternativeNamingStandardEditor = true;
            }
            DataSet dsNamingStandard = da.FeatureCategory_NamingStandardList(featureCategoryID, isAlternativeNamingStandardEditor);
            
            List<Dictionary<string, string>> dicNamingStandard = new List<Dictionary<string, string>>();

            for (int i = 0; i < dsNamingStandard.Tables[1].Rows.Count; i++)
            {
                Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                Dictionary.Add("NamingStandardID", dsNamingStandard.Tables[1].Rows[i]["NamingStandardID"].ToString());
                Dictionary.Add("Name", dsNamingStandard.Tables[1].Rows[i]["Name"].ToString());
                dicNamingStandard.Add(Dictionary);
            }
            return dicNamingStandard;
        }
        [WebMethod]
        public static List<Dictionary<string, string>> GetFeatureCategory(int featureClassID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                DataSet dsFeatureCategory = da.GetFeatureCategoryByFeatureClassID(featureClassID);

                DataView dv = dsFeatureCategory.Tables[0].DefaultView;
                dv.RowFilter = "State='Active' and Name NOT LIKE 'AMO:%'";
                List<Dictionary<string, string>> dicFeatureCategory = new List<Dictionary<string, string>>();

                for (int i = 0; i < dv.Count; i++)
                {
                    Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("FeatureCategoryID", dv[i]["FeatureCategoryID"].ToString());
                    Dictionary.Add("Name", dv[i]["Name"].ToString());
                    dicFeatureCategory.Add(Dictionary);
                }
                return dicFeatureCategory;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
        [WebMethod]
        public static string DeleteFeature(int featureID)
        {
            string strMsg = "";
            try
            {
                if (featureID > -1)
                {
                    FeaturesBLL da = new FeaturesBLL();
                    da.DeleteFeature(featureID);
                }
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strMsg = ex.Message;
            }
            return strMsg;
        }

        [WebMethod(EnableSession = true)]
        public static string SaveFeature(int featureID, int featureClassID, int featureCategoryID, int namingStandardID, int deliveryTypeID,
            string codeName, string ruleID, int status, string chinaIdentifier, int requiresRoot,
            string featureName, string GPGPHweb40_NB, string GPSy40_NB, string PMG100_NB,
            string GPSy200_NB, string PMG250_NB, string GPGPHweb40_DT, string GPSy40_DT,
            string PMG100_DT, string GPSy200_DT, string PMG250_DT,
            string ZSRP32_NB, string ZSRP32_DT, string specControl, string notes, string selectedSMBIOSAddIDs,
            string selectedSMBIOSRemoveIDs, int moduleID, int isCombo, string childFeatureList,
            int platformID, int aliasID, int OSID,
            int viewableToODM, string selectedODMIDs, string selectedHPTeamIDs, int productVersionID, string overrideRequestReason,
            string businessSegmentIDs, string releaseIDs, int panelLocationA, int panelLocationB, int keyboardLocationA, int keyboardLocationB, string featureValue, string ms4, bool allowReference, int? amoBsID, bool isLocalized, bool serialFlag, string previousProduct, string warrantyCode, List<Dictionary<string, string>> footnotes)
        {

            int intReturnedFeatureID = 0;
            try
            {
                if ((FeatureDeliveryType)deliveryTypeID == FeatureDeliveryType.New_AMO && _isFromAVPage)
                {
                    throw new Exception("Cannot create New AMO Feature for AV.");
                }

                FeaturesBLL da = new FeaturesBLL();
                intReturnedFeatureID = da.SaveFeature(featureID, featureClassID, featureCategoryID,
                    namingStandardID, deliveryTypeID, codeName, ruleID, status,
                    chinaIdentifier, requiresRoot, UserInfo.GetCurrentUserName(), featureName.Trim(),
                    GPGPHweb40_NB, GPSy40_NB, PMG100_NB, GPSy200_NB, PMG250_NB,
                    GPGPHweb40_DT, GPSy40_DT, PMG100_DT, GPSy200_DT, PMG250_DT,
                    ZSRP32_NB, ZSRP32_DT, specControl, notes, selectedSMBIOSAddIDs, selectedSMBIOSRemoveIDs,
                    moduleID, isCombo, UserInfo.GetCurrentUserID(), childFeatureList, platformID, ref aliasID, OSID,
                    viewableToODM, selectedODMIDs, selectedHPTeamIDs, featureValue, ms4, allowReference, productVersionID, overrideRequestReason, businessSegmentIDs,
                    releaseIDs, panelLocationA, panelLocationB, keyboardLocationA, keyboardLocationB);

                if (intReturnedFeatureID > 0)
                {
                    string amoNotes = JsonConvert.SerializeObject(footnotes);
                    da.SaveAmoFeatureInfo((FeatureDeliveryType)deliveryTypeID, intReturnedFeatureID, amoBsID, isLocalized, serialFlag, previousProduct, warrantyCode, amoNotes);
                }
                return string.Concat(intReturnedFeatureID.ToString(), ",", aliasID.ToString());


            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static void InsertMessageQueuedEmail(bool isAlternateNSEdit, int featureID, string fieldText)
        {
            try
            {
                string subject = isAlternateNSEdit ? "Feature Naming Override Request Updated" : "Feature Naming Standard field has changed for an Override Feature";

                FeaturesBLL da = new FeaturesBLL();
                da.InsertMessageQueuedEmail(featureID, subject, fieldText, UserInfo.GetCurrentUserID());
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static void UpdateFeatureAndNamingOverrideStatus(int featureID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                da.UpdateFeatureAndNamingOverrideStatus(featureID, UserInfo.GetCurrentUserID());
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static void InsertFeatureOverride(int featureID, int formulaID, string overrideName)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                da.InsertFeatureOverride(featureID, formulaID, overrideName, UserInfo.GetCurrentUserID());
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static void DeleteFeatureOverride(int featureID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                da.DeleteFeatureOverride(featureID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static void InsertFeatureTrulylinkToComponentRoot(int featureID, int componentRootID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                da.InsertFeatureTrulylinkToComponentRoot(featureID, componentRootID);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static void Feature_SaveNamingStandard(int featureID, string NSFields)
        {
            try
            {
                if (featureID > -1)
                {
                    FeaturesBLL da = new FeaturesBLL();
                    da.Feature_NamingStandardModify(featureID, NSFields, UserInfo.GetCurrentUserName());
                }
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static string GetCurrentFeatures(int featureID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                DataSet dsFeatureList = new DataSet();
                dsFeatureList = da.ComboFeature_GetCurrentFeatures(featureID);
                string strFeatureList = "";

                for (int i = 0; i < dsFeatureList.Tables[0].Rows.Count; i++)
                {
                    string FeatureName = dsFeatureList.Tables[0].Rows[i]["FeatureName"].ToString();
                    strFeatureList = strFeatureList == "" ? dsFeatureList.Tables[0].Rows[i]["FeatureID"].ToString() + "|" + FeatureName.Replace(",", " ") + "|" + dsFeatureList.Tables[0].Rows[i]["Quantity"].ToString()
                        : strFeatureList + "," + dsFeatureList.Tables[0].Rows[i]["FeatureID"].ToString() + "|" + FeatureName.Replace(",", " ") + "|" + dsFeatureList.Tables[0].Rows[i]["Quantity"].ToString();
                }

                return strFeatureList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static bool GetComboCheckBox(int featureID)
        {
            bool bIsCombo = false;
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                DataSet dsFeatureList = new DataSet();
                dsFeatureList = da.ComboFeature_GetCurrentFeatures(featureID);
                bIsCombo = Convert.ToBoolean(dsFeatureList.Tables[1].Rows[0]["IsCombo"]);
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
            return bIsCombo;
        }
        [WebMethod]
        public static List<Dictionary<string, string>> GetSelectedFeatureProperties(int intSelectedFeatureID, int IsDesktop)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();

                List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
                Dictionary<string, string> Dictionary = null;

                DataSet ds = da.GetFeatureDetailsForUIRefresh(intSelectedFeatureID, IsDesktop, "");

                int count = ds.Tables[0].Rows.Count;
                for (int i = 0; i < count; i++)
                {
                    Dictionary = new Dictionary<string, string>();

                    Dictionary.Add("FeatureID", ds.Tables[0].Rows[i]["FeatureID"].ToString());
                    Dictionary.Add("FeatureName", ds.Tables[0].Rows[i]["FeatureName"].ToString());
                    Dictionary.Add("FeatureCategoryID", ds.Tables[0].Rows[i]["FeatureCategoryID"].ToString());
                    Dictionary.Add("RequiresRoot", ds.Tables[0].Rows[i]["RequiresRoot"].ToString());
                    Dictionary.Add("ComponentLinkage", ds.Tables[0].Rows[i]["ComponentLinkage"].ToString());
                    Dictionary.Add("ComponentRootID", ds.Tables[0].Rows[i]["ComponentRootID"].ToString());
                    Dictionary.Add("GPGDescription", ds.Tables[0].Rows[i]["GPGDescription"].ToString());
                    Dictionary.Add("MarketingDescriptionPMG", ds.Tables[0].Rows[i]["MarketingDescriptionPMG"].ToString());
                    Dictionary.Add("MarketingDescription", ds.Tables[0].Rows[i]["MarketingDescription"].ToString());
                    Dictionary.Add("FeatureClass", ds.Tables[0].Rows[i]["FeatureClass"].ToString());
                    Dictionary.Add("FeatureCategory", ds.Tables[0].Rows[i]["FeatureCategory"].ToString());
                    Dictionary.Add("NamingStandard", ds.Tables[0].Rows[i]["NamingStandard"].ToString());
                    Dictionary.Add("DeliveryType", ds.Tables[0].Rows[i]["DeliveryType"].ToString());
                    Dictionary.Add("FeatureStatus", ds.Tables[0].Rows[i]["FeatureStatus"].ToString());
                    rows.Add(Dictionary);
                }
                return rows;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        //Malichi - 03/16/16 -Product Backlog Item 17917:Features: If there is Requires a Root, detect if there is an owner for the Component Category
        public static string GetComponentCategoryOwner(int featureClassID, int featureCategoryID, string businessSegmentIDs)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();

                DataSet ds = da.Feature_GetComponentCategoryOwner(featureClassID, featureCategoryID, businessSegmentIDs);

                if (!string.Equals(ds.Tables[0].Rows[0]["result"].ToString(), "PASS", StringComparison.OrdinalIgnoreCase))
                {
                    throw new ArgumentException("No owner has been assigned for the Component Category " + ds.Tables[0].Rows[0]["result"].ToString() + " in Admin. The workflow cannot continue until an owner is assigned. You can save the Feature without Requires a Root and then change later after an owner is assigned to then check the Requires a Root checkbox.");
                }

                return ds.Tables[0].Rows[0]["result"].ToString();
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        // Get Feature descriptions for Shared AV Admin
        [WebMethod]
        public static List<Dictionary<string, string>> SharedAVs_GetFeatureDescriptions(int intSelectedAvDetailID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();

                List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
                Dictionary<string, string> Dictionary = null;

                DataSet ds = da.SharedAVs_GetFeatureDescriptions(intSelectedAvDetailID);

                int count = ds.Tables[0].Rows.Count;
                for (int i = 0; i < count; i++)
                {
                    Dictionary = new Dictionary<string, string>();

                    Dictionary.Add("GPGDescription", ds.Tables[0].Rows[i]["GPGDescription"].ToString());
                    Dictionary.Add("MarketingDescriptionPMG", ds.Tables[0].Rows[i]["MarketingDescriptionPMG"].ToString());
                    Dictionary.Add("MarketingDescription", ds.Tables[0].Rows[i]["MarketingDescription"].ToString());

                    rows.Add(Dictionary);
                }
                return rows;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static void CancelFNORequest(int featureID)
        {
            try
            {
                if (featureID > -1)
                {
                    FeaturesBLL da = new FeaturesBLL();
                    da.CancelFNORequest(featureID);
                }
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static List<PreviousReasonOverrideRequest> GetPreviousReasonforOverrideRequest(int intFeatureID)
        {
            List<PreviousReasonOverrideRequest> reasonList = new List<PreviousReasonOverrideRequest>();

            try
            {
                if (intFeatureID > -1)
                {
                    FeaturesBLL da = new FeaturesBLL();
                    foreach (DataTable table in da.GetPreviousReasonforOverrideRequest(intFeatureID).Tables)
                    {
                        foreach (DataRow row in table.Rows)
                        {
                            object item = row["Reason"];
                            reasonList.Add(new PreviousReasonOverrideRequest { Reason = item.ToString() });
                        }
                    }
                }

                return reasonList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static List<string> GetCurrentProductsForFeature(int FeatureID)
        {
            try
            {
                List<string> listProd = new List<string>();

                DataSet ds = new DataSet();
                FeaturesBLL da = new FeaturesBLL();
                if (FeatureID != 0)
                {
                    ds = da.GetSCMProductsByFeatureId(FeatureID);
                    int rowcount = ds.Tables[0].Rows.Count;
                    for (int i = 0; i < rowcount; i++)
                    {
                        listProd.Add(ds.Tables[0].Rows[i]["ProductName"].ToString());
                    }
                }
                return listProd;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static List<Dictionary<string, string>> ReloadDeliveryType()
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                DataSet dsDeliveryType = da.GetAllDeliveryType();
                List<Dictionary<string, string>> dicDeliveryType = new List<Dictionary<string, string>>();

                for (int i = 0; i < dsDeliveryType.Tables[0].Rows.Count; i++)
                {
                    if (dsDeliveryType.Tables[0].Rows[i]["Name"].ToString() == "AMO")
                    {
                        continue;
                    }

                    Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("DeliveryTypeID", dsDeliveryType.Tables[0].Rows[i]["DeliveryTypeID"].ToString());
                    Dictionary.Add("Name", dsDeliveryType.Tables[0].Rows[i]["Name"].ToString());
                    dicDeliveryType.Add(Dictionary);
                }
                return dicDeliveryType;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }
    }

    public class PreviousReasonOverrideRequest
    {
        public string Reason;
    }
}