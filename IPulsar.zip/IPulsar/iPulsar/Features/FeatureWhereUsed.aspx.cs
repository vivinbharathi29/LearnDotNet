﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;

using Infragistics.Web.UI.GridControls;
using Telerik.Web.UI;
using Infragistics.Documents.Excel;
using System.IO;
using System.Drawing;




namespace iPulsar.Features
{
    public partial class FeatureWhereUsed : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            int intFeatureID = 0;
            if (Request.QueryString["FeatureID"] != null)
                intFeatureID = Convert.ToInt32(Request.QueryString["FeatureID"]);
            hdnFeatureID.Value = intFeatureID.ToString();
            lblDate.Text = DateTime.Now.ToString();
            GetFeatureName(intFeatureID);
            if (UserInfo.GetCurrentUserIsODM() == 1)
                txtISUserODM.Value = "1";

        }
        private void GetFeatureName(int intFeatureID)
        {
            FeaturesBLL da = new FeaturesBLL();
            DataSet ds = new DataSet();
            ds = da.GetFeatureProperties(intFeatureID);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                lblFeatureName.Text = ds.Tables[0].Rows[0]["FeatureName"].ToString();
            lblFeatureName2.Text = ds.Tables[0].Rows[0]["FeatureName"].ToString();
            lblFeatureName1.Text = ds.Tables[0].Rows[0]["FeatureName"].ToString();
            lblFeatureName3.Text = ds.Tables[0].Rows[0]["FeatureName"].ToString();
        }
        [WebMethod]
        public static List<Dictionary<string, string>> GetFeatureWhereUsed_PRL(int intFeatureID)
        {
            try
            {
                List<Dictionary<string, string>> lstPRLNames = new List<Dictionary<string, string>>();

                DataTable dtPRLNames = new DataTable();
                WhereUsed_BLL da = new WhereUsed_BLL();
                dtPRLNames = da.GetFeatureWhereUsed(intFeatureID.ToString(), 1, UserInfo.GetCurrentUserID(), 1).Tables[0];
                for (int i = 0; i < dtPRLNames.Rows.Count; i++)
                {
                    Dictionary<string, string> dcPRL = new Dictionary<string, string>();
                    dcPRL.Add("PRLName", dtPRLNames.Rows[i]["PRLName"].ToString());
                    dcPRL.Add("PRLStatus", dtPRLNames.Rows[i]["PRLStatus"].ToString());
                    dcPRL.Add("PRLPath", dtPRLNames.Rows[i]["Path"].ToString());

                    lstPRLNames.Add(dcPRL);
                }
                return lstPRLNames;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static List<Dictionary<string, string>> GetFeatureWhereUsed_Component(int intFeatureID)
        {
            try
            {
                List<Dictionary<string, string>> lstComponents = new List<Dictionary<string, string>>();

                DataTable dtComponents = new DataTable();
                WhereUsed_BLL da = new WhereUsed_BLL();
                dtComponents = da.GetFeatureWhereUsed(intFeatureID.ToString(), 1, UserInfo.GetCurrentUserID(), 2).Tables[0];
                for (int i = 0; i < dtComponents.Rows.Count; i++)
                {
                    Dictionary<string, string> dcComponents = new Dictionary<string, string>();
                    dcComponents.Add("ProductName", dtComponents.Rows[i]["Product"].ToString());
                    dcComponents.Add("ProductStatus", dtComponents.Rows[i]["ProductStatus"].ToString());
                    dcComponents.Add("PartNumber", dtComponents.Rows[i]["PartNumber"].ToString());
                    dcComponents.Add("ComponentStatus", dtComponents.Rows[i]["ComponentStatus"].ToString());
                    dcComponents.Add("ComponentName", dtComponents.Rows[i]["ComponentName"].ToString());
                    lstComponents.Add(dcComponents);
                }
                return lstComponents;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }



        [WebMethod]
        public static List<Dictionary<string, string>> GetFeatureWhereUsed_SCM(int intFeatureID)
        {
            try
            {
                List<Dictionary<string, string>> lstSCM = new List<Dictionary<string, string>>();

                DataTable dtSCM = new DataTable();
                WhereUsed_BLL da = new WhereUsed_BLL();
                dtSCM = da.GetFeatureWhereUsed(intFeatureID.ToString(), 1, UserInfo.GetCurrentUserID(), 3).Tables[0];
                for (int i = 0; i < dtSCM.Rows.Count; i++)
                {
                    Dictionary<string, string> dcSCM = new Dictionary<string, string>();
                    dcSCM.Add("SCMName", dtSCM.Rows[i]["SCMName"].ToString());
                    dcSCM.Add("MarketingName", dtSCM.Rows[i]["MarketingName"].ToString());
                    dcSCM.Add("AVNo", dtSCM.Rows[i]["AVNo"].ToString());
                    dcSCM.Add("PublishDate", dtSCM.Rows[i]["PublishedDate"].ToString());
                    dcSCM.Add("ProductBrandID", dtSCM.Rows[i]["ProductBrandID"].ToString());
                    dcSCM.Add("Published", dtSCM.Rows[i]["Published"].ToString());
                    dcSCM.Add("ProductVersionID", dtSCM.Rows[i]["ProductVersionID"].ToString());
                    lstSCM.Add(dcSCM);
                }
                return lstSCM;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod]
        public static List<Dictionary<string, string>> GetFeatureWhereUsed_ImageDefinition(int featureID)
        {
            try
            {
                List<Dictionary<string, string>> lstImageDefinition = new List<Dictionary<string, string>>();

                WhereUsed_BLL da = new WhereUsed_BLL();
                DataTable dtImageDefinition = da.GetFeatureWhereUsed(featureID.ToString(), 1, UserInfo.GetCurrentUserID(), 4).Tables[0];
                for (int i = 0; i < dtImageDefinition.Rows.Count; i++)
                {
                    Dictionary<string, string> dcImageDefinition = new Dictionary<string, string>();
                    dcImageDefinition.Add("ProductName", dtImageDefinition.Rows[i]["ProductName"].ToString());
                    dcImageDefinition.Add("ProductDropName", dtImageDefinition.Rows[i]["ProductDropName"].ToString());
                    dcImageDefinition.Add("OS", dtImageDefinition.Rows[i]["OS"].ToString());
                    dcImageDefinition.Add("Release", dtImageDefinition.Rows[i]["Release"].ToString());
                    dcImageDefinition.Add("Status", dtImageDefinition.Rows[i]["Status"].ToString());

                    lstImageDefinition.Add(dcImageDefinition);
                }
                return lstImageDefinition;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {

            string strErrmsg = "";
            try
            {
                Workbook workbook = new Workbook();
                GenerateReport(workbook);
                string filename = "FeatureWhereUsed.xls";
                SendForDownload(workbook, filename);
            }
            catch (Exception ex)
            {
                strErrmsg = ex.Message + " Report Not Generated.";
            }
        }


        private void GenerateReport(Workbook workbook)
        {
            // Create a new workbook with three worksheets
            string sheet1Name = "PRL ";
            string sheet2Name = "Component";
            string sheet3Name = "SCM";
            string sheet4Name = "Image";
            Worksheet worksheet1 = workbook.Worksheets.Add(sheet1Name);
            Worksheet worksheet2 = workbook.Worksheets.Add(sheet2Name);
            Worksheet worksheet3 = workbook.Worksheets.Add(sheet3Name);
            Worksheet worksheet4 = workbook.Worksheets.Add(sheet4Name);

            // Fetch "Where used" data from stored procedure - usp_Feature_GetWhereUsed_Pulsar
            DataSet ds = new DataSet();
            WhereUsed_BLL da = new WhereUsed_BLL();
            int FeatureID = 0;
            if (Request.QueryString["FeatureID"] != null)
                FeatureID = Convert.ToInt32(Request.QueryString["FeatureID"]);
            ds = da.GetFeatureWhereUsed(FeatureID.ToString(), 1, UserInfo.GetCurrentUserID(), 0);



            Infragistics.Documents.Excel.IWorkbookFont normalFont = workbook.Styles.NormalStyle.StyleFormat.Font;
            normalFont.Name = "Calibri";


            //---------------- Worksheet PRL -----------------------------------
            int columncount = ds.Tables[0].Columns.Count;

            worksheet1.Rows[0].Cells[0].Value = "PRL Name";
            worksheet1.Columns[0].Width = 7500;
            worksheet1.Rows[0].Cells[1].Value = "PRL Status";
            worksheet1.Columns[1].Width = 7500;
            worksheet1.Rows[0].Cells[2].Value = "PRL Path";
            worksheet1.Columns[2].Width = 35000;
            //---- formatting header
            for (int i = 0; i < 3; i++)
            {
                worksheet1.Rows[0].Cells[i].CellFormat.Fill = new CellFillPattern(new WorkbookColorInfo(Color.LightGray), null, FillPatternStyle.None);
                worksheet1.Rows[0].Cells[i].CellFormat.BottomBorderColorInfo = Color.Black;
                worksheet1.Rows[0].Cells[i].CellFormat.TopBorderColorInfo = Color.Black;
                worksheet1.Rows[0].Cells[i].CellFormat.LeftBorderColorInfo = Color.Black;
                worksheet1.Rows[0].Cells[i].CellFormat.RightBorderColorInfo = Color.Black;
                worksheet1.Rows[0].Cells[i].CellFormat.BottomBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet1.Rows[0].Cells[i].CellFormat.TopBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet1.Rows[0].Cells[i].CellFormat.LeftBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet1.Rows[0].Cells[i].CellFormat.RightBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet1.Rows[0].Cells[i].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
            }

            int rowcount = ds.Tables[0].Rows.Count;
            for (int i = 0; i < rowcount; i++)
            {
                worksheet1.Rows[i + 1].Cells[0].Value = ds.Tables[0].Rows[i]["PRLName"].ToString();
                worksheet1.Rows[i + 1].Cells[1].Value = ds.Tables[0].Rows[i]["PRLStatus"].ToString();
                worksheet1.Rows[i + 1].Cells[2].Value = ds.Tables[0].Rows[i]["ExcelPath"].ToString();

                worksheet1.Rows[i + 1].Cells[0].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet1.Rows[i + 1].Cells[1].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet1.Rows[i + 1].Cells[2].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
            }

            //---------------- Worksheet Component -----------------------------------
            worksheet2.Rows[0].Cells[0].Value = "Product";
            worksheet2.Rows[0].Cells[1].Value = "Product Status";
            worksheet2.Rows[0].Cells[2].Value = "Component Root Name";
            worksheet2.Rows[0].Cells[3].Value = "Component Part Number";
            worksheet2.Rows[0].Cells[4].Value = "Component Status";
            for (int i = 0; i < 5; i++)
            {
                //---- formatting header
                //worksheet2.Rows[0].Cells[i].CellFormat.FillPatternForegroundColor = Color.LightGray;
                worksheet2.Rows[0].Cells[i].CellFormat.Fill = new CellFillPattern(new WorkbookColorInfo(Color.LightGray), null, FillPatternStyle.None);
                worksheet2.Rows[0].Cells[i].CellFormat.BottomBorderColorInfo = Color.Black;
                worksheet2.Rows[0].Cells[i].CellFormat.TopBorderColorInfo = Color.Black;
                worksheet2.Rows[0].Cells[i].CellFormat.LeftBorderColorInfo = Color.Black;
                worksheet2.Rows[0].Cells[i].CellFormat.RightBorderColorInfo = Color.Black;
                worksheet2.Rows[0].Cells[i].CellFormat.BottomBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet2.Rows[0].Cells[i].CellFormat.TopBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet2.Rows[0].Cells[i].CellFormat.LeftBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet2.Rows[0].Cells[i].CellFormat.RightBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet2.Rows[0].Cells[i].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet2.Columns[i].Width = 8000;

            }
            int rowcount2 = ds.Tables[2].Rows.Count;
            for (int i = 0; i < rowcount2; i++)
            {
                worksheet2.Rows[i + 1].Cells[0].Value = ds.Tables[2].Rows[i]["Product"].ToString();
                worksheet2.Rows[i + 1].Cells[1].Value = ds.Tables[2].Rows[i]["ProductStatus"].ToString();
                worksheet2.Rows[i + 1].Cells[2].Value = ds.Tables[2].Rows[i]["ComponentName"].ToString();
                worksheet2.Rows[i + 1].Cells[3].Value = ds.Tables[2].Rows[i]["PartNumber"].ToString();
                worksheet2.Rows[i + 1].Cells[4].Value = ds.Tables[2].Rows[i]["ComponentStatus"].ToString();

                worksheet2.Rows[i + 1].Cells[0].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet2.Rows[i + 1].Cells[1].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet2.Rows[i + 1].Cells[2].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet2.Rows[i + 1].Cells[3].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet2.Rows[i + 1].Cells[4].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
            }


            //---------------- Worksheet SCM-----------------------------------            
            worksheet3.Rows[0].Cells[0].Value = "SCM Name";
            worksheet3.Columns[0].Width = 25000;
            worksheet3.Rows[0].Cells[1].Value = "Marketing Name";
            worksheet3.Columns[1].Width = 8500;
            worksheet3.Rows[0].Cells[2].Value = "Published Date";
            worksheet3.Columns[2].Width = 7500;
            worksheet3.Rows[0].Cells[3].Value = "AV Number";
            worksheet3.Columns[3].Width = 25000;
            for (int i = 0; i < 4; i++)
            {
                //---- formatting header
                worksheet3.Rows[0].Cells[i].CellFormat.Fill = new CellFillPattern(new WorkbookColorInfo(Color.LightGray), null, FillPatternStyle.None);
                //worksheet3.Rows[0].Cells[i].CellFormat.FillPatternForegroundColor = Color.LightGray;
                worksheet3.Rows[0].Cells[i].CellFormat.BottomBorderColorInfo = Color.Black;
                worksheet3.Rows[0].Cells[i].CellFormat.TopBorderColorInfo = Color.Black;
                worksheet3.Rows[0].Cells[i].CellFormat.LeftBorderColorInfo = Color.Black;
                worksheet3.Rows[0].Cells[i].CellFormat.RightBorderColorInfo = Color.Black;
                worksheet3.Rows[0].Cells[i].CellFormat.BottomBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet3.Rows[0].Cells[i].CellFormat.TopBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet3.Rows[0].Cells[i].CellFormat.LeftBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet3.Rows[0].Cells[i].CellFormat.RightBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet3.Rows[0].Cells[i].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;

            }
            int rowcount1 = ds.Tables[1].Rows.Count;
            for (int i = 0; i < rowcount1; i++)
            {
                worksheet3.Rows[i + 1].Cells[0].Value = ds.Tables[1].Rows[i]["SCMName"].ToString();
                worksheet3.Rows[i + 1].Cells[1].Value = ds.Tables[1].Rows[i]["MarketingName"].ToString();
                worksheet3.Rows[i + 1].Cells[2].Value = ds.Tables[1].Rows[i]["PublishedDate"].ToString();
                worksheet3.Rows[i + 1].Cells[3].Value = ds.Tables[1].Rows[i]["AVNumber"].ToString();

                worksheet3.Rows[i + 1].Cells[0].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet3.Rows[i + 1].Cells[1].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet3.Rows[i + 1].Cells[2].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet3.Rows[i + 1].Cells[3].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
            }

            //---------------- Worksheet PRL -----------------------------------

            worksheet4.Rows[0].Cells[0].Value = "Product Name";
            worksheet4.Columns[0].Width = 7500;
            worksheet4.Rows[0].Cells[1].Value = "ProductDrop Name";
            worksheet4.Columns[1].Width = 7500;
            worksheet4.Rows[0].Cells[2].Value = "OS";
            worksheet4.Columns[2].Width = 20000;
            worksheet4.Rows[0].Cells[3].Value = "Release";
            worksheet4.Columns[3].Width = 6000;
            worksheet4.Rows[0].Cells[4].Value = "Status";
            worksheet4.Columns[4].Width = 6000;
            //---- formatting header
            //worksheet1.Rows[0].Cells[i].CellFormat.FillPatternForegroundColor = Color.LightGray;
            for (int i = 0; i < 5; i++)
            {
                worksheet4.Rows[0].Cells[i].CellFormat.Fill = new CellFillPattern(new WorkbookColorInfo(Color.LightGray), null, FillPatternStyle.None);
                worksheet4.Rows[0].Cells[i].CellFormat.BottomBorderColorInfo = Color.Black;
                worksheet4.Rows[0].Cells[i].CellFormat.TopBorderColorInfo = Color.Black;
                worksheet4.Rows[0].Cells[i].CellFormat.LeftBorderColorInfo = Color.Black;
                worksheet4.Rows[0].Cells[i].CellFormat.RightBorderColorInfo = Color.Black;
                worksheet4.Rows[0].Cells[i].CellFormat.BottomBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet4.Rows[0].Cells[i].CellFormat.TopBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet4.Rows[0].Cells[i].CellFormat.LeftBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet4.Rows[0].Cells[i].CellFormat.RightBorderStyle = Infragistics.Documents.Excel.CellBorderLineStyle.Thin;
                worksheet4.Rows[0].Cells[i].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
            }

            rowcount = ds.Tables[3].Rows.Count;
            for (int i = 0; i < rowcount; i++)
            {
                worksheet4.Rows[i + 1].Cells[0].Value = ds.Tables[3].Rows[i]["ProductName"].ToString();
                worksheet4.Rows[i + 1].Cells[1].Value = ds.Tables[3].Rows[i]["ProductDropName"].ToString();
                worksheet4.Rows[i + 1].Cells[2].Value = ds.Tables[3].Rows[i]["OS"].ToString();
                worksheet4.Rows[i + 1].Cells[3].Value = ds.Tables[3].Rows[i]["Release"].ToString();
                worksheet4.Rows[i + 1].Cells[4].Value = ds.Tables[3].Rows[i]["Status"].ToString();

                worksheet4.Rows[i + 1].Cells[0].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet4.Rows[i + 1].Cells[1].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet4.Rows[i + 1].Cells[2].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet4.Rows[i + 1].Cells[3].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
                worksheet4.Rows[i + 1].Cells[4].CellFormat.WrapText = Infragistics.Documents.Excel.ExcelDefaultableBoolean.True;
            }

        }

        private void SendForDownload(Workbook workbook, string filename)
        {
            try
            {
                Response.Clear();
                Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
                Response.ContentType = "application/octet-stream";
                workbook.Save(Response.OutputStream);
                Response.End();
            }
            catch (System.Threading.ThreadAbortException abrtEx)
            {
                string strErrmsg = abrtEx.Message;
                lblErrorGeneratingReport.Text = strErrmsg;
            }
        }
    }
}