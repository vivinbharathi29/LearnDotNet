﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace iPulsar.Features
{

    public partial class AMOFeatureProperties : System.Web.UI.Page
    {
        private bool AMOUpdate;
        private bool AMOCreate;
        private bool PORUpdate;
        private bool PORView;
        private bool PORCreate;
        private bool CostUpdate;
        private bool CostCreate;
        private bool InUsed;
        private int UpdaterID;
        private string Updater;
        private int CloneFromCTO;
        private bool AMORASEdit;
        private int FeatureID;

        private int defaultProductLineId
        {
            set
            {
                ViewState["defaultProductLineId"] = value;
            }
            get
            {
                if (ViewState["defaultProductLineId"] != null)
                    return (int)ViewState["defaultProductLineId"];
                else
                    return 0;
            }
        }

        private string defaultWarrantyCode
        {
            set
            {

                ViewState["defaultWarrantyCode"] = value;
            }
            get
            {
                if (ViewState["defaultWarrantyCode"] != null)
                    return ViewState["defaultWarrantyCode"].ToString();
                else
                    return "";
            }
        }

        private int IsODM
        {
            set
            {
                ViewState["IsODM"] = value;
            }
            get
            {
                if (ViewState["IsODM"] != null)
                    return (int)ViewState["IsODM"];
                else
                    return 0;
            }
        }

        private string BusinessSegmentIDs
        {
            set
            {

                ViewState["BusinessSegmentIDs"] = value;
            }
            get
            {
                if (ViewState["BusinessSegmentIDs"] != null)
                    return ViewState["BusinessSegmentIDs"].ToString();
                else
                    return "";
            }
        }

        private string PlatformIDs
        {
            set { ViewState["PlatformIDs"] = value; }
            get
            {
                if (ViewState["PlatformIDs"] != null)
                    return ViewState["PlatformIDs"].ToString();
                else
                    return "";
            }
        }

        private Enumeration.PageEditMode Mode
        {
            set
            {
                ViewState["Mode"] = value;
            }
            get
            {
                if (ViewState["Mode"] != null)
                    return (Enumeration.PageEditMode)ViewState["Mode"];
                else
                    return Enumeration.PageEditMode.View;
            }
        }

        protected void Page_PreInit(object sender, EventArgs e)
        {
            const string preferredLayoutCookieName = "PreferredLayout2";
            const string preferredLayoutName = "pulsar2";

            if (Request.Cookies.Get(preferredLayoutCookieName) == null || (string.Equals(Request.Cookies.Get(preferredLayoutCookieName).Value, preferredLayoutName, StringComparison.OrdinalIgnoreCase) && string.Equals(Request.QueryString["Layout"], "pulsar2", StringComparison.OrdinalIgnoreCase)))
            {
                MasterPageFile = "~/MasterPages/MainMasterPageNoTitleBar.master";
                return;
            }

            MasterPageFile = "~/MasterPages/MainMasterPopup.master";
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.QueryString.Get("FeatureID") != null)
                FeatureID = int.Parse(Request.QueryString["FeatureID"].ToString());

            if (Request.QueryString.Get("CloneFromCTO") != null)
                CloneFromCTO = int.Parse(Request.QueryString["CloneFromCTO"].ToString());


            if (Request.QueryString.Get("FromASP") != null)
                hfFromASP.Value = Request.QueryString["FromASP"].ToString();
            else
                hfFromASP.Value = "0";

            hfFeatureID.Value = FeatureID.ToString();

            UserInfo UI = UserInfo.GetCurrentUserInfo();
            UpdaterID = UI.ID;
            Updater = UI.LastName + ", " + UI.FirstName;
            IsODM = UI.IsODM;

            Authenticate.ValidateSession();
            if (!IsPostBack)
            {
                if (Convert.ToInt32(hfFeatureID.Value) == 0)
                {
                    Mode = Enumeration.PageEditMode.Create; //"Create";
                    hdnIsNewFeature.Value = "1";
                    trFeatureID.Visible = false;
                    AMOFeatureBLL obj = new AMOFeatureBLL();
                    DataTable dt = obj.AMOFeatureUserDefault(UI.UserID);
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Select("State = 'Active'"))
                        {
                            BusinessSegmentIDs = row["BusinessSegmentID"].ToString();
                            defaultProductLineId = (int)row["ProductLineID"];
                            defaultWarrantyCode = row["WarrantyCode"].ToString();
                        }
                        dt.Dispose();
                    }
                }
                else
                {
                    Mode = Enumeration.PageEditMode.Edit;
                    trFeatureID.Visible = true;
                    lblFeatureID.Text = FeatureID.ToString();
                }

                if (Request.QueryString["Mode"] != null)
                    Mode = (Enumeration.PageEditMode)Enum.Parse(typeof(Enumeration.PageEditMode), Request.QueryString["Mode"].ToString());

                // check if request is from PRL - bug 22199
                if (Request.QueryString.Get("FromModule") != null)
                    hdnFromPRL.Value = Request.QueryString.Get("FromModule").ToString();
                else
                    hdnFromPRL.Value = "0";

                GetPermission();
                loaddata();
                SetData();
                SetStatus();
                LoadSavedLocalization(this.FeatureID);

                hidAMOFeatureSKUVisibility.Value = Enumeration.Enum_AMOFeature_SKUVisibility.Global.ToString();
                hidddlAPJClientID.Value = ddlAPJ.ClientID;
                hidddlEMEAClientID.Value = ddlEMEA.ClientID;
                hidddlLAClientID.Value = ddlLA.ClientID;
                hidddlNAClientID.Value = ddlNA.ClientID;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "CallDualList", "DualListBind()", true);
            }


        }

        private void GetPermission()
        {  // check permission from resource file instead of enums - task 19440
           //new code start from here
            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.Feature_Edit_Permission.ToString()))
            {
                AMOUpdate = true;
                AMOCreate = true;
                PORUpdate = true;
                PORView = true;
                PORCreate = true;
            }

            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.AMOCost_Edit_Permission.ToString()))
            {
                CostUpdate = true;
                CostCreate = true;
            }

            if (Permission.IsCurrentUserHasPermission(Resources.Permissions.AMORAS_Edit_Permission.ToString()))
            {
                AMORASEdit = true;
            }

            //if user is ODM, view only
            if (UserInfo.GetCurrentUserIsODM() == 1)
            {
                AMOUpdate = false;
                AMOCreate = false;
                CostUpdate = false;
                CostCreate = false;
            }
        }

        private void SetStatus()
        {
            if (IsODM == 1)
            {
                // hide cost fields from ODM user
                rowAMOCost.Visible = false;
                rowAMOPrice.Visible = false;
                rowActualCost.Visible = false;
                por_odm1.Visible = false;
                por_odm2.Visible = false;
                por_odm3.Visible = false;
                por_odm4.Visible = false;
                por_odm5.Visible = false;
                por_odm6.Visible = false;
                por_odm7.Visible = false;
                por_odm8.Visible = false;
                por_odm9.Visible = false;
                por_odm10.Visible = false;
                por_odm11.Visible = false;
                por_odm12.Visible = false;
            }


            Enumeration.Enum_Module_AMO_Status amostatustype;
            if (ddlStatus.SelectedValue != "")
                amostatustype = (Enumeration.Enum_Module_AMO_Status)Enum.Parse(typeof(Enumeration.Enum_Module_AMO_Status), ddlStatus.SelectedValue);
            else
                amostatustype = Enumeration.Enum_Module_AMO_Status.AMO_NEW;

            switch (Mode)
            {
                case Enumeration.PageEditMode.Clone:

                    lblTitle.Text = "Clone AMO Module";
                    if (AMOCreate)
                    {
                        btnSave.Visible = true;  // For Fusion 2 release - true;
                    }

                    if (AMOCreate && PORCreate)
                        TurnPORTab(true, amostatustype.ToString());
                    else
                        TurnPORTab(false, amostatustype.ToString());

                    if ((!AMOCreate || !CostCreate))
                    {
                        txtAMOCost.ReadOnly = true;
                        txtAMOCost.CssClass = "readonly";
                        txtAMOPrice.ReadOnly = true;
                        txtAMOPrice.CssClass = "readonly";
                        txtActualPrice.ReadOnly = true;
                        txtActualPrice.CssClass = "readonly";
                    }
                    else
                    {
                        txtAMOCost.ReadOnly = false;
                        txtAMOCost.CssClass = "";
                        txtAMOPrice.ReadOnly = false;
                        txtAMOPrice.CssClass = "";
                        txtActualPrice.ReadOnly = false;
                        txtActualPrice.CssClass = "";
                    }

                    EnableControl2(true, false);
                    EnableControl1(true, false, amostatustype.ToString());

                    btnClone.Visible = false;
                    btnDelete.Visible = false;

                    lblCreatedby.Text = "";
                    lblLastUpdatedby.Text = "";

                    break;

                case Enumeration.PageEditMode.Create:

                    lblTitle.Text = "Create AMO Feature";

                    if (AMOCreate)
                    {
                        btnSave.Visible = true;  // For Fusion 2 release - true;
                    }

                    if (AMOCreate && PORCreate)
                        TurnPORTab(true, amostatustype.ToString());
                    else
                        TurnPORTab(false, amostatustype.ToString());

                    if ((!AMOCreate || !CostCreate))
                    {
                        txtAMOCost.ReadOnly = true;
                        txtAMOCost.CssClass = "readonly";
                        txtAMOPrice.ReadOnly = true;
                        txtAMOPrice.CssClass = "readonly";
                        txtActualPrice.ReadOnly = true;
                        txtActualPrice.CssClass = "readonly";
                    }
                    else
                    {
                        txtAMOCost.ReadOnly = false;
                        txtAMOCost.CssClass = "";
                        txtAMOPrice.ReadOnly = false;
                        txtAMOPrice.CssClass = "";
                        txtActualPrice.ReadOnly = false;
                        txtActualPrice.CssClass = "";
                    }

                    EnableControl2(true, false);
                    EnableControl1(true, false, amostatustype.ToString());
                    //lbtnWhereUsed.Enabled = false;
                    //lbtnReport.Enabled = false;
                    btnClone.Visible = false;
                    btnDelete.Visible = false;

                    break;
                default:

                    if (AMOUpdate)
                    {
                        lblTitle.Text = "View/Edit AMO Feature";

                        btnSave.Visible = true;  // For Fusion 2 release - true;

                        if (amostatustype == Enumeration.Enum_Module_AMO_Status.AMO_DISABLED)
                        {
                            EnableControl1(false, true, amostatustype.ToString());
                            EnableControl2(false, true);
                        }
                        else
                        {
                            if (Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW == amostatustype ||
                                            Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE == amostatustype)
                            {
                                EnableControl2(false, true);
                                EnableControl1(true, false, amostatustype.ToString());
                            }
                            else
                            {
                                EnableControl2(true, false);
                                EnableControl1(true, false, amostatustype.ToString());
                            }
                        }
                    }
                    else
                    {
                        lblTitle.Text = "View AMO Feature";
                        EnableControl1(false, true, amostatustype.ToString());
                        EnableControl2(false, true);
                        btnClone.Enabled = false;
                        btnDelete.Enabled = false;
                        btnSave.Enabled = false;
                    }

                    if (PORUpdate)
                    {
                        TurnPORTab(true, amostatustype.ToString());
                        btnSave.Visible = true; // For Fusion 2 release - true;
                    }
                    else
                        TurnPORTab(false, amostatustype.ToString());

                    if (!CostUpdate || Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW == amostatustype
                                    || Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE == amostatustype
                                    || amostatustype == Enumeration.Enum_Module_AMO_Status.AMO_DISABLED)
                    {
                        txtAMOCost.ReadOnly = true;
                        txtAMOCost.CssClass = "readonly";
                        txtAMOPrice.ReadOnly = true;
                        txtAMOPrice.CssClass = "readonly";
                        txtActualPrice.ReadOnly = true;
                        txtActualPrice.CssClass = "readonly";
                    }
                    else
                    {
                        txtAMOCost.ReadOnly = false;
                        txtAMOCost.CssClass = "";
                        txtAMOPrice.ReadOnly = false;
                        txtAMOPrice.CssClass = "";
                        txtActualPrice.ReadOnly = false;
                        txtActualPrice.CssClass = "";
                        btnSave.Visible = true;  // For Fusion 2 release - true;
                    }

                    if (AMOCreate)
                        btnClone.Visible = true; // For Fusion 2 release - true;

                    if (AMOCreate)
                        btnClone.Visible = true; // For Fusion 2 release - true

                    if (PORView)
                        TurnPORTab(true, amostatustype.ToString());

                    if (InUsed)
                    {
                        btnDelete.Enabled = false;
                        btnDelete.CssClass = "ui-button ui-widget ui-state-default ui-corner-all";
                    }
                    break;
            }
        }

        private void EnableControl1(bool Enable, bool ReadOnly, string status)
        {
            string css = "";
            if (ReadOnly)
                css = "readonly";

            txtMarketingDescription.ReadOnly = ReadOnly;
            txtMarketingDescription.CssClass = css;

            ddlFeatureClass.Enabled = Enable;
            ddlFeatureCategory.Enabled = Enable;
            RLBAvailBS.Enabled = Enable;
            RLBSelBS.Enabled = Enable;
            ddlProductLine.Enabled = Enable;
            chkHideFromMOL.Enabled = Enable;
            // chkHideFromSCL.Enabled = Enable;
            chkHideFromSCM.Enabled = Enable;
            RLBAvailCompatibility.Enabled = Enable;
            RLBSelCompatibility.Enabled = Enable;

            rblLocalized.Enabled = Enable;

            if (Mode == Enumeration.PageEditMode.Clone || Mode == Enumeration.PageEditMode.Create)
            {
                ddlStatus.Enabled = false;
            }
            else
            {
                ddlStatus.Enabled = true;
            }


        }

        private void EnableControl2(bool Enable, bool ReadOnly)
        {
            string css = "";
            if (ReadOnly)
                css = "readonly";

            txtShortDescription.ReadOnly = ReadOnly;
            txtShortDescription.CssClass = css;

            txtLongDescription.ReadOnly = ReadOnly;
            txtLongDescription.CssClass = css;

            txtCodeName.ReadOnly = ReadOnly;
            txtCodeName.CssClass = css;

            txtHPPartNumber.ReadOnly = ReadOnly;
            txtHPPartNumber.CssClass = css;

            txtReplacement.ReadOnly = ReadOnly;
            txtReplacement.CssClass = css;

            txtAlternative.ReadOnly = ReadOnly;
            txtAlternative.CssClass = css;

            txtNetWeight.ReadOnly = ReadOnly;
            txtNetWeight.CssClass = css;

            txtExportWeight.ReadOnly = ReadOnly;
            txtExportWeight.CssClass = css;

            txtAirPackedWeight.ReadOnly = ReadOnly;
            txtAirPackedCubic.CssClass = css;

            txtAirPackedCubic.ReadOnly = ReadOnly;
            txtAirPackedWeight.CssClass = css;

            txtExportCubic.ReadOnly = ReadOnly;
            txtExportCubic.CssClass = css;

            txtWarrantyCode.ReadOnly = ReadOnly;
            txtWarrantyCode.CssClass = css;

            //sug 9881
            ddlSerialFlag.Enabled = Enable;

            txtCountryofManufacture.ReadOnly = ReadOnly;
            txtCountryofManufacture.CssClass = css;

            EnableLocalize(Enable);
            txtRulesDescription.ReadOnly = ReadOnly;
            txtRulesDescription.CssClass = css;

            txtNotes.ReadOnly = ReadOnly;
            txtNotes.CssClass = css;

            txtOrderInstructions.ReadOnly = ReadOnly;
            txtOrderInstructions.CssClass = css;

            txtReplacementAVDescription.ReadOnly = ReadOnly;
            txtReplacementAVDescription.CssClass = css;

            //dlbPlatforms.Disabled = ReadOnly;

            ddlAPJ.Enabled = Enable;
            ddlEMEA.Enabled = Enable;
            ddlLA.Enabled = Enable;
            ddlNA.Enabled = Enable;
        }

        private void EnableLocalize(bool bEnable)
        {
            wdgLoc.Behaviors.EditingCore.Behaviors.CellEditing.Enabled = bEnable;
        }

        private void TurnPORTab(bool bTurnOn, string status)
        {
            // WebTab1.Tabs.FindTabFromKey("PORDetail").Enabled = bTurnOn;
            //if (!bTurnOn)
            //    hidEnablePOR.Value = "false";
            //else
            //    hidEnablePOR.Value = "";
            if (bTurnOn)
            {
                // WebTab1.Tabs.FindTabFromKey("PORDetail").ToolTip = "";
                hidPORTitle.Value = "";

                if (Enumeration.Enum_Module_AMO_Status.AMO_DISABLED.ToString() == status)
                {
                    txtAMOPartNumber.ReadOnly = true;
                    txtAMOPartNumber.CssClass = "readonly";
                    txtTargetLifetimeVolumeNA.ReadOnly = true;
                    txtTargetLifetimeVolumeNA.CssClass = "readonly";
                    txtTargetLifetimeVolumeLA.ReadOnly = true;
                    txtTargetLifetimeVolumeLA.CssClass = "readonly";
                    txtContra.ReadOnly = true;
                    txtContra.CssClass = "readonly";
                    txtBurden.ReadOnly = true;
                    txtBurden.CssClass = "readonly";
                    txtTargetLifetimeVolumeEMEA.ReadOnly = true;
                    txtTargetLifetimeVolumeEMEA.CssClass = "readonly";
                    txtTargetLifetimeVolumeAPJ.ReadOnly = true;
                    txtTargetLifetimeVolumeAPJ.CssClass = "readonly";
                    txtMarginJustification.ReadOnly = true;
                    txtMarginJustification.CssClass = "readonly";
                    btnPORCalculate.Enabled = false;
                    btnPORClear.Enabled = false;
                }
                else
                {
                    txtAMOPartNumber.ReadOnly = false;
                    txtAMOPartNumber.CssClass = "";
                    txtTargetLifetimeVolumeNA.ReadOnly = false;
                    txtTargetLifetimeVolumeNA.CssClass = "";
                    txtTargetLifetimeVolumeLA.ReadOnly = false;
                    txtTargetLifetimeVolumeLA.CssClass = "";
                    txtContra.ReadOnly = false;
                    txtContra.CssClass = "";
                    txtBurden.ReadOnly = false;
                    txtBurden.CssClass = "";
                    txtTargetLifetimeVolumeEMEA.ReadOnly = false;
                    txtTargetLifetimeVolumeEMEA.CssClass = "";
                    txtTargetLifetimeVolumeAPJ.ReadOnly = false;
                    txtTargetLifetimeVolumeAPJ.CssClass = "";
                    txtMarginJustification.ReadOnly = false;
                    txtMarginJustification.CssClass = "";
                    btnPORCalculate.Enabled = true;
                    btnPORClear.Enabled = true;
                }
            }
            else
            {
                //WebTab1.Tabs.FindTabFromKey("PORDetail").ToolTip = "You neither don't have permission or status is disabled.";
                hidPORTitle.Value = "You neither don't have permission or status is disabled.";
            }
        }

        private int ChangeMask()
        {
            int mask = 0;
            if (Mode == Enumeration.PageEditMode.Edit)
            {
                mask = int.Parse(hfChangeMask.Value);
                if (txtMarketingDescription.Text != hfMarketingDescription.Value.ToString())
                    mask = mask | 32768;
                if (txtShortDescription.Text != hfShortDescription.Value.ToString())
                    mask = mask | 65536;
                if (txtHPPartNumber.Text != hfPartNumber.Value.ToString())
                    mask = mask | 1;
                if (txtAMOCost.ValueDecimal.ToString() != hfAMOCost.Value.ToString())
                    mask = mask | 32;
                if (txtAMOPrice.ValueDecimal.ToString() != hfAMOPrice.Value.ToString())
                    mask = mask | 64;
                if (txtActualPrice.ValueDecimal.ToString() != hfActualCost.Value.ToString())
                    mask = mask | 131072;
                if (txtReplacement.Text != hfReplacement.Value.ToString())
                    mask = mask | 128;
                if (txtAlternative.Text != hfAlternative.Value.ToString())
                    mask = mask | 256;
                if (txtNetWeight.Text != hfNetWeight.Value.ToString())
                    mask = mask | 512;
                if (txtExportWeight.Text != hfNetWeight.Value.ToString())
                    mask = mask | 1024;
                if (txtAirPackedWeight.Text != hfAirPackedWeight.Value.ToString())
                    mask = mask | 2048;
                if (txtAirPackedCubic.Text != hfAirPackedCubic.Value.ToString())
                    mask = mask | 4096;
                if (txtExportCubic.Text != hfExportCubic.Value.ToString())
                    mask = mask | 8192;
                if (txtWarrantyCode.Text != hfWarrantyCode.Value.ToString())
                    mask = mask | 16777216;
                if (txtCountryofManufacture.Text != hfCountryofManufacture.Value.ToString())
                    mask = mask | 67108864;
                if (txtRulesDescription.Text != hfRulesDescription.Value.ToString())
                    mask = mask | 2;
                if (txtOrderInstructions.Text != hfOrderInstructions.Value.ToString())
                    mask = mask | 268435456;
                if (txtReplacementAVDescription.Text != hfReplacementAVDescription.Value.ToString())
                    mask = mask | 536870912;
                if (hfProductLine.Value.ToString() != ddlProductLine.SelectedValue.ToString())
                    mask = mask | 1073741824;
            }

            return mask;
        }

        private void SetData()
        {
            AMOFeatureInfoBLL m = new AMOFeatureInfoBLL();
            AMOFeatureBLL module = new AMOFeatureBLL();

            if (Mode == Enumeration.PageEditMode.Edit || Mode == Enumeration.PageEditMode.Clone || Mode == Enumeration.PageEditMode.View)
            {
                try
                {
                    if (CloneFromCTO == 0)
                        m = module.FeatureView_AMO(FeatureID);
                    else
                        m = module.ModuleView(FeatureID);

                    txtShortDescription.Text = m.ShortDesc;
                    hfShortDescription.Value = m.ShortDesc;
                    txtLongDescription.Text = m.LongDescription;
                    txtCodeName.Text = m.CodeName;
                    Tools.SetSelected_DropdownList(ddlFeatureClass, m.ModuleTypeID);

                    ViewState["CategoryID"] = m.CategoryID;

                    LoadFeatureCategory(m.ModuleTypeID);
                    Tools.SetSelected_DropdownList(ddlFeatureCategory, m.CategoryID);

                    hfDivisionIDs.Value = m.GroupToDivisions;

                    if (Mode == Enumeration.PageEditMode.Clone)
                    {
                        txtMarketingDescription.Text = "Clone of " + m.Description;
                        txtHPPartNumber.Text = "";

                        AMOFeatureBLL mod = new AMOFeatureBLL();

                        loadStatus((int)Enumeration.Enum_Module_AMO_Status.AMO_NEW);
                        hfStatusID.Value = ddlStatus.SelectedValue;

                    }
                    else
                    {
                        txtMarketingDescription.Text = m.Description;
                        txtHPPartNumber.Text = m.PartNumber;
                        hfPartNumber.Value = m.PartNumber;


                        // RLBAvailBS.SelectedValues = m.DivisionIDs;
                        hfStatusID.Value = m.StatusID.ToString();
                        loadStatus(m.StatusID);
                        Tools.SetSelected_DropdownList(ddlStatus, m.StatusID);
                    }

                    hfMarketingDescription.Value = m.Description;

                    txtAMOCost.Text = m.AMOCost;
                    hfAMOCost.Value = m.AMOCost;
                    txtAMOPrice.Text = m.AMOPrice;
                    hfAMOPrice.Value = m.AMOPrice;
                    txtActualPrice.Text = m.ActualCost;
                    hfActualCost.Value = m.ActualCost;
                    txtReplacement.Text = m.Replacement;
                    hfReplacement.Value = m.Replacement;
                    txtAlternative.Text = m.Alternative;
                    hfAlternative.Value = m.Alternative;
                    txtNetWeight.Value = m.NetWeight;
                    hfNetWeight.Value = m.NetWeight.ToString();
                    txtExportWeight.Value = m.ExportWeight;
                    hfExportWeight.Value = m.ExportWeight.ToString();
                    txtAirPackedWeight.Value = m.AirPackedWeight;
                    hfAirPackedWeight.Value = m.AirPackedWeight.ToString();
                    txtAirPackedCubic.Value = m.AirPackedCubic;
                    hfAirPackedCubic.Value = m.AirPackedCubic.ToString();
                    txtExportCubic.Value = m.ExportCubic;
                    hfExportCubic.Value = m.ExportCubic.ToString();
                    txtWarrantyCode.Text = m.WarrantyCode.Trim();
                    hfWarrantyCode.Value = m.WarrantyCode.Trim();
                    Tools.SetSelected_DropdownList(ddlSerialFlag, m.SerialFlag);
                    txtCountryofManufacture.Text = m.CountryofManufacture.Trim();
                    hfCountryofManufacture.Value = m.CountryofManufacture.Trim();
                    Tools.SetSelected_RadioButtonList(rblLocalized, m.Localized);
                    InUsed = m.InUsed;
                    txtRulesDescription.Text = m.RuleDescription;
                    hfRulesDescription.Value = m.RuleDescription;
                    txtNotes.Text = m.Notes;
                    txtOrderInstructions.Text = m.OrderInstruction;
                    hfOrderInstructions.Value = m.OrderInstruction;
                    txtReplacementAVDescription.Text = m.ReplacementAVDescription;
                    hfReplacementAVDescription.Value = m.ReplacementAVDescription;
                    if (m.MOLHide == 1)
                        chkHideFromMOL.Checked = true;
                    if (m.SCMHide == 1)
                        chkHideFromSCM.Checked = true;
                    lblCreatedby.Text = m.Creator + " " + m.TimeCreated;
                    lblLastUpdatedby.Text = m.Updater + " " + m.TimeChanged;

                    Tools.SetSelected_DropdownList(ddlAPJ, m.Visibility_AP_ID);
                    Tools.SetSelected_DropdownList(ddlEMEA, m.Visibility_EM_ID);
                    Tools.SetSelected_DropdownList(ddlLA, m.Visibility_LA_ID);
                    Tools.SetSelected_DropdownList(ddlNA, m.Visibility_NA_ID);
                    Tools.SetSelected_DropdownList(ddlProductLine, m.ProductLineID);

                    PlatformIDs = m.platformIDs;

                    txtAMOPartNumber.Text = m.AMOPN_Replacement;
                    txtTargetLifetimeVolumeAPJ.Text = m.TargetVolumn_AP;
                    txtTargetLifetimeVolumeEMEA.Text = m.TargetVolumn_EM;
                    txtTargetLifetimeVolumeLA.Text = m.TargetVolumn_LA;
                    txtTargetLifetimeVolumeNA.Text = m.TargetVolumn_NA;

                    txtBurden.Text = m.Burden;
                    txtContra.Text = m.Contra;
                    txtMarginJustification.Text = m.VolumnMargin_Justification;

                    txtCommenttoRas.Text = m.InfoComment;
                    txtCommentfromRas.Text = m.RasComment;
                    chkRasComplete.Checked = m.RAS;
                    chkGPSyComplete.Checked = m.GPSy;

                    hfChangeMask.Value = m.ChangeMask.ToString();
                    hfRuleID.Value = m.RuleID;
                }
                catch (Exception ex)
                {
                    lblError.Visible = true;
                    lblError.Text = ex.Message.ToString();
                }
            }
            else if (Mode == Enumeration.PageEditMode.Create)
            {
                hfChangeMask.Value = "0";
                ViewState["PlatformIDs"] = "";
                loadStatus((int)Enumeration.Enum_Module_AMO_Status.AMO_NEW);
                hfStatusID.Value = ddlStatus.SelectedValue;
                Tools.SetSelected_RadioButtonList(rblLocalized, 0);
                txtWarrantyCode.Text = defaultWarrantyCode;
            }

            DataTable tbStatus = new DataTable();
            tbStatus = module.GetStatusByType(23);
            DataRow[] foundRows;

            // Use the Select method to find all rows matching the filter.
            foundRows = tbStatus.Select("StatusID = " + hfStatusID.Value + " and Constant in ('" + Enumeration.Enum_Module_AMO_Status.AMO_IN_PROCESS.ToString() + "','" +
                Enumeration.Enum_Module_AMO_Status.AMO_NEW.ToString() + "','" + Enumeration.Enum_Module_AMO_Status.AMO_REJECT.ToString() + "')");

            if (foundRows.Length == 0 || !AMORASEdit)
            {
                txtCommenttoRas.ReadOnly = true;
                txtCommenttoRas.CssClass = "readonly";
                txtCommenttoRas.Attributes["onfocus"] = "this.blur()";
            }

            foundRows = tbStatus.Select("StatusID = " + hfStatusID.Value + " and Constant in ('" + Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW.ToString() + "','" +
                Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE.ToString() + "')");

            if (foundRows.Length == 0 || !AMORASEdit)
            {
                txtCommentfromRas.ReadOnly = true;
                txtCommentfromRas.CssClass = "readonly";
                txtCommentfromRas.Attributes["onfocus"] = "this.blur()";
                chkRasComplete.Enabled = false;
                chkGPSyComplete.Enabled = false;
            }
        }

        private void LoadProductLine()
        {
            AdminSCMCategoryBLL da = new AdminSCMCategoryBLL();
            DataSet dsProductLineList = new DataSet();
            dsProductLineList = da.GetProductLines();
            ddlProductLine.DataSource = dsProductLineList;
            ddlProductLine.DataTextField = "ProductLineName";
            ddlProductLine.DataValueField = "ProductLineID";
            ddlProductLine.DataBind();

            ddlProductLine.Items.Insert(0, new ListItem("Select a Product Line", "0"));

            if (defaultProductLineId > 0)
                ddlProductLine.Items.FindByValue(defaultProductLineId.ToString()).Selected = true;
        }


        private void loaddata()
        {
            loadProducts(FeatureID);
            loadPlatforms(FeatureID);
            //loadUnassociatedPlatforms(FeatureID);
            LoadFeatureClass();
            loadDivision(FeatureID);
            loadCompatibility(FeatureID);
            LoadProductLine();


            string sname, Id;
            foreach (string item in Enum.GetNames(typeof(Enumeration.Enum_AMOFeature_SKUVisibility)))
            {
                sname = item.ToString();
                Id = ((int)Enum.Parse(typeof(Enumeration.Enum_AMOFeature_SKUVisibility), item)).ToString();

                ddlAPJ.Items.Add(new ListItem(sname, Id));
                ddlEMEA.Items.Add(new ListItem(sname, Id));
                ddlLA.Items.Add(new ListItem(sname, Id));
                ddlNA.Items.Add(new ListItem(sname, Id));
            }
        }

        private void loadDivision(int intFeatureID)
        {
            AMOFeatureBLL adBll = new AMOFeatureBLL();
            DataSet ds = new DataSet();
            ds = adBll.AMOFeature_GetBusinessSegments(intFeatureID);
            DataView dv = ds.Tables[0].DefaultView;

            if (string.IsNullOrEmpty(BusinessSegmentIDs))
            {
                dv.RowFilter = "bSelected=0";
                RLBAvailBS.DataSource = dv;
                RLBAvailBS.DataTextField = "SegmentName";
                RLBAvailBS.DataValueField = "BusinessSegmentID";
                RLBAvailBS.DataBind();

                dv.RowFilter = "bSelected=1";
                RLBSelBS.DataSource = dv;
                RLBSelBS.DataTextField = "SegmentName";
                RLBSelBS.DataValueField = "BusinessSegmentID";
                RLBSelBS.DataBind();

                RLBAvailCompatibility.DataSource = dv;
                RLBAvailCompatibility.DataTextField = "SegmentName";
                RLBAvailCompatibility.DataValueField = "BusinessSegmentID";
                RLBAvailCompatibility.DataBind();
            }
            else
            {
                dv.RowFilter = "bSelected=0 and BusinessSegmentID not in (" + BusinessSegmentIDs + ")";
                RLBAvailBS.DataSource = dv;
                RLBAvailBS.DataTextField = "SegmentName";
                RLBAvailBS.DataValueField = "BusinessSegmentID";
                RLBAvailBS.DataBind();

                dv.RowFilter = "bSelected=0 and BusinessSegmentID in (" + BusinessSegmentIDs + ")";
                RLBSelBS.DataSource = dv;
                RLBSelBS.DataTextField = "SegmentName";
                RLBSelBS.DataValueField = "BusinessSegmentID";
                RLBSelBS.DataBind();

                RLBAvailCompatibility.DataSource = dv;
                RLBAvailCompatibility.DataTextField = "SegmentName";
                RLBAvailCompatibility.DataValueField = "BusinessSegmentID";
                RLBAvailCompatibility.DataBind();
            }
        }
        private void loadProducts(int intFeatureID)
        {
            AMOFeatureBLL adBll = new AMOFeatureBLL();
            DataSet ds = new DataSet();
            ds = adBll.AMOFeature_GetProducts(intFeatureID);
            DataView dv = ds.Tables[0].DefaultView;

            dv.RowFilter = "Selected=0";
            RLBAvailProducts.DataSource = dv;
            RLBAvailProducts.DataTextField = "ProductName";
            RLBAvailProducts.DataValueField = "ProductVersionID";
            RLBAvailProducts.DataBind();

            dv.RowFilter = "Selected=1";
            RLBSelProducts.DataSource = dv;
            RLBSelProducts.DataTextField = "ProductName";
            RLBSelProducts.DataValueField = "ProductVersionID";
            RLBSelProducts.DataBind();
        }

        private void loadPlatforms(int intFeatureID)
        {
            AMOFeatureBLL adBll = new AMOFeatureBLL();
            DataSet ds = new DataSet();
            ds = adBll.AMOFeature_GetPlatforms(intFeatureID);
            DataView dv = ds.Tables[0].DefaultView;

            dv.RowFilter = "Selected=0";
            RLBavailPlatforms.DataSource = dv;
            RLBavailPlatforms.DataTextField = "Description";
            RLBavailPlatforms.DataValueField = "PlatformID";
            RLBavailPlatforms.DataBind();

            dv.RowFilter = "Selected=1";
            RLBSelPlatforms.DataSource = dv;
            RLBSelPlatforms.DataTextField = "Description";
            RLBSelPlatforms.DataValueField = "PlatformID";
            RLBSelPlatforms.DataBind();

        }


        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> loadProductPlatforms(string SelectedIds, int AMOFeatureID)
        {
            try
            {
                List<Dictionary<string, object>> dicList = new List<Dictionary<string, object>>();
                Dictionary<string, object> dic = null;
                AMOFeatureBLL adBll = new AMOFeatureBLL();
                DataSet dsList = new DataSet();
                dsList = adBll.AMOFeature_GetPlatforms(SelectedIds, AMOFeatureID);
                for (int i = 0; i < dsList.Tables[0].Rows.Count; i++)
                {
                    dic = new Dictionary<string, object>();
                    dic.Add("PlatformID", dsList.Tables[0].Rows[i]["PlatformID"].ToString());
                    dic.Add("Description", dsList.Tables[0].Rows[i]["Description"].ToString());
                    dic.Add("Active", dsList.Tables[0].Rows[i]["Active"].ToString());
                    dicList.Add(dic);
                }
                return dicList;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        private void loadCompatibility(int intFeatureID)
        {
            DataSet ds;

            AMOFeatureBLL adBll = new AMOFeatureBLL();
            ds = adBll.AMOFeature_GetCompatibility(intFeatureID);
            DataView dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "bSelected=0";
            RLBAvailCompatibility.DataSource = dv;
            RLBAvailCompatibility.DataTextField = "SegmentName";
            RLBAvailCompatibility.DataValueField = "BusinessSegmentID";
            RLBAvailCompatibility.DataBind();
            dv.RowFilter = "bSelected=1";
            RLBSelCompatibility.DataSource = dv;
            RLBSelCompatibility.DataTextField = "SegmentName";
            RLBSelCompatibility.DataValueField = "BusinessSegmentID";
            RLBSelCompatibility.DataBind();
        }

        private void LoadFeatureClass()
        {
            AdminFeatureCategoryBLL da = new AdminFeatureCategoryBLL();
            DataSet dsFeatureClass = new DataSet();
            dsFeatureClass = da.GetAllFeatureClass();
            DataView dvFeatureClass = dsFeatureClass.Tables[0].DefaultView;

            ddlFeatureClass.DataSource = dvFeatureClass;
            ddlFeatureClass.DataTextField = "Name";
            ddlFeatureClass.DataValueField = "FeatureClassID";
            ddlFeatureClass.DataBind();

            ddlFeatureClass.Items.Insert(0, new ListItem("Select a Feature Class", "0"));
        }

        private void LoadFeatureCategory(int intFeatureClassID)
        {
            FeaturesBLL da = new FeaturesBLL();
            DataSet dsFeatureCategory = new DataSet();
            DataTable finalTable = new DataTable();

            dsFeatureCategory = da.GetFeatureCategoryByFeatureClassID(intFeatureClassID);

            DataTable table = dsFeatureCategory.Tables[0];
            DataRow[] result = table.Select("State='Active'");
            finalTable = result.CopyToDataTable();

            ddlFeatureCategory.DataSource = finalTable;
            ddlFeatureCategory.DataTextField = "Name";
            ddlFeatureCategory.DataValueField = "FeatureCategoryID";
            ddlFeatureCategory.DataBind();
        }

        private void validateBS()
        {
            string strBS = "";
            string strBSes = "";
            foreach (RadListBoxItem item in RLBSelBS.Items)
            {
                strBS = item.Value;
                if (strBSes == "")
                    strBSes = strBS;
                else
                    strBSes += "," + strBS;
            }

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string sError = "";
            lblError.Visible = false;

            //enable module
            if ((int)Enumeration.Enum_Module_AMO_Status.AMO_REENABLED == int.Parse(ddlStatus.SelectedValue) && (int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED == int.Parse(hfStatusID.Value))
            {
                Enable();
                return;
            }
            else  //save and set status
            {
                AMOFeatureInfoBLL MDetail = new AMOFeatureInfoBLL();

                if (Mode == Enumeration.PageEditMode.Clone || Mode == Enumeration.PageEditMode.Create)
                {
                    MDetail.DataKey = 0;
                    CloneFromCTO = 0;
                }
                else
                {
                    MDetail.DataKey = FeatureID;
                }
                //get Feature deatail tab field values
                MDetail.Description = txtMarketingDescription.Text;
                MDetail.ShortDesc = txtShortDescription.Text;
                MDetail.LongDescription = txtLongDescription.Text;
                MDetail.CodeName = txtCodeName.Text;
                MDetail.ModuleTypeID = int.Parse(ddlFeatureClass.SelectedValue);
                //  MDetail.CategoryID = int.Parse(ddlFeatureCategory.SelectedValue);
                MDetail.CategoryID = int.Parse(txtSelectedFeatureCategoryID.Value);

                string strBS = "";
                string strBSes = "";
                foreach (RadListBoxItem item in RLBSelBS.Items)
                {
                    strBS = item.Value;
                    if (strBSes == "")
                        strBSes = strBS;
                    else
                        strBSes += "," + strBS;
                }
                MDetail.DivisionIDs = strBSes;
                MDetail.StatusID = int.Parse(ddlStatus.SelectedValue);
                MDetail.PartNumber = txtHPPartNumber.Text;
                MDetail.AMOCost = txtAMOCost.ValueDecimal.ToString();
                MDetail.AMOPrice = txtAMOPrice.ValueDecimal.ToString();
                MDetail.ActualCost = txtActualPrice.ValueDecimal.ToString();
                MDetail.Replacement = txtReplacement.Text;
                MDetail.Alternative = txtAlternative.Text;
                if (txtNetWeight.Value != null)
                    MDetail.NetWeight = (int)txtNetWeight.Value;
                if (txtExportWeight.Value != null)
                    MDetail.ExportWeight = (int)txtExportWeight.Value;
                if (txtAirPackedWeight.Value != null)
                    MDetail.AirPackedWeight = (int)txtAirPackedWeight.Value;
                if (txtAirPackedCubic.Value != null)
                    MDetail.AirPackedCubic = (int)txtAirPackedCubic.Value;
                if (txtExportCubic.Value != null)
                    MDetail.ExportCubic = (int)txtExportCubic.Value;
                MDetail.SerialFlag = int.Parse(ddlSerialFlag.SelectedValue);
                MDetail.WarrantyCode = txtWarrantyCode.Text;
                MDetail.CountryofManufacture = txtCountryofManufacture.Text;
                MDetail.Localized = int.Parse(rblLocalized.SelectedValue);
                MDetail.RuleDescription = txtRulesDescription.Text;
                MDetail.Notes = txtNotes.Text;
                MDetail.OrderInstruction = txtOrderInstructions.Text;
                MDetail.ReplacementAVDescription = txtReplacementAVDescription.Text;
                MDetail.ProductLineID = int.Parse(ddlProductLine.SelectedValue);
                if (chkHideFromMOL.Checked) MDetail.MOLHide = 1; else MDetail.MOLHide = 0;
                if (chkHideFromSCM.Checked) MDetail.SCMHide = 1; else MDetail.SCMHide = 0;
                MDetail.UpdaterID = UserInfo.GetCurrentUserID();
                MDetail.Updater = UserInfo.GetCurrentUserName();

                MDetail.InfoComment = txtCommenttoRas.Text;
                MDetail.RasComment = txtCommentfromRas.Text;
                MDetail.RAS = chkRasComplete.Checked;
                MDetail.GPSy = chkGPSyComplete.Checked;

                //get SKU visibility tab field values
                string strCompatibility = "";
                string strCompatibilityes = "";
                foreach (RadListBoxItem item in RLBSelCompatibility.Items)
                {
                    strCompatibility = item.Value;
                    if (strCompatibilityes == "")
                        strCompatibilityes = strCompatibility;
                    else
                        strCompatibilityes += "," + strCompatibility;
                }
                MDetail.ComparatibilityDivisions = strCompatibilityes;
                MDetail.Visibility_NA_ID = int.Parse(ddlNA.SelectedValue);
                MDetail.Visibility_EM_ID = int.Parse(ddlEMEA.SelectedValue);
                MDetail.Visibility_AP_ID = int.Parse(ddlAPJ.SelectedValue);
                MDetail.Visibility_LA_ID = int.Parse(ddlLA.SelectedValue);

                //get Platform tab field values
                string strPlatform = "";
                string strPlatforms = "";
                foreach (RadListBoxItem item in RLBSelPlatforms.Items)
                {
                    strPlatform = item.Value;
                    if (strPlatforms == "")
                        strPlatforms = strPlatform;
                    else
                        strPlatforms += "," + strPlatform;
                }
                MDetail.platformIDs = strPlatforms;

                //get Product tab field values
                string strProduct = "";
                string strProducts = "";
                foreach (RadListBoxItem item in RLBSelProducts.Items)
                {
                    strProduct = item.Value;
                    if (strProducts == "")
                        strProducts = strProduct;
                    else
                        strProducts += "," + strProduct;
                }
                MDetail.productIDs = strProducts;

                //get POR detail tab field values
                MDetail.ChangeMask = ChangeMask();
                MDetail.AMOPN_Replacement = txtAMOPartNumber.Text;
                MDetail.TargetVolumn_NA = txtTargetLifetimeVolumeNA.Text;
                MDetail.TargetVolumn_LA = txtTargetLifetimeVolumeLA.Text;
                MDetail.TargetVolumn_EM = txtTargetLifetimeVolumeEMEA.Text;
                MDetail.TargetVolumn_AP = txtTargetLifetimeVolumeAPJ.Text;
                MDetail.Burden = txtBurden.Text.Replace("%", "").Trim();
                MDetail.Contra = txtContra.Text.Replace("%", "").Trim();
                MDetail.VolumnMargin_Justification = txtMarginJustification.Text;

                MDetail.RuleID = hfRuleID.Value;

                try
                {
                    AMOFeatureBLL m = new AMOFeatureBLL();
                    FeatureID = m.UpdateFeature_AMO(MDetail);
                    //comment out localization part for now, will uncomment whe the sp is ready
                    if (Mode == Enumeration.PageEditMode.Edit || Mode == Enumeration.PageEditMode.View)
                    {
                        m.AMOFeature_UpdateLocalization(FeatureID, CreateDataTable(wdgLoc), UserInfo.GetCurrentUserName(), 0, UserInfo.GetCurrentUserID());
                        //Update Module in IRS when Feature is Updated.
                        m.UpdateAMOModule(MDetail);
                        m.AMOModule_UpdateLocalization(FeatureID, CreateDataTable(wdgLoc), UserInfo.GetCurrentUserName(), 0, UserInfo.GetCurrentUserID());
                    }
                    else if (Mode == Enumeration.PageEditMode.Clone || Mode == Enumeration.PageEditMode.Create)
                    {
                        m.AMOFeature_UpdateLocalization(FeatureID, CreateDataTable(wdgLoc), UserInfo.GetCurrentUserName(), 1, UserInfo.GetCurrentUserID());
                        Mode = Enumeration.PageEditMode.Edit;
                        lblTitle.Text = "View/Edit AMO Feature";
                    }

                    hfFeatureID.Value = Convert.ToString(FeatureID);

                    hfRefreshTree.Value = "1";
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "ClosePopup", "CloseFeaturePropertiesPopUpOnSave(true," + txtSelectedFeatureCategoryID.Value + ")", true);

                }
                catch (Exception ex)
                {
                    hidSelectedTab.Value = "0";
                    sError = ex.Message;
                }
            }

            if (sError != "")
            {
                lblError.Visible = true;
                lblError.Text = sError;
                lblError.ForeColor = System.Drawing.Color.Red;
            }

        }


        private DataTable CreateDataTable(Infragistics.Web.UI.GridControls.WebDataGrid dataGridName)
        {
            DataTable table = new DataTable();

            DataColumn colKey = new DataColumn(dataGridName.DataKeyFields.ToString());
            table.Columns.Add(colKey);

            // Add columns to the DataTable
            for (int c = 0; c < dataGridName.Columns.Count; c++)
            {
                DataColumn col = new DataColumn(dataGridName.Columns[c].Key);
                table.Columns.Add(col);
            }

            // Iterate the datagrid to populate the table
            for (int i = 0; i < dataGridName.Rows.Count; i++)
            {
                DataRow dr = table.NewRow();
                dr[0] = (int)dataGridName.Rows[i].DataKey[0];
                for (int j = 0; j < dataGridName.Columns.Count; j++)
                {
                    if (j < 9)
                    {
                        if (dataGridName.Rows[i].Items[j].Value != null)
                            dr[j + 1] = dataGridName.Rows[i].Items[j].Value.ToString();
                        else
                            dr[j + 1] = null;
                    }
                    else
                    {
                        CheckBox chk = new CheckBox();
                        chk = (CheckBox)dataGridName.Rows[i].Items[j].FindControl("chk" + dataGridName.Columns[j].Key);
                        dr[j + 1] = chk.Checked;
                    }
                }

                table.Rows.Add(dr);
            }


            return table;
        }

        private void LoadFeatureCategory(Enum_CategoryInfoType Type)
        {
            Catergory ModuleCategory = new Catergory();
            ddlFeatureCategory.Items.Clear();
            ddlFeatureCategory.DataSource = ModuleCategory.GetCategoryDataSet(Type);
            ddlFeatureCategory.DataTextField = "FullCatDescription";
            ddlFeatureCategory.DataValueField = "CategoryID";
            ddlFeatureCategory.DataBind();

            if (ViewState["CategoryID"] != null)
                Tools.SetSelected_DropdownList(ddlFeatureCategory, int.Parse(ViewState["CategoryID"].ToString()));
        }

        protected void btnDisable_Click(object sender, EventArgs e)
        {
            AMOFeatureBLL m = new AMOFeatureBLL();
            m.AMOFeature_UpdateStatus(FeatureID, (int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED, UserInfo.GetCurrentUserName(), 0);
            loaddata();
            SetData();
            GetPermission();
            SetStatus();
            btnLoadLoc.Enabled = true;
            hidSelectedTab.Value = "0";
        }

        protected void Enable()
        {
            try
            {
                lblError.Visible = false;
                AMOFeatureBLL m = new AMOFeatureBLL();
                m.AMOFeature_UpdateStatus(FeatureID, (int)Enumeration.Enum_Module_AMO_Status.AMO_REENABLED, UserInfo.GetCurrentUserName(), 0);
                loadStatus((int)Enumeration.Enum_Module_AMO_Status.AMO_REENABLED);
                GetPermission();
                SetData();
                SetStatus();
                hidSelectedTab.Value = "0";
                FeatureReEnabled.Value = "1";
            }
            catch (Exception ex)
            {
                //  WebTab1.SelectedIndex = 0;
                hidSelectedTab.Value = "0";
                lblError.Visible = true;
                lblError.Text = ex.Message.ToString();
                FeatureReEnabled.Value = "";
            }
        }

        protected void btnClone_Click(object sender, EventArgs e)
        {
            Authenticate.ValidateSession(false);
            try
            {
                lblError.Visible = false;
                Mode = Enumeration.PageEditMode.Clone;

                SetData();

                GetPermission();

                txtMarketingDescription.Text = txtMarketingDescription.Text;

                txtHPPartNumber.Text = "";
                SetStatus();
                //  WebTab1.SelectedIndex = 0;
                hidSelectedTab.Value = "0";
            }
            catch (Exception ex)
            {
                // WebTab1.SelectedIndex = 0;
                hidSelectedTab.Value = "0";
                lblError.Visible = true;
                lblError.Text = ex.Message.ToString();
            }
        }

        protected string getstatus(Enumeration.Enum_Module_AMO_Status status)
        {
            string sStatus = "";
            switch (status)
            {
                case Enumeration.Enum_Module_AMO_Status.AMO_REENABLED:
                    sStatus = "Re-enabled";
                    break;

                case Enumeration.Enum_Module_AMO_Status.AMO_REJECT:
                    sStatus = "Reject";
                    break;

                case Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE:
                    sStatus = "RAS Update";
                    break;

                case Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW:
                    sStatus = "RAS Review";
                    break;

                case Enumeration.Enum_Module_AMO_Status.AMO_OBSOLETE:
                    sStatus = "Obsolete";
                    break;

                case Enumeration.Enum_Module_AMO_Status.AMO_NEW:
                    sStatus = "New";
                    break;

                case Enumeration.Enum_Module_AMO_Status.AMO_IN_PROCESS:
                    sStatus = "In Process";
                    break;

                case Enumeration.Enum_Module_AMO_Status.AMO_DISABLED:
                    sStatus = "Disabled";
                    break;

                case Enumeration.Enum_Module_AMO_Status.AMO_COMPLETE:
                    sStatus = "Complete";
                    break;
            }

            return sStatus;

        }

        private void loadStatus(int statusid)
        {
            ddlStatus.Items.Clear();
            switch (statusid)
            {
                case (int)Enumeration.Enum_Module_AMO_Status.AMO_REENABLED:
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_REENABLED), statusid.ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE), ((int)Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_DISABLED), ((int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED).ToString()));
                    break;
                case (int)Enumeration.Enum_Module_AMO_Status.AMO_NEW:
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_NEW), statusid.ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW), ((int)Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_DISABLED), ((int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED).ToString()));
                    break;
                case (int)Enumeration.Enum_Module_AMO_Status.AMO_IN_PROCESS:
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_IN_PROCESS), statusid.ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE), ((int)Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_DISABLED), ((int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED).ToString()));
                    break;
                case (int)Enumeration.Enum_Module_AMO_Status.AMO_COMPLETE:
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_COMPLETE), statusid.ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE), ((int)Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_DISABLED), ((int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED).ToString()));
                    break;
                case (int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED:
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_DISABLED), statusid.ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_REENABLED), ((int)Enumeration.Enum_Module_AMO_Status.AMO_REENABLED).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE), ((int)Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE).ToString()));
                    break;
                case (int)Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE:
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE), ((int)Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_REJECT), ((int)Enumeration.Enum_Module_AMO_Status.AMO_REJECT).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_COMPLETE), ((int)Enumeration.Enum_Module_AMO_Status.AMO_COMPLETE).ToString()));
                    break;
                case (int)Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW:
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW), ((int)Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_REJECT), ((int)Enumeration.Enum_Module_AMO_Status.AMO_REJECT).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_COMPLETE), ((int)Enumeration.Enum_Module_AMO_Status.AMO_COMPLETE).ToString()));
                    break;
                case (int)Enumeration.Enum_Module_AMO_Status.AMO_REJECT:
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_REJECT), statusid.ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE), ((int)Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE).ToString()));
                    ddlStatus.Items.Add(new ListItem(getstatus(Enumeration.Enum_Module_AMO_Status.AMO_DISABLED), ((int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED).ToString()));
                    break;
            }

        }

        protected void wdgLoc_InitializeRow(object sender, Infragistics.Web.UI.GridControls.RowEventArgs e)
        {
            //int Localized = 0;
            //int statusid = 0;

            int statusid = Convert.ToInt32(ddlStatus.SelectedValue);
            int Localized = Convert.ToInt32(rblLocalized.SelectedValue);

            if ((e.Row.DataKey[0].ToString() == "334" || statusid == (int)Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE || statusid == (int)Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW
                    || statusid == (int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED) || Localized == 0)
            {
                ((WebControl)(e.Row.Items.FindItemByKey("HideFromHub").FindControl("chkHideFromHub"))).Enabled = false;
                ((WebControl)(e.Row.Items.FindItemByKey("IsHubSku").FindControl("chkIsHubSku"))).Enabled = false;
            }
            else
            {
                ((WebControl)(e.Row.Items.FindItemByKey("HideFromHub").FindControl("chkHideFromHub"))).Enabled = true;
                ((WebControl)(e.Row.Items.FindItemByKey("IsHubSku").FindControl("chkIsHubSku"))).Enabled = true;
            }
        }

        protected void btnLoadLoc_Click(object sender, EventArgs e)
        {
            int IsLocalized = int.Parse(rblLocalized.SelectedValue);
            AMOFeatureBLL m = new AMOFeatureBLL();
            string strBS = "";
            string strBSes = "";
            foreach (RadListBoxItem item in RLBSelBS.Items)
            {
                strBS = item.Value;
                if (strBSes == "")
                    strBSes = strBS;
                else
                    strBSes += "," + strBS;
            }
            wdgLoc.Rows.Clear();
            wdgLoc.DataSource = m.AMOFeature_GetRegions(FeatureID, 1, strBSes, IsLocalized);
            wdgLoc.DataBind();
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "PopulateFeatureCategory", "PopulateFeatureCategory()", true);
            hidSelectedTab.Value = "0";
        }
        protected void btnSKU_Click(object sender, EventArgs e)
        {

        }

        [WebMethod(EnableSession = true)]
        public static string DeleteFeature(string FeatureID)
        {

            string strMsg = "";
            try
            {
                AMOFeatureBLL m = new AMOFeatureBLL();
                m.DeleteFeature(Convert.ToInt32(FeatureID));
                strMsg = "";
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                strMsg = ex.Message;
            }
            return strMsg;
        }

        [System.Web.Services.WebMethod]
        public static bool Disable(int StatusID)
        {
            /* On server side we can do any thing. Like we can access the Session.
             * We can do database access operation. Without postback.
             */
            try
            {
                if (StatusID == (int)Enumeration.Enum_Module_AMO_Status.AMO_DISABLED || StatusID == (int)Enumeration.Enum_Module_AMO_Status.AMO_RASREVIEW
                        || StatusID == (int)Enumeration.Enum_Module_AMO_Status.AMO_RASUPDATE)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, string>> GetFeatureCategory(int intFeatureClassID)
        {
            try
            {
                FeaturesBLL da = new FeaturesBLL();
                DataSet dsFeatureCategory = new DataSet();

                dsFeatureCategory = da.GetFeatureCategoryByFeatureClassID(intFeatureClassID);
                DataView dv = dsFeatureCategory.Tables[0].DefaultView;
                dv.RowFilter = "State='Active'";
                List<Dictionary<string, string>> dicFeatureCategory = new List<Dictionary<string, string>>();

                for (int i = 0; i < dv.Count; i++)
                {
                    Dictionary<string, string> Dictionary = new Dictionary<string, string>();
                    Dictionary.Add("FeatureCategoryID", dv[i]["FeatureCategoryID"].ToString());
                    Dictionary.Add("Name", dv[i]["Name"].ToString());
                    dicFeatureCategory.Add(Dictionary);
                }
                return dicFeatureCategory;
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
        }

        protected void LoadSelectedLocalization(object sender, RadListBoxTransferringEventArgs e)
        {
            int IsLocalized = int.Parse(rblLocalized.SelectedValue);
            AMOFeatureBLL m = new AMOFeatureBLL();
            string strBS = "";
            string strBSes = "";
            foreach (RadListBoxItem item in e.Items)
            {
                strBS = item.Value;
                if (strBSes == "")
                    strBSes = strBS;
                else
                    strBSes += "," + strBS;
            }
            foreach (RadListBoxItem item in RLBSelBS.Items)
            {
                strBS = item.Value;
                if (strBSes == "")
                    strBSes = strBS;
                else
                    strBSes += "," + strBS;
            }
            wdgLoc.DataSource = m.AMOFeature_GetRegions(FeatureID, 1, strBSes, IsLocalized);
            wdgLoc.DataBind();
            hidSelectedTab.Value = "0";
        }

        protected void LoadSavedLocalization(int FeatureID)
        {
            int IsLocalized = int.Parse(rblLocalized.SelectedValue);
            AMOFeatureBLL m = new AMOFeatureBLL();
            string strBS = "";
            string strBSes = "";

            foreach (RadListBoxItem item in RLBSelBS.Items)
            {
                strBS = item.Value;
                if (strBSes == "")
                    strBSes = strBS;
                else
                    strBSes += "," + strBS;
            }
            wdgLoc.DataSource = m.AMOFeature_GetRegions(FeatureID, 1, strBSes, IsLocalized);
            wdgLoc.DataBind();
            hidSelectedTab.Value = "0";
        }

        protected void RLBAvailBS_Transferring(object sender, RadListBoxTransferringEventArgs e)
        {
            LoadSelectedLocalization(sender, e);

        }
    }
}