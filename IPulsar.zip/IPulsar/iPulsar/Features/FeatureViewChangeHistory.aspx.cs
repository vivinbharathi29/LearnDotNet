﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;

namespace iPulsar.Features
{
    public partial class FeatureViewChangeHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Authenticate.ValidateSession();

            int intFeatureID = 0;
            if (Request.QueryString["FeatureID"] != null)
                intFeatureID = Convert.ToInt32(Request.QueryString["FeatureID"]);
            hdnFeatureID.Value = intFeatureID.ToString();
            GetFeatureName();
        }
        private void GetFeatureName()
        {
            FeaturesBLL da = new FeaturesBLL();
            DataSet dsFeatureProperty = new DataSet();
            int intFeatureID = 0;
            intFeatureID = Convert.ToInt32(hdnFeatureID.Value);
            dsFeatureProperty = da.GetFeatureProperties(intFeatureID);
            if (dsFeatureProperty.Tables.Count > 0)
            {
                if (dsFeatureProperty.Tables[0].Rows.Count > 0)
                {
                    lblTitle.Text = "Change History Log: " + dsFeatureProperty.Tables[0].Rows[0]["FeatureName"].ToString();
                }
            }
        }
        [WebMethod(EnableSession = true)]
        public static List<Dictionary<string, object>> GetChangeHistoy(int FeatureID)
        {
            List<Dictionary<string, object>> dicChangeHistoryList = new List<Dictionary<string, object>>();
            Dictionary<string, object> dicChangeHistory = null;
            DataSet dsChangeHistory = new DataSet();
            FeaturesBLL da = new FeaturesBLL();                
            try
            {
                dsChangeHistory = da.GetChangeHistoy(FeatureID);
                for (int i = 0; i < dsChangeHistory.Tables[0].Rows.Count; i++)
                {
                    dicChangeHistory = new Dictionary<string, object>();
                    dicChangeHistory.Add("HistoryID", dsChangeHistory.Tables[0].Rows[i]["HistoryID"].ToString());
                    dicChangeHistory.Add("FormulaName", dsChangeHistory.Tables[0].Rows[i]["FormulaName"].ToString());
                    dicChangeHistory.Add("OldName", dsChangeHistory.Tables[0].Rows[i]["OldName"].ToString());
                    dicChangeHistory.Add("NewName", dsChangeHistory.Tables[0].Rows[i]["NewName"].ToString());
                    dicChangeHistory.Add("Created", dsChangeHistory.Tables[0].Rows[i]["Created"].ToString());
                    dicChangeHistory.Add("CreatedBy", dsChangeHistory.Tables[0].Rows[i]["CreatedBy"].ToString());

                    dicChangeHistoryList.Add(dicChangeHistory);
                }
            }
            catch (Exception ex)
            {
                Tools.InsertError(System.Reflection.MethodBase.GetCurrentMethod().Name, ex);
                throw;
            }
            return dicChangeHistoryList;
        }
    }
}