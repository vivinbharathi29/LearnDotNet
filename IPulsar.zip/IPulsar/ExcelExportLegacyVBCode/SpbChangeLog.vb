Imports Microsoft.VisualBasic
Imports System
Imports System.Xml
Imports System.Text
Imports CarlosAg.ExcelXmlWriter
Namespace SpbExport
  Public Class SpbChangeLog

#Region " Properties "
    Private _partnerId As String = String.Empty
    Public Property PartnerId() As String
      Get
        Return _partnerId
      End Get
      Set(ByVal value As String)
        _partnerId = value
      End Set
    End Property

    Private _dateDiffDays As String = String.Empty
    Public Property DateDiffDays() As String
      Get
        Return _dateDiffDays
      End Get
      Set(ByVal value As String)
        _dateDiffDays = value
      End Set
    End Property

    Private _partnerName As String = String.Empty
    Public Property PartnerName() As String
      Get
        Return _partnerName
      End Get
      Set(ByVal value As String)
        _partnerName = value
      End Set
    End Property
#End Region

#Region " Generate Workbook "
    Public Sub Generate(ByRef stream As System.IO.Stream, ByRef FileName As String)
      Dim book As Workbook = New Workbook
      '-----------------------------------------------
      ' Properties
      '-----------------------------------------------
      book.Properties.Author = ""
      book.Properties.LastAuthor = "Excalibur"
      book.Properties.Created = Now()
      book.Properties.LastSaved = Now()
            book.Properties.Company = "HP"
            book.Properties.Version = "12.00"
      book.ExcelWorkbook.WindowHeight = 8580
      book.ExcelWorkbook.WindowWidth = 7680
      book.ExcelWorkbook.WindowTopX = -15
      book.ExcelWorkbook.WindowTopY = -15
      book.ExcelWorkbook.ProtectWindows = False
      book.ExcelWorkbook.ProtectStructure = False
      '-----------------------------------------------
      ' Generate Styles
      '-----------------------------------------------
      Me.GenerateStyles(book.Styles)

      '
      ' Get the data
      '
      Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
      Dim dt As DataTable = dwExcalibur.SelectSpbChangeLog(PartnerId, DateDiffDays)

      '
      ' Create worksheets
      '
      Me.CreateChangeLogWorksheet(book.Worksheets)

      '
      ' Build Worksheet
      '
      Dim sLastDotsName As String = String.Empty
      For Each row As DataRow In dt.Rows
        If sLastDotsName <> row("dotsname") Then
          AddPlatformRow(book.Worksheets, row)
          sLastDotsName = row("dotsname")
        End If
        AddChangeLogRow(book.Worksheets, row)
      Next

      Me.CloseWorksheetChangeLog(book.Worksheets)
      book.Save(stream)
    End Sub
#End Region

#Region " GenerateStyles "
    Private Sub GenerateStyles(ByVal styles As WorksheetStyleCollection)
      '-----------------------------------------------
      ' Default
      '-----------------------------------------------
      Dim [Default] As WorksheetStyle = styles.Add("Default")
      [Default].Name = "Normal"
      [Default].Font.FontName = "Arial"
      [Default].Alignment.Vertical = StyleVerticalAlignment.Bottom

      '-----------------------------------------------
      ' sTitleBlockLabel
      '-----------------------------------------------
      Dim sTitleBlockLabel As WorksheetStyle = styles.Add("sTitleBlockLabel")
      sTitleBlockLabel.Font.Bold = True
      sTitleBlockLabel.Font.FontName = "Arial"
      sTitleBlockLabel.Font.Size = "10"
      sTitleBlockLabel.Alignment.Horizontal = StyleHorizontalAlignment.Right
      sTitleBlockLabel.Alignment.Vertical = StyleVerticalAlignment.Bottom

      '-----------------------------------------------
      ' sTitleBlockValue
      '-----------------------------------------------
      Dim sTitleBlockValue As WorksheetStyle = styles.Add("sTitleBlockValue")
      sTitleBlockValue.Font.Bold = True
      sTitleBlockValue.Font.FontName = "Arial"
      sTitleBlockValue.Font.Size = "10"
      sTitleBlockValue.Alignment.Horizontal = StyleHorizontalAlignment.Center
      sTitleBlockValue.Alignment.Vertical = StyleVerticalAlignment.Bottom

      '-----------------------------------------------
      ' sKitLevel
      '-----------------------------------------------

      '-----------------------------------------------
      ' sLowerLevels
      '-----------------------------------------------

      '-----------------------------------------------
      ' s85
      '-----------------------------------------------
      Dim s85 As WorksheetStyle = styles.Add("s85")
      s85.Name = "AutoFormat Options"
      s85.Font.FontName = "Arial"
      s85.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s16
      '-----------------------------------------------
      Dim s16 As WorksheetStyle = styles.Add("s16")
      s16.Name = "Style 1"
      s16.Font.FontName = "Helv"
      s16.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s25
      '-----------------------------------------------
      Dim s25 As WorksheetStyle = styles.Add("s25")
      s25.Parent = "s85"
      s25.Font.Bold = True
      s25.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s26
      '-----------------------------------------------
      Dim s26 As WorksheetStyle = styles.Add("s26")
      s26.Parent = "s85"
      s26.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s27
      '-----------------------------------------------
      Dim s27 As WorksheetStyle = styles.Add("s27")
      s27.Parent = "s85"
      s27.Font.Bold = True
      s27.Font.FontName = "Arial"
      s27.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s27.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s28
      '-----------------------------------------------
      Dim s28 As WorksheetStyle = styles.Add("s28")
      s28.Parent = "s85"
      s28.Font.FontName = "Arial"
      s28.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s28.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s29
      '-----------------------------------------------
      Dim s29 As WorksheetStyle = styles.Add("s29")
      s29.Parent = "s85"
      s29.Font.Bold = True
      s29.Font.FontName = "Arial"
      s29.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s29.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s30
      '-----------------------------------------------
      Dim s30 As WorksheetStyle = styles.Add("s30")
      s30.Parent = "s85"
      s30.Font.Bold = True
      s30.Font.FontName = "Arial"
      s30.Font.Color = "#008000"
      s30.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s30.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s31
      '-----------------------------------------------
      Dim s31 As WorksheetStyle = styles.Add("s31")
      s31.Parent = "s85"
      s31.Font.Bold = True
      s31.Font.FontName = "Arial"
      s31.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s31.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s31.Alignment.WrapText = True
      '-----------------------------------------------
      ' s32
      '-----------------------------------------------
      Dim s32 As WorksheetStyle = styles.Add("s32")
      s32.Parent = "s16"
      s32.Font.Bold = True
      s32.Font.FontName = "Arial"
      s32.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s32.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s32.Alignment.WrapText = True
      '-----------------------------------------------
      ' s33
      '-----------------------------------------------
      Dim s33 As WorksheetStyle = styles.Add("s33")
      s33.Parent = "s85"
      s33.Font.FontName = "Arial"
      s33.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s33.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s33.Alignment.WrapText = True
      '-----------------------------------------------
      ' s34
      '-----------------------------------------------
      Dim s34 As WorksheetStyle = styles.Add("s34")
      s34.Parent = "s85"
      s34.Font.FontName = "Arial"
      s34.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s34.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s36
      '-----------------------------------------------
      Dim s36 As WorksheetStyle = styles.Add("s36")
      s36.Parent = "s16"
      s36.Font.Bold = True
      s36.Font.FontName = "Arial"
      s36.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s36.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s37
      '-----------------------------------------------
      Dim s37 As WorksheetStyle = styles.Add("s37")
      s37.Parent = "s85"
      s37.Font.Bold = True
      s37.Font.FontName = "Arial"
      s37.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s37.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s37.NumberFormat = "[ENG][$-409]mmmm\ d\,\ yyyy;@"
      '-----------------------------------------------
      ' s38
      '-----------------------------------------------
      Dim s38 As WorksheetStyle = styles.Add("s38")
      s38.Parent = "s85"
      s38.Font.Bold = True
      s38.Font.FontName = "Arial"
      s38.Font.Color = "#FF0000"
      s38.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s38.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s39
      '-----------------------------------------------
      Dim s39 As WorksheetStyle = styles.Add("s39")
      s39.Parent = "s85"
      s39.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s40
      '-----------------------------------------------
      Dim s40 As WorksheetStyle = styles.Add("s40")
      s40.Parent = "s16"
      s40.Font.Bold = True
      s40.Font.FontName = "Arial"
      s40.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s40.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s40.Alignment.WrapText = True
      '-----------------------------------------------
      ' s41
      '-----------------------------------------------
      Dim s41 As WorksheetStyle = styles.Add("s41")
      s41.Parent = "s85"
      s41.Font.Bold = True
      s41.Font.FontName = "Arial"
      s41.Font.Color = "#FF0000"
      s41.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s41.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s42
      '-----------------------------------------------
      Dim s42 As WorksheetStyle = styles.Add("s42")
      s42.Parent = "s85"
      s42.Font.Bold = True
      s42.Font.FontName = "Arial"
      s42.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s42.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s42.Alignment.WrapText = True
      '-----------------------------------------------
      ' s43
      '-----------------------------------------------
      Dim s43 As WorksheetStyle = styles.Add("s43")
      s43.Parent = "s16"
      s43.Font.Bold = True
      s43.Font.FontName = "Arial"
      s43.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s43.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s44
      '-----------------------------------------------
      Dim s44 As WorksheetStyle = styles.Add("s44")
      s44.Parent = "s16"
      s44.Font.Bold = True
      s44.Font.FontName = "Arial"
      s44.Interior.Color = "#99CCFF"
      s44.Interior.Pattern = StyleInteriorPattern.Solid
      s44.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s44.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s44.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s44.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s44.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s44.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s45
      '-----------------------------------------------
      Dim s45 As WorksheetStyle = styles.Add("s45")
      s45.Parent = "s16"
      s45.Font.Bold = True
      s45.Font.FontName = "Arial"
      s45.Interior.Color = "#99CCFF"
      s45.Interior.Pattern = StyleInteriorPattern.Solid
      s45.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s45.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s45.Alignment.WrapText = True
      s45.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s45.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s45.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s45.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s46
      '-----------------------------------------------
      Dim s46 As WorksheetStyle = styles.Add("s46")
      s46.Parent = "s16"
      s46.Font.FontName = "Arial"
      s46.Interior.Pattern = StyleInteriorPattern.Solid
      s46.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s46.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s46.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s47
      '-----------------------------------------------
      Dim s47 As WorksheetStyle = styles.Add("s47")
      s47.Parent = "s16"
      s47.Font.FontName = "Arial"
      s47.Interior.Pattern = StyleInteriorPattern.Solid
      s47.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s47.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s47.Alignment.WrapText = True
      s47.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s47.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s47.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s47.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s48
      '-----------------------------------------------
      Dim s48 As WorksheetStyle = styles.Add("s48")
      s48.Parent = "s16"
      s48.Font.FontName = "Arial"
      s48.Interior.Pattern = StyleInteriorPattern.Solid
      s48.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s48.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s48.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s49
      '-----------------------------------------------
      Dim s49 As WorksheetStyle = styles.Add("s49")
      s49.Parent = "s16"
      s49.Font.FontName = "Arial"
      s49.Interior.Pattern = StyleInteriorPattern.Solid
      s49.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s49.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s49.Alignment.WrapText = True
      s49.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s49.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s49.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s49.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s44h
      '-----------------------------------------------
      Dim s44h As WorksheetStyle = styles.Add("s44h")
      s44h.Parent = "s16"
      s44h.Font.Bold = True
      s44h.Font.FontName = "Arial"
      s44h.Interior.Color = "#FFFF00"
      s44h.Interior.Pattern = StyleInteriorPattern.Solid
      s44h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s44h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s44h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s44h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s44h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s44h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s45h
      '-----------------------------------------------
      Dim s45h As WorksheetStyle = styles.Add("s45h")
      s45h.Parent = "s16"
      s45h.Font.Bold = True
      s45h.Font.FontName = "Arial"
      s45h.Interior.Color = "#FFFF00"
      s45h.Interior.Pattern = StyleInteriorPattern.Solid
      s45h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s45h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s45h.Alignment.WrapText = True
      s45h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s45h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s45h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s45h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s46h
      '-----------------------------------------------
      Dim s46h As WorksheetStyle = styles.Add("s46h")
      s46h.Parent = "s16"
      s46h.Font.FontName = "Arial"
      s46h.Interior.Pattern = StyleInteriorPattern.Solid
      s46h.Interior.Color = "#FFFF00"
      s46h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s46h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s46h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s46h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s46h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s46h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s47h
      '-----------------------------------------------
      Dim s47h As WorksheetStyle = styles.Add("s47h")
      s47h.Parent = "s16"
      s47h.Font.FontName = "Arial"
      s47h.Interior.Pattern = StyleInteriorPattern.Solid
      s47h.Interior.Color = "#FFFF00"
      s47h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s47h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s47h.Alignment.WrapText = True
      s47h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s47h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s47h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s47h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s46halb
      '-----------------------------------------------
      Dim s46halb As WorksheetStyle = styles.Add("s46halb")
      s46halb.Parent = "s16"
      s46halb.Font.FontName = "Arial"
      s46halb.Interior.Pattern = StyleInteriorPattern.Solid
      s46halb.Interior.Color = "#DBEEF3"
      s46halb.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s46halb.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s46halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s46halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s46halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s46halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s47halb
      '-----------------------------------------------
      Dim s47halb As WorksheetStyle = styles.Add("s47halb")
      s47halb.Parent = "s16"
      s47halb.Font.FontName = "Arial"
      s47halb.Interior.Pattern = StyleInteriorPattern.Solid
      s47halb.Interior.Color = "#DBEEF3"
      s47halb.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s47halb.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s47halb.Alignment.WrapText = True
      s47halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s47halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s47halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s47halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s48h
      '-----------------------------------------------
      Dim s48h As WorksheetStyle = styles.Add("s48h")
      s48h.Parent = "s16"
      s48h.Font.FontName = "Arial"
      s48h.Interior.Pattern = StyleInteriorPattern.Solid
      s48h.Interior.Color = "#FFFF00"
      s48h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s48h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s48h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s48h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s48h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s48h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s49
      '-----------------------------------------------
      Dim s49h As WorksheetStyle = styles.Add("s49h")
      s49h.Parent = "s16"
      s49h.Font.FontName = "Arial"
      s49h.Interior.Pattern = StyleInteriorPattern.Solid
      s49h.Interior.Color = "#FFFF00"
      s49h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s49h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s49h.Alignment.WrapText = True
      s49h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s49h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s49h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s49h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s50
      '-----------------------------------------------
      Dim s50 As WorksheetStyle = styles.Add("s50")
      s50.Parent = "s85"
      s50.Font.FontName = "Arial"
      s50.Interior.Pattern = StyleInteriorPattern.Solid
      s50.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s50.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s50.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s50.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s50.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s50.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s50h
      '-----------------------------------------------
      Dim s50h As WorksheetStyle = styles.Add("s50h")
      s50h.Parent = "s85"
      s50h.Font.FontName = "Arial"
      s50h.Interior.Pattern = StyleInteriorPattern.Solid
      s50h.Interior.Color = "#FFFF00"
      s50h.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s50h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s50h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s50h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s50h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s50h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s51
      '-----------------------------------------------
      Dim s51 As WorksheetStyle = styles.Add("s51")
      s51.Parent = "s85"
      s51.Font.FontName = "Arial"
      s51.Interior.Pattern = StyleInteriorPattern.Solid
      s51.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s51.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s51.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s51.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s51.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s51.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s52
      '-----------------------------------------------
      Dim s52 As WorksheetStyle = styles.Add("s52")
      s52.Parent = "s85"
      s52.Font.Bold = True
      s52.Font.FontName = "Arial"
      s52.Interior.Color = "#99CCFF"
      s52.Interior.Pattern = StyleInteriorPattern.Solid
      s52.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s52.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s52.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s52.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s52h
      '-----------------------------------------------
      Dim s52h As WorksheetStyle = styles.Add("s52h")
      s52h.Parent = "s85"
      s52h.Font.Bold = True
      s52h.Font.FontName = "Arial"
      s52h.Interior.Color = "#FFFF00"
      s52h.Interior.Pattern = StyleInteriorPattern.Solid
      s52h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s52h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s52h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s52h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s53
      '-----------------------------------------------
      Dim s53 As WorksheetStyle = styles.Add("s53")
      s53.Parent = "s85"
      s53.Font.Bold = True
      s53.Font.FontName = "Arial"
      s53.Font.Size = 16
      s53.Font.Color = "#FF0000"
      s53.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s53.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s54
      '-----------------------------------------------
      Dim s54 As WorksheetStyle = styles.Add("s54")
      s54.Parent = "s85"
      s54.Font.FontName = "Arial"
      s54.Font.Color = "#C0C0C0"
      s54.Interior.Pattern = StyleInteriorPattern.Solid
      s54.Alignment.Vertical = StyleVerticalAlignment.Center
      s54.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s54.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s54.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s54.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s54h
      '-----------------------------------------------
      Dim s54h As WorksheetStyle = styles.Add("s54h")
      s54h.Parent = "s85"
      s54h.Font.FontName = "Arial"
      s54h.Font.Color = "#C0C0C0"
      s54h.Interior.Pattern = StyleInteriorPattern.Solid
      s54h.Interior.Color = "#FFFF00"
      s54h.Alignment.Vertical = StyleVerticalAlignment.Center
      s54h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s54h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s54h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s54h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s55
      '-----------------------------------------------
      Dim s55 As WorksheetStyle = styles.Add("s55")
      s55.Parent = "s85"
      s55.Font.FontName = "Arial"
      s55.Font.Color = "#C0C0C0"
      s55.Interior.Pattern = StyleInteriorPattern.Solid
      s55.Alignment.Vertical = StyleVerticalAlignment.Center
      s55.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s55.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s55.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s55.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s56
      '-----------------------------------------------
      Dim s56 As WorksheetStyle = styles.Add("s56")
      s56.Parent = "s16"
      s56.Font.FontName = "Arial"
      s56.Interior.Pattern = StyleInteriorPattern.Solid
      s56.Alignment.Vertical = StyleVerticalAlignment.Center
      s56.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s56.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s56.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s56.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s57
      '-----------------------------------------------
      Dim s57 As WorksheetStyle = styles.Add("s57")
      s57.Parent = "s16"
      s57.Font.FontName = "Arial"
      s57.Interior.Pattern = StyleInteriorPattern.Solid
      s57.Alignment.Vertical = StyleVerticalAlignment.Center
      s57.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s57.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s57.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s57.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s56h
      '-----------------------------------------------
      Dim s56h As WorksheetStyle = styles.Add("s56h")
      s56h.Parent = "s16"
      s56h.Font.FontName = "Arial"
      s56h.Interior.Pattern = StyleInteriorPattern.Solid
      s56h.Interior.Color = "#FFFF00"
      s56h.Alignment.Vertical = StyleVerticalAlignment.Center
      s56h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s56h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s56h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s56h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s56halb
      '-----------------------------------------------
      Dim s56halb As WorksheetStyle = styles.Add("s56halb")
      s56halb.Parent = "s16"
      s56halb.Font.FontName = "Arial"
      s56halb.Interior.Pattern = StyleInteriorPattern.Solid
      s56halb.Interior.Color = "#DBEEF3"
      s56halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s56halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s56halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s56halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s56halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s57
      '-----------------------------------------------
      Dim s57h As WorksheetStyle = styles.Add("s57h")
      s57h.Parent = "s16"
      s57h.Font.FontName = "Arial"
      s57h.Interior.Pattern = StyleInteriorPattern.Solid
      s57h.Interior.Color = "#FFFF00"
      s57h.Alignment.Vertical = StyleVerticalAlignment.Center
      s57h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s57h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s57h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s57h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s58
      '-----------------------------------------------
      Dim s58 As WorksheetStyle = styles.Add("s58")
      s58.Parent = "s85"
      s58.Font.FontName = "Arial"
      s58.Interior.Pattern = StyleInteriorPattern.Solid
      s58.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s58.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s58.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s58.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s59
      '-----------------------------------------------
      Dim s59 As WorksheetStyle = styles.Add("s59")
      s59.Parent = "s85"
      s59.Font.FontName = "Arial"
      s59.Interior.Pattern = StyleInteriorPattern.Solid
      s59.Alignment.Vertical = StyleVerticalAlignment.Center
      s59.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s59.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s59.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s59.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s60
      '-----------------------------------------------
      Dim s60 As WorksheetStyle = styles.Add("s60")
      s60.Parent = "s16"
      s60.Font.FontName = "Arial"
      s60.Interior.Pattern = StyleInteriorPattern.Solid
      s60.Alignment.Vertical = StyleVerticalAlignment.Center
      s60.Alignment.WrapText = True
      s60.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s60.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s60.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s60.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s59h
      '-----------------------------------------------
      Dim s59h As WorksheetStyle = styles.Add("s59h")
      s59h.Parent = "s85"
      s59h.Font.FontName = "Arial"
      s59h.Interior.Pattern = StyleInteriorPattern.Solid
      s59h.Interior.Color = "#FFFF00"
      s59h.Alignment.Vertical = StyleVerticalAlignment.Center
      s59h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s59h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s59h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s59h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s60h
      '-----------------------------------------------
      Dim s60h As WorksheetStyle = styles.Add("s60h")
      s60h.Parent = "s16"
      s60h.Font.FontName = "Arial"
      s60h.Interior.Pattern = StyleInteriorPattern.Solid
      s60h.Interior.Color = "#FFFF00"
      s60h.Alignment.Vertical = StyleVerticalAlignment.Center
      s60h.Alignment.WrapText = True
      s60h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s60h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s60h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s60h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s59halb
      '-----------------------------------------------
      Dim s59halb As WorksheetStyle = styles.Add("s59halb")
      s59halb.Parent = "s85"
      s59halb.Font.FontName = "Arial"
      s59halb.Interior.Pattern = StyleInteriorPattern.Solid
      s59halb.Interior.Color = "#DBEEF3"
      s59halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s59halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s59halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s59halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s59halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s60halb
      '-----------------------------------------------
      Dim s60halb As WorksheetStyle = styles.Add("s60halb")
      s60halb.Parent = "s16"
      s60halb.Font.FontName = "Arial"
      s60halb.Interior.Pattern = StyleInteriorPattern.Solid
      s60halb.Interior.Color = "#DBEEF3"
      s60halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s60halb.Alignment.WrapText = True
      s60halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s60halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s60halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s60halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s61
      '-----------------------------------------------
      Dim s61 As WorksheetStyle = styles.Add("s61")
      s61.Parent = "s85"
      s61.Font.FontName = "Arial"
      s61.Alignment.Vertical = StyleVerticalAlignment.Center
      s61.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s61.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s61.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s61.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s61h
      '-----------------------------------------------
      Dim s61h As WorksheetStyle = styles.Add("s61h")
      s61h.Parent = "s85"
      s61h.Font.FontName = "Arial"
      s61h.Interior.Pattern = StyleInteriorPattern.Solid
      s61h.Interior.Color = "#FFFF00"
      s61h.Alignment.Vertical = StyleVerticalAlignment.Center
      s61h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s61h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s61h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s61h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s61halb
      '-----------------------------------------------
      Dim s61halb As WorksheetStyle = styles.Add("s61halb")
      s61halb.Parent = "s85"
      s61halb.Font.FontName = "Arial"
      s61halb.Interior.Pattern = StyleInteriorPattern.Solid
      s61halb.Interior.Color = "#DBEEF3"
      s61halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s61halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s61halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s61halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s61halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s62
      '-----------------------------------------------
      Dim s62 As WorksheetStyle = styles.Add("s62")
      s62.Parent = "s85"
      s62.Font.FontName = "Arial"
      s62.Interior.Pattern = StyleInteriorPattern.Solid
      s62.Alignment.Vertical = StyleVerticalAlignment.Center
      s62.Alignment.WrapText = True
      s62.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s62.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s62.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s62.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s63
      '-----------------------------------------------
      Dim s63 As WorksheetStyle = styles.Add("s63")
      s63.Parent = "s85"
      s63.Font.FontName = "Arial"
      s63.Interior.Pattern = StyleInteriorPattern.Solid
      s63.Alignment.Vertical = StyleVerticalAlignment.Center
      s63.Alignment.WrapText = True
      s63.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s63.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s63.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s63.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s65
      '-----------------------------------------------
      Dim s65 As WorksheetStyle = styles.Add("s65")
      s65.Parent = "s85"
      s65.Font.FontName = "Arial"
      s65.Interior.Pattern = StyleInteriorPattern.Solid
      s65.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s65.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s65.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s65.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s65.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s65.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s65h
      '-----------------------------------------------
      Dim s65h As WorksheetStyle = styles.Add("s65h")
      s65h.Parent = "s85"
      s65h.Font.FontName = "Arial"
      s65h.Interior.Pattern = StyleInteriorPattern.Solid
      s65h.Interior.Color = "#FFFF00"
      s65h.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s65h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s65h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s65h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s65h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s65h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s65halb
      '-----------------------------------------------
      Dim s65halb As WorksheetStyle = styles.Add("s65halb")
      s65halb.Parent = "s85"
      s65halb.Font.FontName = "Arial"
      s65halb.Interior.Pattern = StyleInteriorPattern.Solid
      s65halb.Interior.Color = "#DBEEF3"
      s65halb.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s65halb.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s65halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s65halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s65halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s65halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s66
      '-----------------------------------------------
      Dim s66 As WorksheetStyle = styles.Add("s66")
      s66.Parent = "s85"
      s66.Font.FontName = "Arial"
      s66.Interior.Pattern = StyleInteriorPattern.Solid
      s66.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s66.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s66.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s66.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s66.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s66.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s67
      '-----------------------------------------------
      Dim s67 As WorksheetStyle = styles.Add("s67")
      s67.Parent = "s85"
      s67.Font.FontName = "Arial"
      s67.Interior.Pattern = StyleInteriorPattern.Solid
      s67.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s67.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s67.Alignment.WrapText = True
      s67.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s67.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s67.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s67.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s68
      '-----------------------------------------------
      Dim s68 As WorksheetStyle = styles.Add("s68")
      s68.Parent = "s85"
      s68.Font.FontName = "Arial"
      s68.Interior.Pattern = StyleInteriorPattern.Solid
      s68.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s68.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s68.Alignment.WrapText = True
      s68.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s68.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s68.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s68.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s71
      '-----------------------------------------------
      Dim s71 As WorksheetStyle = styles.Add("s71")
      s71.Parent = "s16"
      s71.Font.Bold = True
      s71.Font.FontName = "Arial"
      s71.Interior.Color = "#99CCFF"
      s71.Interior.Pattern = StyleInteriorPattern.Solid
      s71.Alignment.Vertical = StyleVerticalAlignment.Center
      s71.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s71.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s71.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s71.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s72
      '-----------------------------------------------
      Dim s72 As WorksheetStyle = styles.Add("s72")
      s72.Parent = "s85"
      s72.Font.Bold = True
      s72.Font.FontName = "Arial"
      s72.Interior.Color = "#99CCFF"
      s72.Interior.Pattern = StyleInteriorPattern.Solid
      s72.Alignment.Vertical = StyleVerticalAlignment.Center
      s72.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s72.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s72.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s72.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s71
      '-----------------------------------------------
      Dim s71h As WorksheetStyle = styles.Add("s71h")
      s71h.Parent = "s16"
      s71h.Font.Bold = True
      s71h.Font.FontName = "Arial"
      s71h.Interior.Color = "#FFFF00"
      s71h.Interior.Pattern = StyleInteriorPattern.Solid
      s71h.Alignment.Vertical = StyleVerticalAlignment.Center
      s71h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s71h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s71h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s71h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s72
      '-----------------------------------------------
      Dim s72h As WorksheetStyle = styles.Add("s72h")
      s72h.Parent = "s85"
      s72h.Font.Bold = True
      s72h.Font.FontName = "Arial"
      s72h.Interior.Color = "#FFFF00"
      s72h.Interior.Pattern = StyleInteriorPattern.Solid
      s72h.Alignment.Vertical = StyleVerticalAlignment.Center
      s72h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s72h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s72h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s72h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s73
      '-----------------------------------------------
      Dim s73 As WorksheetStyle = styles.Add("s73")
      s73.Parent = "s85"
      s73.Font.Bold = True
      s73.Font.FontName = "Arial"
      s73.Interior.Color = "#99CCFF"
      s73.Interior.Pattern = StyleInteriorPattern.Solid
      s73.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s73.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s73.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s73.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s73.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s73.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s74
      '-----------------------------------------------
      Dim s74 As WorksheetStyle = styles.Add("s74")
      s74.Parent = "s85"
      s74.Font.Bold = True
      s74.Font.FontName = "Arial"
      s74.Interior.Color = "#99CCFF"
      s74.Interior.Pattern = StyleInteriorPattern.Solid
      s74.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s74.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s74.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s74.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s74.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s74.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s75
      '-----------------------------------------------
      Dim s75 As WorksheetStyle = styles.Add("s75")
      s75.Parent = "s85"
      s75.Font.Bold = True
      s75.Font.FontName = "Arial"
      s75.Interior.Color = "#99CCFF"
      s75.Interior.Pattern = StyleInteriorPattern.Solid
      s75.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s75.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s75.Alignment.WrapText = True
      s75.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s75.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s75.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s75.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s76
      '-----------------------------------------------
      Dim s76 As WorksheetStyle = styles.Add("s76")
      s76.Parent = "s85"
      s76.Font.FontName = "Arial"
      s76.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s76.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s77
      '-----------------------------------------------
      Dim s77 As WorksheetStyle = styles.Add("s77")
      s77.Parent = "s85"
      s77.Font.FontName = "Arial"
      s77.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s77.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s78
      '-----------------------------------------------
      Dim s78 As WorksheetStyle = styles.Add("s78")
      s78.Parent = "s16"
      s78.Font.Bold = True
      s78.Font.FontName = "Arial"
      s78.Interior.Color = "#99CCFF"
      s78.Interior.Pattern = StyleInteriorPattern.Solid
      s78.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s78.Alignment.Vertical = StyleVerticalAlignment.Center
      s78.Alignment.WrapText = True
      s78.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s78.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s78.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s78.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s79
      '-----------------------------------------------
      Dim s79 As WorksheetStyle = styles.Add("s79")
      s79.Parent = "s85"
      s79.Font.FontName = "Arial"
      s79.Interior.Pattern = StyleInteriorPattern.Solid
      s79.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s79.Alignment.Vertical = StyleVerticalAlignment.Center
      s79.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s79.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s79.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s79.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s79h
      '-----------------------------------------------
      Dim s79h As WorksheetStyle = styles.Add("s79h")
      s79h.Parent = "s85"
      s79h.Font.FontName = "Arial"
      s79h.Interior.Pattern = StyleInteriorPattern.Solid
      s79h.Interior.Color = "#FFFF00"
      s79h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s79h.Alignment.Vertical = StyleVerticalAlignment.Center
      s79h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s79h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s79h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s79h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s79halb
      '-----------------------------------------------
      Dim s79halb As WorksheetStyle = styles.Add("s79halb")
      s79halb.Parent = "s85"
      s79halb.Font.FontName = "Arial"
      s79halb.Interior.Pattern = StyleInteriorPattern.Solid
      s79halb.Interior.Color = "#DBEEF3"
      s79halb.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s79halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s79halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s79halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s79halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s79halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s80
      '-----------------------------------------------
      Dim s80 As WorksheetStyle = styles.Add("s80")
      s80.Parent = "s85"
      s80.Font.FontName = "Arial"
      s80.Interior.Pattern = StyleInteriorPattern.Solid
      s80.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s80.Alignment.Vertical = StyleVerticalAlignment.Center
      s80.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s80.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s80.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s80.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s80h
      '-----------------------------------------------
      Dim s80h As WorksheetStyle = styles.Add("s80h")
      s80h.Parent = "s85"
      s80h.Font.FontName = "Arial"
      s80h.Interior.Pattern = StyleInteriorPattern.Solid
      s80h.Interior.Color = "#FFFF00"
      s80h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s80h.Alignment.Vertical = StyleVerticalAlignment.Center
      s80h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s80h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s80h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s80h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s81
      '-----------------------------------------------
      Dim s81 As WorksheetStyle = styles.Add("s81")
      s81.Parent = "s85"
      s81.Font.FontName = "Arial"
      s81.Interior.Pattern = StyleInteriorPattern.Solid
      s81.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s81.Alignment.Vertical = StyleVerticalAlignment.Center
      s81.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s81.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s81.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s81.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s82
      '-----------------------------------------------
      Dim s82 As WorksheetStyle = styles.Add("s82")
      s82.Parent = "s85"
      s82.Font.FontName = "Arial"
      s82.Interior.Pattern = StyleInteriorPattern.Solid
      s82.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s82.Alignment.Vertical = StyleVerticalAlignment.Center
      s82.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s82.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s82.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s82.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s82h
      '-----------------------------------------------
      Dim s82h As WorksheetStyle = styles.Add("s82h")
      s82h.Parent = "s85"
      s82h.Font.FontName = "Arial"
      s82h.Interior.Pattern = StyleInteriorPattern.Solid
      s82h.Interior.Color = "#FFFF00"
      s82h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s82h.Alignment.Vertical = StyleVerticalAlignment.Center
      s82h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s82h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s82h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s82h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s84
      '-----------------------------------------------
      Dim s84 As WorksheetStyle = styles.Add("s84")
      s84.Parent = "s16"
      s84.Font.Bold = True
      s84.Font.FontName = "Arial"
      s84.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s84.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s84.Alignment.WrapText = True
      '-----------------------------------------------
      ' s100
      '-----------------------------------------------
      Dim s100 As WorksheetStyle = styles.Add("s100")
      s100.Parent = "s85"
      s100.Font.FontName = "Arial"
      s100.Font.Color = "#A0A0A0"
      s100.Alignment.Vertical = StyleVerticalAlignment.Center
      s100.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s100.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s100.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s100.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s100h
      '-----------------------------------------------
      Dim s100h As WorksheetStyle = styles.Add("s100h")
      s100h.Parent = "s85"
      s100h.Font.FontName = "Arial"
      s100h.Font.Color = "#A0A0A0"
      s100h.Interior.Pattern = StyleInteriorPattern.Solid
      s100h.Interior.Color = "#FFFF00"
      s100h.Alignment.Vertical = StyleVerticalAlignment.Center
      s100h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s100h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s100h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s100h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s100halb
      '-----------------------------------------------
      Dim s100halb As WorksheetStyle = styles.Add("s100halb")
      s100halb.Parent = "s85"
      s100halb.Font.FontName = "Arial"
      s100halb.Font.Color = "#A0A0A0"
      s100halb.Interior.Pattern = StyleInteriorPattern.Solid
      s100halb.Interior.Color = "#DBEEF3"
      s100halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s100halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s100halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s100halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s100halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)

      '-----------------------------------------------
      ' Default
      '-----------------------------------------------
      Dim s200 As WorksheetStyle = styles.Add("s200")
      s200.Name = "ChangeNormal"
      s200.Font.FontName = "Calibri"
      s200.Font.Size = 11
      s200.Font.Color = "#000000"
      s200.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s201
      '-----------------------------------------------
      Dim s201 As WorksheetStyle = styles.Add("s201")
      s201.Name = "Normal_Sheet1"
      s201.Font.FontName = "Arial"
      s201.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s202
      '-----------------------------------------------
      Dim s202 As WorksheetStyle = styles.Add("s202")
      s202.Name = "ChangeStyle 1"
      s202.Font.FontName = "Helv"
      s202.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s203
      '-----------------------------------------------
      Dim s203 As WorksheetStyle = styles.Add("s203")
      '-----------------------------------------------
      ' s204
      '-----------------------------------------------
      Dim s204 As WorksheetStyle = styles.Add("s204")
      s204.Parent = "s202"
      s204.Font.Bold = True
      s204.Font.FontName = "Arial"
      s204.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s204.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s204.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s204.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 3)
      '-----------------------------------------------
      ' s205
      '-----------------------------------------------
      Dim s205 As WorksheetStyle = styles.Add("s205")
      s205.Parent = "s202"
      s205.Font.Bold = True
      s205.Font.FontName = "Arial"
      s205.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s205.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s205.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
      s205.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s206
      '-----------------------------------------------
      Dim s206 As WorksheetStyle = styles.Add("s206")
      s206.Parent = "s202"
      s206.Font.FontName = "Arial"
      s206.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s206.Alignment.Vertical = StyleVerticalAlignment.Bottom
      Dim s206Border0 As WorksheetStyleBorder = s206.Borders.Add
      s206Border0.Position = StylePosition.Bottom
      s206Border0.LineStyle = LineStyleOption.Continuous
      s206.NumberFormat = "Short Date"
      '-----------------------------------------------
      ' s207
      '-----------------------------------------------
      Dim s207 As WorksheetStyle = styles.Add("s207")
      s207.Parent = "s201"
      s207.Font.FontName = "Arial"
      s207.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s207.Alignment.Vertical = StyleVerticalAlignment.Bottom
      Dim s207Border0 As WorksheetStyleBorder = s207.Borders.Add
      s207Border0.Position = StylePosition.Bottom
      s207Border0.LineStyle = LineStyleOption.Continuous
      '-----------------------------------------------
      ' s208
      '-----------------------------------------------
      Dim s208 As WorksheetStyle = styles.Add("s208")
      s208.Parent = "s202"
      s208.Font.FontName = "Arial"
      s208.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s208.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s209
      '-----------------------------------------------
      Dim s209 As WorksheetStyle = styles.Add("s209")
      s209.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s209.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s210
      '-----------------------------------------------
      Dim s210 As WorksheetStyle = styles.Add("s210")
      s210.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s210.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s211
      '-----------------------------------------------
      Dim s211 As WorksheetStyle = styles.Add("s211")
      s211.Parent = "s202"
      s211.Font.Bold = True
      s211.Font.FontName = "Arial"
      s211.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s211.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s211.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
      s211.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s212
      '-----------------------------------------------
      Dim s212 As WorksheetStyle = styles.Add("s212")
      s212.Parent = "s202"
      s212.Font.FontName = "Arial"
      s212.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s212.Alignment.Vertical = StyleVerticalAlignment.Bottom
      Dim s212Border0 As WorksheetStyleBorder = s212.Borders.Add
      s212Border0.Position = StylePosition.Bottom
      s212Border0.LineStyle = LineStyleOption.Continuous
      '-----------------------------------------------
      ' s213
      '-----------------------------------------------
      Dim s213 As WorksheetStyle = styles.Add("s213")
      s213.Parent = "s202"
      s213.Font.FontName = "Arial"
      s213.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s213.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s214
      '-----------------------------------------------
      Dim s214 As WorksheetStyle = styles.Add("s214")
      s214.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s214.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s215
      '-----------------------------------------------
      Dim s215 As WorksheetStyle = styles.Add("s215")
      s215.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s215.Alignment.Vertical = StyleVerticalAlignment.Bottom

      '-----------------------------------------------
      ' sPlatformRow
      '-----------------------------------------------
      Dim sPlatformRow As WorksheetStyle = styles.Add("PlatformRow")
      sPlatformRow.Parent = "s202"
      sPlatformRow.Font.Bold = True
      sPlatformRow.Font.FontName = "Arial"
      sPlatformRow.Alignment.Horizontal = StyleHorizontalAlignment.Left
      sPlatformRow.Alignment.Vertical = StyleVerticalAlignment.Bottom
      sPlatformRow.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      sPlatformRow.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)

    End Sub
#End Region

#Region " Change Log Worksheet "
#Region " Create ChangeLog Worksheet "
    Private Sub CreateChangeLogWorksheet(ByVal sheets As WorksheetCollection)
      Dim sheet As Worksheet = sheets.Add("Change Log")
      sheet.Table.ExpandedColumnCount = 5
      sheet.Table.FullColumns = 1
      sheet.Table.FullRows = 1
      Dim column1 As WorksheetColumn = sheet.Table.Columns.Add
      column1.Width = 76
      column1.StyleID = "s214"
      column1.Span = 2
      Dim column2 As WorksheetColumn = sheet.Table.Columns.Add
      column2.Index = 4
      column2.Width = 111
      Dim column3 As WorksheetColumn = sheet.Table.Columns.Add
      column3.Width = 288
      column3.StyleID = "s209"
      '-----------------------------------------------
      Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
      Row0.Height = 13
      Row0.AutoFitHeight = False
      Dim cell As WorksheetCell
      cell = Row0.Cells.Add
      cell.StyleID = "sTitleBlockValue"
      cell.Data.Text = String.Format("{0} SPB Change Log {1}", PartnerName, Now.ToShortDateString())
      '-----------------------------------------------
      Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
      Row1.Index = 3
      Row1.Height = 13
      Row1.AutoFitHeight = False
      cell = Row1.Cells.Add
      cell.StyleID = "s204"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Change Log"
      cell.MergeAcross = 4
      '-----------------------------------------------
      Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
      Row2.Height = 13
      Row2.AutoFitHeight = False
      Row2.Cells.Add("Spare Kit", DataType.String, "s205")
      Row2.Cells.Add("HP Part No", DataType.String, "s205")
      Row2.Cells.Add("Level", DataType.String, "s205")
      Row2.Cells.Add("Column", DataType.String, "s205")
      Row2.Cells.Add("Details", DataType.String, "s211")
      '-----------------------------------------------
    End Sub
#End Region

#Region " Add Platform Row "
    Private Sub AddPlatformRow(ByVal sheets As WorksheetCollection, ByVal ClRow As DataRow)
      Dim sheet As Worksheet = sheets("Change Log")
      Dim Row As WorksheetRow = sheet.Table.Rows.Add
      Dim Cell As WorksheetCell = Row.Cells.Add()
      Cell.StyleID = "PlatformRow"
      Cell.Data.Text = ClRow("DotsName")
      Cell.MergeAcross = 4

    End Sub
#End Region

#Region " Add Change Log Rows "
    Private Sub AddChangeLogRow(ByVal sheets As WorksheetCollection, ByVal ClRow As DataRow)

      Dim sheet As Worksheet = sheets("Change Log")
      '-----------------------------------------------
      Dim Row As WorksheetRow = sheet.Table.Rows.Add
      Row.Cells.Add(ClRow("SpareKit").ToString(), DataType.String, "s207")
      Row.Cells.Add(ClRow("HpPartNo").ToString(), DataType.String, "s207")
      Row.Cells.Add(ClRow("BomLevel").ToString(), DataType.String, "s207")
      Row.Cells.Add(ClRow("ColumnChanged").ToString(), DataType.String, "s207")
      Row.Cells.Add(ClRow("ChangeDetails").ToString(), DataType.String, "s212")

    End Sub
#End Region

#Region " Close ChangeLog Worksheet "
    Private Sub CloseWorksheetChangeLog(ByVal sheets As WorksheetCollection)
      Dim sheet As Worksheet = sheets("Change Log")
      '-----------------------------------------------
      ' Options
      '-----------------------------------------------
      sheet.Options.Selected = True
      sheet.Options.ProtectObjects = False
      sheet.Options.ProtectScenarios = False
      sheet.Options.PageSetup.Header.Margin = 0.3!
      sheet.Options.PageSetup.Footer.Data = "&LHP Confidential&CPage &P of &N&RDate Printed: &D"
      sheet.Options.PageSetup.Footer.Margin = 0.25!
      sheet.Options.PageSetup.PageMargins.Bottom = 0.75!
      sheet.Options.PageSetup.PageMargins.Left = 0.7!
      sheet.Options.PageSetup.PageMargins.Right = 0.7!
      sheet.Options.PageSetup.PageMargins.Top = 0.75!
    End Sub
#End Region
#End Region

#Region " Format Excel Date "

    Function FormatExcelDate(ByVal dt As Date) As String
      Dim s As StringBuilder = New StringBuilder
      s.Append(dt.Year.ToString.Trim())
      s.Append("-")
      s.Append(dt.Month.ToString.PadLeft(2, "0"))
      s.Append("-")
      s.Append(dt.Day.ToString.PadLeft(2, "0"))
      s.Append("T")
      s.Append(dt.Hour.ToString.PadLeft(2, "0"))
      s.Append(":")
      s.Append(dt.Minute.ToString.PadLeft(2, "0"))
      s.Append(":")
      s.Append(dt.Second.ToString.PadLeft(2, "0"))
      s.Append(".000")

      Return s.ToString.Trim
    End Function


#End Region
  End Class
End Namespace