Imports System
Imports System.Xml
Imports CarlosAg.ExcelXmlWriter
Imports System.Text
Namespace ExcelExport
  Public Class XmlScmTemplate

#Region " Properties "
    Dim _ProductBrandID As Long = 0
    Public Property ProductBrandID() As Long
      Get
        Return _ProductBrandID
      End Get
      Set(ByVal value As Long)
        _ProductBrandID = value
      End Set
    End Property

    Dim _ProductVersion As Long = 0
    Public Property ProductVersion() As Long
      Get
        Return _ProductVersion
      End Get
      Set(ByVal value As Long)
        _ProductVersion = value
      End Set
    End Property
#End Region

    Public Sub Generate(ByRef stream As System.IO.Stream, ByRef FileName As String)
      Dim book As Workbook = New Workbook
      '-----------------------------------------------
      ' Properties
      '-----------------------------------------------
      book.Properties.Title = "Excalibur SCM Working Template"
      book.Properties.LastAuthor = "PSG Excalibur"
      book.Properties.Version = "12.00"
      book.ExcelWorkbook.WindowHeight = 4785
      book.ExcelWorkbook.WindowWidth = 7650
      book.ExcelWorkbook.WindowTopX = 7665
      book.ExcelWorkbook.WindowTopY = -15
      book.ExcelWorkbook.ProtectWindows = False
      book.ExcelWorkbook.ProtectStructure = False
      '-----------------------------------------------
      ' Generate Styles
      '-----------------------------------------------
      Me.GenerateStyles(book.Styles)
      '-----------------------------------------------
      ' Generate SCM AV Data Worksheet
      '-----------------------------------------------
      Dim prodInfo As ProductInfo = New ProductInfo(ProductBrandID)
      Me.GenerateWorksheetSCMAVData(book.Worksheets, prodInfo)

      Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
      Dim dt As DataTable = dwExcalibur.ListScmNames("", ProductBrandID)
      Dim sFamily As String = dt.Rows(0)("Name").ToString()
      Dim sVersion As String = dt.Rows(0)("Version").ToString()
      Dim sSeries As String = dt.Rows(0)("SeriesName").ToString()
      Dim sKmat As String = dt.Rows(0)("KMAT").ToString()

      Dim saFileName(5) As String
      saFileName(0) = prodInfo.Family
      saFileName(1) = prodInfo.ProductVersion
      saFileName(2) = prodInfo.Series
      saFileName(3) = "ScmWorkbook"
      saFileName(4) = String.Format("{0}{1}{2}", Now.Year.ToString(), Now.Month.ToString.PadLeft(2, "0"), Now.Day.ToString.PadLeft(2, "0"))
      FileName = String.Format("{0}_{1}_{2}_{3}_{4}.xls", saFileName)
      FileName = FileName.Replace(" ", "_")

      For Each character As Char In System.IO.Path.GetInvalidFileNameChars()
        FileName = FileName.Replace(character, "_")
      Next

      book.Save(stream)
    End Sub

#Region " GenerateStyles "
    Private Sub GenerateStyles(ByVal styles As WorksheetStyleCollection)
      '-----------------------------------------------
      ' Default
      '-----------------------------------------------
      Dim [Default] As WorksheetStyle = styles.Add("Default")
      [Default].Name = "Normal"
      [Default].Alignment.Vertical = StyleVerticalAlignment.Top
      '-----------------------------------------------
      ' s62
      '-----------------------------------------------
      Dim s62 As WorksheetStyle = styles.Add("s62")
      s62.NumberFormat = "@"
      '-----------------------------------------------
      ' s63
      '-----------------------------------------------
      Dim s63 As WorksheetStyle = styles.Add("s63")
      s63.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s63.Alignment.Vertical = StyleVerticalAlignment.Top
      '-----------------------------------------------
      ' s64
      '-----------------------------------------------
      Dim s64 As WorksheetStyle = styles.Add("s64")
      s64.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s64.Alignment.Vertical = StyleVerticalAlignment.Top
      s64.NumberFormat = "@"
      '-----------------------------------------------
      ' s65
      '-----------------------------------------------
      Dim s65 As WorksheetStyle = styles.Add("s65")
      s65.NumberFormat = "[$-409]m/d/yy\ h:mm\ AM/PM;@"
      '-----------------------------------------------
      ' s66
      '-----------------------------------------------
      Dim s66 As WorksheetStyle = styles.Add("s66")
      s66.Font.Bold = True
      s66.Font.FontName = "Calibri"
      s66.Font.Size = 11
      s66.Font.Color = "#FFFFFF"
      s66.Alignment.Vertical = StyleVerticalAlignment.Top
      s66.Alignment.WrapText = True
      '-----------------------------------------------
      ' s67
      '-----------------------------------------------
      Dim s67 As WorksheetStyle = styles.Add("s67")
      s67.Font.Bold = True
      s67.Font.FontName = "Calibri"
      s67.Font.Size = 11
      s67.Font.Color = "#FFFFFF"
      s67.Interior.Color = "#000000"
      s67.Interior.Pattern = StyleInteriorPattern.Solid
      s67.Alignment.Vertical = StyleVerticalAlignment.Top
      s67.Alignment.WrapText = True
      '-----------------------------------------------
      ' s68
      '-----------------------------------------------
      Dim s68 As WorksheetStyle = styles.Add("s68")
      s68.Font.Bold = True
      s68.Font.FontName = "Calibri"
      s68.Font.Size = 11
      s68.Font.Color = "#000000"
      s68.Alignment.Vertical = StyleVerticalAlignment.Top
      s68.Alignment.WrapText = True
      '-----------------------------------------------
      ' s69
      '-----------------------------------------------
      Dim s69 As WorksheetStyle = styles.Add("s69")
      s69.Font.Bold = True
      s69.Font.FontName = "Calibri"
      s69.Font.Size = 11
      s69.Font.Color = "#000000"
      s69.Interior.Color = "#D8D8D8"
      s69.Interior.Pattern = StyleInteriorPattern.Solid
      s69.Alignment.Vertical = StyleVerticalAlignment.Top
      s69.Alignment.WrapText = True
      '-----------------------------------------------
      ' s70
      '-----------------------------------------------
      Dim s70 As WorksheetStyle = styles.Add("s70")
      s70.Font.Bold = True
      s70.Font.FontName = "Calibri"
      s70.Font.Size = 11
      s70.Font.Color = "#000000"
      s70.Interior.Color = "#D8D8D8"
      s70.Interior.Pattern = StyleInteriorPattern.Solid
      s70.Alignment.Vertical = StyleVerticalAlignment.Top
      '-----------------------------------------------
      ' s71
      '-----------------------------------------------
      Dim s71 As WorksheetStyle = styles.Add("s71")
      s71.Font.FontName = "Calibri"
      s71.Font.Color = "#000000"
      s71.Alignment.Vertical = StyleVerticalAlignment.Top
      s71.Alignment.WrapText = True
      '-----------------------------------------------
      ' s72
      '-----------------------------------------------
      Dim s72 As WorksheetStyle = styles.Add("s72")
      s72.Font.FontName = "Calibri"
      s72.Font.Color = "#000000"
      s72.Font.Size = 11
      s72.Alignment.Vertical = StyleVerticalAlignment.Top
      s72.Alignment.WrapText = True

    End Sub
#End Region

#Region " Generate Worksheet "
    Private Sub GenerateWorksheetSCMAVData(ByVal sheets As WorksheetCollection, ByVal prodInfo As ProductInfo)

      Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data

      Dim sheet As Worksheet = sheets.Add("SCMAVData")
      sheet.Names.Add(New WorksheetNamedRange("Print_Titles", "='SCM AV Data'!C4:C5,'SCM AV Data'!R10", False))
      sheet.Table.DefaultRowHeight = 15.0!
      'sheet.Table.ExpandedColumnCount = 28
      sheet.Table.FullColumns = 1
      sheet.Table.FullRows = 1
      Dim column0 As WorksheetColumn = sheet.Table.Columns.Add
      column0.Hidden = True
      column0.Span = 1
      Dim column1 As WorksheetColumn = sheet.Table.Columns.Add
      column1.Index = 4
      column1.Width = 93
      sheet.Table.Columns.Add(240)
      sheet.Table.Columns.Add(240)
      sheet.Table.Columns.Add(240)
      sheet.Table.Columns.Add(60)
      Dim column4 As WorksheetColumn = sheet.Table.Columns.Add
      column4.Width = 100
      Dim column5 As WorksheetColumn = sheet.Table.Columns.Add
      column5.Index = 10
      column5.Width = 110
      sheet.Table.Columns.Add(110)
      sheet.Table.Columns.Add(110)

      Dim column7 As WorksheetColumn = sheet.Table.Columns.Add
      column7.Width = 60
      column7.Span = 1
      Dim column8 As WorksheetColumn = sheet.Table.Columns.Add
      column8.Index = 15
      column8.Width = 60
      column8.Span = 1
      Dim column9 As WorksheetColumn = sheet.Table.Columns.Add
      If prodInfo.BsamFlag Then
        column9.Index = 19
        column9.Width = 100
      Else
        column9.Index = 17
        column9.Width = 100
      End If
      sheet.Table.Columns.Add(92)
      sheet.Table.Columns.Add(200)
      sheet.Table.Columns.Add(250)
      sheet.Table.Columns.Add(81)
      sheet.Table.Columns.Add(81)
      sheet.Table.Columns.Add(81)
      sheet.Table.Columns.Add(81)
      sheet.Table.Columns.Add(81)
      sheet.Table.Columns.Add(81)
      sheet.Table.Columns.Add(250)
      sheet.Table.Columns.Add(250)
      '-----------------------------------------------
      Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
      Row0.AutoFitHeight = False
      Row0.Cells.Add(prodInfo.ProductBrandID.ToString(), DataType.Number, "s62")
      Dim cell As WorksheetCell
      cell = Row0.Cells.Add 'Column A
      cell.StyleID = "s62"
      cell = Row0.Cells.Add 'Column B
      cell.Data.Type = DataType.String
      cell.Data.Text = "Product"
      cell.Index = 4
      cell = Row0.Cells.Add 'Column C
      cell.StyleID = "s63"
      cell.Data.Type = DataType.String
      cell.Data.Text = prodInfo.ProductLongName
      '-----------------------------------------------
      Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
      Row1.AutoFitHeight = False
      '   Row1.Cells.Add(ConfigurationManager.AppSettings.Get("ExcelMacroVersion").ToString(), DataType.String, "s62")
      Row1.Cells.Add("1.0.4.0", DataType.String, "s62") 'hardcoded, at this point I don't think it matters anymore
      cell = Row1.Cells.Add
      cell.Data.Type = DataType.String
      cell.Data.Text = "KMAT"
      cell.Index = 4
      cell = Row1.Cells.Add
      cell.StyleID = "s64"
      cell.Data.Type = DataType.String
      cell.Data.Text = prodInfo.Kmat
      '-----------------------------------------------
      Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
      Row2.AutoFitHeight = False
      If prodInfo.BsamFlag Then
        Row2.Cells.Add("BSAM", DataType.String, "s62")
      End If
      cell = Row2.Cells.Add
      cell.Data.Type = DataType.String
      cell.Data.Text = "EZCKMAT"
      cell.Index = 4
      cell = Row2.Cells.Add
      cell.StyleID = "s64"
      cell.Data.Type = DataType.String
      cell.Data.Text = prodInfo.EzcKmat
      '-----------------------------------------------
      Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
      Row3.AutoFitHeight = False
      cell = Row3.Cells.Add
      cell.Data.Type = DataType.String
      cell.Data.Text = "Project Code"
      cell.Index = 4
      cell = Row3.Cells.Add
      cell.StyleID = "s64"
      cell.Data.Type = DataType.String
      cell.Data.Text = prodInfo.ProjectCode
      '-----------------------------------------------
      Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
      Row4.AutoFitHeight = False
      cell = Row4.Cells.Add
      cell.Data.Type = DataType.String
      cell.Data.Text = "Plant Code"
      cell.Index = 4
      cell = Row4.Cells.Add
      cell.StyleID = "s64"
      cell.Data.Type = DataType.String
      cell.Data.Text = prodInfo.PlantCode
      '-----------------------------------------------
      Dim Row5 As WorksheetRow = sheet.Table.Rows.Add
      Row5.AutoFitHeight = False
      cell = Row5.Cells.Add
      cell.Data.Type = DataType.String
      cell.Data.Text = "Sales Org"
      cell.Index = 4
      cell = Row5.Cells.Add
      cell.StyleID = "s64"
      cell.Data.Type = DataType.String
      cell.Data.Text = prodInfo.SalesOrg
      '-----------------------------------------------
      Dim Row6 As WorksheetRow = sheet.Table.Rows.Add
      Row6.Index = 8
      Row6.AutoFitHeight = False
      cell = Row6.Cells.Add
      cell.Data.Type = DataType.String
      cell.Data.Text = "Published"
      cell.Index = 4
      cell = Row6.Cells.Add
      cell.StyleID = "s65"
      If FormatExcelDate(prodInfo.ScmLastPublishDt) <> String.Empty Then
        cell.Data.Type = DataType.DateTime
        cell.Data.Text = FormatExcelDate(prodInfo.ScmLastPublishDt)
      End If
      '-----------------------------------------------
      Dim Row7 As WorksheetRow = sheet.Table.Rows.Add
      Row7.Height = 30
      Row7.AutoFitHeight = False
      cell = Row7.Cells.Add
      cell.Data.Type = DataType.String
      cell.Data.Text = "Exported"
      cell.Index = 4
      cell = Row7.Cells.Add
      cell.StyleID = "s65"
      cell.Data.Type = DataType.DateTime
      cell.Data.Text = FormatExcelDate(Now())
      '-----------------------------------------------
      Dim Row8 As WorksheetRow = sheet.Table.Rows.Add
      Row8.Height = 30
      Row8.AutoFitHeight = False
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Status"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "AV#"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "GPG Description"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Marketing Description" & Microsoft.VisualBasic.ChrW(10) & "(40 Char GPSy)"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Marketing Description" & Microsoft.VisualBasic.ChrW(10) & "(100 Char PMG)"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "SDF Flag"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "RTP Date"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Select Availability" & Microsoft.VisualBasic.ChrW(10) & "(SA) Date"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "General Availability" & Microsoft.VisualBasic.ChrW(10) & "(GA) Date"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "End of Manufacturing" & Microsoft.VisualBasic.ChrW(10) & "(EM) Date"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s67"
      'cell.Data.Type = DataType.String
      'cell.Data.Text = "PA:AD" & Microsoft.VisualBasic.ChrW(10) & "(Intro Date)"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "IDS-SKUS"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "IDS-CTO"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "RCTO-SKUS"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "RCTO-CTO"
      If prodInfo.BsamFlag Then
        cell = Row8.Cells.Add
        cell.StyleID = "s67"
        cell.Data.Type = DataType.String
        cell.Data.Text = "BSAM SKUS"
        cell = Row8.Cells.Add
        cell.StyleID = "s67"
        cell.Data.Type = DataType.String
        cell.Data.Text = "BSAM" & Microsoft.VisualBasic.ChrW(10) & "-B parts"
      End If
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "UPC"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Weight (in oz)"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Global Series Config Plan for" & Microsoft.VisualBasic.ChrW(10) & "End of Manufacturing (PE) Date"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Configuration Rules"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "AVID"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Group 1"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Group 2"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Group 3"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Group 4"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Group 5"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Manufacturing Notes"
      cell = Row8.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.String
      cell.Data.Text = "PhWeb Instructions"

      Dim Row As WorksheetRow
      Dim iLastCategory As Integer = 0
      Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
      Dim dt As DataTable
      dt = dwExcalibur.SelectWorkingScmDetail(prodInfo.ProductBrandID.ToString())
      Dim strMinMaxValue As String
      For Each dRow As DataRow In dt.Rows
        strMinMaxValue = String.Empty
        If iLastCategory <> dRow("FeatureCategoryID") Then
          iLastCategory = dRow("FeatureCategoryID")
          '-----------------------------------------------
          ' Category Row
          '-----------------------------------------------
          Row = sheet.Table.Rows.Add
          Row.AutoFitHeight = True
          Row.Cells.Add("C", DataType.String, "s69")
          Row.Cells.Add(dRow("FeatureCategoryID").ToString(), DataType.Number, "s69")
          Row.Cells.Add(dRow("AvFeatureCategory").ToString(), DataType.String, "s70")
          'cell = Row.Cells.Add
          'cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          If prodInfo.BsamFlag Then
            cell = Row.Cells.Add
            cell.StyleID = "s70"
            cell = Row.Cells.Add
            cell.StyleID = "s70"
          End If
          Row.Cells.Add(dRow("CategoryRules").ToString(), DataType.String, "s69")
          cell = Row.Cells.Add
          If (Not IsDBNull(dRow("CatMin"))) Then
            Row.Cells.Add("Min=" & dRow("CatMin").ToString(), DataType.String, "s69")
          Else
            cell.StyleID = "s70"
            cell = Row.Cells.Add
          End If
          If (Not IsDBNull(dRow("CatMin"))) Then
            Row.Cells.Add("Max=" & dRow("CatMax").ToString(), DataType.String, "s69")
          Else
            cell.StyleID = "s70"
            cell = Row.Cells.Add
          End If

          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          cell = Row.Cells.Add
          cell.StyleID = "s70"
          Row.Cells.Add(dRow("CategoryNotes").ToString(), DataType.String, "s69")
          cell = Row.Cells.Add
          cell.StyleID = "s70"
        End If
        '-----------------------------------------------
        ' AV Row
        '-----------------------------------------------
        Row = sheet.Table.Rows.Add
        Row.AutoFitHeight = True
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell = Row.Cells.Add
        cell.Data.Type = DataType.Number
        cell.Data.Text = dRow("AvDetailID").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("Status").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("AvNo").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("GPGDescription").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("MarketingDescription").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("MarketingDescriptionPMG").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("SDFFlag").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("RTPDate").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("CplBlindDt").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("GeneralAvailDt").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("RasDiscontinueDt").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        'cell.Data.Text = dRow("PAADDate").ToString()
        'cell = Row.Cells.Add
        'cell.Data.Type = DataType.String
        If dRow("IdsSkus_YN").ToString() = "Y" Then cell.Data.Text = "X"
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        If dRow("IdsCto_YN").ToString() = "Y" Then cell.Data.Text = "X"
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        If dRow("RctoSkus_YN").ToString() = "Y" Then cell.Data.Text = "X"
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        If dRow("RctoCto_YN").ToString() = "Y" Then cell.Data.Text = "X"
        If prodInfo.BsamFlag Then
          cell = Row.Cells.Add
          cell.Data.Type = DataType.String
          If dRow("BSAMSkus_YN").ToString() = "Y" Then cell.Data.Text = "X"
          cell = Row.Cells.Add
          cell.Data.Type = DataType.String
          If dRow("BSAMBparts_YN").ToString() = "Y" Then cell.Data.Text = "X"
        End If
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("UPC").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("Weight").ToString()
        cell = Row.Cells.Add
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("GsEndDt").ToString()
        cell = Row.Cells.Add
        cell.StyleID = "s72"
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("ConfigRules").ToString()
        cell = Row.Cells.Add
        cell.StyleID = "s72"
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("AvId").ToString()
        cell = Row.Cells.Add
        cell.StyleID = "s72"
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("Group1").ToString()
        cell = Row.Cells.Add
        cell.StyleID = "s72"
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("Group2").ToString()
        cell = Row.Cells.Add
        cell.StyleID = "s72"
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("Group3").ToString()
        cell = Row.Cells.Add
        cell.StyleID = "s72"
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("Group4").ToString()
        cell = Row.Cells.Add
        cell.StyleID = "s72"
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("Group5").ToString()
        cell = Row.Cells.Add
        cell.StyleID = "s72"
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("ManufacturingNotes").ToString()
        cell = Row.Cells.Add
        cell.StyleID = "s72"
        cell.Data.Type = DataType.String
        cell.Data.Text = dRow("PhWebInstruction").ToString()


      Next
      '-----------------------------------------------
      ' Options
      '-----------------------------------------------
      sheet.Options.Selected = True
      sheet.Options.FitToPage = True
      sheet.Options.ProtectObjects = False
      sheet.Options.ProtectScenarios = False
      sheet.Options.PageSetup.Layout.Orientation = Orientation.Landscape
      sheet.Options.PageSetup.Layout.CenterHorizontal = True
      sheet.Options.PageSetup.Footer.Data = "&LHP Confidential&CPage &P of &N&R&F" & Microsoft.VisualBasic.ChrW(10) & "&A"
      sheet.Options.PageSetup.Footer.Margin = 0.25!
      sheet.Options.PageSetup.PageMargins.Bottom = 0.5!
      sheet.Options.PageSetup.PageMargins.Left = 0.25!
      sheet.Options.PageSetup.PageMargins.Right = 0.25!
      sheet.Options.PageSetup.PageMargins.Top = 0.5!
      sheet.Options.Print.FitHeight = 100
      sheet.Options.Print.ValidPrinterInfo = True
    End Sub
#End Region

#Region " Format Excel Date "

    Function FormatExcelDate(ByVal dt As Date) As String
      If dt = New Date Then
        Return String.Empty
      End If

      Dim s As StringBuilder = New StringBuilder
      s.Append(dt.Year.ToString.Trim())
      s.Append("-")
      s.Append(dt.Month.ToString.PadLeft(2, "0"))
      s.Append("-")
      s.Append(dt.Day.ToString.PadLeft(2, "0"))
      s.Append("T")
      s.Append(dt.Hour.ToString.PadLeft(2, "0"))
      s.Append(":")
      s.Append(dt.Minute.ToString.PadLeft(2, "0"))
      s.Append(":")
      s.Append(dt.Second.ToString.PadLeft(2, "0"))
      s.Append(".000")

      Return s.ToString.Trim
    End Function


#End Region
  End Class

#Region " Class ProductInfo "
  Class ProductInfo
    Private _productBrandID As Long
    Public Property ProductBrandID() As Long
      Get
        Return _productBrandID
      End Get
      Set(ByVal value As Long)
        _productBrandID = value
        Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
        Dim dt As DataTable = dwExcalibur.SelectKMAT(_productBrandID.ToString())
        _productVersionID = dt.Rows(0)("ProductVersionID")
        _kmat = dt.Rows(0)("KMAT").ToString()
        _ezcKmat = dt.Rows(0)("EzcKmat").ToString()
        _projectCode = dt.Rows(0)("ProjectCd").ToString()
        _plantCode = dt.Rows(0)("PlantCd").ToString()
        _salesOrg = dt.Rows(0)("SalesOrg").ToString()

        dt = dwExcalibur.ListScmNames(String.Empty, ProductBrandID)
        _productVersion = dt.Rows(0)("Version").ToString()
        _productName = String.Format("{0} {1} {2}", dt.Rows(0)("name"), dt.Rows(0)("version"), dt.Rows(0)("seriesname"))
        _productLongName = dt.Rows(0)("Name").ToString() & " " & dt.Rows(0)("version") & " - " & dt.Rows(0)("LongName").ToString()
        _family = dt.Rows(0)("Name").ToString()
        _series = dt.Rows(0)("SeriesName").ToString()
        Boolean.TryParse(dt.Rows(0)("BsamFlag").ToString(), _bsamFlag)
        If Not IsDBNull(dt.Rows(0)("LastPublishDt")) Then
          _scmLastPublishDt = dt.Rows(0)("LastPublishDt")
        End If

      End Set
    End Property

#Region " ReadOnly Properties "
    Private _productVersionID As Long
    Public ReadOnly Property ProductVersionID() As Long
      Get
        Return _productVersionID
      End Get
    End Property

    Private _kmat As String
    Public ReadOnly Property Kmat() As String
      Get
        Return _kmat
      End Get
    End Property

    Private _ezcKmat As String
    Public ReadOnly Property EzcKmat() As String
      Get
        Return _ezcKmat
      End Get
    End Property

    Private _projectCode As String
    Public ReadOnly Property ProjectCode() As String
      Get
        Return _projectCode
      End Get
    End Property

    Private _plantCode As String
    Public ReadOnly Property PlantCode() As String
      Get
        Return _plantCode
      End Get
    End Property

    Private _salesOrg As String
    Public ReadOnly Property SalesOrg() As String
      Get
        Return _salesOrg
      End Get
    End Property

    Private _productName As String
    Public ReadOnly Property ProductName() As String
      Get
        Return _productName
      End Get
    End Property

    Private _productLongName As String
    Public ReadOnly Property ProductLongName() As String
      Get
        Return _productLongName
      End Get
    End Property

    Private _productVersion As String
    Public ReadOnly Property ProductVersion() As String
      Get
        Return _productVersion
      End Get
    End Property

    Private _scmLastPublishDt As Date = Nothing
    Public ReadOnly Property ScmLastPublishDt() As Date
      Get
        Return _scmLastPublishDt
      End Get
    End Property

    Private _family As String
    Public ReadOnly Property Family() As String
      Get
        Return _family
      End Get
    End Property

    Private _series As String
    Public ReadOnly Property Series() As String
      Get
        Return _series
      End Get
    End Property

    Private _bsamFlag As Boolean
    Public ReadOnly Property BsamFlag() As Boolean
      Get
        Return _bsamFlag
      End Get
    End Property
#End Region

#Region " Constructors "
    Public Sub New()

    End Sub

    Public Sub New(ByVal ProductBrandID As Long)
      Me.ProductBrandID = ProductBrandID
    End Sub
#End Region

  End Class
#End Region

End Namespace