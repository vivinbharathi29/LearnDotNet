﻿Imports System.Text

Namespace CodeBehind

    Public Class StructureToBOM
        Inherits System.Web.UI.Page

        Private ReadOnly Property PVID() As String
            Get
                Return Request.QueryString("PVID")
            End Get
        End Property

        Private ReadOnly Property BrandID() As String
            Get
                Return Request.QueryString("BID")
            End Get
        End Property

        Private ReadOnly Property KMAT() As String
            Get
                Return Request.QueryString("KMAT")
            End Get
        End Property

        Private ReadOnly Property UserName() As String
            Get
                Return Request.QueryString("User")
            End Get
        End Property

        Private ReadOnly Property ChildOnBOM() As String
            Get
                Return Request.QueryString("Child")
            End Get
        End Property

        Private ReadOnly Property ParentOnBOM() As String
            Get
                Return Request.QueryString("Parent")
            End Get
        End Property

        Private ReadOnly Property ItemNumber() As String
            Get
                Return Request.QueryString("ItemNumber")
            End Get
        End Property

        Protected Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If Not Page.IsPostBack And BrandID <> "" Then
                Dim excaliburData As HPQ.Excalibur.Data = New HPQ.Excalibur.Data

                Dim StructureToBOM As StructureToBOMRequest.StructureToBOMRequest = New StructureToBOMRequest.StructureToBOMRequest

                Dim strm As System.IO.MemoryStream = New System.IO.MemoryStream
                Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
                Dim dt As DataTable = dw.ListScmNames(String.Empty, BrandID)

                Dim sFamily As String = dt.Rows(0)("Name").ToString()
                Dim sVersion As String = dt.Rows(0)("Version").ToString()
                Dim sSeries As String = dt.Rows(0)("SeriesName").ToString()
                Dim sKmat As String = dt.Rows(0)("KMAT").ToString()


                Dim saFileName(5) As String
                saFileName(0) = sFamily
                saFileName(1) = sVersion
                saFileName(2) = sSeries
                saFileName(3) = "StructureToBOM"
                saFileName(4) = String.Format("{0}{1}{2}", Now.Year.ToString(), Now.Month.ToString.PadLeft(2, "0"), Now.Day.ToString.PadLeft(2, "0"))
                Dim fileName As String = String.Format("{0}_{1}_{2}_{3}_{4}.xls", saFileName)
                fileName = fileName.Replace(" ", "_")
                For Each character As Char In System.IO.Path.GetInvalidFileNameChars()
                    fileName = fileName.Replace(character, "_")
                Next

                StructureToBOM.PVID = PVID
                StructureToBOM.BrandID = BrandID
                StructureToBOM.KMAT = KMAT
                StructureToBOM.UserName = UserName
                StructureToBOM.ChildOnBOM = ChildOnBOM
                StructureToBOM.ParentOnBOM = ParentOnBOM
                StructureToBOM.ItemNumber = ItemNumber
                StructureToBOM.Generate(strm)

                Response.Clear()
                Response.AddHeader("Content-Disposition", String.Format("attachment; filename={0}", fileName))
                Response.ContentType = "application/vnd.ms-excel"

                Dim outputString As StringBuilder = New StringBuilder(2048)

                Dim b As Integer
                Dim prevChar1 As Char = ""
                Dim prevChar2 As Char = ""
                strm.Position = 3
                While True
                    b = strm.ReadByte()
                    If b = -1 Then Exit While
                    If b > 31 And b < 127 Or b = 10 Then
                        If prevChar2 <> Convert.ToChar(">") And b = 10 Then
                            outputString.Append("&#10;")
                        Else
                            outputString.Append(Convert.ToChar(b))
                        End If
                    End If
                    prevChar2 = prevChar1
                    prevChar1 = Convert.ToChar(b)

                End While

                Response.Write(outputString.ToString())
            End If
        End Sub

    End Class
End Namespace
