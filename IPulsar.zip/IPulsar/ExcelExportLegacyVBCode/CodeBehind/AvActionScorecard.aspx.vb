﻿
Imports System.Text

Namespace CodeBehind
    Public Class AvActionScorecard
        Inherits System.Web.UI.Page

        Private ReadOnly Property ToDate() As String
            Get
                Return Request.QueryString("ToDate")
            End Get
        End Property

        Private ReadOnly Property FromDate() As String
            Get
                Return Request.QueryString("FromDate")
            End Get
        End Property

        Private ReadOnly Property Days() As String
            Get
                Return Request.QueryString("Days")
            End Get
        End Property

        Private ReadOnly Property DateRangeType() As String
            Get
                Return Request.QueryString("DateRangeType")
            End Get
        End Property

        Private ReadOnly Property PVIDs() As String
            Get
                Return Request.QueryString("PVIDs")
            End Get
        End Property

        Private ReadOnly Property Status() As String
            Get
                Return Request.QueryString("Status")
            End Get
        End Property

        Protected Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If Not Page.IsPostBack Then
                Dim excaliburData As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
                Dim AvActionScorecard As New SCAvActionScorecardRequest.SCAvActionScorecardRequest
                Dim strm As System.IO.MemoryStream = New System.IO.MemoryStream
                Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()

                Dim fileName As String = "AvActionScorecard_" & Now.Year.ToString() & "_" & Now.Month.ToString.PadLeft(2, "0") & "_" & Now.Day.ToString.PadLeft(2, "0") & ".xls"

                AvActionScorecard.ToDate = ToDate
                AvActionScorecard.FromDate = FromDate
                AvActionScorecard.Days = Days
                AvActionScorecard.DateRangeType = DateRangeType
                AvActionScorecard.PVIDs = PVIDs
                AvActionScorecard.Status = Status
                AvActionScorecard.Generate(strm)

                Response.Clear()
                Response.AddHeader("Content-Disposition", String.Format("attachment; filename={0}", fileName))
                Response.ContentType = "application/vnd.ms-excel"

                Dim outputString As StringBuilder = New StringBuilder(2048)

                Dim b As Integer
                Dim prevChar1 As Char = ""
                Dim prevChar2 As Char = ""
                strm.Position = 3
                While True
                    b = strm.ReadByte()
                    If b = -1 Then Exit While
                    If b > 31 And b < 127 Or b = 10 Then
                        If prevChar2 <> Convert.ToChar(">") And b = 10 Then
                            outputString.Append("&#10;")
                        Else
                            outputString.Append(Convert.ToChar(b))
                        End If
                    End If
                    prevChar2 = prevChar1
                    prevChar1 = Convert.ToChar(b)

                End While

                Response.Write(outputString.ToString())
            End If
        End Sub

    End Class
End Namespace
