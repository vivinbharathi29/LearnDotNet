Imports System.Data.SqlClient
Imports System.Text
Imports CarlosAg.ExcelXmlWriter

Namespace CodeBehind

    Public Class SCM
        Inherits System.Web.UI.Page

#Region " Properties "
        Private ReadOnly Property ProductVersionID() As String
            Get
                Return Request.QueryString("PVID")
            End Get
        End Property

        Private ReadOnly Property ProductBrandID() As String
            Get
                Return Request.QueryString("BID")
            End Get
        End Property

        Private ReadOnly Property RegionID() As String
            Get
                Return Request.QueryString("RegionID")
            End Get
        End Property

        Private ReadOnly Property SCMPlants() As String
            Get
                Return Request.QueryString("SCMPlants")
            End Get
        End Property

        Private ReadOnly Property SCMMktCamps() As String
            Get
                Return Request.QueryString("SCMMktCamps")
            End Get
        End Property

        Private ReadOnly Property Publish() As Boolean
            Get
                Dim returnValue As Boolean = False
                Boolean.TryParse(Request.QueryString("Publish"), returnValue)
                Return returnValue
            End Get
        End Property

        Dim _LastPublishDate As DateTime
        Private Property LastPublishDate() As DateTime
            Get
                Return _LastPublishDate
            End Get
            Set(ByVal value As DateTime)
                _LastPublishDate = value
            End Set
        End Property

        Dim _DisplayedPublishDate As DateTime
        Private Property DisplayedPublishDate() As DateTime
            Get
                Return _DisplayedPublishDate
            End Get
            Set(ByVal value As DateTime)
                _DisplayedPublishDate = value
            End Set
        End Property

        Private ReadOnly Property ScitPublish() As Boolean
            Get
                Dim returnValue As Boolean = False

                Boolean.TryParse(Request.QueryString("ScitPublish"), returnValue)
                Return returnValue
            End Get
        End Property
#End Region

#Region " Page Load "
        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
            Dim dt As DataTable = dw.ListScmNames(String.Empty, ProductBrandID)
            Dim programVersion As String = dt.Rows(0)("Version")
            Dim scmName As String = dt.Rows(0)("Name").ToString() & " " & dt.Rows(0)("version") & " - " & dt.Rows(0)("LongName").ToString()

            Dim fusion As Boolean = dt.Rows(0)("Fusion")

            Dim SCMPlantsID As String = ""
            Dim SCMPlantsName As String = ""
            If (SCMPlants <> "") Then
                Dim sSCMPlants() As String = SCMPlants.Split(":")
                SCMPlantsID = sSCMPlants(0)
                SCMPlantsName = sSCMPlants(1)
            End If

            Dim SCMMktCampsID As String = ""
            Dim SCMMktCampsName As String = ""
            If (SCMMktCamps <> "") Then
                Dim sSCMMktCamps() As String = SCMMktCamps.Split(":")
                SCMMktCampsID = sSCMMktCamps(0)
                SCMMktCampsName = sSCMMktCamps(1)
            End If

            If (RegionID = "") Then
                scmName = scmName
            Else
                If (SCMPlants = "") Then
                    If (SCMMktCamps = "") Then 'Regional View
                        scmName = scmName & " - " & RegionID & " Regional View"
                    Else 'Marketing View
                        scmName = scmName & " - " & SCMMktCampsName & " Marketing Campaign: " & RegionID & " Regional View"
                    End If
                Else
                    If (SCMMktCamps = "") Then 'Plant View
                        scmName = scmName & " - " & SCMPlantsName & " Plant: " & RegionID & " Regional View"
                    Else
                        scmName = scmName & " - " & SCMMktCampsName & " Marketing Campaign: " & RegionID & " Regional View"
                    End If
                End If
            End If

            'intRegionID, SCMPlants, SCMMktCamps

            Dim sUserName As String = User.Identity.Name
            Dim aFileName(3) As String
            aFileName(0) = dt.Rows(0)("seriesname").ToString.Trim
            aFileName(1) = dt.Rows(0)("name").ToString.Trim
            aFileName(2) = dt.Rows(0)("version").ToString.Trim
            aFileName(3) = Now.ToString("MMM_dd_yyyy")
            Dim fileName As String = String.Format("SCM_{0}_{1}_{2}_{3}.xls", aFileName)

            For Each character As Char In System.IO.Path.GetInvalidFileNameChars()
                fileName = fileName.Replace(character, "_")
            Next


            If Not IsDBNull(dt.Rows(0)("LastPublishDt")) Then
                LastPublishDate = dt.Rows(0)("LastPublishDt")
            Else
                LastPublishDate = Now()
            End If

            If Publish Then
                DisplayedPublishDate = Now()

                dw.InsertScmPublishEvent(ProductBrandID, User.Identity.Name)
            Else
                DisplayedPublishDate = LastPublishDate
            End If

            If ScitPublish Then
                dw.InsertScmScitPublishEvent(ProductBrandID, User.Identity.Name)
            End If

            Generate(fileName, programVersion, scmName, SCMPlantsID, SCMMktCampsID)

            If Publish Then
                dw.SetSCMPublishDt(ProductBrandID, User.Identity.Name)
                If (fusion) Then
                    Dim dtdw As HPQ.Data.DataWrapper = New HPQ.Data.DataWrapper()
                    Dim cmd As SqlCommand = dtdw.CreateCommand("dbo.usp_SSSB_SendSync_Message")
                    dtdw.CreateParameter(cmd, "@Operation", SqlDbType.VarChar, "MSMQLegacy")
                    dtdw.CreateParameter(cmd, "@TypeID", SqlDbType.Int, 8)
                    dtdw.CreateParameter(cmd, "@ObjectID", SqlDbType.VarChar, ProductBrandID)
                    dtdw.CreateParameter(cmd, "@Arg", SqlDbType.Int, 1)
                    dtdw.CreateParameter(cmd, "@source", SqlDbType.VarChar, "SCM")
                    dtdw.ExecuteCommandNonQuery(cmd)
                End If
            End If
        End Sub
#End Region

#Region " XmlEncode "
        Public Function XmlEncode(ByVal strText As String) As String
            Return strText
        End Function
#End Region

#Region " ConvertYN "
        Function ConvertYN(ByVal value As String) As String

            Dim returnValue As String = String.Empty

            If Trim(UCase(value)) = "Y" Then
                returnValue = "X"
            End If

            Return returnValue

        End Function
#End Region

#Region " GetCellStyle "
        Function GetCellStyle(ByVal ChangedBit As Object) As String
            If IsDBNull(ChangedBit) Then
                ChangedBit = False
            End If

            If ChangedBit Then
                GetCellStyle = "s32"
            Else
                GetCellStyle = "s31"
            End If
        End Function
#End Region

#Region " FormatDate "
        Function FormatDate(ByVal Value As String) As String
            Dim ReturnValue As String = ""
            'Test Change
            If IsDate(Value) Then
                ReturnValue = Date.Parse(Value).ToShortDateString
            End If

            Return ReturnValue
        End Function
#End Region

#Region " Generate Workbook "
        Public Sub Generate(ByVal FileName As String, ByVal ProgramVersion As String, ByVal ScmName As String, ByVal SCMPlantsID As String, ByVal SCMMktCampsID As String)

            Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data

            Dim BSAMInfo As BSAMBoolInfo = New BSAMBoolInfo(ProductBrandID)
            Dim bolBSAMProd As Boolean = BSAMInfo.BsamFlag

            Dim book As Workbook = New Workbook
            '-----------------------------------------------
            ' Properties
            '-----------------------------------------------
            book.Properties.Title = "Excalibur Generated SCM"
            book.Properties.Author = ""
            book.Properties.LastAuthor = ""
            book.Properties.Created = New Date(2000, 1, 24, 13, 36, 9, 0)
            book.Properties.LastSaved = New Date(2006, 5, 10, 17, 50, 25, 0)
            book.Properties.Version = "11.6408"
            book.ExcelWorkbook.WindowHeight = 4785
            book.ExcelWorkbook.WindowWidth = 7650
            book.ExcelWorkbook.WindowTopX = 7665
            book.ExcelWorkbook.WindowTopY = -15
            book.ExcelWorkbook.ActiveSheetIndex = 2
            book.ExcelWorkbook.ProtectWindows = False
            book.ExcelWorkbook.ProtectStructure = False
            '-----------------------------------------------
            ' Generate Styles
            '-----------------------------------------------
            Me.GenerateStyles(book.Styles)
            '-----------------------------------------------
            ' Generate Using the SCM - Contacts&Terms Worksheet
            '-----------------------------------------------
            Me.GenerateWorksheetUsingtheSCMContactsTerms(book.Worksheets, ScmName, bolBSAMProd)
            '-----------------------------------------------
            ' Generate SCM Change Log Worksheet
            '-----------------------------------------------
            Me.GenerateWorksheetSCMChangeLog(book.Worksheets, ScmName)
            '-----------------------------------------------
            ' Generate SCM AV Data Worksheet
            '-----------------------------------------------
            Me.GenerateWorksheetSCMAVData(book.Worksheets, ScmName, ProgramVersion, SCMPlantsID, SCMMktCampsID, bolBSAMProd)
            '-----------------------------------------------
            ' Generate Obsolete SCM AV Data Worksheet
            '-----------------------------------------------
            Me.GenerateWorksheetObsoleteSCMAVData(book.Worksheets, ScmName, ProductVersionID, bolBSAMProd)
            '-----------------------------------------------
            ' Generate SCM Platform data Worksheet
            '-----------------------------------------------
            Me.GenerateWorksheetSCMPlatformdata(book.Worksheets, ScmName)

            Response.Clear()
            Response.AddHeader("Content-Disposition", String.Format("attachment; filename={0}", FileName))
            Response.ContentType = "application/vnd.ms-excel"

            Dim strm As System.IO.Stream = New System.IO.MemoryStream()
            book.Save(strm)

            Dim outputString As StringBuilder = New StringBuilder(2048)

            Dim b As Integer
            Dim prevChar1 As Char = ""
            Dim prevChar2 As Char = ""
            strm.Position = 3
            While True
                b = strm.ReadByte()
                If b = -1 Then Exit While
                If b > 31 And b < 127 Or b = 10 Then
                    If prevChar2 <> Convert.ToChar(">") And b = 10 Then
                        outputString.Append("&#10;")
                    Else
                        outputString.Append(Convert.ToChar(b))
                    End If
                End If
                prevChar2 = prevChar1
                prevChar1 = Convert.ToChar(b)

            End While

            Response.Write(outputString.ToString())

            'book.Save(Response.OutputStream)
            'Response.End()
        End Sub
#End Region

#Region " Generate Styles "
        Private Sub GenerateStyles(ByVal styles As WorksheetStyleCollection)
            '-----------------------------------------------
            ' Default
            '-----------------------------------------------
            Dim [Default] As WorksheetStyle = styles.Add("Default")
            [Default].Name = "Normal"
            [Default].Alignment.Vertical = StyleVerticalAlignment.Top
            '-----------------------------------------------
            ' m19709554
            '-----------------------------------------------
            Dim m19709554 As WorksheetStyle = styles.Add("m19709554")
            m19709554.Font.Bold = True
            m19709554.Font.Size = 12
            m19709554.Alignment.Horizontal = StyleHorizontalAlignment.Left
            m19709554.Alignment.Vertical = StyleVerticalAlignment.Top
            m19709554.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            m19709554.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            m19709554.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' m19709564
            '-----------------------------------------------
            Dim m19709564 As WorksheetStyle = styles.Add("m19709564")
            m19709564.Font.Bold = True
            m19709564.Font.Size = 12
            m19709564.Alignment.Horizontal = StyleHorizontalAlignment.Left
            m19709564.Alignment.Vertical = StyleVerticalAlignment.Top
            m19709564.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            m19709564.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            m19709564.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' m19709574
            '-----------------------------------------------
            Dim m19709574 As WorksheetStyle = styles.Add("m19709574")
            m19709574.Font.Bold = True
            m19709574.Font.Size = 12
            m19709574.Alignment.Horizontal = StyleHorizontalAlignment.Left
            m19709574.Alignment.Vertical = StyleVerticalAlignment.Top
            m19709574.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            m19709574.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            m19709574.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s11
            '-----------------------------------------------
            Dim s11 As WorksheetStyle = styles.Add("s11")
            s11.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s11.Alignment.Vertical = StyleVerticalAlignment.Top
            s11.Alignment.WrapText = True
            s11.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s11.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s11.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s11.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s21
            '-----------------------------------------------
            Dim s21 As WorksheetStyle = styles.Add("s21")
            s21.Font.Bold = True
            s21.Font.Size = 20
            '-----------------------------------------------
            ' h21
            '-----------------------------------------------
            Dim h21 As WorksheetStyle = styles.Add("h21")
            h21.Font.Bold = True
            h21.Font.Size = 20
            h21.Font.Color = "#FF0000"
            '-----------------------------------------------
            ' s22
            '-----------------------------------------------
            Dim s22 As WorksheetStyle = styles.Add("s22")
            s22.Font.Bold = True
            s22.Font.Size = 12
            s22.Font.Color = "#0000FF"
            '-----------------------------------------------
            ' s23
            '-----------------------------------------------
            Dim s23 As WorksheetStyle = styles.Add("s23")
            s23.Font.Bold = True
            s23.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s23.Alignment.Vertical = StyleVerticalAlignment.Top
            s23.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s23.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s23.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s23.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s24
            '-----------------------------------------------
            Dim s24 As WorksheetStyle = styles.Add("s24")
            s24.Font.Bold = True
            s24.Interior.Color = "#FFFF00"
            s24.Interior.Pattern = StyleInteriorPattern.Solid
            s24.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s24.Alignment.Vertical = StyleVerticalAlignment.Top
            s24.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s24.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s24.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s24.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s25
            '-----------------------------------------------
            Dim s25 As WorksheetStyle = styles.Add("s25")
            s25.Font.Bold = True
            s25.Interior.Color = "#00CCFF"
            s25.Interior.Pattern = StyleInteriorPattern.Solid
            s25.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s25.Alignment.Vertical = StyleVerticalAlignment.Top
            s25.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s25.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s25.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s25.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s26
            '-----------------------------------------------
            Dim s26 As WorksheetStyle = styles.Add("s26")
            s26.Font.Bold = True
            s26.Interior.Color = "#99CC00"
            s26.Interior.Pattern = StyleInteriorPattern.Solid
            s26.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s26.Alignment.Vertical = StyleVerticalAlignment.Top
            s26.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s26.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s26.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s26.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s27
            '-----------------------------------------------
            Dim s27 As WorksheetStyle = styles.Add("s27")
            s27.Font.Bold = True
            s27.Interior.Color = "#CCFFCC"
            s27.Interior.Pattern = StyleInteriorPattern.Solid
            s27.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s27.Alignment.Vertical = StyleVerticalAlignment.Top
            s27.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s27.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s27.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s27.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s28
            '-----------------------------------------------
            Dim s28 As WorksheetStyle = styles.Add("s28")
            s28.Font.Bold = True
            s28.Interior.Color = "#FF99CC"
            s28.Interior.Pattern = StyleInteriorPattern.Solid
            s28.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s28.Alignment.Vertical = StyleVerticalAlignment.Top
            s28.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s28.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s28.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s28.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s29
            '-----------------------------------------------
            Dim s29 As WorksheetStyle = styles.Add("s29")
            s29.Font.Bold = True
            s29.Interior.Color = "#C0C0C0"
            s29.Interior.Pattern = StyleInteriorPattern.Solid
            s29.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s29.Alignment.Vertical = StyleVerticalAlignment.Top
            s29.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s29.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s29.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s29.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s30
            '-----------------------------------------------
            Dim s30 As WorksheetStyle = styles.Add("s30")
            s30.Font.Bold = True
            s30.Interior.Color = "#C0C0C0"
            s30.Interior.Pattern = StyleInteriorPattern.Solid
            s30.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s30.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s30.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s30.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s31
            '-----------------------------------------------
            Dim s31 As WorksheetStyle = styles.Add("s31")
            s31.Alignment.Vertical = StyleVerticalAlignment.Center
            s31.Alignment.WrapText = True
            s31.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s31.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s31.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s31.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s32
            '-----------------------------------------------
            Dim s32 As WorksheetStyle = styles.Add("s32")
            s32.Interior.Color = "#FFFF99"
            s32.Interior.Pattern = StyleInteriorPattern.Solid
            s32.Alignment.Vertical = StyleVerticalAlignment.Center
            s32.Alignment.WrapText = True
            s32.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s32.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s32.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s32.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s33
            '-----------------------------------------------
            Dim s33 As WorksheetStyle = styles.Add("s33")
            s33.Font.Bold = True
            s33.Alignment.Vertical = StyleVerticalAlignment.Top
            s33.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s33.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s33.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s33.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s34
            '-----------------------------------------------
            Dim s34 As WorksheetStyle = styles.Add("s34")
            s34.Interior.Color = "#00FFFF"
            s34.Interior.Pattern = StyleInteriorPattern.Solid
            s34.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s34.Alignment.Vertical = StyleVerticalAlignment.Top
            s34.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s34.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s34.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s34.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s35
            '-----------------------------------------------
            Dim s35 As WorksheetStyle = styles.Add("s35")
            s35.Font.Bold = True
            s35.Font.Size = 12
            '-----------------------------------------------
            ' s36
            '-----------------------------------------------
            Dim s36 As WorksheetStyle = styles.Add("s36")
            s36.Font.Bold = True
            s36.Font.Size = 12
            s36.NumberFormat = "m/d/yyyy;@"
            '-----------------------------------------------
            ' s37
            '-----------------------------------------------
            Dim s37 As WorksheetStyle = styles.Add("s37")
            s37.Interior.Color = "#FFFF00"
            s37.Interior.Pattern = StyleInteriorPattern.Solid
            s37.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s37.Alignment.Vertical = StyleVerticalAlignment.Top
            s37.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s37.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s37.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s37.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s38
            '-----------------------------------------------
            Dim s38 As WorksheetStyle = styles.Add("s38")
            s38.Interior.Color = "#C0C0C0"
            s38.Interior.Pattern = StyleInteriorPattern.Solid
            s38.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s38.Alignment.Vertical = StyleVerticalAlignment.Top
            s38.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s38.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s38.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s38.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s39
            '-----------------------------------------------
            Dim s39 As WorksheetStyle = styles.Add("s39")
            s39.Font.Bold = True
            s39.Interior.Color = "#C0C0C0"
            s39.Interior.Pattern = StyleInteriorPattern.Solid
            s39.Alignment.Horizontal = StyleHorizontalAlignment.Right
            s39.Alignment.Vertical = StyleVerticalAlignment.Top
            s39.Alignment.WrapText = True
            s39.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s39.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s39.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s39.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s40
            '-----------------------------------------------
            Dim s40 As WorksheetStyle = styles.Add("s40")
            s40.Font.Bold = True
            s40.Interior.Color = "#C0C0C0"
            s40.Interior.Pattern = StyleInteriorPattern.Solid
            s40.Alignment.Vertical = StyleVerticalAlignment.Top
            s40.Alignment.WrapText = True
            s40.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s40.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s40.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s40.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s41
            '-----------------------------------------------
            Dim s41 As WorksheetStyle = styles.Add("s41")
            s41.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s41.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s41.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s41.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s41.NumberFormat = "m/d/yyyy;@"
            '-----------------------------------------------
            ' s42
            '-----------------------------------------------
            Dim s42 As WorksheetStyle = styles.Add("s42")
            s42.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s42.Alignment.Vertical = StyleVerticalAlignment.Top
            s42.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s42.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s42.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s42.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s43
            '-----------------------------------------------
            Dim s43 As WorksheetStyle = styles.Add("s43")
            s43.Font.Bold = True
            s43.Font.Size = 12
            s43.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s43.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s43.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s43.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s44
            '-----------------------------------------------
            Dim s44 As WorksheetStyle = styles.Add("s44")
            s44.Font.Bold = True
            s44.Font.Size = 12
            s44.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s44.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s44.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s44.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s44.NumberFormat = "m/d/yyyy;@"
            '-----------------------------------------------
            ' s45
            '-----------------------------------------------
            Dim s45 As WorksheetStyle = styles.Add("s45")
            s45.Interior.Color = "#C0C0C0"
            s45.Interior.Pattern = StyleInteriorPattern.Solid
            s45.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s45.Alignment.Vertical = StyleVerticalAlignment.Top
            s45.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s45.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s45.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s45.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s46
            '-----------------------------------------------
            Dim s46 As WorksheetStyle = styles.Add("s46")
            s46.Interior.Color = "#CCFFCC"
            s46.Interior.Pattern = StyleInteriorPattern.Solid
            s46.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s46.Alignment.Vertical = StyleVerticalAlignment.Top
            '-----------------------------------------------
            ' s47
            '-----------------------------------------------
            Dim s47 As WorksheetStyle = styles.Add("s47")
            s47.Font.Bold = True
            s47.Font.Size = 12
            s47.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s47.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s47.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s48
            '-----------------------------------------------
            Dim s48 As WorksheetStyle = styles.Add("s48")
            s48.Font.Bold = True
            s48.Font.Size = 12
            s48.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s48.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s48.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s48.NumberFormat = "m/d/yyyy;@"
            '-----------------------------------------------
            ' s56
            '-----------------------------------------------
            Dim s56 As WorksheetStyle = styles.Add("s56")
            s56.Font.Bold = True
            s56.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s56.Alignment.Vertical = StyleVerticalAlignment.Top
            s56.Alignment.WrapText = True
            s56.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s56.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s56.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s56.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s57
            '-----------------------------------------------
            Dim s57 As WorksheetStyle = styles.Add("s57")
            s57.Font.Bold = True
            s57.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s57.Alignment.Vertical = StyleVerticalAlignment.Top
            s57.Alignment.WrapText = True
            s57.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s57.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s57.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s57.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s58
            '-----------------------------------------------
            Dim s58 As WorksheetStyle = styles.Add("s58")
            s58.Font.Bold = True
            s58.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s58.Alignment.Rotate = 90
            s58.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s58.Alignment.WrapText = True
            s58.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s58.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s58.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s58.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s59
            '-----------------------------------------------
            Dim s59 As WorksheetStyle = styles.Add("s59")
            s59.Font.Bold = True
            s59.Font.Color = "#FF0000"
            s59.Interior.Color = "#FFFF00"
            s59.Interior.Pattern = StyleInteriorPattern.Solid
            s59.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s59.Alignment.Vertical = StyleVerticalAlignment.Center
            s59.Alignment.WrapText = True
            s59.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s59.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s59.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s59.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s60
            '-----------------------------------------------
            Dim s60 As WorksheetStyle = styles.Add("s60")
            s60.Font.Bold = True
            s60.Font.Color = "#FF0000"
            s60.Interior.Color = "#00CCFF"
            s60.Interior.Pattern = StyleInteriorPattern.Solid
            s60.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s60.Alignment.Vertical = StyleVerticalAlignment.Center
            s60.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s60.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s60.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s60.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s61
            '-----------------------------------------------
            Dim s61 As WorksheetStyle = styles.Add("s61")
            s61.Font.Bold = True
            s61.Font.Color = "#FF0000"
            s61.Interior.Color = "#99CC00"
            s61.Interior.Pattern = StyleInteriorPattern.Solid
            s61.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s61.Alignment.Vertical = StyleVerticalAlignment.Center
            s61.Alignment.WrapText = True
            s61.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s61.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s61.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s61.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s62
            '-----------------------------------------------
            Dim s62 As WorksheetStyle = styles.Add("s62")
            s62.Font.Bold = True
            s62.Interior.Color = "#000000"
            s62.Interior.Pattern = StyleInteriorPattern.Solid
            s62.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s62.Alignment.Vertical = StyleVerticalAlignment.Top
            s62.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s62.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s62.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s62.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s63
            '-----------------------------------------------
            Dim s63 As WorksheetStyle = styles.Add("s63")
            s63.Alignment.Vertical = StyleVerticalAlignment.Top
            s63.Alignment.WrapText = True
            s63.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s63.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s63.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s63.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s64
            '-----------------------------------------------
            Dim s64 As WorksheetStyle = styles.Add("s64")
            s64.Alignment.Vertical = StyleVerticalAlignment.Top
            s64.Alignment.WrapText = True
            '-----------------------------------------------
            ' s65
            '-----------------------------------------------
            Dim s65 As WorksheetStyle = styles.Add("s65")
            s65.Font.Bold = True
            s65.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s65.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s65.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s65.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s66
            '-----------------------------------------------
            Dim s66 As WorksheetStyle = styles.Add("s66")
            s66.NumberFormat = "Short Date"
            '-----------------------------------------------
            ' s67
            '-----------------------------------------------
            Dim s67 As WorksheetStyle = styles.Add("s67")
            s67.Font.Bold = True
            s67.Alignment.Vertical = StyleVerticalAlignment.Center
            s67.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s67.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s67.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s67.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s68
            '-----------------------------------------------
            Dim s68 As WorksheetStyle = styles.Add("s68")
            s68.Interior.Color = "#FFFF99"
            s68.Interior.Pattern = StyleInteriorPattern.Solid
            s68.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s68.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s68.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s68.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s71
            '-----------------------------------------------
            Dim s71 As WorksheetStyle = styles.Add("s71")
            s71.Font.Strikethrough = True
            '-----------------------------------------------
            ' s72
            '-----------------------------------------------
            Dim s72 As WorksheetStyle = styles.Add("s72")
            s72.Font.Strikethrough = True
            s72.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s72.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s72.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s72.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s73
            '-----------------------------------------------
            Dim s73 As WorksheetStyle = styles.Add("s73")
            s73.Font.Strikethrough = True
            s73.Alignment.Vertical = StyleVerticalAlignment.Top
            s73.Alignment.WrapText = True
            s73.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s73.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s73.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s73.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s74
            '-----------------------------------------------
            Dim s74 As WorksheetStyle = styles.Add("s74")
            s74.Font.Strikethrough = True
            s74.Interior.Color = "#FFFF99"
            s74.Interior.Pattern = StyleInteriorPattern.Solid
            s74.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s74.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s74.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s74.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s75
            '-----------------------------------------------
            Dim s75 As WorksheetStyle = styles.Add("s75")
            s75.Font.Strikethrough = True
            s75.Interior.Color = "#FFFF99"
            s75.Interior.Pattern = StyleInteriorPattern.Solid
            s75.Alignment.Vertical = StyleVerticalAlignment.Top
            s75.Alignment.WrapText = True
            s75.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s75.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s75.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s75.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s80
            '-----------------------------------------------
            Dim s80 As WorksheetStyle = styles.Add("s80")
            s80.Font.Bold = True
            s80.Font.Color = "#FF0000"
            s80.Interior.Color = "#000000"
            s80.Interior.Pattern = StyleInteriorPattern.Solid
            s80.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s80.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s80.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s80.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
        End Sub
#End Region

#Region " Generate Worksheet Contacts & Terms "
        Private Sub GenerateWorksheetUsingtheSCMContactsTerms(ByVal sheets As WorksheetCollection, ByVal ScmName As String, ByVal bolBSAMProd As Boolean)

            Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
            Dim dt As DataTable = dw.SelectSystemTeam(ProductVersionID)

            Dim sheet As Worksheet = sheets.Add("Using the SCM - Contacts&Terms")
            sheet.Names.Add(New WorksheetNamedRange("Print_Area", "='Using the SCM - Contacts&Terms'!R1C1:R47C6", False))
            sheet.Table.FullColumns = 1
            sheet.Table.FullRows = 1
            sheet.Table.Columns.Add(141)
            sheet.Table.Columns.Add(171)
            sheet.Table.Columns.Add(194)
            sheet.Table.Columns.Add(180)
            sheet.Table.Columns.Add(99)
            sheet.Table.Columns.Add(179)
            '-----------------------------------------------
            If ScitPublish Then
                Dim ScitRow As WorksheetRow = sheet.Table.Rows.Add
                ScitRow.Height = 26
                ScitRow.AutoFitHeight = False
                ScitRow.Cells.Add("SCIT PUBLISH FOR TESTING ONLY", DataType.String, "h21")
            End If

            Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
            Row0.Height = 26
            Row0.AutoFitHeight = False
            Dim cell As WorksheetCell
            cell = Row0.Cells.Add
            cell.StyleID = "s21"
            cell.Data.Type = DataType.String
            cell.Data.Text = ScmName
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
            Row1.AutoFitHeight = False
            '-----------------------------------------------
            Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
            Row2.Height = 15
            Row2.AutoFitHeight = False
            cell = Row2.Cells.Add
            cell.StyleID = "s22"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Contacts"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row3.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Business Function"
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Name"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row4.Cells.Add
            cell.StyleID = "s24"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row4.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = XmlEncode(dt.Rows(0)("pc_name").ToString)
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row5 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row5.Cells.Add
            cell.StyleID = "s25"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Marketing"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            Dim sMarketing As String = String.Empty
            If dt.Rows(0)("commercialmarketing_name").ToString.Trim <> "" Then
                sMarketing = ", " & Trim(XmlEncode(dt.Rows(0)("commercialmarketing_name").ToString))
            End If
            If dt.Rows(0)("smbmarketing_name").ToString.Trim <> "" Then
                sMarketing = sMarketing & ", " & Trim(XmlEncode(dt.Rows(0)("smbmarketing_name").ToString))
            End If
            If dt.Rows(0)("consumermarketing_name").ToString.Trim <> "" Then
                sMarketing = sMarketing & ", " & Trim(XmlEncode(dt.Rows(0)("consumermarketing_name").ToString))
            End If
            sMarketing = Mid(sMarketing, 2)
            cell.Data.Text = sMarketing
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row6 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row6.Cells.Add
            cell.StyleID = "s26"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PDM Team"
            cell.NamedCell.Add("Print_Area")
            Row6.Cells.Add(XmlEncode(dt.Rows(0)("MarketingOps_name").ToString), DataType.String, "s23")
            '-----------------------------------------------
            Dim Row7 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row7.Cells.Add
            cell.StyleID = "s27"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Supply Chain"
            cell.NamedCell.Add("Print_Area")
            cell = Row7.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = XmlEncode(dt.Rows(0)("supplychain_name").ToString)
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row8 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row8.Cells.Add
            cell.StyleID = "s28"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Plat Eng"
            cell.NamedCell.Add("Print_Area")
            cell = Row8.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = XmlEncode(dt.Rows(0)("platformdev_name").ToString)
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row9 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row9.Cells.Add
            cell.StyleID = "s29"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Service"
            cell.NamedCell.Add("Print_Area")
            cell = Row9.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = XmlEncode(dt.Rows(0)("service_name").ToString)
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row10 As WorksheetRow = sheet.Table.Rows.Add
            Row10.Index = 14
            Row10.Height = 15
            Row10.AutoFitHeight = False
            cell = Row10.Cells.Add
            cell.StyleID = "s22"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Guidelines for Change control "
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row11 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row11.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Item"
            cell.NamedCell.Add("Print_Area")
            cell = Row11.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Action required on SCM Data tab"
            cell.NamedCell.Add("Print_Area")
            cell = Row11.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Action required on Change Form tab"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row12 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row12.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Add AV#"
            cell.NamedCell.Add("Print_Area")
            cell = Row12.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Add in SCM document in Col A"
            cell.NamedCell.Add("Print_Area")
            cell = Row12.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Add in change log"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row13 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row13.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Delete AV#"
            cell.NamedCell.Add("Print_Area")
            cell = Row13.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Strike through AV# in Col A"
            cell.NamedCell.Add("Print_Area")
            cell = Row13.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "track on change log"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row14 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row14.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Marketing Description"
            cell.NamedCell.Add("Print_Area")
            cell = Row14.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Correct description"
            cell.NamedCell.Add("Print_Area")
            cell = Row14.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "track on change log (To/From) by AV#"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row15 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row15.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Typos/Correcting mistakes"
            cell.NamedCell.Add("Print_Area")
            cell = Row15.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Correct mistake"
            cell.NamedCell.Add("Print_Area")
            cell = Row15.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "track on change log (To/From) by AV#"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row16 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row16.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Date Changes"
            cell.NamedCell.Add("Print_Area")
            cell = Row16.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "strike through and put new date"
            cell.NamedCell.Add("Print_Area")
            cell = Row16.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "none"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row17 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row17.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Configuration Rules changes"
            cell.NamedCell.Add("Print_Area")
            cell = Row17.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "add/delete/correct changes"
            cell.NamedCell.Add("Print_Area")
            cell = Row17.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "track on change log in comments"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row18 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row18.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Localization changes"
            cell.NamedCell.Add("Print_Area")
            cell = Row18.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "add/delete/correct changes"
            cell.NamedCell.Add("Print_Area")
            cell = Row18.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "track on change log (To/From) by AV#"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row19 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row19.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "UPC changes"
            cell.NamedCell.Add("Print_Area")
            cell = Row19.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "add/delete/correct changes"
            cell.NamedCell.Add("Print_Area")
            cell = Row19.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "track on change log (To/From) by AV#"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row20 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row20.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Weight changes"
            cell.NamedCell.Add("Print_Area")
            cell = Row20.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "add/delete/correct changes"
            cell.NamedCell.Add("Print_Area")
            cell = Row20.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "track on change log (To/From) by AV#"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row21 As WorksheetRow = sheet.Table.Rows.Add
            If (bolBSAMProd = True) Then
                Row21.Index = 28
            Else
                Row21.Index = 26
            End If
            cell = Row21.Cells.Add
            cell.Data.Type = DataType.String
            cell.Data.Text = "Prior to 1st publish (1.0): The initial creation to initial publish, only AV#s ne" & "ed to be tracked on change control."
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row22 As WorksheetRow = sheet.Table.Rows.Add
            If (bolBSAMProd = True) Then
                Row22.Index = 31
            Else
                Row22.Index = 29
            End If
            Row22.Height = 15
            Row22.AutoFitHeight = False
            cell = Row22.Cells.Add
            cell.StyleID = "s22"
            cell.Data.Type = DataType.String
            cell.Data.Text = "SCM Field Documentation"
            cell.MergeAcross = 1
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row23 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row23.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Column Header (row 4)"
            cell.NamedCell.Add("Print_Area")
            cell = Row23.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Column Subheader (row 5)"
            cell.NamedCell.Add("Print_Area")
            cell = Row23.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Description"
            cell.NamedCell.Add("Print_Area")
            cell = Row23.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Populated By"
            cell.NamedCell.Add("Print_Area")
            cell = Row23.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "End User of Data"
            cell.NamedCell.Add("Print_Area")
            cell = Row23.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Comments"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row24 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row24.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "AV# "
            cell.NamedCell.Add("Print_Area")
            cell = Row24.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row24.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Feature Product ID (PID)"
            cell.NamedCell.Add("Print_Area")
            cell = Row24.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row24.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Region"
            cell.NamedCell.Add("Print_Area")
            cell = Row24.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row25 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row25.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Feature Category"
            cell.NamedCell.Add("Print_Area")
            cell = Row25.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "n/a"
            cell.NamedCell.Add("Print_Area")
            cell = Row25.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Main category of the feature"
            cell.NamedCell.Add("Print_Area")
            cell = Row25.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row25.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "KE"
            cell.NamedCell.Add("Print_Area")
            cell = Row25.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row26 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row26.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "GPG Description"
            cell.NamedCell.Add("Print_Area")
            cell = Row26.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row26.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "SAP global description of PID"
            cell.NamedCell.Add("Print_Area")
            cell = Row26.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row26.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "GBU, Region"
            cell.NamedCell.Add("Print_Area")
            cell = Row26.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row27 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row27.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Marketing  Description (30 Characters Max)"
            cell.NamedCell.Add("Print_Area")
            cell = Row27.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Marketing"
            cell.NamedCell.Add("Print_Area")
            cell = Row27.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Consumer description of PID"
            cell.NamedCell.Add("Print_Area")
            cell = Row27.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Marketing"
            cell.NamedCell.Add("Print_Area")
            cell = Row27.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "GPSy"
            cell.NamedCell.Add("Print_Area")
            cell = Row27.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row28 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row28.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Program Version where used"
            cell.NamedCell.Add("Print_Area")
            cell = Row28.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row28.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "x.y release of platform"
            cell.NamedCell.Add("Print_Area")
            cell = Row28.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row28.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "GBU, Region"
            cell.NamedCell.Add("Print_Area")
            cell = Row28.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row29 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row29.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = """"
            cell.NamedCell.Add("Print_Area")
            cell = Row29.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = """"
            cell.NamedCell.Add("Print_Area")
            cell = Row29.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "x.y+1 release of platform"
            cell.NamedCell.Add("Print_Area")
            cell = Row29.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row29.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "GBU, Region"
            cell.NamedCell.Add("Print_Area")
            cell = Row29.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "need to define rules"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row30 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row30.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "CPL Blind Date"
            cell.NamedCell.Add("Print_Area")
            cell = Row30.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PDM Team"
            cell.NamedCell.Add("Print_Area")
            cell = Row30.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "First date orders can be taken for this AV PID."
            cell.NamedCell.Add("Print_Area")
            cell = Row30.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PDM Team"
            cell.NamedCell.Add("Print_Area")
            cell = Row30.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Conrad order checker"
            cell.NamedCell.Add("Print_Area")
            cell = Row30.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "The date will be shown on the Base Unit row with exceptions only noted in the CPL" &
" Blind Date column"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row31 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row31.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "RAS Disc. Date"
            cell.NamedCell.Add("Print_Area")
            cell = Row31.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PDM Team"
            cell.NamedCell.Add("Print_Area")
            cell = Row31.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "RAS Discontinuation Date"
            cell.NamedCell.Add("Print_Area")
            cell = Row31.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PDM Team"
            cell.NamedCell.Add("Print_Area")
            cell = Row31.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "RAS Automation"
            cell.NamedCell.Add("Print_Area")
            cell = Row31.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "The date will be shown on the Base Unit row with exceptions only noted in the RAS" &
" Disc. Date column"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row32 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row32.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Configuration Rules"
            cell.NamedCell.Add("Print_Area")
            cell = Row32.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Engineering"
            cell.NamedCell.Add("Print_Area")
            cell = Row32.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Notes of capability and availability by region"
            cell.NamedCell.Add("Print_Area")
            cell = Row32.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "STL Program Manager"
            cell.NamedCell.Add("Print_Area")
            cell = Row32.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Region"
            cell.NamedCell.Add("Print_Area")
            cell = Row32.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row33 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row33.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "IDS-SKUS"
            cell.NamedCell.Add("Print_Area")
            cell = Row33.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row33.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "X = IDS-SKUS Fullfillment/Deployment"
            cell.NamedCell.Add("Print_Area")
            cell = Row33.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row33.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "KE"
            cell.NamedCell.Add("Print_Area")
            cell = Row33.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row34 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row34.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "IDS-CTO"
            cell.NamedCell.Add("Print_Area")
            cell = Row34.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row34.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "X = IDS-CTO Fullfillment/Deployment"
            cell.NamedCell.Add("Print_Area")
            cell = Row34.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row34.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "KE"
            cell.NamedCell.Add("Print_Area")
            cell = Row34.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row35 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row35.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "RCTO-SKUS"
            cell.NamedCell.Add("Print_Area")
            cell = Row35.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row35.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "X = RCTO-SKUS Fullfillment/Deployment"
            cell.NamedCell.Add("Print_Area")
            cell = Row35.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row35.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "KE"
            cell.NamedCell.Add("Print_Area")
            cell = Row35.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row36 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row36.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "RCTO-CTO"
            cell.NamedCell.Add("Print_Area")
            cell = Row36.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row36.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "X = RCTO-CTO Fullfillment/Deployment"
            cell.NamedCell.Add("Print_Area")
            cell = Row36.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row36.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "KE"
            cell.NamedCell.Add("Print_Area")
            cell = Row36.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row37 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row37.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "EMEA Offering"
            cell.NamedCell.Add("Print_Area")
            cell = Row37.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "EMEA"
            cell.NamedCell.Add("Print_Area")
            cell = Row37.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Field only to be used by EMEA"
            cell.NamedCell.Add("Print_Area")
            cell = Row37.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "EMEA "
            cell.NamedCell.Add("Print_Area")
            cell = Row37.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "EMEA"
            cell.NamedCell.Add("Print_Area")
            cell = Row37.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row38 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row38.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "UPC"
            cell.NamedCell.Add("Print_Area")
            cell = Row38.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row38.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "UPC code for PID (if applicable)"
            cell.NamedCell.Add("Print_Area")
            cell = Row38.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row38.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "NA Retail Web Kiosk CTO"
            cell.NamedCell.Add("Print_Area")
            cell = Row38.Cells.Add
            cell.StyleID = "s11"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row39 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row39.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Weight (in oz)"
            cell.NamedCell.Add("Print_Area")
            cell = Row39.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row39.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Weight of PID"
            cell.NamedCell.Add("Print_Area")
            cell = Row39.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row39.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "???"
            cell.NamedCell.Add("Print_Area")
            cell = Row39.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "NB will leave blank until user and rules are defined"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row40 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row40.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Region or Country"
            cell.NamedCell.Add("Print_Area")
            cell = Row40.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Localization Suffix"
            cell.NamedCell.Add("Print_Area")
            cell = Row40.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Region/Country/Suffix where PID is available per Base Unit Date or Suffix Excepti" &
"on Only Date"
            cell.NamedCell.Add("Print_Area")
            cell = Row40.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Operations"
            cell.NamedCell.Add("Print_Area")
            cell = Row40.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Region"
            cell.NamedCell.Add("Print_Area")
            cell = Row40.Cells.Add
            cell.StyleID = "s11"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Notebook usage:  " & Microsoft.VisualBasic.ChrW(10) & "The Base Unit date is the date applicable to all PIDs.  Excepti" &
"ons Only are noted for specific PIDs." & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(10) & "Types of NB Localizations:" & Microsoft.VisualBasic.ChrW(10) & "1. Localized i" &
"ndependent - date per base unit; exceptions only noted per PID" & Microsoft.VisualBasic.ChrW(10) & "2. Localized by A" &
"V# (ex: keyboards) - date per base unit; exceptions only noted per PID" & Microsoft.VisualBasic.ChrW(10) & "3. Substi" &
"tution Localization (ex: modems, DIB) - localized per config rules with date per" &
" base unit; exceptions only noted per PID"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            ' Options
            '-----------------------------------------------
            sheet.Options.Selected = True
            sheet.Options.FitToPage = True
            sheet.Options.ProtectObjects = False
            sheet.Options.ProtectScenarios = False
            sheet.Options.PageSetup.Layout.Orientation = Orientation.Landscape
            sheet.Options.PageSetup.Header.Margin = 0.25!
            sheet.Options.PageSetup.Footer.Margin = 0.26!
            sheet.Options.PageSetup.PageMargins.Bottom = 0.41!
            sheet.Options.PageSetup.PageMargins.Left = 0.75!
            sheet.Options.PageSetup.PageMargins.Right = 0.75!
            sheet.Options.PageSetup.PageMargins.Top = 0.5!
            sheet.Options.Print.Scale = 67
            sheet.Options.Print.FitHeight = 2
            sheet.Options.Print.ValidPrinterInfo = True
        End Sub
#End Region

#Region " Generate Worksheet Change Log "
        Private Sub GenerateWorksheetSCMChangeLog(ByVal sheets As WorksheetCollection, ByVal ScmName As String)

            Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
            Dim dt As DataTable
            Dim intRegionID As Integer

            If (RegionID = "") Then
                dt = dw.SelectAvHistory(ProductBrandID, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty)
            Else
                Select Case RegionID
                    Case "Americas"
                        intRegionID = 1
                    Case "EMEA"
                        intRegionID = 2
                    Case "APJ"
                        intRegionID = 3
                End Select
                dt = HPQ.Excalibur.Data.SelectAvHistory_ByRegionView(ProductBrandID, intRegionID)
            End If

            Dim sheet As Worksheet = sheets.Add("SCM Change Log")
            sheet.Table.ExpandedColumnCount = 9
            sheet.Table.FullColumns = 1
            sheet.Table.FullRows = 1
            sheet.Table.Columns.Add(141)
            sheet.Table.Columns.Add(129)
            sheet.Table.Columns.Add(80)
            sheet.Table.Columns.Add(190)
            sheet.Table.Columns.Add(50)
            sheet.Table.Columns.Add(126)
            sheet.Table.Columns.Add(126)
            sheet.Table.Columns.Add(126)
            sheet.Table.Columns.Add(630)
            '-----------------------------------------------
            If ScitPublish Then
                Dim ScitRow As WorksheetRow = sheet.Table.Rows.Add
                ScitRow.Height = 26
                ScitRow.AutoFitHeight = False
                ScitRow.Cells.Add("SCIT PUBLISH FOR TESTING ONLY", DataType.String, "h21")
            End If

            Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
            Row0.Height = 27
            Row0.AutoFitHeight = False
            Row0.Cells.Add(ScmName, DataType.String, "s21")
            Dim cell As WorksheetCell
            cell = Row0.Cells.Add
            cell.StyleID = "s34"
            cell.Data.Type = DataType.String
            cell.Data.Text = "A"
            cell.Index = 4
            Row0.Cells.Add("Added ", DataType.String, "s31")
            '-----------------------------------------------
            Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
            Row1.Height = 22
            Row1.AutoFitHeight = False
            Row1.Cells.Add("Published", DataType.String, "s35")
            cell = Row1.Cells.Add
            cell.StyleID = "s36"
            cell.Data.Type = DataType.DateTime
            cell.Data.Text = DisplayedPublishDate.ToString("yyyy-MM-ddT00:00:00.000")
            cell = Row1.Cells.Add
            cell.StyleID = "s37"
            cell.Data.Type = DataType.String
            cell.Data.Text = "C"
            cell.Index = 4
            Row1.Cells.Add("Changed ", DataType.String, "s31")
            '-----------------------------------------------
            Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
            Row2.Height = 24
            Row2.AutoFitHeight = False
            Row2.Cells.Add("Today's date", DataType.String, "s35")
            cell = Row2.Cells.Add
            cell.StyleID = "s36"
            cell.Data.Type = DataType.DateTime
            cell.Data.Text = Now.ToString("yyyy-MM-ddThh:mm:ss.000")
            cell.Formula = "TODAY()"
            cell = Row2.Cells.Add
            cell.StyleID = "s38"
            cell.Data.Type = DataType.String
            cell.Data.Text = "O"
            cell.Index = 4
            Row2.Cells.Add("Obsoleted", DataType.String, "s31")
            '-----------------------------------------------
            Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
            Row3.Height = 40
            Row3.AutoFitHeight = False
            '-----------------------------------------------
            Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
            Row4.Height = 26
            Row4.AutoFitHeight = False
            Row4.Cells.Add("Changed Date", DataType.String, "s39")
            Row4.Cells.Add("Changed By", DataType.String, "s40")
            Row4.Cells.Add("AV#", DataType.String, "s40")
            Row4.Cells.Add("GPG Description", DataType.String, "s40")
            Row4.Cells.Add("Change", DataType.String, "s40")
            Row4.Cells.Add("Field Changed", DataType.String, "s40")
            Row4.Cells.Add("Change From", DataType.String, "s40")
            Row4.Cells.Add("Change To", DataType.String, "s40")
            Row4.Cells.Add("Comment", DataType.String, "s40")

            Dim RowX As WorksheetRow
            For Each tr As DataRow In dt.Rows
                If tr("ShowOnScm") Then
                    RowX = sheet.Table.Rows.Add

                    Select Case tr("AvChangeTypeCd").ToString().ToUpper()
                        Case "A"
                            RowX.Cells.Add(FormatDate(tr("Last_Upd_Date").ToString()), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("Last_Upd_User").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("AvNo").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("GPGDescription").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("AvChangeTypeCd").ToString), DataType.String, "s34")
                            RowX.Cells.Add(XmlEncode(tr("ColumnChanged").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("OldValue").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("NewValue").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("Comments").ToString), DataType.String, "s31")
                        Case "C", "M"
                            RowX.Cells.Add(FormatDate(tr("Last_Upd_Date").ToString()), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("Last_Upd_User").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("AvNo").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("GPGDescription").ToString), DataType.String, "s31")
                            RowX.Cells.Add("C", DataType.String, "s37")
                            RowX.Cells.Add(XmlEncode(tr("ColumnChanged").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("OldValue").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("NewValue").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("Comments").ToString), DataType.String, "s31")
                        Case "O"
                            RowX.Cells.Add(FormatDate(tr("Last_Upd_Date").ToString()), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("Last_Upd_User").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("AvNo").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("GPGDescription").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("AvChangeTypeCd").ToString), DataType.String, "s38")
                            RowX.Cells.Add(XmlEncode(tr("ColumnChanged").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("OldValue").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("NewValue").ToString), DataType.String, "s31")
                            RowX.Cells.Add(XmlEncode(tr("Comments").ToString), DataType.String, "s31")
                        Case "P"
                            RowX.Cells.Add(FormatDate(tr("Last_Upd_Date").ToString()), DataType.String, "s45")
                            RowX.Cells.Add(XmlEncode(tr("Last_Upd_User").ToString), DataType.String, "s45")
                            cell = RowX.Cells.Add()
                            cell.StyleID = "s45"
                            cell = RowX.Cells.Add()
                            cell.StyleID = "s45"
                            cell = RowX.Cells.Add()
                            cell.StyleID = "s45"
                            cell = RowX.Cells.Add()
                            cell.StyleID = "s45"
                            cell = RowX.Cells.Add()
                            cell.StyleID = "s45"
                            cell = RowX.Cells.Add()
                            cell.StyleID = "s45"
                            RowX.Cells.Add(XmlEncode(tr("Comments").ToString), DataType.String, "s45")

                    End Select

                End If
            Next

            '-----------------------------------------------
            ' Options
            '-----------------------------------------------
            sheet.Options.FitToPage = True
            sheet.Options.ProtectObjects = False
            sheet.Options.ProtectScenarios = False
            sheet.Options.PageSetup.Layout.Orientation = Orientation.Landscape
            sheet.Options.PageSetup.Footer.Margin = 0.19!
            sheet.Options.PageSetup.PageMargins.Bottom = 0.47!
            sheet.Options.PageSetup.PageMargins.Left = 0.37!
            sheet.Options.PageSetup.PageMargins.Right = 0.25!
            sheet.Options.PageSetup.PageMargins.Top = 0.42!
            sheet.Options.Print.GridLines = True
            sheet.Options.Print.Scale = 86
            sheet.Options.Print.FitHeight = 0
            sheet.Options.Print.ValidPrinterInfo = True
        End Sub
#End Region

#Region " Generate Worksheet SCM AV Data "
        Private Sub GenerateWorksheetSCMAVData(ByVal sheets As WorksheetCollection, ByVal ScmName As String, ByVal ProgramVersion As String, ByVal SCMPlantsID As String,
                                           ByVal SCMMktCampsID As String, ByVal bolBSAMProd As Boolean)

            Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
            Dim dt As DataTable = dw.SelectBrandLocalizationData(ProductBrandID)
            Dim dv As DataView = dt.DefaultView
            dv.Sort = "OptionConfig DESC"
            dt = dv.ToTable(True, "OptionConfig")

            Dim sb As StringBuilder = New StringBuilder

            For Each drow As DataRow In dt.Rows
                sb.Append(",")
                sb.Append(drow("OptionConfig"))
            Next

            Dim regionCodes As String = sb.ToString.TrimStart(",")

            Dim sheet As Worksheet = sheets.Add("SCM AV Data")
            sheet.Names.Add(New WorksheetNamedRange("Print_Area", "='SCM AV data'!R1C1:R99C15", False))
            sheet.Names.Add(New WorksheetNamedRange("Print_Titles", "='SCM AV data'!C1:C3,'SCM AV data'!R4", False))
            sheet.Table.FullColumns = 1
            sheet.Table.FullRows = 1
            sheet.Table.Columns.Add(93)
            sheet.Table.Columns.Add(61)
            sheet.Table.Columns.Add(164)
            sheet.Table.Columns.Add(164)
            sheet.Table.Columns.Add(164)
            sheet.Table.Columns.Add(100)
            sheet.Table.Columns.Add(100)
            sheet.Table.Columns.Add(100)
            sheet.Table.Columns.Add(100)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            If (bolBSAMProd = True) Then
                sheet.Table.Columns.Add(81)
                sheet.Table.Columns.Add(81)
            End If
            Dim column18 As WorksheetColumn = sheet.Table.Columns.Add
            column18.Width = 90
            column18.Span = 1
            sheet.Table.Columns.Add(164)
            Dim column19 As WorksheetColumn = sheet.Table.Columns.Add
            If (bolBSAMProd = True) Then
                column19.Index = 26
                column19.Width = 18
            Else
                column19.Index = 24
                column19.Width = 16
            End If
            '----------------------------------------
            ' Americas
            '----------------------------------------
            Dim colAC8 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If (bolBSAMProd = True) Then
                colAC8.Index = 27
            Else
                colAC8.Index = 25
            End If
            If Not CBool(InStr(regionCodes, "AC8")) Then colAC8.Hidden = True
            Dim colAC4 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AC4")) Then colAC4.Hidden = True
            Dim colA1Y As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "A1Y")) Then colA1Y.Hidden = True
            Dim colABL As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABL")) Then colABL.Hidden = True
            Dim colABC As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABC")) Then colABC.Hidden = True
            Dim colAKH As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKH")) Then colAKH.Hidden = True
            Dim colABM As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABM")) Then colABM.Hidden = True
            Dim colACH As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACH")) Then colACH.Hidden = True
            Dim colABA As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABA")) Then colABA.Hidden = True
            '----------------------------------------
            ' EMEA
            '----------------------------------------
            Dim colBED As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BED")) Then colBED.Hidden = True
            Dim colBH5 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BH5")) Then colBH5.Hidden = True
            Dim colBH4 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BH4")) Then colBH4.Hidden = True
            Dim colBH6 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BH6")) Then colBH6.Hidden = True
            Dim colABV As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABV")) Then colABV.Hidden = True
            Dim colB1R As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1R")) Then colB1R.Hidden = True
            Dim colUUG As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "UUG")) Then colUUG.Hidden = True
            Dim colAKS As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKS")) Then colAKS.Hidden = True
            Dim colB1T As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1T")) Then colB1T.Hidden = True
            Dim colAKB As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKB")) Then colAKB.Hidden = True
            Dim colBCM As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BCM")) Then colBCM.Hidden = True
            Dim colARL As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ARL")) Then colARL.Hidden = True
            Dim colABY As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABY")) Then colABY.Hidden = True
            Dim colABB As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABB")) Then colABB.Hidden = True
            Dim colAK9 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AK9")) Then colAK9.Hidden = True
            Dim colB10 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B10")) Then colB10.Hidden = True
            Dim colABX As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABX")) Then colABX.Hidden = True
            Dim colABF As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABF")) Then colABF.Hidden = True
            Dim colB1S As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1S")) Then colB1S.Hidden = True
            Dim colABD As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABD")) Then colABD.Hidden = True
            Dim colB1A As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1A")) Then colB1A.Hidden = True
            Dim colAB7 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB7")) Then colAB7.Hidden = True
            Dim colAK7 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AK7")) Then colAK7.Hidden = True
            Dim colAKC As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKC")) Then colAKC.Hidden = True
            Dim colA2M As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "A2M")) Then colA2M.Hidden = True
            Dim colABT As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABT")) Then colABT.Hidden = True
            Dim colABZ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABZ")) Then colABZ.Hidden = True
            Dim colABH As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABH")) Then colABH.Hidden = True
            Dim colUUW As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "UUW")) Then colUUW.Hidden = True
            Dim colABN As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABN")) Then colABN.Hidden = True
            Dim colAB6 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB6")) Then colAB6.Hidden = True
            Dim colAR2 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AR2")) Then colAR2.Hidden = True
            Dim colAKD As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKD")) Then colAKD.Hidden = True
            Dim colAB9 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB9")) Then colAB9.Hidden = True
            Dim colAKE As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKE")) Then colAKE.Hidden = True
            Dim colACB As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACB")) Then colACB.Hidden = True
            Dim colA2N As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "A2N")) Then colA2N.Hidden = True
            Dim colAKQ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKQ")) Then colAKQ.Hidden = True
            Dim colAKR As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKR")) Then colAKR.Hidden = True
            Dim colAKN As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKN")) Then colAKN.Hidden = True
            Dim colACQ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACQ")) Then colACQ.Hidden = True
            Dim colABE As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABE")) Then colABE.Hidden = True
            Dim colABS As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABS")) Then colABS.Hidden = True
            Dim colAK8 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AK8")) Then colAK8.Hidden = True
            Dim colUUZ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "UUZ")) Then colUUZ.Hidden = True
            Dim colB12 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B12")) Then colB12.Hidden = True
            Dim colAB8 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB8")) Then colAB8.Hidden = True
            Dim colA2Q As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "A2Q")) Then colA2Q.Hidden = True
            Dim colABU As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABU")) Then colABU.Hidden = True
            '----------------------------------------
            ' APJ
            '----------------------------------------
            Dim colUUF As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "UUF")) Then colUUF.Hidden = True
            Dim colABG As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABG")) Then colABG.Hidden = True
            Dim colAB5 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB5")) Then colAB5.Hidden = True
            Dim colACJ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACJ")) Then colACJ.Hidden = True
            Dim colAR6 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AR6")) Then colAR6.Hidden = True
            Dim colABJ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABJ")) Then colABJ.Hidden = True
            Dim colACF As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACF")) Then colACF.Hidden = True
            Dim colAB1 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB1")) Then colAB1.Hidden = True
            Dim colB1L As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1L")) Then colB1L.Hidden = True
            Dim colAB2 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB2")) Then colAB2.Hidden = True
            Dim colAB4 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB4")) Then colAB4.Hidden = True
            Dim colAB0 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB0")) Then colAB0.Hidden = True
            Dim colAKL As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKL")) Then colAKL.Hidden = True
            '-----------------------------------------------
            If ScitPublish Then
                Dim ScitRow As WorksheetRow = sheet.Table.Rows.Add
                ScitRow.Height = 26
                ScitRow.AutoFitHeight = False
                ScitRow.Cells.Add("SCIT PUBLISH FOR TESTING ONLY", DataType.String, "h21")
            End If

            Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
            Dim vz As WorksheetCell
            vz = Row0.Cells.Add
            vz.StyleID = "s21"
            vz.Data.Type = DataType.String
            vz.Data.Text = ScmName
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
            vz = Row1.Cells.Add
            vz.StyleID = "s43"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Published"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            vz = Row1.Cells.Add
            vz.StyleID = "s43"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            vz = Row1.Cells.Add
            vz.StyleID = "s44"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            vz.Data.Type = DataType.DateTime
            vz.Data.Text = DisplayedPublishDate.ToString("yyyy-MM-ddT00:00:00.000")
            '-----------------------------------------------
            vz = Row1.Cells.Add
            vz.StyleID = "s46"
            vz.Data.Type = DataType.String
            vz.Data.Text = "* Provides MR Date by Localized location (date format mm/dd/yy)"

            If (bolBSAMProd = True) Then
                vz.Index = 27
            Else
                vz.Index = 25
            End If
            vz.MergeAcross = 68
            '-----------------------------------------------
            Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
            Row2.Height = 30
            Row2.AutoFitHeight = False
            vz = Row2.Cells.Add
            vz.StyleID = "s47"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Today's date"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            vz = Row2.Cells.Add
            vz.StyleID = "s47"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            vz = Row2.Cells.Add
            vz.StyleID = "s48"
            vz.Data.Type = DataType.DateTime
            vz.Data.Text = Now.ToString("yyyy-MM-ddThh:mm:ss.000")
            vz.Formula = "=TODAY()"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            vz = Row2.Cells.Add
            vz.StyleID = "m19709554"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Americas"
            If (bolBSAMProd = True) Then
                vz.Index = 27
            Else
                vz.Index = 25
            End If
            vz.MergeAcross = 8
            '-----------------------------------------------
            vz = Row2.Cells.Add
            vz.StyleID = "m19709564"
            vz.Data.Type = DataType.String
            vz.Data.Text = "EMEA"
            vz.MergeAcross = 48
            '-----------------------------------------------
            vz = Row2.Cells.Add
            vz.StyleID = "m19709574"
            vz.Data.Type = DataType.String
            vz.Data.Text = "APD"
            vz.MergeAcross = 12
            '-----------------------------------------------
            Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
            Row3.Height = 57
            Row3.AutoFitHeight = False
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "AV# "
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Feature Category"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "GPG Description" & Microsoft.VisualBasic.ChrW(10) & "(no ' or "" quote marks)"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Marketing  Description" & Microsoft.VisualBasic.ChrW(10) & "(40 Char GPSy)"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Marketing Description" & Microsoft.VisualBasic.ChrW(10) & "(100 Char PMG)"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Program Version where used"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Select Availability" & Microsoft.VisualBasic.ChrW(10) & "(SA) Date"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "General Availability" & Microsoft.VisualBasic.ChrW(10) & "(GA) Date"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "End of Manufacturing" & Microsoft.VisualBasic.ChrW(10) & "(EM) Date"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Configuration Rules"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "AVID"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Group 1"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Group 2"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Group 3"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Group 4"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Group 5"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "IDS-SKUS"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "IDS-CTO"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "RCTO-SKUS"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "RCTO-CTO"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            If (bolBSAMProd = True) Then
                vz = Row3.Cells.Add
                vz.StyleID = "s56"
                vz.Data.Type = DataType.String
                vz.Data.Text = "BSAM" & Microsoft.VisualBasic.ChrW(10) & "SKUS"
                vz.NamedCell.Add("Print_Titles")
                vz.NamedCell.Add("Print_Area")
                '-----------------------------------------------
                vz = Row3.Cells.Add
                vz.StyleID = "s56"
                vz.Data.Type = DataType.String
                vz.Data.Text = "BSAM" & Microsoft.VisualBasic.ChrW(10) & "BParts"
                vz.NamedCell.Add("Print_Titles")
                vz.NamedCell.Add("Print_Area")
            End If
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "UPC"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Weight (in oz)"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s56"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Global Series Config" & Microsoft.VisualBasic.ChrW(10) & "Plan for End of" & Microsoft.VisualBasic.ChrW(10) & "Manufacturing (PE) Date"
            '"Global" & Microsoft.VisualBasic.ChrW(10) & "Series" & Microsoft.VisualBasic.ChrW(10) & "Config EOL"
            vz.NamedCell.Add("Print_Titles")
            vz.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            vz = Row3.Cells.Add
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Regions"
            vz.NamedCell.Add("Print_Titles")

            '----------------------------------------
            ' Americas
            '----------------------------------------
            vz = Row3.Cells.Add   'AC8
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Argentina"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AC4
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Brazil"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'A1Y
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Brazil (English)"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABL
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Canada"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABC
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Canadian (French)"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AKH
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Chile"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABM
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Latin America"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ACH
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Latin America English"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABA
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "United States"
            vz.NamedCell.Add("Print_Titles")
            '----------------------------------------
            ' EMEA
            '----------------------------------------
            vz = Row3.Cells.Add   'BED
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Adriatic Region"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'BH5
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Africa-English"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'BH4
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Africa-French"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'BH6
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Africa-French/Arabic"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABV
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Arabia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'B1R
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Baltics"
            vz = Row3.Cells.Add   'UUG
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Belgium"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AKS
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Bulgaria"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'B1T
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Bulgaria/Romania"
            vz = Row3.Cells.Add   'AKB
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Czech Republic"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'BCM
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Czech/Slovakia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ARL
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Czech/Slovakia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABY
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Denmark"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add
            vz.StyleID = "s58"    'ABB
            vz.Data.Type = DataType.String
            vz.Data.Text = "Euro"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AK9
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Euro-A2"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'B10
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Euro-A5"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABX
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Finland"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABF
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "France"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'B1S
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "French Arabic"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABD
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Germany"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'B1A
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Greece"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AB7
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Greece"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AK7
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Greece/Poland"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AKC
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Hungary"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'A2M
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Iceland"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABT
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Israel (Hebrew)"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABZ
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Italy"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABH
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Netherlands"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'UUW
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Nordic"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABN
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Norway"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AB6
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "NW Africa"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AR2
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Pan Euro"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AKD
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Poland"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AB9
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Portugal"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AKE
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Romania"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ACB
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Russia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'A2N
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Saudi Arabia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AKQ
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Serbia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AKR
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Slovakia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AKN
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Slovenia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ACQ
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "South Africa"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABE
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Spain"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABS
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Sweden"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AK8
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Sweden / Finland"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'UUZ
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Switzerland"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'B12
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Switzerland"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AB8
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Turkey"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'A2Q
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Ukraine"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABU
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "United Kingdom"
            vz.NamedCell.Add("Print_Titles")
            '----------------------------------------
            ' APJ
            '----------------------------------------
            vz = Row3.Cells.Add   'UUF
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Asia Pacific"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add
            vz.StyleID = "s58"    'ABG
            vz.Data.Type = DataType.String
            vz.Data.Text = "Australia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AB5
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Hong Kong"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ACJ
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "India"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AR6
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Indonesia"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ABJ
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Japan"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'ACF
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Japan (English)"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AB1
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Korea"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'B1L
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "PRC (CH,EN)"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AB2
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "PRC Chinese"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AB4
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Singapore"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AB0
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Taiwan"
            vz.NamedCell.Add("Print_Titles")
            vz = Row3.Cells.Add   'AKL
            vz.StyleID = "s58"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Thailand"
            vz.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
            ' ----------------------------------------
            ' Americas
            ' ----------------------------------------
            vz = Row4.Cells.Add("LA Merco", DataType.String, "s23")   'AC8
            If (bolBSAMProd = True) Then
                vz.Index = 27
            Else
                vz.Index = 25
            End If
            Row4.Cells.Add("BRZL", DataType.String, "s23")      'AC4
            Row4.Cells.Add("BRZE", DataType.String, "s23")      'A1Y
            Row4.Cells.Add("CAN/ENG", DataType.String, "s23")   'ABL
            Row4.Cells.Add("FCAN", DataType.String, "s23")      'ABC
            Row4.Cells.Add("CHILE", DataType.String, "s23")     'AKH
            Row4.Cells.Add("LTNA", DataType.String, "s23")      'ABM
            Row4.Cells.Add("LAE", DataType.String, "s23")       'ACH
            Row4.Cells.Add("US", DataType.String, "s23")        'ABA
            ' ----------------------------------------
            ' EMEA
            ' ----------------------------------------
            Row4.Cells.Add("ADR", DataType.String, "s23")       'BED
            Row4.Cells.Add("AFRC-E", DataType.String, "s23")    'BH5
            Row4.Cells.Add("AFRC-F", DataType.String, "s23")    'BH4
            Row4.Cells.Add("AFRC-F/A", DataType.String, "s23")  'BH6
            Row4.Cells.Add("ARAB", DataType.String, "s23")      'ABV
            Row4.Cells.Add("EUROR2", DataType.String, "s23")    'B1R
            Row4.Cells.Add("EUROA4", DataType.String, "s23")    'UUG
            Row4.Cells.Add("BULG", DataType.String, "s23")      'AKS
            Row4.Cells.Add("EUROR4", DataType.String, "s23")    'B1T
            Row4.Cells.Add("CZECH", DataType.String, "s23")     'AKB
            Row4.Cells.Add("CZECH-SK", DataType.String, "s23")  'BCM
            Row4.Cells.Add("EEUROA8", DataType.String, "s23")    'ARL
            Row4.Cells.Add("DEN", DataType.String, "s23")       'ABY
            Row4.Cells.Add("EURO", DataType.String, "s23")      'ABB
            Row4.Cells.Add("EUROA2", DataType.String, "s23")    'AK9
            Row4.Cells.Add("EUROA5", DataType.String, "s23")    'B10
            Row4.Cells.Add("FI", DataType.String, "s23")        'ABX
            Row4.Cells.Add("FR", DataType.String, "s23")        'ABF
            Row4.Cells.Add("EUROR3", DataType.String, "s23")    'B1S
            Row4.Cells.Add("GR", DataType.String, "s23")        'ABD
            Row4.Cells.Add("GK", DataType.String, "s23")        'B1A
            Row4.Cells.Add("GRK", DataType.String, "s23")       'AB7
            Row4.Cells.Add("GK/PL", DataType.String, "s23")     'AK7
            Row4.Cells.Add("HUNG", DataType.String, "s23")      'AKC
            Row4.Cells.Add("ICELAND", DataType.String, "s23")   'A2M
            Row4.Cells.Add("HE", DataType.String, "s23")        'ABT
            Row4.Cells.Add("ITL", DataType.String, "s23")       'ABZ
            Row4.Cells.Add("NL", DataType.String, "s23")        'ABH
            Row4.Cells.Add("NRL", DataType.String, "s23")       'UUW
            Row4.Cells.Add("NOR", DataType.String, "s23")       'ABN
            Row4.Cells.Add("NWAFR", DataType.String, "s23")     'AB6
            Row4.Cells.Add("EB", DataType.String, "s23")        'AR2
            Row4.Cells.Add("POL", DataType.String, "s23")       'AKD
            Row4.Cells.Add("PORT", DataType.String, "s23")      'AB9
            Row4.Cells.Add("ROM", DataType.String, "s23")       'AKE
            Row4.Cells.Add("RUSS", DataType.String, "s23")      'ACB
            Row4.Cells.Add("SAU", DataType.String, "s23")       'A2N
            Row4.Cells.Add("SCC", DataType.String, "s23")       'AKQ
            Row4.Cells.Add("SK", DataType.String, "s23")        'AKR
            Row4.Cells.Add("SL", DataType.String, "s23")        'AKN
            Row4.Cells.Add("SA", DataType.String, "s23")        'ACQ
            Row4.Cells.Add("SP", DataType.String, "s23")        'ABE
            Row4.Cells.Add("SE", DataType.String, "s23")        'ABS
            Row4.Cells.Add("SE/FI", DataType.String, "s23")     'AK8
            Row4.Cells.Add("SWIS2", DataType.String, "s23")     'UUZ
            Row4.Cells.Add("SWIS1", DataType.String, "s23")     'B12
            Row4.Cells.Add("TURK", DataType.String, "s23")      'AB8
            Row4.Cells.Add("UKRAINE", DataType.String, "s23")   'A2Q
            Row4.Cells.Add("UK", DataType.String, "s23")        'ABU
            ' ----------------------------------------
            ' APJ
            ' ----------------------------------------
            Row4.Cells.Add("A/P", DataType.String, "s23")       'UUF
            Row4.Cells.Add("AUST", DataType.String, "s23")      'ABG
            Row4.Cells.Add("HK", DataType.String, "s23")        'AB5
            Row4.Cells.Add("INDIA", DataType.String, "s23")     'ACJ
            Row4.Cells.Add("INDO", DataType.String, "s23")      'AR6
            Row4.Cells.Add("JPN2", DataType.String, "s23")      'ABJ
            Row4.Cells.Add("JPN/ENG", DataType.String, "s23")   'ACF
            Row4.Cells.Add("KOR", DataType.String, "s23")       'AB1
            Row4.Cells.Add("ASIA", DataType.String, "s23")      'B1L
            Row4.Cells.Add("PRC", DataType.String, "s23")       'AB2
            Row4.Cells.Add("SING", DataType.String, "s23")      'AB4
            Row4.Cells.Add("TW", DataType.String, "s23")        'AB0
            Row4.Cells.Add("THAI", DataType.String, "s23")      'AKL
            '-----------------------------------------------
            Dim Row5 As WorksheetRow = sheet.Table.Rows.Add
            Row5.Height = 30
            Row5.AutoFitHeight = False
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz.NamedCell.Add("Print_Titles")
            vz = Row5.Cells.Add
            vz.StyleID = "s60"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Marketing"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s60"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Marketing"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s61"
            vz.Data.Type = DataType.String
            vz.Data.Text = "PDM Team"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s61"
            vz.Data.Type = DataType.String
            vz.Data.Text = "PDM Team"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s61"
            vz.Data.Type = DataType.String
            vz.Data.Text = "PDM Team"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            If (bolBSAMProd = True) Then
                vz = Row5.Cells.Add
                vz.StyleID = "s59"
                vz.Data.Type = DataType.String
                vz.Data.Text = "Config Mgt"
                vz.NamedCell.Add("Print_Area")
                vz = Row5.Cells.Add
                vz.StyleID = "s59"
                vz.Data.Type = DataType.String
                vz.Data.Text = "Config Mgt"
                vz.NamedCell.Add("Print_Area")
            End If
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s59"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Config Mgt"
            vz.NamedCell.Add("Print_Area")
            vz = Row5.Cells.Add
            vz.StyleID = "s62"

            ' ----------------------------------------
            ' Americas
            ' ----------------------------------------
            Row5.Cells.Add("AC8", DataType.String, "s23")
            Row5.Cells.Add("AC4", DataType.String, "s23")
            Row5.Cells.Add("A1Y", DataType.String, "s23")
            Row5.Cells.Add("ABL", DataType.String, "s23")
            Row5.Cells.Add("ABC", DataType.String, "s23")
            Row5.Cells.Add("AKH", DataType.String, "s23")
            Row5.Cells.Add("ABM", DataType.String, "s23")
            Row5.Cells.Add("ACH", DataType.String, "s23")
            Row5.Cells.Add("ABA", DataType.String, "s23")
            ' ----------------------------------------
            ' EMEA
            ' ----------------------------------------
            Row5.Cells.Add("BED", DataType.String, "s23")
            Row5.Cells.Add("BH5", DataType.String, "s23")
            Row5.Cells.Add("BH4", DataType.String, "s23")
            Row5.Cells.Add("BH6", DataType.String, "s23")
            Row5.Cells.Add("ABV", DataType.String, "s23")
            Row5.Cells.Add("B1R", DataType.String, "s23")
            Row5.Cells.Add("UUG", DataType.String, "s23")
            Row5.Cells.Add("AKS", DataType.String, "s23")
            Row5.Cells.Add("B1T", DataType.String, "s23")
            Row5.Cells.Add("AKB", DataType.String, "s23")
            Row5.Cells.Add("BCM", DataType.String, "s23")
            Row5.Cells.Add("ARL", DataType.String, "s23")
            Row5.Cells.Add("ABY", DataType.String, "s23")
            Row5.Cells.Add("ABB", DataType.String, "s23")
            Row5.Cells.Add("AK9", DataType.String, "s23")
            Row5.Cells.Add("B10", DataType.String, "s23")
            Row5.Cells.Add("ABX", DataType.String, "s23")
            Row5.Cells.Add("ABF", DataType.String, "s23")
            Row5.Cells.Add("B1S", DataType.String, "s23")
            Row5.Cells.Add("ABD", DataType.String, "s23")
            Row5.Cells.Add("B1A", DataType.String, "s23")
            Row5.Cells.Add("AB7", DataType.String, "s23")
            Row5.Cells.Add("AK7", DataType.String, "s23")
            Row5.Cells.Add("AKC", DataType.String, "s23")
            Row5.Cells.Add("A2M", DataType.String, "s23")
            Row5.Cells.Add("ABT", DataType.String, "s23")
            Row5.Cells.Add("ABZ", DataType.String, "s23")
            Row5.Cells.Add("ABH", DataType.String, "s23")
            Row5.Cells.Add("UUW", DataType.String, "s23")
            Row5.Cells.Add("ABN", DataType.String, "s23")
            Row5.Cells.Add("AB6", DataType.String, "s23")
            Row5.Cells.Add("AR2", DataType.String, "s23")
            Row5.Cells.Add("AKD", DataType.String, "s23")
            Row5.Cells.Add("AB9", DataType.String, "s23")
            Row5.Cells.Add("AKE", DataType.String, "s23")
            Row5.Cells.Add("ACB", DataType.String, "s23")
            Row5.Cells.Add("A2N", DataType.String, "s23")
            Row5.Cells.Add("AKQ", DataType.String, "s23")
            Row5.Cells.Add("AKR", DataType.String, "s23")
            Row5.Cells.Add("AKN", DataType.String, "s23")
            Row5.Cells.Add("ACQ", DataType.String, "s23")
            Row5.Cells.Add("ABE", DataType.String, "s23")
            Row5.Cells.Add("ABS", DataType.String, "s23")
            Row5.Cells.Add("AK8", DataType.String, "s23")
            Row5.Cells.Add("UUZ", DataType.String, "s23")
            Row5.Cells.Add("B12", DataType.String, "s23")
            Row5.Cells.Add("AB8", DataType.String, "s23")
            Row5.Cells.Add("A2Q", DataType.String, "s23")
            Row5.Cells.Add("ABU", DataType.String, "s23")
            ' ----------------------------------------
            ' APJ
            ' ----------------------------------------
            Row5.Cells.Add("UUF", DataType.String, "s23")
            Row5.Cells.Add("ABG", DataType.String, "s23")
            Row5.Cells.Add("AB5", DataType.String, "s23")
            Row5.Cells.Add("ACJ", DataType.String, "s23")
            Row5.Cells.Add("AR6", DataType.String, "s23")
            Row5.Cells.Add("ABJ", DataType.String, "s23")
            Row5.Cells.Add("ACF", DataType.String, "s23")
            Row5.Cells.Add("AB1", DataType.String, "s23")
            Row5.Cells.Add("B1L", DataType.String, "s23")
            Row5.Cells.Add("AB2", DataType.String, "s23")
            Row5.Cells.Add("AB4", DataType.String, "s23")
            Row5.Cells.Add("AB0", DataType.String, "s23")
            Row5.Cells.Add("AKL", DataType.String, "s23")
            '-----------------------------------------------
            '
            ' Select Scm Detail
            '
            '-----------------------------------------------
            'Dim dt As DataTable
            Dim intRegionID As Integer

            If (RegionID = "") Then
                dt = dw.SelectScmDetail(ProductVersionID, ProductBrandID)
            Else
                Select Case RegionID
                    Case "Americas"
                        intRegionID = 1
                    Case "EMEA"
                        intRegionID = 2
                    Case "APJ"
                        intRegionID = 3
                End Select

                If (SCMPlants = "") Then
                    If (SCMMktCamps = "") Then 'Regional View
                        dt = HPQ.Excalibur.Data.SelectScmDetail_RegionAndPlatformsView_WithOutCats(ProductVersionID, ProductBrandID, intRegionID)
                    Else 'Marketing View
                        dt = HPQ.Excalibur.Data.SelectScmDetail_RegionAndPlatformsView_MktCamps_WithOutCats(ProductVersionID, ProductBrandID, intRegionID, SCMMktCampsID)
                    End If
                Else
                    If (SCMMktCamps = "") Then 'Plant View
                        dt = HPQ.Excalibur.Data.SelectScmDetail_RegionAndPlatformsView_Plants_WithOutCats(ProductVersionID, ProductBrandID, intRegionID, SCMPlantsID)
                    Else 'Marketing View
                        dt = HPQ.Excalibur.Data.SelectScmDetail_RegionAndPlatformsView_MktCamps_WithOutCats(ProductVersionID, ProductBrandID, intRegionID, SCMMktCampsID)
                    End If
                End If
            End If

            Dim RowX As WorksheetRow
            Dim iCatId As Int32 = 0
            Dim bEmptyCat As Boolean = False
            Dim dtLastUpdate As DateTime

            For Each drow As DataRow In dt.Rows
                If drow("Status").ToString <> "H" Then
                    If iCatId <> drow("FeatureCategoryID") Then
                        iCatId = drow("FeatureCategoryID")
                        '
                        ' Category Row
                        '
                        If bEmptyCat Then
                            sheet.Table.Rows.Add()
                            sheet.Table.Rows.Add()
                        ElseIf iCatId <> 1 Then
                            sheet.Table.Rows.Add()
                        End If

                        dtLastUpdate = drow("ConfigRules_LastUpdDt").ToString
                        If Not IsDate(dtLastUpdate) Then
                            dtLastUpdate = LastPublishDate
                        End If

                        If dtLastUpdate > LastPublishDate Then
                            RowX = sheet.Table.Rows.Add
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s67"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvFeatureCategory").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("CategoryMarketingDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("CategoryRules").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            If (bolBSAMProd = True) Then
                                vz = RowX.Cells.Add
                                vz.StyleID = "s31"
                                vz.NamedCell.Add("Print_Area")
                                vz = RowX.Cells.Add
                                vz.StyleID = "s31"
                                vz.NamedCell.Add("Print_Area")
                            End If
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                        Else
                            RowX = sheet.Table.Rows.Add
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s67"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvFeatureCategory").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("CategoryMarketingDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("CategoryRules").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            If (bolBSAMProd = True) Then
                                vz = RowX.Cells.Add
                                vz.StyleID = "s31"
                                vz.NamedCell.Add("Print_Area")
                                vz = RowX.Cells.Add
                                vz.StyleID = "s31"
                                vz.NamedCell.Add("Print_Area")
                            End If
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                        End If
                        bEmptyCat = True
                    End If

                    If drow("AvNo").ToString <> String.Empty Then
                        bEmptyCat = False
                        RowX = sheet.Table.Rows.Add

                        If drow("Status").ToString = "A" And drow("bStatus").ToString = "1" Then
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvNo").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("GPGDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescriptionPMG").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ProgramVersion
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("CPLBlindDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GeneralAvailDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("RASDiscontinueDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("ConfigRules").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvId").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group1").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group2").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group3").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group4").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group5").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            If (bolBSAMProd = True) Then
                                vz = RowX.Cells.Add
                                vz.StyleID = "s32"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMSkus_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                                vz = RowX.Cells.Add
                                vz.StyleID = "s32"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMBparts_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                            End If
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("UPC").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s32"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GSEndDt").ToString)
                            vz.NamedCell.Add("Print_Area")

                        ElseIf drow("Status").ToString = "A" And (RegionID <> "") Then 'Use this section if the user is filtering the SCM by a region.  This will keep all background colors white since the region version of this spreadsheet isn't suppose to show the change history.
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvNo").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("GPGDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescriptionPMG").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ProgramVersion
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            If (SCMPlants = "") Then
                                If (SCMMktCamps = "") Then 'Regional View
                                    vz.Data.Text = FormatDate(drow("RegionalCPLBlindDate").ToString)
                                Else 'Marketing View
                                    vz.Data.Text = FormatDate(drow("StartDate").ToString)
                                End If
                            Else
                                If (SCMMktCamps = "") Then 'Plant View
                                    vz.Data.Text = FormatDate(drow("PlantStartDate").ToString)
                                Else 'Marketing View
                                    vz.Data.Text = FormatDate(drow("StartDate").ToString)
                                End If
                            End If
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GeneralAvailDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            If (SCMPlants = "") Then
                                If (SCMMktCamps = "") Then 'Regional View
                                    vz.Data.Text = FormatDate(drow("RegionalRasDiscDate").ToString)
                                Else 'Marketing View
                                    vz.Data.Text = FormatDate(drow("EndDate").ToString)
                                End If
                            Else
                                If (SCMMktCamps = "") Then 'Plant View
                                    vz.Data.Text = FormatDate(drow("PlantEndDate").ToString)
                                Else 'Marketing View
                                    vz.Data.Text = FormatDate(drow("EndDate").ToString)
                                End If
                            End If
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("ConfigRules").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvId").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group1").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group2").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group3").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group4").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group5").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            If (bolBSAMProd = True) Then
                                vz = RowX.Cells.Add
                                vz.StyleID = "s31"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMSkus_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                                vz = RowX.Cells.Add
                                vz.StyleID = "s31"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMBparts_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                            End If
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("UPC").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GSEndDt").ToString)
                            vz.NamedCell.Add("Print_Area")

                        ElseIf drow("Status").ToString = "A" Then
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bAvNo"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvNo").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s31"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bGPGDescription"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("GPGDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bMarketingDescription"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bMarketingDescriptionPMG"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescriptionPMG").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bAvNo"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ProgramVersion
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bCPLBlindDt"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("CPLBlindDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bGeneralAvailDt"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GeneralAvailDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bRASDiscontinueDt"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("RASDiscontinueDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add(XmlEncode(drow("ConfigRules").ToString), DataType.String, GetCellStyle(drow("bConfigRules")))
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add(XmlEncode(drow("AvId").ToString), DataType.String, GetCellStyle(drow("bAvId")))
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add(XmlEncode(drow("Group1").ToString), DataType.String, GetCellStyle(drow("bGroup1")))
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add(XmlEncode(drow("Group2").ToString), DataType.String, GetCellStyle(drow("bGroup2")))
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add(XmlEncode(drow("Group3").ToString), DataType.String, GetCellStyle(drow("bGroup3")))
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add(XmlEncode(drow("Group4").ToString), DataType.String, GetCellStyle(drow("bGroup4")))
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add(XmlEncode(drow("Group5").ToString), DataType.String, GetCellStyle(drow("bGroup5")))
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bIdsSkus"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bIdsCto"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bRctoSkus"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bRctoCto"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            If (bolBSAMProd = True) Then
                                vz = RowX.Cells.Add
                                vz.StyleID = GetCellStyle(drow("bBSAMSkus"))
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMSkus_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                                vz = RowX.Cells.Add
                                vz.StyleID = GetCellStyle(drow("bBSAMBparts"))
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMBparts_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                            End If
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bUPC"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("UPC").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bWeight"))
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = GetCellStyle(drow("bGSEndDt"))
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GSEndDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                        ElseIf drow("Status").ToString = "O" And drow("bStatus").ToString = "1" Then
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvNo").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("GPGDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescriptionPMG").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ProgramVersion
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("CPLBlindDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GeneralAvailDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("RASDiscontinueDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("ConfigRules").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvId").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group1").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group2").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group3").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group4").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group5").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            If (bolBSAMProd = True) Then
                                vz = RowX.Cells.Add
                                vz.StyleID = "s74"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMSkus_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                                vz = RowX.Cells.Add
                                vz.StyleID = "s74"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMBparts_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                            End If
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("UPC").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GSEndDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                        ElseIf drow("Status").ToString = "O" And (RegionID <> "") Then 'Use this section if the user is filtering the SCM by a region.  This will keep all background colors white since the region version of this spreadsheet isn't suppose to show the change history.
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvNo").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("GPGDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescriptionPMG").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ProgramVersion
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            If (SCMPlants = "") Then
                                If (SCMMktCamps = "") Then 'Regional View
                                    vz.Data.Text = FormatDate(drow("RegionalCPLBlindDate").ToString)
                                Else 'Marketing View
                                    vz.Data.Text = FormatDate(drow("StartDate").ToString)
                                End If
                            Else
                                If (SCMMktCamps = "") Then 'Plant View
                                    vz.Data.Text = FormatDate(drow("PlantStartDate").ToString)
                                Else 'Marketing View
                                    vz.Data.Text = FormatDate(drow("StartDate").ToString)
                                End If
                            End If
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GeneralAvailDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            If (SCMPlants = "") Then
                                If (SCMMktCamps = "") Then 'Regional View
                                    vz.Data.Text = FormatDate(drow("RegionalRasDiscDate").ToString)
                                Else 'Marketing View
                                    vz.Data.Text = FormatDate(drow("EndDate").ToString)
                                End If
                            Else
                                If (SCMMktCamps = "") Then 'Plant View
                                    vz.Data.Text = FormatDate(drow("PlantEndDate").ToString)
                                Else 'Marketing View
                                    vz.Data.Text = FormatDate(drow("EndDate").ToString)
                                End If
                            End If
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("ConfigRules").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvId").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group1").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group2").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group3").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group4").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group5").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            If (bolBSAMProd = True) Then
                                vz = RowX.Cells.Add
                                vz.StyleID = "s74"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMSkus_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                                vz = RowX.Cells.Add
                                vz.StyleID = "s74"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMBparts_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                            End If
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("UPC").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s74"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GSEndDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                        ElseIf drow("status").ToString = "O" Then
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvNo").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("GPGDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz.NamedCell.Add("Print_Titles")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescription").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("MarketingDescriptionPMG").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ProgramVersion
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("CPLBlindDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GeneralAvailDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("RASDiscontinueDt").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("ConfigRules").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("AvId").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group1").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group2").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group3").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group4").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("Group5").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("IdsCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoSkus_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = ConvertYN(drow("RctoCto_YN").ToString)
                            vz.NamedCell.Add("Print_Area")
                            If (bolBSAMProd = True) Then
                                vz = RowX.Cells.Add
                                vz.StyleID = "s72"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMSkus_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                                vz = RowX.Cells.Add
                                vz.StyleID = "s72"
                                vz.Data.Type = DataType.String
                                vz.Data.Text = ConvertYN(drow("BSAMBparts_YN").ToString)
                                vz.NamedCell.Add("Print_Area")
                            End If
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = XmlEncode(drow("UPC").ToString)
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.NamedCell.Add("Print_Area")
                            vz = RowX.Cells.Add
                            vz.StyleID = "s72"
                            vz.Data.Type = DataType.String
                            vz.Data.Text = FormatDate(drow("GSEndDt").ToString)
                            vz.NamedCell.Add("Print_Area")

                        End If
                        '
                        ' Insert the MR Dates
                        '

                        ' ========================================
                        ' Americas
                        ' ========================================
                        vz = RowX.Cells.Add
                        vz.StyleID = "s31"
                        vz.Data.Type = DataType.String
                        vz.Data.Text = FormatDate(drow("AC8").ToString)
                        If (bolBSAMProd = True) Then
                            vz.Index = 27
                        Else
                            vz.Index = 25
                        End If
                        RowX.Cells.Add(FormatDate(drow("AC4").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("A1Y").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABL").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABC").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKH").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABM").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACH").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABA").ToString), DataType.String, "s31")

                        ' ========================================
                        ' EMEA
                        ' ========================================
                        RowX.Cells.Add(FormatDate(drow("BED").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("BH5").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("BH4").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("BH6").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABV").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1R").ToString), DataType.String, "s32")
                        RowX.Cells.Add(FormatDate(drow("UUG").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKS").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1T").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKB").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("BCM").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ARL").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABY").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABB").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AK9").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B10").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABX").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABF").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1S").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABD").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1A").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB7").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AK7").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKC").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("A2M").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABT").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABZ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABH").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("UUW").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABN").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB6").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AR2").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKD").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB9").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKE").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACB").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("A2N").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKQ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKR").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKN").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACQ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABE").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABS").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AK8").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("UUZ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B12").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB8").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("A2Q").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABU").ToString), DataType.String, "s31")

                        ' ========================================
                        ' APJ
                        ' ========================================
                        RowX.Cells.Add(FormatDate(drow("UUF").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABG").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB5").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACJ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AR6").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABJ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACF").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB1").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1L").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB2").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB4").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB0").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKL").ToString), DataType.String, "s31")


                    End If
                End If
            Next

            '-----------------------------------------------
            Dim Row23 As WorksheetRow = sheet.Table.Rows.Add
            vz = Row23.Cells.Add
            vz.StyleID = "s64"
            vz.Index = 8
            '-----------------------------------------------
            Dim Row24 As WorksheetRow = sheet.Table.Rows.Add
            vz = Row24.Cells.Add
            vz.StyleID = "s64"
            vz.Index = 8
            '-----------------------------------------------
            Dim Row25 As WorksheetRow = sheet.Table.Rows.Add
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.Data.Text = "Items below this line are for US Retail Web/Kiosk only"
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            vz = Row25.Cells.Add
            vz.StyleID = "s80"
            vz.Data.Type = DataType.String
            vz.NamedCell.Add("Print_Titles")
            If (bolBSAMProd = True) Then
                vz = Row25.Cells.Add
                vz.StyleID = "s80"
                vz.Data.Type = DataType.String
                vz.NamedCell.Add("Print_Titles")
                vz = Row25.Cells.Add
                vz.StyleID = "s80"
                vz.Data.Type = DataType.String
                vz.NamedCell.Add("Print_Titles")
            End If
            '-----------------------------------------------
            ' Options
            '-----------------------------------------------
            sheet.Options.FreezePanes = True
            sheet.Options.FitToPage = True
            sheet.Options.SplitHorizontal = 5
            sheet.Options.TopRowBottomPane = 5
            sheet.Options.SplitVertical = 3
            sheet.Options.LeftColumnRightPane = 3
            sheet.Options.ActivePane = 0
            sheet.Options.ProtectObjects = False
            sheet.Options.ProtectScenarios = False
            sheet.Options.PageSetup.Layout.Orientation = Orientation.Landscape
            sheet.Options.PageSetup.Footer.Margin = 0.17!
            sheet.Options.PageSetup.PageMargins.Bottom = 0.42!
            sheet.Options.PageSetup.PageMargins.Left = 0.75!
            sheet.Options.PageSetup.PageMargins.Right = 0.75!
            sheet.Options.PageSetup.PageMargins.Top = 0.44!
            sheet.Options.Print.PaperSizeIndex = 5
            sheet.Options.Print.Scale = 58
            sheet.Options.Print.FitHeight = 48
            sheet.Options.Print.ValidPrinterInfo = True
        End Sub
#End Region

#Region " Generate Worksheet Obsolete SCM AV Data "
        Private Sub GenerateWorksheetObsoleteSCMAVData(ByVal sheets As WorksheetCollection, ByVal ScmName As String, ByVal ProgramVersion As String, ByVal bolBSAMProd As Boolean)

            Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
            Dim dt As DataTable = dw.SelectBrandLocalizationData(ProductBrandID)
            Dim dv As DataView = dt.DefaultView
            dv.Sort = "OptionConfig DESC"
            dt = dv.ToTable(True, "OptionConfig")

            Dim sb As StringBuilder = New StringBuilder

            For Each drow As DataRow In dt.Rows
                sb.Append(",")
                sb.Append(drow("OptionConfig"))
            Next

            Dim regionCodes As String = sb.ToString.TrimStart(",")

            Dim sheet As Worksheet = sheets.Add("SCM Obsolete AV Data")
            sheet.Names.Add(New WorksheetNamedRange("Print_Area", "='SCM AV data'!R1C1:R99C15", False))
            sheet.Names.Add(New WorksheetNamedRange("Print_Titles", "='SCM AV data'!C1:C3,'SCM AV data'!R4", False))
            sheet.Table.FullColumns = 1
            sheet.Table.FullRows = 1
            sheet.Table.Columns.Add(93)
            sheet.Table.Columns.Add(61)
            sheet.Table.Columns.Add(164)
            sheet.Table.Columns.Add(164)
            sheet.Table.Columns.Add(164)
            sheet.Table.Columns.Add(100)
            sheet.Table.Columns.Add(100)
            sheet.Table.Columns.Add(100)
            sheet.Table.Columns.Add(100)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            sheet.Table.Columns.Add(81)
            If (bolBSAMProd = True) Then
                sheet.Table.Columns.Add(81)
                sheet.Table.Columns.Add(81)
            End If
            Dim column18 As WorksheetColumn = sheet.Table.Columns.Add
            column18.Width = 90
            column18.Span = 1
            sheet.Table.Columns.Add(164)
            Dim column19 As WorksheetColumn = sheet.Table.Columns.Add
            If (bolBSAMProd = True) Then
                column19.Index = 26
                column19.Width = 18
            Else
                column19.Index = 24
                column19.Width = 16
            End If
            '----------------------------------------
            ' Americas
            '----------------------------------------
            Dim colAC8 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If (bolBSAMProd = True) Then
                colAC8.Index = 27
            Else
                colAC8.Index = 25
            End If
            If Not CBool(InStr(regionCodes, "AC8")) Then colAC8.Hidden = True
            Dim colAC4 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AC4")) Then colAC4.Hidden = True
            Dim colA1Y As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "A1Y")) Then colA1Y.Hidden = True
            Dim colABL As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABL")) Then colABL.Hidden = True
            Dim colABC As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABC")) Then colABC.Hidden = True
            Dim colAKH As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKH")) Then colAKH.Hidden = True
            Dim colABM As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABM")) Then colABM.Hidden = True
            Dim colACH As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACH")) Then colACH.Hidden = True
            Dim colABA As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABA")) Then colABA.Hidden = True
            '----------------------------------------
            ' EMEA
            '----------------------------------------
            Dim colBED As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BED")) Then colBED.Hidden = True
            Dim colBH5 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BH5")) Then colBH5.Hidden = True
            Dim colBH4 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BH4")) Then colBH4.Hidden = True
            Dim colBH6 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BH6")) Then colBH6.Hidden = True
            Dim colABV As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABV")) Then colABV.Hidden = True
            Dim colB1R As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1R")) Then colB1R.Hidden = True
            Dim colUUG As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "UUG")) Then colUUG.Hidden = True
            Dim colAKS As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKS")) Then colAKS.Hidden = True
            Dim colB1T As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1T")) Then colB1T.Hidden = True
            Dim colAKB As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKB")) Then colAKB.Hidden = True
            Dim colBCM As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "BCM")) Then colBCM.Hidden = True
            Dim colARL As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ARL")) Then colARL.Hidden = True
            Dim colABY As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABY")) Then colABY.Hidden = True
            Dim colABB As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABB")) Then colABB.Hidden = True
            Dim colAK9 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AK9")) Then colAK9.Hidden = True
            Dim colB10 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B10")) Then colB10.Hidden = True
            Dim colABX As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABX")) Then colABX.Hidden = True
            Dim colABF As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABF")) Then colABF.Hidden = True
            Dim colB1S As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1S")) Then colB1S.Hidden = True
            Dim colABD As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABD")) Then colABD.Hidden = True
            Dim colB1A As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1A")) Then colB1A.Hidden = True
            Dim colAB7 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB7")) Then colAB7.Hidden = True
            Dim colAK7 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AK7")) Then colAK7.Hidden = True
            Dim colAKC As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKC")) Then colAKC.Hidden = True
            Dim colA2M As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "A2M")) Then colA2M.Hidden = True
            Dim colABT As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABT")) Then colABT.Hidden = True
            Dim colABZ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABZ")) Then colABZ.Hidden = True
            Dim colABH As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABH")) Then colABH.Hidden = True
            Dim colUUW As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "UUW")) Then colUUW.Hidden = True
            Dim colABN As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABN")) Then colABN.Hidden = True
            Dim colAB6 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB6")) Then colAB6.Hidden = True
            Dim colAR2 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AR2")) Then colAR2.Hidden = True
            Dim colAKD As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKD")) Then colAKD.Hidden = True
            Dim colAB9 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB9")) Then colAB9.Hidden = True
            Dim colACB As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACB")) Then colACB.Hidden = True
            Dim colA2N As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "A2N")) Then colA2N.Hidden = True
            Dim colAKQ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKQ")) Then colAKQ.Hidden = True
            Dim colAKR As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKR")) Then colAKR.Hidden = True
            Dim colAKN As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKN")) Then colAKN.Hidden = True
            Dim colACQ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACQ")) Then colACQ.Hidden = True
            Dim colABE As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABE")) Then colABE.Hidden = True
            Dim colABS As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABS")) Then colABS.Hidden = True
            Dim colAK8 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AK8")) Then colAK8.Hidden = True
            Dim colUUZ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "UUZ")) Then colUUZ.Hidden = True
            Dim colB12 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B12")) Then colB12.Hidden = True
            Dim colAB8 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB8")) Then colAB8.Hidden = True
            Dim colABU As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABU")) Then colABU.Hidden = True
            '----------------------------------------
            ' APJ
            '----------------------------------------
            Dim colUUF As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "UUF")) Then colUUF.Hidden = True
            Dim colABG As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABG")) Then colABG.Hidden = True
            Dim colAB5 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB5")) Then colAB5.Hidden = True
            Dim colACJ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACJ")) Then colACJ.Hidden = True
            Dim colAR6 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AR6")) Then colAR6.Hidden = True
            Dim colABJ As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ABJ")) Then colABJ.Hidden = True
            Dim colACF As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "ACF")) Then colACF.Hidden = True
            Dim colAB1 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB1")) Then colAB1.Hidden = True
            Dim colB1L As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "B1L")) Then colB1L.Hidden = True
            Dim colAB2 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB2")) Then colAB2.Hidden = True
            Dim colAB4 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB4")) Then colAB4.Hidden = True
            Dim colAB0 As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AB0")) Then colAB0.Hidden = True
            Dim colAKL As WorksheetColumn = sheet.Table.Columns.Add(55)
            If Not CBool(InStr(regionCodes, "AKL")) Then colAKL.Hidden = True
            '-----------------------------------------------
            If ScitPublish Then
                Dim ScitRow As WorksheetRow = sheet.Table.Rows.Add
                ScitRow.Height = 26
                ScitRow.AutoFitHeight = False
                ScitRow.Cells.Add("SCIT PUBLISH FOR TESTING ONLY", DataType.String, "h21")
            End If

            Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
            Dim cell As WorksheetCell
            cell = Row0.Cells.Add
            cell.StyleID = "s21"
            cell.Data.Type = DataType.String
            cell.Data.Text = ScmName
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row1.Cells.Add
            cell.StyleID = "s43"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Published"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s43"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s44"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell.Data.Type = DataType.DateTime
            cell.Data.Text = DisplayedPublishDate.ToString("yyyy-MM-ddT00:00:00.000")
            cell = Row1.Cells.Add
            cell.StyleID = "s46"
            cell.Data.Type = DataType.String
            cell.Data.Text = "* Provides MR Date by Localized location (date format mm/dd/yy)"
            If (bolBSAMProd = True) Then
                cell.Index = 27
            Else
                cell.Index = 25
            End If
            cell.MergeAcross = 68
            '-----------------------------------------------
            Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
            Row2.Height = 30
            Row2.AutoFitHeight = False
            cell = Row2.Cells.Add
            cell.StyleID = "s47"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Today's date"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s47"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s48"
            cell.Data.Type = DataType.DateTime
            cell.Data.Text = Now.ToString("yyyy-MM-ddThh:mm:ss.000")
            cell.Formula = "=TODAY()"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "m19709554"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Americas"
            If (bolBSAMProd = True) Then
                cell.Index = 27
            Else
                cell.Index = 25
            End If
            cell.MergeAcross = 8
            cell = Row2.Cells.Add
            cell.StyleID = "m19709564"
            cell.Data.Type = DataType.String
            cell.Data.Text = "EMEA"
            cell.MergeAcross = 46
            cell = Row2.Cells.Add
            cell.StyleID = "m19709574"
            cell.Data.Type = DataType.String
            cell.Data.Text = "APD"
            cell.MergeAcross = 12
            '-----------------------------------------------
            Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
            Row3.Height = 57
            Row3.AutoFitHeight = False
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "AV# "
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Feature Category"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "GPG Description" & Microsoft.VisualBasic.ChrW(10) & "(no ' or "" quote marks)"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Marketing  Description" & Microsoft.VisualBasic.ChrW(10) & "(40 Char GPSy)"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Marketing Description" & Microsoft.VisualBasic.ChrW(10) & "(100 Char PMG)"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Program Version where used"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Select Availability" & Microsoft.VisualBasic.ChrW(10) & "(SA) Date"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "General Availability" & Microsoft.VisualBasic.ChrW(10) & "(GA) Date"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "End of Manufacturing" & Microsoft.VisualBasic.ChrW(10) & "(EM) Date"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Configuration Rules"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "AVID"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 1"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 2"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 3"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 4"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 5"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "IDS-SKUS"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "IDS-CTO"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "RCTO-SKUS"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "RCTO-CTO"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            If (bolBSAMProd = True) Then
                cell = Row3.Cells.Add
                cell.StyleID = "s56"
                cell.Data.Type = DataType.String
                cell.Data.Text = "BSAM" & Microsoft.VisualBasic.ChrW(10) & "Skus"
                cell.NamedCell.Add("Print_Titles")
                cell.NamedCell.Add("Print_Area")
                cell = Row3.Cells.Add
                cell.StyleID = "s56"
                cell.Data.Type = DataType.String
                cell.Data.Text = "BSAM" & Microsoft.VisualBasic.ChrW(10) & "Bparts"
                cell.NamedCell.Add("Print_Titles")
                cell.NamedCell.Add("Print_Area")
            End If
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "UPC"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Weight (in oz)"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s56"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Global Series Config" & Microsoft.VisualBasic.ChrW(10) & "Plan for End of" & Microsoft.VisualBasic.ChrW(10) & "Manufacturing (PE) Date"
            '"Global" & Microsoft.VisualBasic.ChrW(10) & "Series" & Microsoft.VisualBasic.ChrW(10) & "Config EOL"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row3.Cells.Add
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Regions"
            cell.NamedCell.Add("Print_Titles")

            '----------------------------------------
            ' Americas
            '----------------------------------------
            cell = Row3.Cells.Add   'AC8
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Argentina"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AC4
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Brazil"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'A1Y
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Brazil (English)"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABL
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Canada"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABC
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Canadian (French)"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AKH
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Chile"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABM
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Latin America"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ACH
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Latin America English"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABA
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "United States"
            cell.NamedCell.Add("Print_Titles")
            '----------------------------------------
            ' EMEA
            '----------------------------------------
            cell = Row3.Cells.Add   'BED
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Adriatic Region"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'BH5
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Africa-English"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'BH4
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Africa-French"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'BH6
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Africa-French/Arabic"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABV
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Arabia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'B1R
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Baltics"
            cell = Row3.Cells.Add   'UUG
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Belgium"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AKS
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Bulgaria"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'B1T
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Bulgaria/Romania"
            cell = Row3.Cells.Add   'AKB
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Czech Republic"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'BCM
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Czech/Slovakia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ARL
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Czech/Slovakia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABY
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Denmark"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s58"    'ABB
            cell.Data.Type = DataType.String
            cell.Data.Text = "Euro"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AK9
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Euro-A2"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'B10
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Euro-A5"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABX
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Finland"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABF
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "France"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'B1S
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "French Arabic"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABD
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Germany"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'B1A
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Greece"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AB7
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Greece"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AK7
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Greece/Poland"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AKC
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Hungary"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'A2M
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Iceland"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABT
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Israel (Hebrew)"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABZ
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Italy"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABH
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Netherlands"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'UUW
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Nordic"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABN
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Norway"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AB6
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "NW Africa"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AR2
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Pan Euro"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AKD
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Poland"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AB9
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Portugal"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ACB
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Russia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'A2N
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Saudi Arabia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AKQ
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Serbia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AKR
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Slovakia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AKN
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Slovenia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ACQ
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "South Africa"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABE
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Spain"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABS
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Sweden"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AK8
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Sweden / Finland"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'UUZ
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Switzerland"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'B12
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Switzerland"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AB8
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Turkey"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABU
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "United Kingdom"
            cell.NamedCell.Add("Print_Titles")
            '----------------------------------------
            ' EMEA
            '----------------------------------------
            cell = Row3.Cells.Add   'UUF
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Asia Pacific"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s58"    'ABG
            cell.Data.Type = DataType.String
            cell.Data.Text = "Australia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AB5
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Hong Kong"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ACJ
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "India"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AR6
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Indonesia"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ABJ
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Japan"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'ACF
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Japan (English)"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AB1
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Korea"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'B1L
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PRC (CH,EN)"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AB2
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PRC Chinese"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AB4
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Singapore"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AB0
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Taiwan"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add   'AKL
            cell.StyleID = "s58"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Thailand"
            cell.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
            ' ----------------------------------------
            ' Americas
            ' ----------------------------------------
            cell = Row4.Cells.Add("LA Merco", DataType.String, "s23")   'AC8
            If (bolBSAMProd = True) Then
                cell.Index = 27
            Else
                cell.Index = 25
            End If
            Row4.Cells.Add("BRZL", DataType.String, "s23")      'AC4
            Row4.Cells.Add("BRZE", DataType.String, "s23")      'A1Y
            Row4.Cells.Add("CAN/ENG", DataType.String, "s23")   'ABL
            Row4.Cells.Add("FCAN", DataType.String, "s23")      'ABC
            Row4.Cells.Add("CHILE", DataType.String, "s23")     'AKH
            Row4.Cells.Add("LTNA", DataType.String, "s23")      'ABM
            Row4.Cells.Add("LAE", DataType.String, "s23")       'ACH
            Row4.Cells.Add("US", DataType.String, "s23")        'ABA
            ' ----------------------------------------
            ' EMEA
            ' ----------------------------------------
            Row4.Cells.Add("ADR", DataType.String, "s23")       'BED
            Row4.Cells.Add("AFRC-E", DataType.String, "s23")    'BH5
            Row4.Cells.Add("AFRC-F", DataType.String, "s23")    'BH4
            Row4.Cells.Add("AFRC-F/A", DataType.String, "s23")  'BH6
            Row4.Cells.Add("ARAB", DataType.String, "s23")      'ABV
            Row4.Cells.Add("EUROR2", DataType.String, "s23")    'B1R
            Row4.Cells.Add("EUROA4", DataType.String, "s23")    'UUG
            Row4.Cells.Add("BULG", DataType.String, "s23")      'AKS
            Row4.Cells.Add("EUROR4", DataType.String, "s23")    'B1T
            Row4.Cells.Add("CZECH", DataType.String, "s23")     'AKB
            Row4.Cells.Add("CZECH-SK", DataType.String, "s23")  'BCM
            Row4.Cells.Add("EEUROA8", DataType.String, "s23")    'ARL
            Row4.Cells.Add("DEN", DataType.String, "s23")       'ABY
            Row4.Cells.Add("EURO", DataType.String, "s23")      'ABB
            Row4.Cells.Add("EUROA2", DataType.String, "s23")    'AK9
            Row4.Cells.Add("EUROA5", DataType.String, "s23")    'B10
            Row4.Cells.Add("FI", DataType.String, "s23")        'ABX
            Row4.Cells.Add("FR", DataType.String, "s23")        'ABF
            Row4.Cells.Add("EUROR3", DataType.String, "s23")    'B1S
            Row4.Cells.Add("GR", DataType.String, "s23")        'ABD
            Row4.Cells.Add("GK", DataType.String, "s23")        'B1A
            Row4.Cells.Add("GRK", DataType.String, "s23")       'AB7
            Row4.Cells.Add("GK/PL", DataType.String, "s23")     'AK7
            Row4.Cells.Add("HUNG", DataType.String, "s23")      'AKC
            Row4.Cells.Add("ICELAND", DataType.String, "s23")   'A2M
            Row4.Cells.Add("HE", DataType.String, "s23")        'ABT
            Row4.Cells.Add("ITL", DataType.String, "s23")       'ABZ
            Row4.Cells.Add("NL", DataType.String, "s23")        'ABH
            Row4.Cells.Add("NRL", DataType.String, "s23")       'UUW
            Row4.Cells.Add("NOR", DataType.String, "s23")       'ABN
            Row4.Cells.Add("NWAFR", DataType.String, "s23")     'AB6
            Row4.Cells.Add("EB", DataType.String, "s23")        'AR2
            Row4.Cells.Add("POL", DataType.String, "s23")       'AKD
            Row4.Cells.Add("PORT", DataType.String, "s23")      'AB9
            Row4.Cells.Add("RUSS", DataType.String, "s23")      'ACB
            Row4.Cells.Add("SAU", DataType.String, "s23")       'A2N
            Row4.Cells.Add("SCC", DataType.String, "s23")       'AKQ
            Row4.Cells.Add("SK", DataType.String, "s23")        'AKR
            Row4.Cells.Add("SL", DataType.String, "s23")        'AKN
            Row4.Cells.Add("SA", DataType.String, "s23")        'ACQ
            Row4.Cells.Add("SP", DataType.String, "s23")        'ABE
            Row4.Cells.Add("SE", DataType.String, "s23")        'ABS
            Row4.Cells.Add("SE/FI", DataType.String, "s23")     'AK8
            Row4.Cells.Add("SWIS2", DataType.String, "s23")     'UUZ
            Row4.Cells.Add("SWIS1", DataType.String, "s23")     'B12
            Row4.Cells.Add("TURK", DataType.String, "s23")      'AB8
            Row4.Cells.Add("UK", DataType.String, "s23")        'ABU
            ' ----------------------------------------
            ' APJ
            ' ----------------------------------------
            Row4.Cells.Add("A/P", DataType.String, "s23")       'UUF
            Row4.Cells.Add("AUST", DataType.String, "s23")      'ABG
            Row4.Cells.Add("HK", DataType.String, "s23")        'AB5
            Row4.Cells.Add("INDIA", DataType.String, "s23")     'ACJ
            Row4.Cells.Add("INDO", DataType.String, "s23")      'AR6
            Row4.Cells.Add("JPN2", DataType.String, "s23")      'ABJ
            Row4.Cells.Add("JPN/ENG", DataType.String, "s23")   'ACF
            Row4.Cells.Add("KOR", DataType.String, "s23")       'AB1
            Row4.Cells.Add("ASIA", DataType.String, "s23")      'B1L
            Row4.Cells.Add("PRC", DataType.String, "s23")       'AB2
            Row4.Cells.Add("SING", DataType.String, "s23")      'AB4
            Row4.Cells.Add("TW", DataType.String, "s23")        'AB0
            Row4.Cells.Add("THAI", DataType.String, "s23")      'AKL
            '-----------------------------------------------
            Dim Row5 As WorksheetRow = sheet.Table.Rows.Add
            Row5.Height = 30
            Row5.AutoFitHeight = False
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell.NamedCell.Add("Print_Titles")
            cell = Row5.Cells.Add
            cell.StyleID = "s60"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Marketing"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s60"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Marketing"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s61"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PDM Team"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s61"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PDM Team"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s61"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PDM Team"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            If (bolBSAMProd = True) Then
                cell = Row5.Cells.Add
                cell.StyleID = "s59"
                cell.Data.Type = DataType.String
                cell.Data.Text = "Config Mgt"
                cell.NamedCell.Add("Print_Area")
                cell = Row5.Cells.Add
                cell.StyleID = "s59"
                cell.Data.Type = DataType.String
                cell.Data.Text = "Config Mgt"
                cell.NamedCell.Add("Print_Area")
            End If
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s59"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Mgt"
            cell.NamedCell.Add("Print_Area")
            cell = Row5.Cells.Add
            cell.StyleID = "s62"
            ' ----------------------------------------
            ' Americas
            ' ----------------------------------------
            Row5.Cells.Add("AC8", DataType.String, "s23")
            Row5.Cells.Add("AC4", DataType.String, "s23")
            Row5.Cells.Add("A1Y", DataType.String, "s23")
            Row5.Cells.Add("ABL", DataType.String, "s23")
            Row5.Cells.Add("ABC", DataType.String, "s23")
            Row5.Cells.Add("AKH", DataType.String, "s23")
            Row5.Cells.Add("ABM", DataType.String, "s23")
            Row5.Cells.Add("ACH", DataType.String, "s23")
            Row5.Cells.Add("ABA", DataType.String, "s23")
            ' ----------------------------------------
            ' EMEA
            ' ----------------------------------------
            Row5.Cells.Add("BED", DataType.String, "s23")
            Row5.Cells.Add("BH5", DataType.String, "s23")
            Row5.Cells.Add("BH4", DataType.String, "s23")
            Row5.Cells.Add("BH6", DataType.String, "s23")
            Row5.Cells.Add("ABV", DataType.String, "s23")
            Row5.Cells.Add("B1R", DataType.String, "s23")
            Row5.Cells.Add("UUG", DataType.String, "s23")
            Row5.Cells.Add("AKS", DataType.String, "s23")
            Row5.Cells.Add("B1T", DataType.String, "s23")
            Row5.Cells.Add("AKB", DataType.String, "s23")
            Row5.Cells.Add("BCM", DataType.String, "s23")
            Row5.Cells.Add("ARL", DataType.String, "s23")
            Row5.Cells.Add("ABY", DataType.String, "s23")
            Row5.Cells.Add("ABB", DataType.String, "s23")
            Row5.Cells.Add("AK9", DataType.String, "s23")
            Row5.Cells.Add("B10", DataType.String, "s23")
            Row5.Cells.Add("ABX", DataType.String, "s23")
            Row5.Cells.Add("ABF", DataType.String, "s23")
            Row5.Cells.Add("B1S", DataType.String, "s23")
            Row5.Cells.Add("ABD", DataType.String, "s23")
            Row5.Cells.Add("B1A", DataType.String, "s23")
            Row5.Cells.Add("AB7", DataType.String, "s23")
            Row5.Cells.Add("AK7", DataType.String, "s23")
            Row5.Cells.Add("AKC", DataType.String, "s23")
            Row5.Cells.Add("A2M", DataType.String, "s23")
            Row5.Cells.Add("ABT", DataType.String, "s23")
            Row5.Cells.Add("ABZ", DataType.String, "s23")
            Row5.Cells.Add("ABH", DataType.String, "s23")
            Row5.Cells.Add("UUW", DataType.String, "s23")
            Row5.Cells.Add("ABN", DataType.String, "s23")
            Row5.Cells.Add("AB6", DataType.String, "s23")
            Row5.Cells.Add("AR2", DataType.String, "s23")
            Row5.Cells.Add("AKD", DataType.String, "s23")
            Row5.Cells.Add("AB9", DataType.String, "s23")
            Row5.Cells.Add("ACB", DataType.String, "s23")
            Row5.Cells.Add("A2N", DataType.String, "s23")
            Row5.Cells.Add("AKQ", DataType.String, "s23")
            Row5.Cells.Add("AKR", DataType.String, "s23")
            Row5.Cells.Add("AKN", DataType.String, "s23")
            Row5.Cells.Add("ACQ", DataType.String, "s23")
            Row5.Cells.Add("ABE", DataType.String, "s23")
            Row5.Cells.Add("ABS", DataType.String, "s23")
            Row5.Cells.Add("AK8", DataType.String, "s23")
            Row5.Cells.Add("UUZ", DataType.String, "s23")
            Row5.Cells.Add("B12", DataType.String, "s23")
            Row5.Cells.Add("AB8", DataType.String, "s23")
            Row5.Cells.Add("ABU", DataType.String, "s23")
            ' ----------------------------------------
            ' APJ
            ' ----------------------------------------
            Row5.Cells.Add("UUF", DataType.String, "s23")
            Row5.Cells.Add("ABG", DataType.String, "s23")
            Row5.Cells.Add("AB5", DataType.String, "s23")
            Row5.Cells.Add("ACJ", DataType.String, "s23")
            Row5.Cells.Add("AR6", DataType.String, "s23")
            Row5.Cells.Add("ABJ", DataType.String, "s23")
            Row5.Cells.Add("ACF", DataType.String, "s23")
            Row5.Cells.Add("AB1", DataType.String, "s23")
            Row5.Cells.Add("B1L", DataType.String, "s23")
            Row5.Cells.Add("AB2", DataType.String, "s23")
            Row5.Cells.Add("AB4", DataType.String, "s23")
            Row5.Cells.Add("AB0", DataType.String, "s23")
            Row5.Cells.Add("AKL", DataType.String, "s23")
            '-----------------------------------------------
            '
            ' Select Scm Detail
            '
            '-----------------------------------------------
            Dim intRegionID As Integer
            Select Case RegionID
                Case "Americas"
                    intRegionID = 1
                Case "EMEA"
                    intRegionID = 2
                Case "APJ"
                    intRegionID = 3
            End Select

            If (RegionID = "") Then
                dt = dw.SelectScmDetailByStatus(ProductVersionID, ProductBrandID, "O")
            Else
                dt = HPQ.Excalibur.Data.SelectScmDetailByStatus_RegionAndPlatformsView(ProductVersionID, ProductBrandID, "O", intRegionID)
            End If

            Dim RowX As WorksheetRow
            Dim iCatId As Int32 = 0
            Dim bEmptyCat As Boolean = False
            Dim dtLastUpdate As DateTime

            For Each drow As DataRow In dt.Rows
                If drow("Status").ToString <> "H" Then
                    If iCatId <> drow("FeatureCategoryID") Then
                        iCatId = drow("FeatureCategoryID")
                        '
                        ' Category Row
                        '
                        If bEmptyCat Then
                            sheet.Table.Rows.Add()
                            sheet.Table.Rows.Add()
                        ElseIf iCatId <> 1 Then
                            sheet.Table.Rows.Add()
                        End If

                        dtLastUpdate = drow("ConfigRules_LastUpdDt").ToString
                        If Not IsDate(dtLastUpdate) Then
                            dtLastUpdate = LastPublishDate
                        End If

                        If dtLastUpdate > LastPublishDate Then
                            RowX = sheet.Table.Rows.Add
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s67"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("AvFeatureCategory").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("CategoryMarketingDescription").ToString)
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("CategoryRules").ToString)
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            If (bolBSAMProd = True) Then
                                cell = RowX.Cells.Add
                                cell.StyleID = "s32"
                                cell.NamedCell.Add("Print_Area")
                                '-----------------------------------------------------------------------------------
                                cell = RowX.Cells.Add
                                cell.StyleID = "s32"
                                cell.NamedCell.Add("Print_Area")
                            End If
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s32"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                        Else
                            RowX = sheet.Table.Rows.Add
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s67"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("AvFeatureCategory").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("CategoryMarketingDescription").ToString)
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("CategoryRules").ToString)
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            If (bolBSAMProd = True) Then
                                cell = RowX.Cells.Add
                                cell.StyleID = "s31"
                                cell.NamedCell.Add("Print_Area")
                                '-----------------------------------------------------------------------------------
                                cell = RowX.Cells.Add
                                cell.StyleID = "s31"
                                cell.NamedCell.Add("Print_Area")
                            End If
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                            cell = RowX.Cells.Add
                            cell.StyleID = "s31"
                            cell.NamedCell.Add("Print_Area")
                            '-----------------------------------------------------------------------------------
                        End If
                        bEmptyCat = True
                    End If

                    If drow("AvNo").ToString <> String.Empty Then
                        bEmptyCat = False
                        RowX = sheet.Table.Rows.Add

                        If drow("Status").ToString = "O" And drow("bStatus").ToString = "1" Then
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("AvNo").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("GPGDescription").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("MarketingDescription").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("MarketingDescriptionPMG").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ProgramVersion
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = FormatDate(drow("CPLBlindDt").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = FormatDate(drow("GeneralAvailDt").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = FormatDate(drow("RASDiscontinueDt").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("ConfigRules").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("AvId").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group1").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group2").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group3").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group4").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group5").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ConvertYN(drow("IdsSkus_YN").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ConvertYN(drow("IdsCto_YN").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ConvertYN(drow("RctoSkus_YN").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ConvertYN(drow("RctoCto_YN").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            If (bolBSAMProd = True) Then
                                cell = Row3.Cells.Add
                                cell.StyleID = "s74"
                                cell.Data.Type = DataType.String
                                cell.Data.Text = ConvertYN(drow("BSAMSkus_YN").ToString)
                                cell.NamedCell.Add("Print_Area")
                                cell = Row3.Cells.Add
                                cell.StyleID = "s74"
                                cell.Data.Type = DataType.String
                                cell.Data.Text = ConvertYN(drow("BSAMBparts_YN").ToString)
                                cell.NamedCell.Add("Print_Area")
                            End If
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("UPC").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s74"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = FormatDate(drow("GSEndDt").ToString)
                            cell.NamedCell.Add("Print_Area")
                        ElseIf drow("status").ToString = "O" Then
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("AvNo").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("GPGDescription").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell.NamedCell.Add("Print_Titles")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("MarketingDescription").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("MarketingDescriptionPMG").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ProgramVersion
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = FormatDate(drow("CPLBlindDt").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = FormatDate(drow("GeneralAvailDt").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = FormatDate(drow("RASDiscontinueDt").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("ConfigRules").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("AvId").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group1").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group2").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group3").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group4").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("Group5").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ConvertYN(drow("IdsSkus_YN").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ConvertYN(drow("IdsCto_YN").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ConvertYN(drow("RctoSkus_YN").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = ConvertYN(drow("RctoCto_YN").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            If (bolBSAMProd = True) Then
                                cell = Row3.Cells.Add
                                cell.StyleID = "s72"
                                cell.Data.Type = DataType.String
                                cell.Data.Text = ConvertYN(drow("BSAMSkus_YN").ToString)
                                cell.NamedCell.Add("Print_Area")
                                cell = Row3.Cells.Add
                                cell.StyleID = "s72"
                                cell.Data.Type = DataType.String
                                cell.Data.Text = ConvertYN(drow("BSAMBparts_YN").ToString)
                                cell.NamedCell.Add("Print_Area")
                            End If
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = XmlEncode(drow("UPC").ToString)
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.NamedCell.Add("Print_Area")
                            cell = RowX.Cells.Add
                            cell.StyleID = "s72"
                            cell.Data.Type = DataType.String
                            cell.Data.Text = FormatDate(drow("GSEndDt").ToString)
                            cell.NamedCell.Add("Print_Area")
                        End If
                        '
                        ' Insert the MR Dates
                        '

                        ' ========================================
                        ' Americas
                        ' ========================================
                        cell = RowX.Cells.Add
                        cell.StyleID = "s31"
                        cell.Data.Type = DataType.String
                        cell.Data.Text = FormatDate(drow("AC8").ToString)
                        If (bolBSAMProd = True) Then
                            cell.Index = 27
                        Else
                            cell.Index = 25
                        End If
                        RowX.Cells.Add(FormatDate(drow("AC4").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("A1Y").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABL").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABC").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKH").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABM").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACH").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABA").ToString), DataType.String, "s31")

                        ' ========================================
                        ' EMEA
                        ' ========================================
                        RowX.Cells.Add(FormatDate(drow("BED").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("BH5").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("BH4").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("BH6").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABV").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1R").ToString), DataType.String, "s32")
                        RowX.Cells.Add(FormatDate(drow("UUG").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKS").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1T").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKB").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("BCM").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ARL").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABY").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABB").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AK9").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B10").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABX").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABF").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1S").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABD").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1A").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB7").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AK7").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKC").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("A2M").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABT").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABZ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABH").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("UUW").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABN").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB6").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AR2").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKD").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB9").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACB").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("A2N").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKQ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKR").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKN").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACQ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABE").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABS").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AK8").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("UUZ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B12").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB8").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABU").ToString), DataType.String, "s31")

                        ' ========================================
                        ' APJ
                        ' ========================================
                        RowX.Cells.Add(FormatDate(drow("UUF").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABG").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB5").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACJ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AR6").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ABJ").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("ACF").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB1").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("B1L").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB2").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB4").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AB0").ToString), DataType.String, "s31")
                        RowX.Cells.Add(FormatDate(drow("AKL").ToString), DataType.String, "s31")


                    End If
                End If
            Next

            '-----------------------------------------------
            Dim Row23 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row23.Cells.Add
            cell.StyleID = "s64"
            cell.Index = 8
            '-----------------------------------------------
            Dim Row24 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row24.Cells.Add
            cell.StyleID = "s64"
            cell.Index = 8
            '-----------------------------------------------
            Dim Row25 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Items below this line are for US Retail Web/Kiosk only"
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            If (bolBSAMProd = True) Then
                cell = Row25.Cells.Add
                cell.StyleID = "s80"
                cell.Data.Type = DataType.String
                cell.NamedCell.Add("Print_Titles")
                cell = Row25.Cells.Add
                cell.StyleID = "s80"
                cell.Data.Type = DataType.String
                cell.NamedCell.Add("Print_Titles")
            End If
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            cell = Row25.Cells.Add
            cell.StyleID = "s80"
            cell.Data.Type = DataType.String
            cell.NamedCell.Add("Print_Titles")
            '-----------------------------------------------
            ' Options
            '-----------------------------------------------
            sheet.Options.FreezePanes = True
            sheet.Options.FitToPage = True
            sheet.Options.SplitHorizontal = 5
            sheet.Options.TopRowBottomPane = 5
            sheet.Options.SplitVertical = 3
            sheet.Options.LeftColumnRightPane = 3
            sheet.Options.ActivePane = 0
            sheet.Options.ProtectObjects = False
            sheet.Options.ProtectScenarios = False
            sheet.Options.PageSetup.Layout.Orientation = Orientation.Landscape
            sheet.Options.PageSetup.Footer.Margin = 0.17!
            sheet.Options.PageSetup.PageMargins.Bottom = 0.42!
            sheet.Options.PageSetup.PageMargins.Left = 0.75!
            sheet.Options.PageSetup.PageMargins.Right = 0.75!
            sheet.Options.PageSetup.PageMargins.Top = 0.44!
            sheet.Options.Print.PaperSizeIndex = 5
            sheet.Options.Print.Scale = 58
            sheet.Options.Print.FitHeight = 48
            sheet.Options.Print.ValidPrinterInfo = True
        End Sub
#End Region

#Region " Generate Worksheet Platform Data "
        Private Sub GenerateWorksheetSCMPlatformdata(ByVal sheets As WorksheetCollection, ByVal scmname As String)

            Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
            Dim dt As DataTable = dw.SelectKMAT(ProductVersionID, ProductBrandID)

            Dim sheet As Worksheet = sheets.Add("SCM Platform data")
            sheet.Table.FullColumns = 1
            sheet.Table.Columns.Add(120)
            sheet.Table.Columns.Add(72)
            sheet.Table.Columns.Add(85)
            sheet.Table.Columns.Add(83)
            '-----------------------------------------------
            If ScitPublish Then
                Dim ScitRow As WorksheetRow = sheet.Table.Rows.Add
                ScitRow.Height = 26
                ScitRow.AutoFitHeight = False
                ScitRow.Cells.Add("SCIT PUBLISH FOR TESTING ONLY", DataType.String, "h21")
            End If

            Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
            Row0.Height = 26
            Row0.AutoFitHeight = False
            Row0.Cells.Add(scmname, DataType.String, "s21")
            '-----------------------------------------------
            Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
            Row1.Height = 15
            Row1.AutoFitHeight = False
            Row1.Cells.Add("Platform Information", DataType.String, "s22")
            '-----------------------------------------------
            Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
            Row2.Cells.Add("KMAT Part number", DataType.String, "s65")
            Dim cell As WorksheetCell
            cell = Row2.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = XmlEncode(dt.Rows(0)("KMAT").ToString)
            '-----------------------------------------------
            Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
            Row3.Cells.Add("EZC KMAT Part number", DataType.String, "s65")
            cell = Row3.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = XmlEncode(dt.Rows(0)("EZCKMAT").ToString)
            '-----------------------------------------------
            Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
            Row4.Cells.Add("Project Code Number", DataType.String, "s65")
            cell = Row4.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = XmlEncode(dt.Rows(0)("ProjectCd").ToString)
            '-----------------------------------------------
            Dim Row5 As WorksheetRow = sheet.Table.Rows.Add
            Row5.Cells.Add("Sales Orgs", DataType.String, "s65")
            cell = Row5.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = XmlEncode(dt.Rows(0)("SalesOrg").ToString)
            '-----------------------------------------------
            Dim Row6 As WorksheetRow = sheet.Table.Rows.Add
            Row6.Cells.Add("Plant Code", DataType.String, "s65")
            cell = Row6.Cells.Add
            cell.StyleID = "s23"
            cell.Data.Type = DataType.String
            cell.Data.Text = XmlEncode(dt.Rows(0)("PlantCd").ToString)
        End Sub
#End Region

    End Class

#Region " Class BSAMBoolInfo "
    Class BSAMBoolInfo
        Private _productBrandID As Long
        Public Property ProductBrandID() As Long
            Get
                Return _productBrandID
            End Get
            Set(ByVal value As Long)
                _productBrandID = value
                Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
                Dim dt As DataTable = dwExcalibur.SelectKmatVersions(_productBrandID.ToString())
                If dt.Rows.Count > 0 Then
                    Boolean.TryParse(dt.Rows(0)("BsamFlag").ToString(), _bsamFlag)
                Else
                    _bsamFlag = False
                End If
            End Set
        End Property

#Region " ReadOnly Properties "
        Private _bsamFlag As Boolean
        Public ReadOnly Property BsamFlag() As Boolean
            Get
                Return _bsamFlag
            End Get
        End Property
#End Region

#Region " Constructors "
        Public Sub New()

        End Sub

        Public Sub New(ByVal ProductBrandID As Long)
            Me.ProductBrandID = ProductBrandID
        End Sub
#End Region

    End Class
#End Region
End Namespace