﻿
Imports System.Text

Namespace CodeBehind
    Public Class PhWebAutoInput
        Inherits System.Web.UI.Page

        Private ReadOnly Property AvDetailIDs() As String
            Get
                Return Request.Form("AvDetailIDs")
            End Get
        End Property

        Private ReadOnly Property UserID() As String
            Get
                Return Request.Form("UserID")
            End Get
        End Property


        Protected Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If Not Page.IsPostBack And AvDetailIDs <> "" Then

                Dim excaliburData As HPQ.Excalibur.Data = New HPQ.Excalibur.Data

                Dim PhWebAutoInput As New ExcelExportLegacyVBCode.PhWebAutoInputRequest.PhWebAutoInputRequest

                Dim strm As System.IO.MemoryStream = New System.IO.MemoryStream

                Dim saFileName(2) As String
                saFileName(0) = "PhWebAutoInputForm"
                saFileName(1) = String.Format("{0}{1}{2}", Now.Year.ToString(), Now.Month.ToString.PadLeft(2, "0"), Now.Day.ToString.PadLeft(2, "0"))
                Dim fileName As String = String.Format("{0}_{1}.xls", saFileName)
                fileName = fileName.Replace(" ", "_")
                For Each character As Char In System.IO.Path.GetInvalidFileNameChars()
                    fileName = fileName.Replace(character, "_")
                Next

                PhWebAutoInput.AvDetailIDs = AvDetailIDs
                PhWebAutoInput.UserID = UserID
                PhWebAutoInput.Generate(strm)

                Response.Clear()
                Response.AddHeader("Content-Disposition", String.Format("attachment; filename={0}", fileName))
                Response.ContentType = "application/vnd.ms-excel"

                Dim outputString As StringBuilder = New StringBuilder(2048)

                Dim b As Integer
                Dim prevChar1 As Char = ""
                Dim prevChar2 As Char = ""
                strm.Position = 3
                While True
                    b = strm.ReadByte()
                    If b = -1 Then Exit While
                    If b > 31 And b < 127 Or b = 10 Then
                        If prevChar2 <> Convert.ToChar(">") And b = 10 Then
                            outputString.Append("&#10;")
                        Else
                            outputString.Append(Convert.ToChar(b))
                        End If
                    End If
                    prevChar2 = prevChar1
                    prevChar1 = Convert.ToChar(b)

                End While

                Response.Write(outputString.ToString())
            End If
        End Sub

    End Class

End Namespace
