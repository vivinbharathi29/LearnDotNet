Imports System.Data.SqlClient
Imports System.Text


Namespace CodeBehind
    Public Class ProgramMatrix
        Inherits System.Web.UI.Page
        Private ReadOnly Property ProductBrandID() As String
            Get
                Return Request.Form("ProductBrandID")
            End Get
        End Property

        Private ReadOnly Property Publish() As Boolean
            Get
                If Request.Form("chkPublish") = "on" Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property

        Private ReadOnly Property NewProgramMagrix() As Boolean
            Get
                If Request.Form("chkNewMatrix") = "on" Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property

        Private ReadOnly Property CompareToDate() As String
            Get
                Return Request.Form("selCompareDt")
            End Get
        End Property

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


            Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
            Dim dt As DataTable = dwExcalibur.ListScmNames("", ProductBrandID)
            Dim PvCount As Integer = dwExcalibur.SelectKmatVersions(ProductBrandID).Rows.Count()
            Dim sFamily As String = dt.Rows(0)("Name").ToString()
            Dim sVersion As String = dt.Rows(0)("Version").ToString()
            If PvCount > 1 Then sVersion = sVersion.Substring(0, sVersion.IndexOf(".")) & ".x"
            Dim sSeries As String = dt.Rows(0)("SeriesName").ToString()
            Dim sKmat As String = dt.Rows(0)("KMAT").ToString()
            Dim fusion As Boolean = dt.Rows(0)("Fusion")
            Dim ProductVersionId As Integer = 0
            Integer.TryParse(dt.Rows(0)("ProductVersionId").ToString(), ProductVersionId)

            Dim BSAMInfo As BSAMBoolInfo2 = New BSAMBoolInfo2(ProductBrandID)
            Dim bolBSAMProd As Boolean = BSAMInfo.BsamFlag

            Dim saFileName(5) As String
            saFileName(0) = sFamily
            saFileName(1) = sVersion
            saFileName(2) = sSeries
            saFileName(3) = "Program Matrix"
            saFileName(4) = String.Format("{0}{1}{2}", Now.Year.ToString(), Now.Month.ToString.PadLeft(2, "0"), Now.Day.ToString.PadLeft(2, "0"))
            Dim fileName As String = String.Format("{0}_{1}_{2}_{3}_{4}.xls", saFileName)
            fileName = fileName.Replace(" ", "_")
            For Each character As Char In System.IO.Path.GetInvalidFileNameChars()
                fileName = fileName.Replace(character, "_")
            Next

            Dim strm As System.IO.MemoryStream = New System.IO.MemoryStream

            Dim matrix As New ExcelExport.GenPM()
            matrix.NewMatrix = NewProgramMagrix
            matrix.ProductBrandID = ProductBrandID
            matrix.Publish = Publish
            matrix.CompareDt = CompareToDate
            matrix.BSAM = bolBSAMProd
            matrix.Generate(strm, fileName)


            Response.Clear()
            Response.AddHeader("Content-Disposition", String.Format("attachment; filename={0}", fileName))
            Response.ContentType = "application/vnd.ms-excel"

            Dim outputString As StringBuilder = New StringBuilder(2048)

            Dim b As Integer
            Dim prevChar1 As Char = ""
            Dim prevChar2 As Char = ""
            strm.Position = 3
            While True
                b = strm.ReadByte()
                If b = -1 Then Exit While
                If b > 31 And b < 127 Or b = 10 Then
                    If prevChar2 <> Convert.ToChar(">") And b = 10 Then
                        outputString.Append("&#10;")
                    Else
                        outputString.Append(Convert.ToChar(b))
                    End If
                End If
                prevChar2 = prevChar1
                prevChar1 = Convert.ToChar(b)

            End While

            Dim pbId As Integer = 0
            Integer.TryParse(ProductBrandID, pbId)

            If (fusion) And Publish Then
                Dim dw As HPQ.Data.DataWrapper = New HPQ.Data.DataWrapper()
                Dim cmd As SqlCommand = dw.CreateCommand("dbo.usp_SSSB_SendSync_Message")
                dw.CreateParameter(cmd, "@Operation", SqlDbType.VarChar, "MSMQLegacy")
                dw.CreateParameter(cmd, "@TypeID", SqlDbType.Int, 8)
                dw.CreateParameter(cmd, "@ObjectID", SqlDbType.VarChar, ProductBrandID)
                dw.CreateParameter(cmd, "@Arg", SqlDbType.Int, 1)
                dw.CreateParameter(cmd, "@source", SqlDbType.VarChar, "PM")
                dw.ExecuteCommandNonQuery(cmd)
            End If

            If Request.Form("chkXrost") = "on" Then
                Dim xrost As HPQ.Data.DataWrapper = New HPQ.Data.DataWrapper()
                Dim cmdROST As SqlCommand = xrost.CreateCommand("dbo.usp_SSSB_SendXROST_Message")
                xrost.CreateParameter(cmdROST, "@kmat", SqlDbType.VarChar, sKmat)
                xrost.CreateParameter(cmdROST, "@action", SqlDbType.VarChar, "WWOFFERFEED")
                xrost.CreateParameter(cmdROST, "@source", SqlDbType.VarChar, "PM")
                xrost.CreateParameter(cmdROST, "@messageOnHoldId", SqlDbType.Int, DBNull.Value.ToString())
                xrost.ExecuteCommandNonQuery(cmdROST)
            End If

            Response.Write(outputString.ToString())

        End Sub
    End Class

#Region " Class BSAMBoolInfo "
    Class BSAMBoolInfo2
        Private _productBrandID As Long
        Public Property ProductBrandID2() As Long
            Get
                Return _productBrandID
            End Get
            Set(ByVal value As Long)
                _productBrandID = value
                Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
                Dim dt As DataTable = dwExcalibur.SelectKmatVersions(_productBrandID.ToString())
                If (dt.Rows.Count > 0) Then
                    Boolean.TryParse(dt.Rows(0)("BsamFlag").ToString(), _bsamFlag)
                Else
                    _bsamFlag = False
                End If
            End Set
        End Property

#Region " ReadOnly Properties "
        Private _bsamFlag As Boolean = False
        Public ReadOnly Property BsamFlag() As Boolean
            Get
                Return _bsamFlag
            End Get
        End Property
#End Region

#Region " Constructors "
        Public Sub New()

        End Sub

        Public Sub New(ByVal ProductBrandID As Long)
            Me.ProductBrandID2 = ProductBrandID
        End Sub
#End Region

    End Class
#End Region

End Namespace
