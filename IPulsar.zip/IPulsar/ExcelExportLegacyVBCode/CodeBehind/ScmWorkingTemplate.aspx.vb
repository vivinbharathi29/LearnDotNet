Imports System.Data
Imports System.Text

Namespace CodeBehind

    Public Class ScmWorkingTemplate
        Inherits System.Web.UI.Page
        Private ReadOnly Property ProductBrandID() As String
            Get
                Return Request.QueryString("PBID")
            End Get
        End Property

        Private ReadOnly Property ProductVerID() As String
            Get
                Return Request.QueryString("PVID")
            End Get
        End Property

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

            Dim strm As System.IO.MemoryStream = New System.IO.MemoryStream
            Dim matrix As New ExcelExport.XmlScmTemplate()
            matrix.ProductBrandID = ProductBrandID
            matrix.ProductVersion = ProductVerID
            Dim fileName As String = String.Empty

            matrix.Generate(strm, fileName)

            Response.Clear()
            Response.AddHeader("Content-Disposition", String.Format("attachment; filename={0}", fileName))
            Response.ContentType = "application/vnd.ms-excel"

            Dim outputString As StringBuilder = New StringBuilder(2048)

            Dim b As Integer
            Dim prevChar1 As Char = ""
            Dim prevChar2 As Char = ""
            strm.Position = 3
            While True
                b = strm.ReadByte()
                If b = -1 Then Exit While
                If b > 31 And b < 127 Or b = 10 Then
                    If prevChar2 <> Convert.ToChar(">") And b = 10 Then
                        outputString.Append("&#10;")
                    Else
                        outputString.Append(Convert.ToChar(b))
                    End If
                    prevChar2 = prevChar1
                    prevChar1 = Convert.ToChar(b)
                End If
            End While

            Response.Write(outputString.ToString())

        End Sub
    End Class
End Namespace
