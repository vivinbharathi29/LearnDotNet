﻿Imports System.Text

Namespace CodeBehind

    Public Class InitialOfferingSubassemblyReport
        Inherits System.Web.UI.Page

        Private ReadOnly Property BusinessID() As String
            Get
                Return Request.QueryString("BusinessID")
            End Get
        End Property


        Protected Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If Not Page.IsPostBack Then
                Dim excaliburData As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
                Dim InitialOfferingSubassemblyReport As New InitialOfferingSubassemblyReportRequest
                Dim strm As System.IO.MemoryStream = New System.IO.MemoryStream
                Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()

                Dim fileName As String = "InitialOfferingSummaryReport_" & Now.Year.ToString() & "_" & Now.Month.ToString.PadLeft(2, "0") & "_" & Now.Day.ToString.PadLeft(2, "0") & ".xls"

                InitialOfferingSubassemblyReport.BusinessID = BusinessID
                InitialOfferingSubassemblyReport.Generate(strm)

                Response.Clear()
                Response.AddHeader("Content-Disposition", String.Format("attachment; filename={0}", fileName))
                Response.ContentType = "application/vnd.ms-excel"

                Dim outputString As StringBuilder = New StringBuilder(2048)

                Dim b As Integer
                Dim prevChar1 As Char = ""
                Dim prevChar2 As Char = ""
                strm.Position = 3
                While True
                    b = strm.ReadByte()
                    If b = -1 Then Exit While
                    If b > 31 And b < 127 Or b = 10 Then
                        If prevChar2 <> Convert.ToChar(">") And b = 10 Then
                            outputString.Append("&#10;")
                        Else
                            outputString.Append(Convert.ToChar(b))
                        End If
                    End If
                    prevChar2 = prevChar1
                    prevChar1 = Convert.ToChar(b)

                End While

                Response.Write(outputString.ToString())
            End If
        End Sub

    End Class
End Namespace
