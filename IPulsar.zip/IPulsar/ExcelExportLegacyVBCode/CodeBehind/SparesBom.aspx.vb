Imports System.Data
Imports System.Text


Namespace CodeBehind

    Public Class SparesBom
        Inherits System.Web.UI.Page
        Private ReadOnly Property ServiceFamilyPn() As String
            Get
                Return Request.Form("ServiceFamilyPn")
            End Get
        End Property

        Private ReadOnly Property Publish() As Boolean
            Get
                If Request.Form("chkPublish") = "on" Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property

        Private ReadOnly Property NewMatrix() As Boolean
            Get
                If Request.Form("chkNewMatrix") = "on" Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property

        Private ReadOnly Property CompareToDate() As String
            Get
                Return Request.Form("selCompareDt")
            End Get
        End Property

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

            Server.ScriptTimeout = 600

            Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
            Dim spbNfo As New SpbExport.SpbNfo(ServiceFamilyPn)

            Dim sFamily As String = spbNfo.FamilyName

            Dim saFileName(2) As String
            saFileName(0) = sFamily
            saFileName(1) = String.Format("{0}{1}{2}", Now.Year.ToString(), Now.Month.ToString.PadLeft(2, "0"), Now.Day.ToString.PadLeft(2, "0"))
            Dim fileName As String = String.Format("{0}_SPB_HP_{1}.xls", saFileName)
            fileName = fileName.Replace(" ", "_")
            For Each character As Char In System.IO.Path.GetInvalidFileNameChars()
                fileName = fileName.Replace(character, "_")
            Next

            Dim strm As System.IO.MemoryStream = New System.IO.MemoryStream
            Dim matrix As New SpbExport.SpsBom()
            matrix.NewMatrix = NewMatrix
            matrix.ServiceFamilyPn = ServiceFamilyPn
            matrix.Publish = Publish
            matrix.CompareDt = CompareToDate

            matrix.Generate(strm, fileName)


            Response.Clear()
            Response.AddHeader("Content-Disposition", String.Format("attachment; filename={0}", fileName))
            Response.ContentType = "application/vnd.ms-excel"

            Dim outputString As StringBuilder = New StringBuilder(2048)

            Dim b As Integer
            Dim prevChar1 As Char = ""
            Dim prevChar2 As Char = ""
            strm.Position = 3
            While True
                b = strm.ReadByte()
                If b = -1 Then Exit While
                If b > 31 And b < 127 Or b = 10 Then
                    If prevChar2 <> Convert.ToChar(">") And b = 10 Then
                        outputString.Append("&#10;")
                    Else
                        outputString.Append(Convert.ToChar(b))
                    End If
                End If
                prevChar2 = prevChar1
                prevChar1 = Convert.ToChar(b)

            End While

            Response.Write(outputString.ToString())

        End Sub
    End Class
End Namespace