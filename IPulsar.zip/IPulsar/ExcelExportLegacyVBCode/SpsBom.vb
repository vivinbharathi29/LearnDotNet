Imports Microsoft.VisualBasic
Imports System
Imports System.Xml
Imports System.Text
Imports CarlosAg.ExcelXmlWriter
Namespace SpbExport
  Public Class SpsBom

#Region " Properties "
    Private _newMatrix As Boolean = False
    Public Property NewMatrix() As Boolean
      Get
        Return _newMatrix
      End Get
      Set(ByVal value As Boolean)
        _newMatrix = value
      End Set
    End Property

    Private _publish As Boolean = False
    Public Property Publish() As Boolean
      Get
        Return _publish
      End Get
      Set(ByVal value As Boolean)
        _publish = value
      End Set
    End Property

    Private _serviceFamilyPn As String = String.Empty
    Public Property ServiceFamilyPn() As String
      Get
        Return _serviceFamilyPn
      End Get
      Set(ByVal value As String)
        _serviceFamilyPn = value
      End Set
    End Property

    Private _compareDt As String = String.Empty
    Public Property CompareDt() As String
      Get
        Dim dt As DateTime
        If DateTime.TryParse(_compareDt, dt) Then
          Return _compareDt
        Else
          Return String.Empty
        End If
      End Get
      Set(ByVal value As String)
        _compareDt = value
      End Set
    End Property

    Private _exportTime As String = String.Empty
    Private Property ExportTime() As String
      Get
        Return _exportTime
      End Get
      Set(ByVal value As String)
        _exportTime = value
      End Set
    End Property
#End Region

#Region " Generate Workbook "

    Public Sub Generate(ByRef stream As System.IO.MemoryStream, ByRef FileName As String)
      Dim book As Workbook = New Workbook
      '-----------------------------------------------
      ' Properties
      '-----------------------------------------------
      book.Properties.Author = ""
      book.Properties.LastAuthor = "Excalibur"
      book.Properties.Created = Now()
      book.Properties.LastSaved = Now()
            book.Properties.Company = "HP"
            book.Properties.Version = "12.00"
      book.ExcelWorkbook.WindowHeight = 8580
      book.ExcelWorkbook.WindowWidth = 7680
      book.ExcelWorkbook.WindowTopX = -15
      book.ExcelWorkbook.WindowTopY = -15
      book.ExcelWorkbook.ProtectWindows = False
      book.ExcelWorkbook.ProtectStructure = False
      ExportTime = Now.ToString()
      '-----------------------------------------------
      ' Generate Styles
      '-----------------------------------------------
      Me.GenerateStyles(book.Styles)

      '
      ' Get the data
      '
      Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
      Dim dt As DataTable = dwExcalibur.SelectSparesMatrix(ServiceFamilyPn, CompareDt, Publish)

      Dim spbNfo As New SpbNfo(ServiceFamilyPn)

      '
      ' Create worksheets
      '
      Me.CreateServiceProgramBomWorksheet(book.Worksheets, spbNfo)

      Me.CreateChangeLogWorksheet(book.Worksheets)

      '
      ' Build Worksheet
      '
      Dim sLastCategory As String = String.Empty
      Dim sLastSpareKit As String = String.Empty
      Dim sLastSA As String = String.Empty
      Dim sLastPart As String = String.Empty
      Dim bFirstCategory As Boolean = True
      'Dim drSpareKitVersions() As DataRow

      For Each row As DataRow In dt.Rows
        If sLastSpareKit <> row("SpsKitPn").ToString.Trim And row("SpsKitPn").ToString.Trim <> String.Empty Then
          'drSpareKitVersions = dtVersions.Select(String.Format("SpsKitPn = '{0}'", row("SpsKitPn")))
          Me.AddSpareKitRow(book.Worksheets, row) ', drSpareKitVersions)
          sLastSpareKit = row("SpsKitPn").ToString.Trim
          sLastSA = row("SaPn").ToString.Trim
          sLastPart = row("PartPn").ToString.Trim
        ElseIf row("aSpsKitPn").ToString.Trim <> String.Empty And row("SpsKitPn").ToString.Trim = String.Empty And row("aSpsKitPn").ToString.Trim <> sLastSpareKit Then
          Me.AddSpareKitChangeRow(book.Worksheets, row, ChangeType.Remove, "spskitpn")
          sLastSpareKit = row("aSpsKitPn").ToString.Trim()
          sLastSA = row("aSaPn").ToString.Trim()
          sLastPart = row("aPartPn").ToString.Trim()
        ElseIf sLastSA <> row("SaPn").ToString.Trim And row("SaPn").ToString.Trim <> String.Empty Then
          Me.AddSaRow(book.Worksheets, row) ', drSpareKitVersions)
          sLastSA = row("SaPn").ToString.Trim
          sLastPart = row("PartPn").ToString.Trim
        ElseIf row("aSaPn").ToString.Trim <> String.Empty And row("SaPn").ToString.Trim = String.Empty And row("aSaPn").ToString.Trim <> sLastSA Then
          Me.AddSAChangeRow(book.Worksheets, row, ChangeType.Remove, "sapn")
          sLastSA = row("aSaPn").ToString.Trim()
          sLastPart = row("aPartPn").ToString.Trim()
        ElseIf sLastPart <> row("PartPn").ToString.Trim And row("PartPn").ToString.Trim <> String.Empty Then
          Me.AddPartRow(book.Worksheets, row) ', drSpareKitVersions)
          sLastPart = row("PartPn").ToString.Trim
        ElseIf row("aPartPn").ToString.Trim <> String.Empty And row("PartPn").ToString.Trim = String.Empty And row("aPartPn").ToString.Trim <> sLastPart Then
          Me.AddPartChangeRow(book.Worksheets, row, ChangeType.Remove, "partpn")
          sLastPart = row("aPartPn").ToString.Trim()
        End If
      Next

      AddHPConfidential(book.Worksheets("Service Program BOM"))


      Me.CloseServiceProgramBomWorksheet(book.Worksheets)
      Me.CloseWorksheetChangeLog(book.Worksheets)
      book.Save(stream)
    End Sub

    'Add label HPConfidential and time Executed to the report
    Private Sub AddHPConfidential(ByVal RSLSheet As Worksheet)
      RSLSheet.Table.Rows.Add()
      Dim RConfidential As WorksheetRow = RSLSheet.Table.Rows.Add()
      RConfidential.Cells.Add("HP - Confidential", DataType.String, "sHPConfidential")

      Dim RConfidentialCreated As WorksheetRow = RSLSheet.Table.Rows.Add()
      RConfidentialCreated.Cells.Add("Report Generated " + DateTime.Now.ToString(), DataType.String, "sTimeExecuted")
    End Sub

#End Region

#Region " GenerateStyles "
    Private Sub GenerateStyles(ByVal styles As WorksheetStyleCollection)
      '-----------------------------------------------
      ' Default
      '-----------------------------------------------
      Dim [Default] As WorksheetStyle = styles.Add("Default")
      [Default].Name = "Normal"
      [Default].Font.FontName = "Arial"
      [Default].Alignment.Vertical = StyleVerticalAlignment.Bottom

      '-----------------------------------------------
      ' sTitleBlockLabel
      '-----------------------------------------------
      Dim sTitleBlockLabel As WorksheetStyle = styles.Add("sTitleBlockLabel")
      sTitleBlockLabel.Font.Bold = True
      sTitleBlockLabel.Font.FontName = "Arial"
      sTitleBlockLabel.Font.Size = "10"
      sTitleBlockLabel.Alignment.Horizontal = StyleHorizontalAlignment.Right
      sTitleBlockLabel.Alignment.Vertical = StyleVerticalAlignment.Bottom

      '-----------------------------------------------
      ' sTitleBlockValue
      '-----------------------------------------------
      Dim sTitleBlockValue As WorksheetStyle = styles.Add("sTitleBlockValue")
      sTitleBlockValue.Font.Bold = True
      sTitleBlockValue.Font.FontName = "Arial"
      sTitleBlockValue.Font.Size = "10"
      sTitleBlockValue.Alignment.Horizontal = StyleHorizontalAlignment.Center
      sTitleBlockValue.Alignment.Vertical = StyleVerticalAlignment.Bottom

      '-----------------------------------------------
      ' sKitLevel
      '-----------------------------------------------

      '-----------------------------------------------
      ' sLowerLevels
      '-----------------------------------------------

      '-----------------------------------------------
      ' s85
      '-----------------------------------------------
      Dim s85 As WorksheetStyle = styles.Add("s85")
      s85.Name = "AutoFormat Options"
      s85.Font.FontName = "Arial"
      s85.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s16
      '-----------------------------------------------
      Dim s16 As WorksheetStyle = styles.Add("s16")
      s16.Name = "Style 1"
      s16.Font.FontName = "Helv"
      s16.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s25
      '-----------------------------------------------
      Dim s25 As WorksheetStyle = styles.Add("s25")
      s25.Parent = "s85"
      s25.Font.Bold = True
      s25.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s26
      '-----------------------------------------------
      Dim s26 As WorksheetStyle = styles.Add("s26")
      s26.Parent = "s85"
      s26.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s27
      '-----------------------------------------------
      Dim s27 As WorksheetStyle = styles.Add("s27")
      s27.Parent = "s85"
      s27.Font.Bold = True
      s27.Font.FontName = "Arial"
      s27.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s27.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s28
      '-----------------------------------------------
      Dim s28 As WorksheetStyle = styles.Add("s28")
      s28.Parent = "s85"
      s28.Font.FontName = "Arial"
      s28.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s28.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s29
      '-----------------------------------------------
      Dim s29 As WorksheetStyle = styles.Add("s29")
      s29.Parent = "s85"
      s29.Font.Bold = True
      s29.Font.FontName = "Arial"
      s29.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s29.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s30
      '-----------------------------------------------
      Dim s30 As WorksheetStyle = styles.Add("s30")
      s30.Parent = "s85"
      s30.Font.Bold = True
      s30.Font.FontName = "Arial"
      s30.Font.Color = "#008000"
      s30.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s30.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s31
      '-----------------------------------------------
      Dim s31 As WorksheetStyle = styles.Add("s31")
      s31.Parent = "s85"
      s31.Font.Bold = True
      s31.Font.FontName = "Arial"
      s31.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s31.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s31.Alignment.WrapText = True
      '-----------------------------------------------
      ' s32
      '-----------------------------------------------
      Dim s32 As WorksheetStyle = styles.Add("s32")
      s32.Parent = "s16"
      s32.Font.Bold = True
      s32.Font.FontName = "Arial"
      s32.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s32.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s32.Alignment.WrapText = True
      '-----------------------------------------------
      ' s33
      '-----------------------------------------------
      Dim s33 As WorksheetStyle = styles.Add("s33")
      s33.Parent = "s85"
      s33.Font.FontName = "Arial"
      s33.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s33.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s33.Alignment.WrapText = True
      '-----------------------------------------------
      ' s34
      '-----------------------------------------------
      Dim s34 As WorksheetStyle = styles.Add("s34")
      s34.Parent = "s85"
      s34.Font.FontName = "Arial"
      s34.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s34.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s36
      '-----------------------------------------------
      Dim s36 As WorksheetStyle = styles.Add("s36")
      s36.Parent = "s16"
      s36.Font.Bold = True
      s36.Font.FontName = "Arial"
      s36.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s36.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s37
      '-----------------------------------------------
      Dim s37 As WorksheetStyle = styles.Add("s37")
      s37.Parent = "s85"
      s37.Font.Bold = True
      s37.Font.FontName = "Arial"
      s37.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s37.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s37.NumberFormat = "[ENG][$-409]mmmm\ d\,\ yyyy;@"
      '-----------------------------------------------
      ' s38
      '-----------------------------------------------
      Dim s38 As WorksheetStyle = styles.Add("s38")
      s38.Parent = "s85"
      s38.Font.Bold = True
      s38.Font.FontName = "Arial"
      s38.Font.Color = "#FF0000"
      s38.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s38.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s39
      '-----------------------------------------------
      Dim s39 As WorksheetStyle = styles.Add("s39")
      s39.Parent = "s85"
      s39.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s40
      '-----------------------------------------------
      Dim s40 As WorksheetStyle = styles.Add("s40")
      s40.Parent = "s16"
      s40.Font.Bold = True
      s40.Font.FontName = "Arial"
      s40.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s40.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s40.Alignment.WrapText = True
      '-----------------------------------------------
      ' s41
      '-----------------------------------------------
      Dim s41 As WorksheetStyle = styles.Add("s41")
      s41.Parent = "s85"
      s41.Font.Bold = True
      s41.Font.FontName = "Arial"
      s41.Font.Color = "#FF0000"
      s41.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s41.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s42
      '-----------------------------------------------
      Dim s42 As WorksheetStyle = styles.Add("s42")
      s42.Parent = "s85"
      s42.Font.Bold = True
      s42.Font.FontName = "Arial"
      s42.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s42.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s42.Alignment.WrapText = True
      '-----------------------------------------------
      ' s43
      '-----------------------------------------------
      Dim s43 As WorksheetStyle = styles.Add("s43")
      s43.Parent = "s16"
      s43.Font.Bold = True
      s43.Font.FontName = "Arial"
      s43.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s43.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s44
      '-----------------------------------------------
      Dim s44 As WorksheetStyle = styles.Add("s44")
      s44.Parent = "s16"
      s44.Font.Bold = True
      s44.Font.FontName = "Arial"
      s44.Interior.Color = "#99CCFF"
      s44.Interior.Pattern = StyleInteriorPattern.Solid
      s44.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s44.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s44.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s44.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s44.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s44.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s45
      '-----------------------------------------------
      Dim s45 As WorksheetStyle = styles.Add("s45")
      s45.Parent = "s16"
      s45.Font.Bold = True
      s45.Font.FontName = "Arial"
      s45.Interior.Color = "#99CCFF"
      s45.Interior.Pattern = StyleInteriorPattern.Solid
      s45.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s45.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s45.Alignment.WrapText = True
      s45.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s45.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s45.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s45.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s46
      '-----------------------------------------------
      Dim s46 As WorksheetStyle = styles.Add("s46")
      s46.Parent = "s16"
      s46.Font.FontName = "Arial"
      s46.Interior.Pattern = StyleInteriorPattern.Solid
      s46.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s46.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s46.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s47
      '-----------------------------------------------
      Dim s47 As WorksheetStyle = styles.Add("s47")
      s47.Parent = "s16"
      s47.Font.FontName = "Arial"
      s47.Interior.Pattern = StyleInteriorPattern.Solid
      s47.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s47.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s47.Alignment.WrapText = True
      s47.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s47.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s47.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s47.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s48
      '-----------------------------------------------
      Dim s48 As WorksheetStyle = styles.Add("s48")
      s48.Parent = "s16"
      s48.Font.FontName = "Arial"
      s48.Interior.Pattern = StyleInteriorPattern.Solid
      s48.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s48.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s48.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s49
      '-----------------------------------------------
      Dim s49 As WorksheetStyle = styles.Add("s49")
      s49.Parent = "s16"
      s49.Font.FontName = "Arial"
      s49.Interior.Pattern = StyleInteriorPattern.Solid
      s49.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s49.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s49.Alignment.WrapText = True
      s49.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s49.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s49.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s49.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s44h
      '-----------------------------------------------
      Dim s44h As WorksheetStyle = styles.Add("s44h")
      s44h.Parent = "s16"
      s44h.Font.Bold = True
      s44h.Font.FontName = "Arial"
      s44h.Interior.Color = "#FFFF00"
      s44h.Interior.Pattern = StyleInteriorPattern.Solid
      s44h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s44h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s44h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s44h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s44h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s44h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s45h
      '-----------------------------------------------
      Dim s45h As WorksheetStyle = styles.Add("s45h")
      s45h.Parent = "s16"
      s45h.Font.Bold = True
      s45h.Font.FontName = "Arial"
      s45h.Interior.Color = "#FFFF00"
      s45h.Interior.Pattern = StyleInteriorPattern.Solid
      s45h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s45h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s45h.Alignment.WrapText = True
      s45h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s45h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s45h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s45h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s46h
      '-----------------------------------------------
      Dim s46h As WorksheetStyle = styles.Add("s46h")
      s46h.Parent = "s16"
      s46h.Font.FontName = "Arial"
      s46h.Interior.Pattern = StyleInteriorPattern.Solid
      s46h.Interior.Color = "#FFFF00"
      s46h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s46h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s46h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s46h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s46h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s46h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s47h
      '-----------------------------------------------
      Dim s47h As WorksheetStyle = styles.Add("s47h")
      s47h.Parent = "s16"
      s47h.Font.FontName = "Arial"
      s47h.Interior.Pattern = StyleInteriorPattern.Solid
      s47h.Interior.Color = "#FFFF00"
      s47h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s47h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s47h.Alignment.WrapText = True
      s47h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s47h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s47h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s47h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s46halb
      '-----------------------------------------------
      Dim s46halb As WorksheetStyle = styles.Add("s46halb")
      s46halb.Parent = "s16"
      s46halb.Font.FontName = "Arial"
      s46halb.Interior.Pattern = StyleInteriorPattern.Solid
      s46halb.Interior.Color = "#DBEEF3"
      s46halb.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s46halb.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s46halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s46halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s46halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s46halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s47halb
      '-----------------------------------------------
      Dim s47halb As WorksheetStyle = styles.Add("s47halb")
      s47halb.Parent = "s16"
      s47halb.Font.FontName = "Arial"
      s47halb.Interior.Pattern = StyleInteriorPattern.Solid
      s47halb.Interior.Color = "#DBEEF3"
      s47halb.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s47halb.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s47halb.Alignment.WrapText = True
      s47halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s47halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s47halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s47halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s48h
      '-----------------------------------------------
      Dim s48h As WorksheetStyle = styles.Add("s48h")
      s48h.Parent = "s16"
      s48h.Font.FontName = "Arial"
      s48h.Interior.Pattern = StyleInteriorPattern.Solid
      s48h.Interior.Color = "#FFFF00"
      s48h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s48h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s48h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s48h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s48h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s48h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s49
      '-----------------------------------------------
      Dim s49h As WorksheetStyle = styles.Add("s49h")
      s49h.Parent = "s16"
      s49h.Font.FontName = "Arial"
      s49h.Interior.Pattern = StyleInteriorPattern.Solid
      s49h.Interior.Color = "#FFFF00"
      s49h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s49h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s49h.Alignment.WrapText = True
      s49h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s49h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s49h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s49h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s50
      '-----------------------------------------------
      Dim s50 As WorksheetStyle = styles.Add("s50")
      s50.Parent = "s85"
      s50.Font.FontName = "Arial"
      s50.Interior.Pattern = StyleInteriorPattern.Solid
      s50.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s50.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s50.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s50.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s50.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s50.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s50h
      '-----------------------------------------------
      Dim s50h As WorksheetStyle = styles.Add("s50h")
      s50h.Parent = "s85"
      s50h.Font.FontName = "Arial"
      s50h.Interior.Pattern = StyleInteriorPattern.Solid
      s50h.Interior.Color = "#FFFF00"
      s50h.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s50h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s50h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s50h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s50h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s50h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s51
      '-----------------------------------------------
      Dim s51 As WorksheetStyle = styles.Add("s51")
      s51.Parent = "s85"
      s51.Font.FontName = "Arial"
      s51.Interior.Pattern = StyleInteriorPattern.Solid
      s51.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s51.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s51.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s51.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s51.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s51.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s52
      '-----------------------------------------------
      Dim s52 As WorksheetStyle = styles.Add("s52")
      s52.Parent = "s85"
      s52.Font.Bold = True
      s52.Font.FontName = "Arial"
      s52.Interior.Color = "#99CCFF"
      s52.Interior.Pattern = StyleInteriorPattern.Solid
      s52.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s52.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s52.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s52.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s52h
      '-----------------------------------------------
      Dim s52h As WorksheetStyle = styles.Add("s52h")
      s52h.Parent = "s85"
      s52h.Font.Bold = True
      s52h.Font.FontName = "Arial"
      s52h.Interior.Color = "#FFFF00"
      s52h.Interior.Pattern = StyleInteriorPattern.Solid
      s52h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s52h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s52h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s52h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s53
      '-----------------------------------------------
      Dim s53 As WorksheetStyle = styles.Add("s53")
      s53.Parent = "s85"
      s53.Font.Bold = True
      s53.Font.FontName = "Arial"
      s53.Font.Size = 16
      s53.Font.Color = "#FF0000"
      s53.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s53.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s54
      '-----------------------------------------------
      Dim s54 As WorksheetStyle = styles.Add("s54")
      s54.Parent = "s85"
      s54.Font.FontName = "Arial"
      s54.Font.Color = "#C0C0C0"
      s54.Interior.Pattern = StyleInteriorPattern.Solid
      s54.Alignment.Vertical = StyleVerticalAlignment.Center
      s54.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s54.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s54.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s54.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s54h
      '-----------------------------------------------
      Dim s54h As WorksheetStyle = styles.Add("s54h")
      s54h.Parent = "s85"
      s54h.Font.FontName = "Arial"
      s54h.Font.Color = "#C0C0C0"
      s54h.Interior.Pattern = StyleInteriorPattern.Solid
      s54h.Interior.Color = "#FFFF00"
      s54h.Alignment.Vertical = StyleVerticalAlignment.Center
      s54h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s54h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s54h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s54h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s55
      '-----------------------------------------------
      Dim s55 As WorksheetStyle = styles.Add("s55")
      s55.Parent = "s85"
      s55.Font.FontName = "Arial"
      s55.Font.Color = "#C0C0C0"
      s55.Interior.Pattern = StyleInteriorPattern.Solid
      s55.Alignment.Vertical = StyleVerticalAlignment.Center
      s55.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s55.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s55.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s55.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s56
      '-----------------------------------------------
      Dim s56 As WorksheetStyle = styles.Add("s56")
      s56.Parent = "s16"
      s56.Font.FontName = "Arial"
      s56.Interior.Pattern = StyleInteriorPattern.Solid
      s56.Alignment.Vertical = StyleVerticalAlignment.Center
      s56.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s56.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s56.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s56.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s57
      '-----------------------------------------------
      Dim s57 As WorksheetStyle = styles.Add("s57")
      s57.Parent = "s16"
      s57.Font.FontName = "Arial"
      s57.Interior.Pattern = StyleInteriorPattern.Solid
      s57.Alignment.Vertical = StyleVerticalAlignment.Center
      s57.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s57.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s57.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s57.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s56h
      '-----------------------------------------------
      Dim s56h As WorksheetStyle = styles.Add("s56h")
      s56h.Parent = "s16"
      s56h.Font.FontName = "Arial"
      s56h.Interior.Pattern = StyleInteriorPattern.Solid
      s56h.Interior.Color = "#FFFF00"
      s56h.Alignment.Vertical = StyleVerticalAlignment.Center
      s56h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s56h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s56h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s56h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s56halb
      '-----------------------------------------------
      Dim s56halb As WorksheetStyle = styles.Add("s56halb")
      s56halb.Parent = "s16"
      s56halb.Font.FontName = "Arial"
      s56halb.Interior.Pattern = StyleInteriorPattern.Solid
      s56halb.Interior.Color = "#DBEEF3"
      s56halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s56halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s56halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s56halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s56halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s57
      '-----------------------------------------------
      Dim s57h As WorksheetStyle = styles.Add("s57h")
      s57h.Parent = "s16"
      s57h.Font.FontName = "Arial"
      s57h.Interior.Pattern = StyleInteriorPattern.Solid
      s57h.Interior.Color = "#FFFF00"
      s57h.Alignment.Vertical = StyleVerticalAlignment.Center
      s57h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s57h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s57h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s57h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s58
      '-----------------------------------------------
      Dim s58 As WorksheetStyle = styles.Add("s58")
      s58.Parent = "s85"
      s58.Font.FontName = "Arial"
      s58.Interior.Pattern = StyleInteriorPattern.Solid
      s58.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s58.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s58.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s58.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s59
      '-----------------------------------------------
      Dim s59 As WorksheetStyle = styles.Add("s59")
      s59.Parent = "s85"
      s59.Font.FontName = "Arial"
      s59.Interior.Pattern = StyleInteriorPattern.Solid
      s59.Alignment.Vertical = StyleVerticalAlignment.Center
      s59.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s59.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s59.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s59.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s60
      '-----------------------------------------------
      Dim s60 As WorksheetStyle = styles.Add("s60")
      s60.Parent = "s16"
      s60.Font.FontName = "Arial"
      s60.Interior.Pattern = StyleInteriorPattern.Solid
      s60.Alignment.Vertical = StyleVerticalAlignment.Center
      s60.Alignment.WrapText = True
      s60.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s60.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s60.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s60.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s59h
      '-----------------------------------------------
      Dim s59h As WorksheetStyle = styles.Add("s59h")
      s59h.Parent = "s85"
      s59h.Font.FontName = "Arial"
      s59h.Interior.Pattern = StyleInteriorPattern.Solid
      s59h.Interior.Color = "#FFFF00"
      s59h.Alignment.Vertical = StyleVerticalAlignment.Center
      s59h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s59h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s59h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s59h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s60h
      '-----------------------------------------------
      Dim s60h As WorksheetStyle = styles.Add("s60h")
      s60h.Parent = "s16"
      s60h.Font.FontName = "Arial"
      s60h.Interior.Pattern = StyleInteriorPattern.Solid
      s60h.Interior.Color = "#FFFF00"
      s60h.Alignment.Vertical = StyleVerticalAlignment.Center
      s60h.Alignment.WrapText = True
      s60h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s60h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s60h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s60h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s59halb
      '-----------------------------------------------
      Dim s59halb As WorksheetStyle = styles.Add("s59halb")
      s59halb.Parent = "s85"
      s59halb.Font.FontName = "Arial"
      s59halb.Interior.Pattern = StyleInteriorPattern.Solid
      s59halb.Interior.Color = "#DBEEF3"
      s59halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s59halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s59halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s59halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s59halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s60halb
      '-----------------------------------------------
      Dim s60halb As WorksheetStyle = styles.Add("s60halb")
      s60halb.Parent = "s16"
      s60halb.Font.FontName = "Arial"
      s60halb.Interior.Pattern = StyleInteriorPattern.Solid
      s60halb.Interior.Color = "#DBEEF3"
      s60halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s60halb.Alignment.WrapText = True
      s60halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s60halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s60halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s60halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s61
      '-----------------------------------------------
      Dim s61 As WorksheetStyle = styles.Add("s61")
      s61.Parent = "s85"
      s61.Font.FontName = "Arial"
      s61.Alignment.Vertical = StyleVerticalAlignment.Center
      s61.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s61.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s61.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s61.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s61h
      '-----------------------------------------------
      Dim s61h As WorksheetStyle = styles.Add("s61h")
      s61h.Parent = "s85"
      s61h.Font.FontName = "Arial"
      s61h.Interior.Pattern = StyleInteriorPattern.Solid
      s61h.Interior.Color = "#FFFF00"
      s61h.Alignment.Vertical = StyleVerticalAlignment.Center
      s61h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s61h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s61h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s61h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s61halb
      '-----------------------------------------------
      Dim s61halb As WorksheetStyle = styles.Add("s61halb")
      s61halb.Parent = "s85"
      s61halb.Font.FontName = "Arial"
      s61halb.Interior.Pattern = StyleInteriorPattern.Solid
      s61halb.Interior.Color = "#DBEEF3"
      s61halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s61halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s61halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s61halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s61halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s62
      '-----------------------------------------------
      Dim s62 As WorksheetStyle = styles.Add("s62")
      s62.Parent = "s85"
      s62.Font.FontName = "Arial"
      s62.Interior.Pattern = StyleInteriorPattern.Solid
      s62.Alignment.Vertical = StyleVerticalAlignment.Center
      s62.Alignment.WrapText = True
      s62.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s62.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s62.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s62.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s63
      '-----------------------------------------------
      Dim s63 As WorksheetStyle = styles.Add("s63")
      s63.Parent = "s85"
      s63.Font.FontName = "Arial"
      s63.Interior.Pattern = StyleInteriorPattern.Solid
      s63.Alignment.Vertical = StyleVerticalAlignment.Center
      s63.Alignment.WrapText = True
      s63.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s63.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s63.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s63.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s65
      '-----------------------------------------------
      Dim s65 As WorksheetStyle = styles.Add("s65")
      s65.Parent = "s85"
      s65.Font.FontName = "Arial"
      s65.Interior.Pattern = StyleInteriorPattern.Solid
      s65.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s65.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s65.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s65.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s65.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s65.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s65h
      '-----------------------------------------------
      Dim s65h As WorksheetStyle = styles.Add("s65h")
      s65h.Parent = "s85"
      s65h.Font.FontName = "Arial"
      s65h.Interior.Pattern = StyleInteriorPattern.Solid
      s65h.Interior.Color = "#FFFF00"
      s65h.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s65h.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s65h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s65h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s65h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s65h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s65halb
      '-----------------------------------------------
      Dim s65halb As WorksheetStyle = styles.Add("s65halb")
      s65halb.Parent = "s85"
      s65halb.Font.FontName = "Arial"
      s65halb.Interior.Pattern = StyleInteriorPattern.Solid
      s65halb.Interior.Color = "#DBEEF3"
      s65halb.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s65halb.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s65halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s65halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s65halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s65halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s66
      '-----------------------------------------------
      Dim s66 As WorksheetStyle = styles.Add("s66")
      s66.Parent = "s85"
      s66.Font.FontName = "Arial"
      s66.Interior.Pattern = StyleInteriorPattern.Solid
      s66.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s66.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s66.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s66.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s66.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s66.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s67
      '-----------------------------------------------
      Dim s67 As WorksheetStyle = styles.Add("s67")
      s67.Parent = "s85"
      s67.Font.FontName = "Arial"
      s67.Interior.Pattern = StyleInteriorPattern.Solid
      s67.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s67.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s67.Alignment.WrapText = True
      s67.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s67.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s67.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s67.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s68
      '-----------------------------------------------
      Dim s68 As WorksheetStyle = styles.Add("s68")
      s68.Parent = "s85"
      s68.Font.FontName = "Arial"
      s68.Interior.Pattern = StyleInteriorPattern.Solid
      s68.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s68.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s68.Alignment.WrapText = True
      s68.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s68.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s68.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s68.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s71
      '-----------------------------------------------
      Dim s71 As WorksheetStyle = styles.Add("s71")
      s71.Parent = "s16"
      s71.Font.Bold = True
      s71.Font.FontName = "Arial"
      s71.Interior.Color = "#99CCFF"
      s71.Interior.Pattern = StyleInteriorPattern.Solid
      s71.Alignment.Vertical = StyleVerticalAlignment.Center
      s71.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s71.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s71.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s71.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s72
      '-----------------------------------------------
      Dim s72 As WorksheetStyle = styles.Add("s72")
      s72.Parent = "s85"
      s72.Font.Bold = True
      s72.Font.FontName = "Arial"
      s72.Interior.Color = "#99CCFF"
      s72.Interior.Pattern = StyleInteriorPattern.Solid
      s72.Alignment.Vertical = StyleVerticalAlignment.Center
      s72.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s72.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s72.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s72.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s71
      '-----------------------------------------------
      Dim s71h As WorksheetStyle = styles.Add("s71h")
      s71h.Parent = "s16"
      s71h.Font.Bold = True
      s71h.Font.FontName = "Arial"
      s71h.Interior.Color = "#FFFF00"
      s71h.Interior.Pattern = StyleInteriorPattern.Solid
      s71h.Alignment.Vertical = StyleVerticalAlignment.Center
      s71h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s71h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s71h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s71h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s72
      '-----------------------------------------------
      Dim s72h As WorksheetStyle = styles.Add("s72h")
      s72h.Parent = "s85"
      s72h.Font.Bold = True
      s72h.Font.FontName = "Arial"
      s72h.Interior.Color = "#FFFF00"
      s72h.Interior.Pattern = StyleInteriorPattern.Solid
      s72h.Alignment.Vertical = StyleVerticalAlignment.Center
      s72h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s72h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s72h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s72h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s73
      '-----------------------------------------------
      Dim s73 As WorksheetStyle = styles.Add("s73")
      s73.Parent = "s85"
      s73.Font.Bold = True
      s73.Font.FontName = "Arial"
      s73.Interior.Color = "#99CCFF"
      s73.Interior.Pattern = StyleInteriorPattern.Solid
      s73.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s73.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s73.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s73.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s73.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s73.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s74
      '-----------------------------------------------
      Dim s74 As WorksheetStyle = styles.Add("s74")
      s74.Parent = "s85"
      s74.Font.Bold = True
      s74.Font.FontName = "Arial"
      s74.Interior.Color = "#99CCFF"
      s74.Interior.Pattern = StyleInteriorPattern.Solid
      s74.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s74.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s74.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s74.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s74.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s74.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s75
      '-----------------------------------------------
      Dim s75 As WorksheetStyle = styles.Add("s75")
      s75.Parent = "s85"
      s75.Font.Bold = True
      s75.Font.FontName = "Arial"
      s75.Interior.Color = "#99CCFF"
      s75.Interior.Pattern = StyleInteriorPattern.Solid
      s75.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s75.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s75.Alignment.WrapText = True
      s75.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s75.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s75.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s75.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s76
      '-----------------------------------------------
      Dim s76 As WorksheetStyle = styles.Add("s76")
      s76.Parent = "s85"
      s76.Font.FontName = "Arial"
      s76.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s76.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s77
      '-----------------------------------------------
      Dim s77 As WorksheetStyle = styles.Add("s77")
      s77.Parent = "s85"
      s77.Font.FontName = "Arial"
      s77.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s77.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s78
      '-----------------------------------------------
      Dim s78 As WorksheetStyle = styles.Add("s78")
      s78.Parent = "s16"
      s78.Font.Bold = True
      s78.Font.FontName = "Arial"
      s78.Interior.Color = "#99CCFF"
      s78.Interior.Pattern = StyleInteriorPattern.Solid
      s78.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s78.Alignment.Vertical = StyleVerticalAlignment.Center
      s78.Alignment.WrapText = True
      s78.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s78.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s78.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s78.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s79
      '-----------------------------------------------
      Dim s79 As WorksheetStyle = styles.Add("s79")
      s79.Parent = "s85"
      s79.Font.FontName = "Arial"
      s79.Interior.Pattern = StyleInteriorPattern.Solid
      s79.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s79.Alignment.Vertical = StyleVerticalAlignment.Center
      s79.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s79.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s79.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s79.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s79h
      '-----------------------------------------------
      Dim s79h As WorksheetStyle = styles.Add("s79h")
      s79h.Parent = "s85"
      s79h.Font.FontName = "Arial"
      s79h.Interior.Pattern = StyleInteriorPattern.Solid
      s79h.Interior.Color = "#FFFF00"
      s79h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s79h.Alignment.Vertical = StyleVerticalAlignment.Center
      s79h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s79h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s79h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s79h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s79halb
      '-----------------------------------------------
      Dim s79halb As WorksheetStyle = styles.Add("s79halb")
      s79halb.Parent = "s85"
      s79halb.Font.FontName = "Arial"
      s79halb.Interior.Pattern = StyleInteriorPattern.Solid
      s79halb.Interior.Color = "#DBEEF3"
      s79halb.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s79halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s79halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s79halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s79halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s79halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s80
      '-----------------------------------------------
      Dim s80 As WorksheetStyle = styles.Add("s80")
      s80.Parent = "s85"
      s80.Font.FontName = "Arial"
      s80.Interior.Pattern = StyleInteriorPattern.Solid
      s80.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s80.Alignment.Vertical = StyleVerticalAlignment.Center
      s80.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s80.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s80.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s80.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s80h
      '-----------------------------------------------
      Dim s80h As WorksheetStyle = styles.Add("s80h")
      s80h.Parent = "s85"
      s80h.Font.FontName = "Arial"
      s80h.Interior.Pattern = StyleInteriorPattern.Solid
      s80h.Interior.Color = "#FFFF00"
      s80h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s80h.Alignment.Vertical = StyleVerticalAlignment.Center
      s80h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s80h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s80h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s80h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s81
      '-----------------------------------------------
      Dim s81 As WorksheetStyle = styles.Add("s81")
      s81.Parent = "s85"
      s81.Font.FontName = "Arial"
      s81.Interior.Pattern = StyleInteriorPattern.Solid
      s81.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s81.Alignment.Vertical = StyleVerticalAlignment.Center
      s81.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s81.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s81.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s81.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s82
      '-----------------------------------------------
      Dim s82 As WorksheetStyle = styles.Add("s82")
      s82.Parent = "s85"
      s82.Font.FontName = "Arial"
      s82.Interior.Pattern = StyleInteriorPattern.Solid
      s82.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s82.Alignment.Vertical = StyleVerticalAlignment.Center
      s82.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s82.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s82.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s82.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s82h
      '-----------------------------------------------
      Dim s82h As WorksheetStyle = styles.Add("s82h")
      s82h.Parent = "s85"
      s82h.Font.FontName = "Arial"
      s82h.Interior.Pattern = StyleInteriorPattern.Solid
      s82h.Interior.Color = "#FFFF00"
      s82h.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s82h.Alignment.Vertical = StyleVerticalAlignment.Center
      s82h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s82h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s82h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s82h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s84
      '-----------------------------------------------
      Dim s84 As WorksheetStyle = styles.Add("s84")
      s84.Parent = "s16"
      s84.Font.Bold = True
      s84.Font.FontName = "Arial"
      s84.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s84.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s84.Alignment.WrapText = True
      '-----------------------------------------------
      ' s100
      '-----------------------------------------------
      Dim s100 As WorksheetStyle = styles.Add("s100")
      s100.Parent = "s85"
      s100.Font.FontName = "Arial"
      s100.Font.Color = "#A0A0A0"
      s100.Alignment.Vertical = StyleVerticalAlignment.Center
      s100.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s100.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s100.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s100.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s100h
      '-----------------------------------------------
      Dim s100h As WorksheetStyle = styles.Add("s100h")
      s100h.Parent = "s85"
      s100h.Font.FontName = "Arial"
      s100h.Font.Color = "#A0A0A0"
      s100h.Interior.Pattern = StyleInteriorPattern.Solid
      s100h.Interior.Color = "#FFFF00"
      s100h.Alignment.Vertical = StyleVerticalAlignment.Center
      s100h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s100h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s100h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s100h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s100halb
      '-----------------------------------------------
      Dim s100halb As WorksheetStyle = styles.Add("s100halb")
      s100halb.Parent = "s85"
      s100halb.Font.FontName = "Arial"
      s100halb.Font.Color = "#A0A0A0"
      s100halb.Interior.Pattern = StyleInteriorPattern.Solid
      s100halb.Interior.Color = "#DBEEF3"
      s100halb.Alignment.Vertical = StyleVerticalAlignment.Center
      s100halb.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s100halb.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s100halb.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s100halb.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)

      '-----------------------------------------------
      ' Default
      '-----------------------------------------------
      Dim s200 As WorksheetStyle = styles.Add("s200")
      s200.Name = "ChangeNormal"
      s200.Font.FontName = "Calibri"
      s200.Font.Size = 11
      s200.Font.Color = "#000000"
      s200.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s201
      '-----------------------------------------------
      Dim s201 As WorksheetStyle = styles.Add("s201")
      s201.Name = "Normal_Sheet1"
      s201.Font.FontName = "Arial"
      s201.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s202
      '-----------------------------------------------
      Dim s202 As WorksheetStyle = styles.Add("s202")
      s202.Name = "ChangeStyle 1"
      s202.Font.FontName = "Helv"
      s202.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s203
      '-----------------------------------------------
      Dim s203 As WorksheetStyle = styles.Add("s203")
      '-----------------------------------------------
      ' s204
      '-----------------------------------------------
      Dim s204 As WorksheetStyle = styles.Add("s204")
      s204.Parent = "s202"
      s204.Font.Bold = True
      s204.Font.FontName = "Arial"
      s204.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s204.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s204.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s204.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 3)
      '-----------------------------------------------
      ' s205
      '-----------------------------------------------
      Dim s205 As WorksheetStyle = styles.Add("s205")
      s205.Parent = "s202"
      s205.Font.Bold = True
      s205.Font.FontName = "Arial"
      s205.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s205.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s205.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
      s205.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s206
      '-----------------------------------------------
      Dim s206 As WorksheetStyle = styles.Add("s206")
      s206.Parent = "s202"
      s206.Font.FontName = "Arial"
      s206.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s206.Alignment.Vertical = StyleVerticalAlignment.Bottom
      Dim s206Border0 As WorksheetStyleBorder = s206.Borders.Add
      s206Border0.Position = StylePosition.Bottom
      s206Border0.LineStyle = LineStyleOption.Continuous
      s206.NumberFormat = "Short Date"
      '-----------------------------------------------
      ' s207
      '-----------------------------------------------
      Dim s207 As WorksheetStyle = styles.Add("s207")
      s207.Parent = "s201"
      s207.Font.FontName = "Arial"
      s207.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s207.Alignment.Vertical = StyleVerticalAlignment.Bottom
      Dim s207Border0 As WorksheetStyleBorder = s207.Borders.Add
      s207Border0.Position = StylePosition.Bottom
      s207Border0.LineStyle = LineStyleOption.Continuous
      '-----------------------------------------------
      ' s208
      '-----------------------------------------------
      Dim s208 As WorksheetStyle = styles.Add("s208")
      s208.Parent = "s202"
      s208.Font.FontName = "Arial"
      s208.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s208.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s209
      '-----------------------------------------------
      Dim s209 As WorksheetStyle = styles.Add("s209")
      s209.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s209.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s210
      '-----------------------------------------------
      Dim s210 As WorksheetStyle = styles.Add("s210")
      s210.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s210.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s211
      '-----------------------------------------------
      Dim s211 As WorksheetStyle = styles.Add("s211")
      s211.Parent = "s202"
      s211.Font.Bold = True
      s211.Font.FontName = "Arial"
      s211.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s211.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s211.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
      s211.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s212
      '-----------------------------------------------
      Dim s212 As WorksheetStyle = styles.Add("s212")
      s212.Parent = "s202"
      s212.Font.FontName = "Arial"
      s212.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s212.Alignment.Vertical = StyleVerticalAlignment.Bottom
      Dim s212Border0 As WorksheetStyleBorder = s212.Borders.Add
      s212Border0.Position = StylePosition.Bottom
      s212Border0.LineStyle = LineStyleOption.Continuous
      '-----------------------------------------------
      ' s213
      '-----------------------------------------------
      Dim s213 As WorksheetStyle = styles.Add("s213")
      s213.Parent = "s202"
      s213.Font.FontName = "Arial"
      s213.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s213.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s214
      '-----------------------------------------------
      Dim s214 As WorksheetStyle = styles.Add("s214")
      s214.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s214.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s215
      '-----------------------------------------------
      Dim s215 As WorksheetStyle = styles.Add("s215")
      s215.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s215.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' sHPConfidential
      '-----------------------------------------------
      Dim sHPConfidential As WorksheetStyle = styles.Add("sHPConfidential")
      sHPConfidential.Font.Bold = True
      sHPConfidential.Font.FontName = "verdana"
      sHPConfidential.Font.Size = 13
      sHPConfidential.Font.Color = "#FF0000"
      '-----------------------------------------------
      ' sTimeExecuted
      '-----------------------------------------------
      Dim sTimeExecuted As WorksheetStyle = styles.Add("sTimeExecuted")
      sTimeExecuted.Font.Bold = True
      sTimeExecuted.Font.FontName = "verdana"

    End Sub
#End Region

#Region " Spares Bom Worksheet "

#Region " Create Spb Worksheet "
    Private Sub CreateServiceProgramBomWorksheet(ByVal sheets As WorksheetCollection, ByVal spbNfo As SpbNfo)
      Dim sheet As Worksheet = sheets.Add("Service Program BOM")
      Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
      'Dim dtProductVersions As DataTable = dwExcalibur.SelectSpbVersions(spbNfo.FamilySpsPn)
      sheet.Table.ExpandedColumnCount = 21 '+ dtProductVersions.Rows.Count() - 1
      'sheet.Table.ExpandedRowCount = 35
      sheet.Table.FullColumns = 1
      sheet.Table.FullRows = 1
      sheet.Table.StyleID = "s26"
      'Dim columnA As WorksheetColumn = sheet.Table.Columns.Add
      'columnA.Width = 225
      'columnA.StyleID = "s29"
      Dim columnB As WorksheetColumn = sheet.Table.Columns.Add
      columnB.Width = 115
      columnB.StyleID = "s28"
      Dim columnC As WorksheetColumn = sheet.Table.Columns.Add
      columnC.Width = 36
      columnC.StyleID = "s34"
      Dim columnD As WorksheetColumn = sheet.Table.Columns.Add
      columnD.Width = 122
      columnD.StyleID = "s76"
      Dim columnE As WorksheetColumn = sheet.Table.Columns.Add
      columnE.Width = 40
      columnE.StyleID = "s76"
      Dim columnF As WorksheetColumn = sheet.Table.Columns.Add
      columnF.Width = 85
      columnF.StyleID = "s28"
      Dim columnG As WorksheetColumn = sheet.Table.Columns.Add
      columnG.Width = 25
      columnG.StyleID = "s28"
      Dim colXPlant As WorksheetColumn = sheet.Table.Columns.Add
      colXPlant.Width = 40
      colXPlant.StyleID = "s28"
      Dim column5 As WorksheetColumn = sheet.Table.Columns.Add
      column5.Width = 25
      column5.StyleID = "s34"
      Dim column6 As WorksheetColumn = sheet.Table.Columns.Add
      column6.Width = 30
      column6.StyleID = "s34"
      Dim column7 As WorksheetColumn = sheet.Table.Columns.Add
      column7.Width = 97
      column7.StyleID = "s28"
      Dim column8 As WorksheetColumn = sheet.Table.Columns.Add
      column8.Width = 245
      column8.StyleID = "s28"
      Dim column9 As WorksheetColumn = sheet.Table.Columns.Add
      column9.Width = 120
      column9.StyleID = "s28"
      Dim column10 As WorksheetColumn = sheet.Table.Columns.Add
      column10.Width = 261
      column10.StyleID = "s28"
      Dim column11 As WorksheetColumn = sheet.Table.Columns.Add
      column11.Width = 113
      column11.StyleID = "s28"
      Dim column12 As WorksheetColumn = sheet.Table.Columns.Add
      column12.Width = 83
      column12.StyleID = "s34"
      Dim column13 As WorksheetColumn = sheet.Table.Columns.Add
      column13.Width = 81
      column13.StyleID = "s34"
      Dim column14 As WorksheetColumn = sheet.Table.Columns.Add
      column14.Width = 81
      column14.StyleID = "s33"
      Dim column15 As WorksheetColumn = sheet.Table.Columns.Add
      column15.Width = 108
      column15.StyleID = "s28"
      'Dim column16 As WorksheetColumn = sheet.Table.Columns.Add
      'column16.Width = 132
      'column16.StyleID = "s28"
      'Dim columnVersions As WorksheetColumn
      'For Each drow As DataRow In dtProductVersions.Rows
      '    columnVersions = sheet.Table.Columns.Add
      '    columnVersions.Width = 30
      '    columnVersions.StyleID = "s28"
      'Next
      Dim column20 As WorksheetColumn = sheet.Table.Columns.Add
      column20.Width = 180
      column20.StyleID = "s28"
      '-----------------------------------------------
      Dim cell As WorksheetCell
      Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
      Row0.Cells.Add("Program Name:", DataType.String, "sTitleBlockLabel")
      cell = Row0.Cells.Add(spbNfo.FamilyName, DataType.String, "sTitleBlockValue")
      cell.MergeAcross = 1
      '-----------------------------------------------
      Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
      Row1.Height = 15
      Row1.Cells.Add("Project ID:", DataType.String, "sTitleBlockLabel")
      cell = Row1.Cells.Add(spbNfo.ProjectCode, DataType.String, "sTitleBlockValue")
      cell.MergeAcross = 1
      '-----------------------------------------------
      Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
      Row2.Cells.Add("Family SPS Pn:", DataType.String, "sTitleBlockLabel")
      cell = Row2.Cells.Add(spbNfo.FamilySpsPn, DataType.String, "sTitleBlockValue")
      cell.MergeAcross = 1
      '-----------------------------------------------
      Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
      Row3.Cells.Add("SPDM Contact:", DataType.String, "sTitleBlockLabel")
      cell = Row3.Cells.Add(spbNfo.SpdmContact, DataType.String, "sTitleBlockValue")
      cell.MergeAcross = 1
      '-----------------------------------------------
      Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
      Row4.Cells.Add("ODM:", DataType.String, "sTitleBlockLabel")
      cell = Row4.Cells.Add(spbNfo.Partner, DataType.String, "sTitleBlockValue")
      cell.MergeAcross = 1
      '-----------------------------------------------
      sheet.Table.Rows.Add()
      '-----------------------------------------------
      Dim Row5 As WorksheetRow = sheet.Table.Rows.Add
      Row5.Height = 38
      'Row5.Cells.Add("Add,Chg,Delete", DataType.String, "s30")
      Row5.Cells.Add("Part Type", DataType.String, "s27")
      cell = Row5.Cells.Add
      cell.StyleID = "s29"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Level"
      cell.Comment.Author = " "
      cell.Comment.Data.Text = "Level 2 = HP Spare Kit" & Microsoft.VisualBasic.ChrW(10) & "Level 3 = HP Sub-Assembly or Component" & Microsoft.VisualBasic.ChrW(10) & "Level 4 = HP component PN"
      Row5.Cells.Add("OSSP Orderable PN Yes/No", DataType.String, "s32")
      Row5.Cells.Add("Line Item", DataType.String, "s32")
      Row5.Cells.Add("Spare Kit PN", DataType.String, "s42")
      Row5.Cells.Add("Rev", DataType.String, "s42")
      Row5.Cells.Add("Cross Plant Status", DataType.String, "s32")
      Row5.Cells.Add("Qty", DataType.String, "s29")
      cell = Row5.Cells.Add
      cell.StyleID = "s31"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Pri Alt Gen"
      cell.Comment.Author = " "
      cell.Comment.Data.Text = "Primary/Alternate designation simply means use one of the items listed.  Primary does not mean preferred."
      Row5.Cells.Add("HP 6-3 Component or SA PN", DataType.String, "s31")
      Row5.Cells.Add("HP Part Description", DataType.String, "s27")
      Row5.Cells.Add("ODM Part Number", DataType.String, "s42")
      Row5.Cells.Add("ODM Part Description", DataType.String, "s36")
      Row5.Cells.Add("ODM Bulk Part Number", DataType.String, "s32")
      Row5.Cells.Add("ODM Production MOQ", DataType.String, "s32")
      Row5.Cells.Add("ODM Post-Production MOQ", DataType.String, "s32")
      'Row5.Cells.Add("Lead-Time (Days)", DataType.String, "s32")
      Row5.Cells.Add("Part Supplier (ODM/OEM)", DataType.String, "s31")
      Row5.Cells.Add("Model / Mfg Pn", DataType.String, "s40")
      'For Each dRow As DataRow In dtProductVersions.Rows
      '    Row5.Cells.Add(dRow("Version").ToString.Trim(), DataType.String, "s84")
      'Next
      Row5.Cells.Add("Comment", DataType.String, "s27")
      '-----------------------------------------------

    End Sub
#End Region

#Region " Add Spd Rows "
    Private Sub AddSpareKitRow(ByVal sheets As WorksheetCollection, ByVal drow As DataRow) ', ByVal drVersions() As DataRow)
      Dim sheet As Worksheet = sheets("Service Program BOM")
      'Dim cell As WorksheetCell

      If ValidRow(drow, BomLevelEnum.Kit) Then
        Dim Row6 As WorksheetRow = sheet.Table.Rows.Add
        Row6.Height = 16
        'cell = Row6.Cells.Add
        'cell.StyleID = "s71"
        Row6.Cells.Add(drow("SpsKitDelCat").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsKitDelCat", "s52")) 'Part Type
        Row6.Cells.Add("2", DataType.Number, GetKitStyleID(sheets, drow, "", "s44")) 'Level
        Dim strSpsKitOsspOrderable As String
        strSpsKitOsspOrderable = "FG"
        If Not IsDBNull(drow("SpsKitOsspOrderable")) AndAlso drow("SpsKitOsspOrderable") Then
          strSpsKitOsspOrderable = "Yes"
        End If
        Row6.Cells.Add(strSpsKitOsspOrderable, DataType.String, GetKitStyleID(sheets, drow, "", "s45")) 'Ossp Orderable
        Row6.Cells.Add("", DataType.String, GetKitStyleID(sheets, drow, "", "s72")) 'Line Item
        Row6.Cells.Add(drow("SpsKitPn").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsKitPn", "s72")) 'HP Spare Kit Pn
        Row6.Cells.Add(drow("SpsKitRev").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsKitRev", "s45")) 'Rev
        Row6.Cells.Add(drow("SpsXplantStatus").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsXPlantStatus", "s45")) 'XPlant
        Row6.Cells.Add("", DataType.String, GetKitStyleID(sheets, drow, "", "s72")) 'Qty
        Row6.Cells.Add("", DataType.String, GetKitStyleID(sheets, drow, "", "s72")) 'Pri Alt Gen
        Row6.Cells.Add("", DataType.String, GetKitStyleID(sheets, drow, "", "s72")) 'HP Pn
        Row6.Cells.Add(drow("SpsKitDescription").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsKitDescription", "s72")) 'HP Description
        Row6.Cells.Add(drow("SpsOdmPartNo").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsOdmPartNo", "s72")) 'Odm Pn
        Row6.Cells.Add(drow("SpsOdmPartDescription").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsOdmPartDescription", "s72")) 'Odm Description
        Row6.Cells.Add(drow("SpsOdmBulkPartNo").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsOdmBulkPartNo", "s72")) 'Odm Bulk Pn
        Row6.Cells.Add(drow("SpsOdmProductionMoq").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsOdmProductionMoq", "s72")) 'Odm Production Moq
        Row6.Cells.Add(drow("SpsOdmPostProductionMoq").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsOdmPostProductionMoq", "s72")) 'Odm Post-Production Moq
        'Row6.Cells.Add("", DataType.String, GetKitStyleID(sheets, drow, "", "s72")) 'Lead Time
        Row6.Cells.Add(drow("SpsSupplier").ToString(), DataType.String, GetKitStyleID(sheets, drow, "", "s72")) 'Part Supplier
        Row6.Cells.Add("", DataType.String, GetKitStyleID(sheets, drow, "", "s72")) 'Model
        '
        ' Run Version Routine 
        ' Removed 3/15/2010 Version data will now be in the RSL
        '
        'For Each vRow As DataRow In drVersions
        '    If vRow("VersionSupported").ToString.Trim <> String.Empty Then
        '        Row6.Cells.Add("x", DataType.String, GetVersionStyleId(sheets, drow, "s72", vRow))
        '    Else
        '        Row6.Cells.Add("", DataType.String, GetVersionStyleId(sheets, drow, "s72", vRow))
        '    End If
        'Next
        '
        ' End Version Loop
        '
        Row6.Cells.Add(drow("SpsComments").ToString(), DataType.String, GetKitStyleID(sheets, drow, "SpsComments", "s72")) 'Comment
        '-----------------------------------------------
        If drow("SaPn").ToString() <> String.Empty Then
          AddSaRow(sheets, drow) ', drVersions)
        End If
      Else
        'Check to see if the status changed.
        If (drow("SpsXplantStatus").ToString.Trim = "C6" Or drow("SpsXplantStatus").ToString.Trim = "C1") And (drow("aSpsXplantStatus").ToString.Trim() = "C2" Or drow("aSpsXplantStatus").ToString.Trim = "C5") Then
          AddChangeLogRow(sheets, drow("spskitpn").ToString.Trim, String.Empty, "2", "Cross Plant Status", String.Format("{0} -> {1}", drow("aspsxplantstatus").ToString.Trim, drow("spsxplantstatus")))
        End If
      End If

    End Sub

    Private Sub AddSaRow(ByVal sheets As WorksheetCollection, ByVal drow As DataRow) ', ByVal drVersions() As DataRow)
      Dim sheet As Worksheet = sheets("Service Program BOM")
      'Dim cell As WorksheetCell

      '-----------------------------------------------
      If drow("SaPn").ToString() <> String.Empty And ValidRow(drow, BomLevelEnum.SubAssembly) Then
        Dim Row7 As WorksheetRow = sheet.Table.Rows.Add
        Row7.Height = 15
        'cell = Row7.Cells.Add
        'cell.StyleID = "s56"
        Row7.Cells.Add(drow("SpsKitDelCat").ToString(), DataType.String, GetSAStyleID(sheets, drow, "", "s100"))
        Row7.Cells.Add("3", DataType.Number, GetSAStyleID(sheets, drow, "", "s46"))
        Row7.Cells.Add(IIf(drow("SaOsspOrderable"), "Yes", "No").ToString, DataType.String, GetSAStyleID(sheets, drow, "SaOsspOrderable", "s47"))
        Row7.Cells.Add(drow("SaBomItemNo").ToString, DataType.String, GetSAStyleID(sheets, drow, "SaBomItemNo", "s47"))
        Row7.Cells.Add(drow("SpsKitPn").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SpsKitPn", "s100"))
        Row7.Cells.Add(drow("SaRev").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaRev", "s79"))
        Row7.Cells.Add(drow("SaXplantStatus").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaXPlantStatus", "s79"))
        Row7.Cells.Add(drow("SaQty").ToString(), DataType.Number, GetSAStyleID(sheets, drow, "SaQty", "s79"))
        Row7.Cells.Add(drow("SaPriAlt").ToString.Trim(), DataType.String, GetSAStyleID(sheets, drow, "SaPriAlt", "s79"))
        Row7.Cells.Add(drow("SaPn").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaPn", "s60"))
        Row7.Cells.Add(drow("SaDescription").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaDescription", "s60"))
        Row7.Cells.Add(drow("SaOdmPartNo").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaOdmPartNo", "s60"))
        Row7.Cells.Add(drow("SaOdmPartDescription").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaOdmPartDescription", "s60"))
        Row7.Cells.Add(drow("SaOdmBulkPartNo").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaOdmBulkPartNo", "s60"))
        Row7.Cells.Add(drow("SaOdmProductionMoq").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaOdmProductionMoq", "s60"))
        Row7.Cells.Add(drow("SaOdmPostProductionMoq").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaOdmPostProductionMoq", "s60"))
        'Row7.Cells.Add(drow("SaLeadTime").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaLeadTime", "s60"))
        Row7.Cells.Add(drow("SaSupplier").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaSupplier", "s60"))
        Row7.Cells.Add(drow("SaModel").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaSupplier", "s60"))

        '
        ' Run Version Routine 
        '
        'For Each vRow As DataRow In drVersions
        '    cell = Row7.Cells.Add
        '    cell.StyleID = GetSAStyleID(sheets, drow, "", "s59")
        'Next
        '
        ' End Version Loop
        '
        Row7.Cells.Add(drow("SaComments").ToString(), DataType.String, GetSAStyleID(sheets, drow, "SaComments", "s60")) 'Comment

        '-----------------------------------------------
        If drow("PartPn").ToString() <> String.Empty Then
          AddPartRow(sheets, drow) ', drVersions)
        End If
      Else
        'Check to see if the status changed.
        If (drow("SaXplantStatus").ToString.Trim = "C6" Or drow("SaXplantStatus").ToString.Trim = "C1") And (drow("aSaXplantStatus").ToString.Trim() = "C2" Or drow("aSaXplantStatus").ToString.Trim = "C5") Then
          AddChangeLogRow(sheets, drow("spskitpn").ToString.Trim, drow("sapn").ToString.Trim, "2", "Cross Plant Status", String.Format("{0} -> {1}", drow("aSaXplantStatus").ToString.Trim, drow("SaXplantStatus")))
        End If
      End If

    End Sub

    Private Sub AddPartRow(ByVal sheets As WorksheetCollection, ByVal drow As DataRow) ', ByVal drVersions() As DataRow)
      Dim sheet As Worksheet = sheets("Service Program BOM")
      'Dim cell As WorksheetCell

      '-----------------------------------------------
      If drow("PartPn").ToString() <> String.Empty And ValidRow(drow, BomLevelEnum.Part) Then
        Dim Row8 As WorksheetRow = sheet.Table.Rows.Add
        Row8.Height = 15
        'cell = Row8.Cells.Add
        'cell.StyleID = "s57"
        Row8.Cells.Add(drow("SpsKitDelCat").ToString(), DataType.String, GetPartStyleID(sheets, drow, "SpsKitDelCat", "s100"))
        Row8.Cells.Add("4", DataType.Number, GetPartStyleID(sheets, drow, "", "s48"))
        Row8.Cells.Add(IIf(drow("PartOsspOrderable"), "Yes", "No").ToString, DataType.String, GetPartStyleID(sheets, drow, "PartOsspOrderable", "s49"))
        Row8.Cells.Add(drow("PartBomItemNo").ToString, DataType.String, GetPartStyleID(sheets, drow, "PartBomItemNo", "s49"))
        Row8.Cells.Add(drow("SpsKitPn").ToString(), DataType.String, GetPartStyleID(sheets, drow, "SpsKitPn", "s100"))
        Row8.Cells.Add(drow("PartRev").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartRev", "s80"))
        Row8.Cells.Add(drow("PartXplantStatus").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartXPlantStatus", "s80"))
        Row8.Cells.Add(drow("PartQty").ToString, DataType.Number, GetPartStyleID(sheets, drow, "PartQty", "s80"))
        Row8.Cells.Add(drow("PartPriAlt").ToString.Trim(), DataType.String, GetPartStyleID(sheets, drow, "PartPriAlt", "s82"))
        Row8.Cells.Add(drow("PartPn").ToString, DataType.String, GetPartStyleID(sheets, drow, "PartPn", "s57"))
        Row8.Cells.Add(drow("PartDescription").ToString, DataType.String, GetPartStyleID(sheets, drow, "PartDescription", "s61"))
        Row8.Cells.Add(drow("PartOdmPartNo").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartOdmPartNo", "s61"))
        Row8.Cells.Add(drow("PartOdmPartDescription").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartOdmPartDescription", "s61"))
        Row8.Cells.Add(drow("PartOdmBulkPartNo").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartOdmBulkPartNo", "s61"))
        Row8.Cells.Add(drow("PartOdmProductionMoq").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartOdmProductionMoq", "s61"))
        Row8.Cells.Add(drow("PartOdmPostProductionMoq").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartOdmPostProductionMoq", "s61"))
        'Row8.Cells.Add(drow("PartLeadTime").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartLeadTime", "s61"))
        Row8.Cells.Add(drow("PartSupplier").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartSupplier", "s61"))
        Row8.Cells.Add(drow("PartModel").ToString(), DataType.String, GetPartStyleID(sheets, drow, "PartModel", "s61"))
        '
        ' Run Version Routine 
        '
        'For Each vRow As DataRow In drVersions
        '    cell = Row8.Cells.Add
        '    cell.StyleID = GetPartStyleID(sheets, drow, "", "s61")
        'Next
        '
        ' End Version Loop
        '
        Row8.Cells.Add(drow("PartComments").ToString, DataType.String, GetPartStyleID(sheets, drow, "PartComments", "s50"))
      Else
        'Check to see if the status changed.
        If (drow("PartXplantStatus").ToString.Trim = "C6" Or drow("PartXplantStatus").ToString.Trim = "C1") And (drow("aPartXplantStatus").ToString.Trim() = "C2" Or drow("aPartXplantStatus").ToString.Trim = "C5") Then
          AddChangeLogRow(sheets, drow("spskitpn").ToString.Trim, drow("PartPn").ToString.Trim, "2", "Cross Plant Status", String.Format("{0} -> {1}", drow("aPartXplantStatus").ToString.Trim, drow("PartXplantStatus")))
        End If
      End If

      '-----------------------------------------------

    End Sub
#End Region

#Region " Close Spd Worksheet "
    Private Sub CloseServiceProgramBomWorksheet(ByVal sheets As WorksheetCollection)
      Dim sheet As Worksheet = sheets("Service Program BOM")
      '-----------------------------------------------
      ' Options
      '-----------------------------------------------
      sheet.Options.Selected = True
      sheet.Options.ProtectObjects = False
      sheet.Options.ProtectScenarios = False
      sheet.Options.PageSetup.Layout.Orientation = Orientation.Landscape
      sheet.Options.PageSetup.Layout.CenterHorizontal = True
      sheet.Options.PageSetup.Footer.Data = "&LHP Confidential&CPage &P of &N&RDate Printed: &D"
      sheet.Options.PageSetup.Footer.Margin = 0.25!
      sheet.Options.PageSetup.PageMargins.Bottom = 0.5!
      sheet.Options.PageSetup.PageMargins.Left = 0.25!
      sheet.Options.PageSetup.PageMargins.Right = 0.25!
      sheet.Options.PageSetup.PageMargins.Top = 0.5!
      sheet.Options.Print.ValidPrinterInfo = True

    End Sub
#End Region
#End Region

#Region " Change Log Worksheet "
#Region " Create ChangeLog Worksheet "
    Private Sub CreateChangeLogWorksheet(ByVal sheets As WorksheetCollection)
      Dim sheet As Worksheet = sheets.Add("Change Log")
      sheet.Table.ExpandedColumnCount = 5
      sheet.Table.FullColumns = 1
      sheet.Table.FullRows = 1
      Dim column1 As WorksheetColumn = sheet.Table.Columns.Add
      column1.Width = 76
      column1.StyleID = "s214"
      column1.Span = 2
      Dim column2 As WorksheetColumn = sheet.Table.Columns.Add
      column2.Index = 4
      column2.Width = 111
      Dim column3 As WorksheetColumn = sheet.Table.Columns.Add
      column3.Width = 288
      column3.StyleID = "s209"
      '-----------------------------------------------
      Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
      Row0.Index = 2
      Row0.Height = 13
      Row0.AutoFitHeight = False
      Dim cell As WorksheetCell
      cell = Row0.Cells.Add
      cell.StyleID = "s215"
      cell.Index = 2
      cell = Row0.Cells.Add
      cell.StyleID = "s210"
      cell.Index = 4
      '-----------------------------------------------
      Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
      Row1.Height = 13
      Row1.AutoFitHeight = False
      cell = Row1.Cells.Add
      cell.StyleID = "s204"
      cell.Data.Type = DataType.String
      cell.Data.Text = "Change Log"
      cell.MergeAcross = 4
      '-----------------------------------------------
      Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
      Row2.Height = 13
      Row2.AutoFitHeight = False
      Row2.Cells.Add("Spare Kit", DataType.String, "s205")
      Row2.Cells.Add("HP Part No", DataType.String, "s205")
      Row2.Cells.Add("Level", DataType.String, "s205")
      Row2.Cells.Add("Column", DataType.String, "s205")
      Row2.Cells.Add("Details", DataType.String, "s211")
      '-----------------------------------------------
    End Sub
#End Region

#Region " Add Change Log Rows "
    Private Sub AddChangeLogRow(ByVal sheets As WorksheetCollection, ByVal SpsKitPn As String, ByVal HpPartNo As String,
        ByVal Level As String, ByVal ColumnName As String, ByVal ChangeDetails As String)

      If Publish Then
        Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
        dw.InsertSpbChangeLog(ServiceFamilyPn, ExportTime, SpsKitPn, HpPartNo, Level, ColumnName, ChangeDetails)

      End If

      Dim sheet As Worksheet = sheets("Change Log")
      '-----------------------------------------------
      Dim Row As WorksheetRow = sheet.Table.Rows.Add
      Row.Cells.Add(SpsKitPn, DataType.String, "s207")
      Row.Cells.Add(HpPartNo, DataType.String, "s207")
      Row.Cells.Add(Level, DataType.String, "s207")
      Row.Cells.Add(ColumnName, DataType.String, "s207")
      Row.Cells.Add(ChangeDetails, DataType.String, "s212")

    End Sub
#End Region

#Region " Close ChangeLog Worksheet "
    Private Sub CloseWorksheetChangeLog(ByVal sheets As WorksheetCollection)
      Dim sheet As Worksheet = sheets("Change Log")
      '-----------------------------------------------
      ' Options
      '-----------------------------------------------
      sheet.Options.Selected = True
      sheet.Options.ProtectObjects = False
      sheet.Options.ProtectScenarios = False
      sheet.Options.PageSetup.Header.Margin = 0.3!
      sheet.Options.PageSetup.Footer.Data = "&LHP Confidential&CPage &P of &N&RDate Printed: &D"
      sheet.Options.PageSetup.Footer.Margin = 0.25!
      sheet.Options.PageSetup.PageMargins.Bottom = 0.75!
      sheet.Options.PageSetup.PageMargins.Left = 0.7!
      sheet.Options.PageSetup.PageMargins.Right = 0.7!
      sheet.Options.PageSetup.PageMargins.Top = 0.75!
    End Sub
#End Region
#End Region

#Region " Categories Worksheet "
    Private Sub GenerateWorksheetSPSCategories(ByVal sheets As WorksheetCollection)
      Dim sheet As Worksheet = sheets.Add("SPSCategories")
      sheet.Table.ExpandedColumnCount = 1
      sheet.Table.ExpandedRowCount = 39
      sheet.Table.FullColumns = 1
      sheet.Table.FullRows = 1
      sheet.Table.Columns.Add(223)
      '-----------------------------------------------
      Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
      Row0.Index = 7
      Row0.Cells.Add("Base Unit", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
      Row1.Cells.Add("Cable", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
      Row2.Cells.Add("Case", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
      Row3.Cells.Add("Communication Device", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
      Row4.Cells.Add("Cradle", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row5 As WorksheetRow = sheet.Table.Rows.Add
      Row5.Cells.Add("Display", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row6 As WorksheetRow = sheet.Table.Rows.Add
      Row6.Cells.Add("Dock", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row7 As WorksheetRow = sheet.Table.Rows.Add
      Row7.Cells.Add("Input/Output Device - Earbud", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row8 As WorksheetRow = sheet.Table.Rows.Add
      Row8.Cells.Add("Input/Output Device - Headset", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row9 As WorksheetRow = sheet.Table.Rows.Add
      Row9.Cells.Add("Input/Output Device - Keyboard", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row10 As WorksheetRow = sheet.Table.Rows.Add
      Row10.Cells.Add("Input/Output Device - Mouse", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row11 As WorksheetRow = sheet.Table.Rows.Add
      Row11.Cells.Add("Input/Output Device - Pen", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row12 As WorksheetRow = sheet.Table.Rows.Add
      Row12.Cells.Add("Input/Output Device - Remote", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row13 As WorksheetRow = sheet.Table.Rows.Add
      Row13.Cells.Add("Input/Output Device - Speaker", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row14 As WorksheetRow = sheet.Table.Rows.Add
      Row14.Cells.Add("Input/Output Device - Touchpad", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row15 As WorksheetRow = sheet.Table.Rows.Add
      Row15.Cells.Add("Input/Output Device - TV Tuner", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row16 As WorksheetRow = sheet.Table.Rows.Add
      Row16.Cells.Add("Memory", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row17 As WorksheetRow = sheet.Table.Rows.Add
      Row17.Cells.Add("Misc.Hardware e.g., screws, plastic, brackets", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row18 As WorksheetRow = sheet.Table.Rows.Add
      Row18.Cells.Add("PCAs - Miscellaneous", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row19 As WorksheetRow = sheet.Table.Rows.Add
      Row19.Cells.Add("PCAs - System Board", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row20 As WorksheetRow = sheet.Table.Rows.Add
      Row20.Cells.Add("Power - AC Adapter", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row21 As WorksheetRow = sheet.Table.Rows.Add
      Row21.Cells.Add("Power - Battery", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row22 As WorksheetRow = sheet.Table.Rows.Add
      Row22.Cells.Add("Power - Battery Charger", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row23 As WorksheetRow = sheet.Table.Rows.Add
      Row23.Cells.Add("Power - Power cord", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row24 As WorksheetRow = sheet.Table.Rows.Add
      Row24.Cells.Add("Processor", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row25 As WorksheetRow = sheet.Table.Rows.Add
      Row25.Cells.Add("Security - Fingerprint Reader", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row26 As WorksheetRow = sheet.Table.Rows.Add
      Row26.Cells.Add("Security - Lock", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row27 As WorksheetRow = sheet.Table.Rows.Add
      Row27.Cells.Add("Security - Privacy Film", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row28 As WorksheetRow = sheet.Table.Rows.Add
      Row28.Cells.Add("Storage - Hard Drive", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row29 As WorksheetRow = sheet.Table.Rows.Add
      Row29.Cells.Add("Storage - Optical Storage Device", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row30 As WorksheetRow = sheet.Table.Rows.Add
      Row30.Cells.Add("Storage - SSD", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row31 As WorksheetRow = sheet.Table.Rows.Add
      Row31.Cells.Add("Thermal - Fan", DataType.String, "s25")
      '-----------------------------------------------
      Dim Row32 As WorksheetRow = sheet.Table.Rows.Add
      Row32.Cells.Add("Thermal - Heatsink", DataType.String, "s25")
      '-----------------------------------------------
      ' Options
      '-----------------------------------------------
      sheet.Options.ProtectObjects = False
      sheet.Options.ProtectScenarios = False
    End Sub
#End Region

#Region " Odm Change Log Worksheet "
    Private Sub GenerateWorksheetODMChangeLog(ByVal sheets As WorksheetCollection)
      Dim sheet As Worksheet = sheets.Add("ODMChangeLog")
      sheet.Table.ExpandedColumnCount = 1
      sheet.Table.ExpandedRowCount = 1
      sheet.Table.FullColumns = 1
      sheet.Table.FullRows = 1
      '-----------------------------------------------
      ' Options
      '-----------------------------------------------
      sheet.Options.ProtectObjects = False
      sheet.Options.ProtectScenarios = False
    End Sub
#End Region

#Region " GetStyleID "
    Private Function GetVersionStyleId(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal CellStyle As String, ByVal vRow As DataRow)
      Dim sNormal As String = CellStyle
      Dim sHighlight As String = CellStyle & "h"
      Dim sStrike As String = CellStyle & "s"

      If NewMatrix Then Return sNormal

      If row("SpsKitPn").ToString.Trim() <> String.Empty And row("aSpsKitPn").ToString.Trim() = String.Empty Then
        Return sHighlight
      End If

      If vRow("VersionSupported").ToString.Trim() <> vRow("aVersionSupported").ToString.Trim() Then
        AddVersionChangeRow(sheets, row, vRow)
        Return sHighlight
      End If

      Return sNormal

    End Function

    Private Function GetKitStyleID(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal ColumnName As String, ByVal CellStyle As String) As String
      Dim sNormal As String = CellStyle
      Dim sHighlight As String = CellStyle & "h"
      Dim sStrike As String = CellStyle & "s"

      If NewMatrix Then Return sNormal

      If row("SpsKitPn").ToString.Trim() <> String.Empty And row("aSpsKitPn").ToString.Trim() = String.Empty And ColumnName.ToLower() <> "spskitpn" Then
        Return sHighlight
      End If

      If ColumnName = String.Empty Then Return sNormal

      If row(ColumnName).ToString.Trim() <> row("a" & ColumnName).ToString.Trim() And Not NewMatrix Then
        If row("SpsKitPn").ToString.Trim() = String.Empty Then
          AddSpareKitChangeRow(sheets, row, ChangeType.Remove, ColumnName)
          Return sStrike 'Strike Through
        ElseIf row("aSpsKitPn").ToString.Trim = String.Empty Then
          AddSpareKitChangeRow(sheets, row, ChangeType.Add, ColumnName)
          Return sHighlight 'Highlight
        Else
          AddSpareKitChangeRow(sheets, row, ChangeType.Change, ColumnName)
          Return sHighlight 'Highlight
        End If
      Else
        Return sNormal 'Normal
      End If
    End Function

    Private Function GetSAStyleID(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal ColumnName As String, ByVal CellStyle As String) As String
      Dim sNormal As String = CellStyle
      Dim sHighlight As String = CellStyle & "h"
      Dim sStrike As String = CellStyle & "s"
      Dim sHalb As String = CellStyle & "halb"

      If row("SaMatlType").ToString.ToUpper.Trim() = "HALB" Then
        sNormal = sHalb
      End If

      If NewMatrix Then Return sNormal

      If row("SaPn").ToString.Trim() <> String.Empty And row("aSaPn").ToString.Trim() = String.Empty And ColumnName.ToLower() <> "sapn" Then
        Return sHighlight
      End If

      If ColumnName = String.Empty Then Return sNormal
      If ColumnName.Contains("SpsKitPn") Then Return sNormal
      If ColumnName.Contains("SpsKitDelCat") Then Return sNormal

      If row(ColumnName).ToString.Trim() <> row("a" & ColumnName).ToString.Trim() And Not NewMatrix Then
        If row("SaPn").ToString.Trim() = String.Empty Then
          AddSAChangeRow(sheets, row, ChangeType.Remove, ColumnName)
          Return sStrike 'Strike Through
        ElseIf row("aSaPn").ToString.Trim = String.Empty Then
          AddSAChangeRow(sheets, row, ChangeType.Add, ColumnName)
          Return sHighlight 'Highlight
        Else
          AddSAChangeRow(sheets, row, ChangeType.Change, ColumnName)
          Return sHighlight 'Highlight
        End If
      Else
        Return sNormal 'Normal
      End If

    End Function

    Private Function GetPartStyleID(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal ColumnName As String, ByVal CellStyle As String) As String
      Dim sNormal As String = CellStyle
      Dim sHighlight As String = CellStyle & "h"
      Dim sStrike As String = CellStyle & "s"

      If NewMatrix Then Return sNormal

      If row("PartPn").ToString.Trim() <> String.Empty And row("aPartPn").ToString.Trim() = String.Empty And ColumnName.ToLower() <> "partpn" Then
        Return sHighlight
      End If

      If ColumnName = String.Empty Then Return sNormal
      If ColumnName.Contains("SpsKitPn") Then Return sNormal
      If ColumnName.Contains("SpsKitDelCat") Then Return sNormal

      If row(ColumnName).ToString.Trim() <> row("a" & ColumnName).ToString.Trim() And Not NewMatrix Then
        If row("PartPn").ToString.Trim() = String.Empty Then
          AddPartChangeRow(sheets, row, ChangeType.Remove, ColumnName)
          Return sStrike 'Strike Through
        ElseIf row("aPartPn").ToString.Trim = String.Empty Then
          AddPartChangeRow(sheets, row, ChangeType.Add, ColumnName)
          Return sHighlight 'Highlight
        Else
          AddPartChangeRow(sheets, row, ChangeType.Change, ColumnName)
          Return sHighlight 'Highlight
        End If
      Else
        Return sNormal 'Normal
      End If

    End Function
#End Region

#Region " Log Change Details "
#Region " ChangeType Enum "
    Public Enum ChangeType As Integer
      Add = 1
      Change = 2
      Remove = 3
    End Enum
#End Region

    Sub AddVersionChangeRow(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal vRow As DataRow)
      Dim sSpsKitPn As String = row("SpsKitPn").ToString.Trim()
      Dim sLevel As String = "2"
      Dim sColumnName As String = "Version"
      Dim sChangeDetails As String = String.Empty

      If vRow("VersionSupported").ToString.Trim() <> String.Empty And vRow("aVersionSupported").ToString.Trim() = String.Empty Then
        sChangeDetails = String.Format("Spare Kit {0} Added to Version {1}", sSpsKitPn, vRow("VersionSupported").ToString())
      ElseIf vRow("VersionSupported").ToString.Trim() = String.Empty And vRow("aVersionSupported").ToString.Trim() <> String.Empty Then
        sChangeDetails = String.Format("Spare Kit {0} Removed from Version {1}", sSpsKitPn, vRow("VersionSupported").ToString())
      Else
        Exit Sub
      End If

      AddChangeLogRow(sheets, sSpsKitPn, String.Empty, sLevel, sColumnName, sChangeDetails)

    End Sub

    Sub AddSpareKitChangeRow(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal Type As ChangeType, ByVal ColumnName As String)
      If ColumnName = String.Empty Then Exit Sub

      Dim sSpsKitPn As String = row("SpsKitPn").ToString.Trim()
      If sSpsKitPn = String.Empty Then sSpsKitPn = row("aSpsKitPn").ToString.Trim()

      Dim sLevel As String = "2"
      Dim sColumnName As String = String.Empty
      Dim sChangeDetails As String = String.Empty

      Select Case ColumnName.ToLower
        Case "spsdelcat"
          sColumnName = "Part Type"
        Case "spskitossporderable"
          sColumnName = "OSSP Orderable"
        Case "spskitpn"
          sColumnName = "Spare Kit Pn"
        Case "spskitrev"
          sColumnName = "Revision"
        Case "spskitdescription"
          sColumnName = "Description"
        Case "spsqty"
          sColumnName = "Quantity"
        Case "spsusage"
          sColumnName = "Usage"
        Case "spsbomitemno"
          sColumnName = "Item No"
        Case "spsmatltype"
          sColumnName = "Material Type"
        Case "spsxplantstatus"
          sColumnName = "Cross Plant Status"
      End Select

      sChangeDetails = String.Format("{0} -> {1}", row("a" & ColumnName).ToString.Trim(), row(ColumnName).ToString.Trim())

      If Type = ChangeType.Add And ColumnName.ToLower() = "spskitpn" Then
        sChangeDetails = "Spare Kit Added"
        sColumnName = String.Empty
      ElseIf Type = ChangeType.Add Then
        Exit Sub
      End If

      If Type = ChangeType.Remove And ColumnName.ToLower = "spskitpn" Then
        sChangeDetails = "Spare Kit Removed"
        sColumnName = String.Empty
      ElseIf Type = ChangeType.Remove Then
        Exit Sub
      End If

      AddChangeLogRow(sheets, sSpsKitPn, String.Empty, sLevel, sColumnName, sChangeDetails)

    End Sub

    Sub AddSAChangeRow(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal Type As ChangeType, ByVal ColumnName As String)
      If ColumnName = String.Empty Then Exit Sub

      Dim sSpsKitPn As String = row("SpsKitPn").ToString.Trim()
      Dim sHpPartNo As String = row("SaPn").ToString.Trim()
      If Type = ChangeType.Remove Then
        sSpsKitPn = row("aSpsKitPn").ToString.Trim()
        sHpPartNo = row("aSaPn").ToString.Trim()
      End If
      Dim sLevel As String = "3"
      Dim sColumnName As String = String.Empty
      Dim sChangeDetails As String = String.Empty

      Select Case ColumnName.ToLower
        Case "saossporderable"
          sColumnName = "OSSP Orderable"
        Case "saqty"
          sColumnName = "Quantity"
        Case "sarev"
          sColumnName = "Revision"
        Case "sausage"
          sColumnName = "Usage"
        Case "sabomitemno"
          sColumnName = "BOM Item No"
        Case "saprialt"
          sColumnName = "Pri / Alt / Gen"
        Case "sapn"
          sColumnName = "HP Part No"
        Case "sadescription"
          sColumnName = "Description"
        Case "saodmpartno"
          sColumnName = "ODM Part No"
        Case "saodmpartdescription"
          sColumnName = "ODM Description"
        Case "saodmbulkpartno"
          sColumnName = "ODM Bulk Part No"
        Case "saodmproductionmoq"
          sColumnName = "ODM Production MOQ"
        Case "saodmpostproductionmoq"
          sColumnName = "ODM Post-Production MOQ"
        Case "saleadtime"
          sColumnName = "Lead Time"
        Case "sasupplier"
          sColumnName = "Supplier"
        Case "sacomments"
          sColumnName = "Comments"
        Case "samatltype"
          sColumnName = "Material Type"
        Case "saxplantstatus"
          sColumnName = "Cross Plant Status"
        Case "samodel"
          sColumnName = "Model / Mfg Pn"
      End Select

      sChangeDetails = String.Format("{0} -> {1}", row("a" & ColumnName).ToString.Trim(), row(ColumnName).ToString.Trim())

      If Type = ChangeType.Add And ColumnName.ToLower() = "sapn" Then
        sChangeDetails = "Sub Assembly Added"
        sColumnName = String.Empty
      ElseIf Type = ChangeType.Add Then
        Exit Sub
      End If

      If Type = ChangeType.Remove And ColumnName.ToLower = "sapn" Then
        sChangeDetails = "Sub Assembly Removed"
        sColumnName = String.Empty
      ElseIf Type = ChangeType.Remove Then
        Exit Sub
      End If

      AddChangeLogRow(sheets, sSpsKitPn, sHpPartNo, sLevel, sColumnName, sChangeDetails)

    End Sub

    Sub AddPartChangeRow(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal Type As ChangeType, ByVal ColumnName As String)
      If ColumnName = String.Empty Then Exit Sub

      Dim sSpsKitPn As String = row("SpsKitPn").ToString.Trim()
      Dim sHpPartNo As String = row("PartPn").ToString.Trim()
      If Type = ChangeType.Remove Then
        sSpsKitPn = row("aSpsKitPn").ToString.Trim()
        sHpPartNo = row("aPartPn").ToString.Trim()
      End If
      Dim sLevel As String = "4"
      Dim sColumnName As String = String.Empty
      Dim sChangeDetails As String = String.Empty

      Select Case ColumnName.ToLower
        Case "partossporderable"
          sColumnName = "OSSP Orderable"
        Case "partqty"
          sColumnName = "Quantity"
        Case "partrev"
          sColumnName = "Revision"
        Case "partusage"
          sColumnName = "Usage"
        Case "partbomitemno"
          sColumnName = "BOM Item No"
        Case "partprialt"
          sColumnName = "Pri / Alt / Gen"
        Case "partpn"
          sColumnName = "HP Part No"
        Case "partdescription"
          sColumnName = "Description"
        Case "partodmpartno"
          sColumnName = "ODM Part No"
        Case "partodmpartdescription"
          sColumnName = "ODM Description"
        Case "partodmbulkpartno"
          sColumnName = "ODM Bulk Part No"
        Case "partodmproductionmoq"
          sColumnName = "ODM Production MOQ"
        Case "partodmpostproductionmoq"
          sColumnName = "ODM Post-Production MOQ"
        Case "partleadtime"
          sColumnName = "Lead Time"
        Case "partsupplier"
          sColumnName = "Supplier"
        Case "partcomments"
          sColumnName = "Comments"
        Case "partmatltype"
          sColumnName = "Material Type"
        Case "partxplantstatus"
          sColumnName = "Cross Plant Status"
        Case "partmodel"
          sColumnName = "Model / Mfg Pn"
      End Select

      sChangeDetails = String.Format("{0} -> {1}", row("a" & ColumnName).ToString.Trim(), row(ColumnName).ToString.Trim())

      If Type = ChangeType.Add And ColumnName.ToLower() = "partpn" Then
        sChangeDetails = "Component Added"
        sColumnName = String.Empty
      ElseIf Type = ChangeType.Add Then
        Exit Sub
      End If

      If Type = ChangeType.Remove And ColumnName.ToLower = "partpn" Then
        sChangeDetails = "Component Removed"
        sColumnName = String.Empty
      ElseIf Type = ChangeType.Remove Then
        Exit Sub
      End If

      AddChangeLogRow(sheets, sSpsKitPn, sHpPartNo, sLevel, sColumnName, sChangeDetails)

    End Sub

#End Region

#Region " Format Excel Date "

    Function FormatExcelDate(ByVal dt As Date) As String
      Dim s As StringBuilder = New StringBuilder
      s.Append(dt.Year.ToString.Trim())
      s.Append("-")
      s.Append(dt.Month.ToString.PadLeft(2, "0"))
      s.Append("-")
      s.Append(dt.Day.ToString.PadLeft(2, "0"))
      s.Append("T")
      s.Append(dt.Hour.ToString.PadLeft(2, "0"))
      s.Append(":")
      s.Append(dt.Minute.ToString.PadLeft(2, "0"))
      s.Append(":")
      s.Append(dt.Second.ToString.PadLeft(2, "0"))
      s.Append(".000")

      Return s.ToString.Trim
    End Function


#End Region

    Private Enum BomLevelEnum As Integer
      Kit
      SubAssembly
      Part
    End Enum

    Private Function ValidRow(ByVal drow As DataRow, ByVal BomLevel As BomLevelEnum) As Boolean
      Dim sKitMatlType As String = drow("SpsMatlType").ToString
      Dim sSaMatlType As String = drow("SaMatlType").ToString
      Dim sPartMatlType As String = drow("PartMatlType").ToString
      Dim bValidType As Boolean = False

      Dim sKitXplantStatus As String = drow("SpsXplantStatus").ToString
      Dim sSaXplantStatus As String = drow("SaXplantStatus").ToString
      Dim sPartXplantStatus As String = drow("PartXplantStatus").ToString
      Dim bValidStatus As Boolean = False

      Select Case BomLevel
        Case BomLevelEnum.Kit
          bValidType = ValidMaterial(sKitMatlType)
          bValidStatus = ValidStatus(sKitXplantStatus)
        Case BomLevelEnum.SubAssembly
          bValidType = ValidMaterial(sKitMatlType) And ValidMaterial(sSaMatlType)
          bValidStatus = ValidStatus(sKitXplantStatus) And ValidStatus(sSaXplantStatus)
        Case BomLevelEnum.Part
          bValidType = ValidMaterial(sKitMatlType) And ValidMaterial(sSaMatlType) And ValidMaterial(sPartMatlType)
          bValidStatus = ValidStatus(sKitXplantStatus) And ValidStatus(sSaXplantStatus) And ValidStatus(sPartXplantStatus)
      End Select

      Return bValidType And bValidStatus

    End Function

    Private Function ValidMaterial(ByVal MatlType As String)
      Select Case MatlType.ToUpper.Trim
        Case "HALB"
          Return True
        Case "FERT"
          Return True
        Case "ROH"
          Return True
        Case Else
          Return False
      End Select
    End Function

    Private Function ValidStatus(ByVal XplantStatus As String)
      Select Case XplantStatus.ToUpper.Trim
        Case "C2"
          Return True
        Case "C5"
          Return True
        Case Else
          Return False
      End Select
    End Function

  End Class

#Region " Class SpdmInfo "
  Public Class SpbNfo
    Private _familySpsPn As String
    Public Property FamilySpsPn() As String
      Get
        Return _familySpsPn
      End Get
      Set(ByVal value As String)
        _familySpsPn = value
        Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
        Dim dt As DataTable = dwExcalibur.SelectSpbDetails(_familySpsPn)
        If dt.Rows.Count = 0 Then Throw New Exception(String.Format("No Details for Family Pn : {0}", value))
        _productVersionID = dt.Rows(0)("ProductVersionID")
        _projectCode = dt.Rows(0)("ProjectCd").ToString()
        _partnerName = dt.Rows(0)("PartnerName").ToString()
        _spdmContact = dt.Rows(0)("SpdmContact").ToString()
        _productVersion = dt.Rows(0)("Version").ToString()
        _family = dt.Rows(0)("FamilyName").ToString()
        _familyName = dt.Rows(0)("XFamilyName").ToString()
        _division = dt.Rows(0)("Division").ToString()
      End Set
    End Property

#Region " ReadOnly Properties "
    Private _productVersionID As Long
    Public ReadOnly Property ProductVersionID() As Long
      Get
        Return _productVersionID
      End Get
    End Property

    Private _spdmContact As String
    Public ReadOnly Property SpdmContact() As String
      Get
        Return _spdmContact
      End Get
    End Property

    Private _partnerName As String
    Public ReadOnly Property Partner() As String
      Get
        Return _partnerName
      End Get
    End Property

    Private _projectCode As String
    Public ReadOnly Property ProjectCode() As String
      Get
        Return _projectCode
      End Get
    End Property

    Private _family As String
    Public ReadOnly Property Family() As String
      Get
        Return _family
      End Get
    End Property

    Private _familyName As String
    Public ReadOnly Property FamilyName() As String
      Get
        Return _familyName
      End Get
    End Property

    Private _productVersion As String
    Public ReadOnly Property ProductVersion() As String
      Get
        Return _productVersion
      End Get
    End Property

    Private _division As String
    Public ReadOnly Property Division() As String
      Get
        Return _division
      End Get
    End Property
#End Region

#Region " Constructors "
    Public Sub New()

    End Sub

    Public Sub New(ByVal FamilySpsPn As String)
      Me.FamilySpsPn = FamilySpsPn
    End Sub
#End Region

  End Class
#End Region

End Namespace
