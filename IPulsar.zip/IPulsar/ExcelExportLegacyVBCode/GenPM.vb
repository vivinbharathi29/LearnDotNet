Imports Microsoft.VisualBasic
Imports System
Imports System.Xml
Imports System.Text
Imports CarlosAg.ExcelXmlWriter

Namespace ExcelExport
  Public Class GenPM

#Region " Properties "
    Private _NewMatrix As Boolean = False
    Public Property NewMatrix() As Boolean
      Get
        Return _NewMatrix
      End Get
      Set(ByVal value As Boolean)
        _NewMatrix = value
      End Set
    End Property

    Private _Publish As Boolean = False
    Public Property Publish() As Boolean
      Get
        Return _Publish
      End Get
      Set(ByVal value As Boolean)
        _Publish = value
      End Set
    End Property

    Private _ProductBrandID As String = String.Empty
    Public Property ProductBrandID() As String
      Get
        Return _ProductBrandID
      End Get
      Set(ByVal value As String)
        _ProductBrandID = value
      End Set
    End Property

    Private _CompareDt As String = String.Empty
    Public Property CompareDt() As String
      Get
        Return _CompareDt
      End Get
      Set(ByVal value As String)
        _CompareDt = value
      End Set
    End Property

    Private _PvCount As Integer = 0
    Private ReadOnly Property PvCount() As Integer
      Get
        Return _PvCount
      End Get
    End Property

    Private _BSAM As Boolean = False
    Public Property BSAM() As Boolean
      Get
        Return _BSAM
      End Get
      Set(ByVal value As Boolean)
        _BSAM = value
      End Set
    End Property
#End Region

    Dim _DeletedAvRows As WorksheetRowCollection
        Dim _DeletedSaRows As WorksheetRowCollection
        Dim _DeletedPartRows As WorksheetRowCollection

#Region " Generate Workbook "
        Public Sub Generate(ByRef stream As System.IO.Stream, ByRef FileName As String)
            Dim book As Workbook = New Workbook
            '-----------------------------------------------
            ' Properties
            '-----------------------------------------------
            book.Properties.Author = "Excalibur"
            book.Properties.LastAuthor = "Excalibur"
            book.Properties.Created = Date.Now()
            book.Properties.LastSaved = Date.Now()
            book.Properties.Company = "HP"
            book.Properties.Version = "12.00"
            book.ExcelWorkbook.WindowHeight = 8835
            book.ExcelWorkbook.WindowWidth = 15180
            book.ExcelWorkbook.WindowTopX = 120
            book.ExcelWorkbook.WindowTopY = 105
            book.ExcelWorkbook.ActiveSheetIndex = 1
            book.ExcelWorkbook.ProtectWindows = False
            book.ExcelWorkbook.ProtectStructure = False
            '-----------------------------------------------
            ' Generate Styles
            '-----------------------------------------------
            Me.GenerateStyles(book.Styles)

            '
            ' Get the data
            '
            Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
            Dim dt As DataTable = dwExcalibur.SelectProgramMatrix(ProductBrandID, CompareDt, Publish)
            _PvCount = dwExcalibur.SelectKmatVersions(ProductBrandID).Rows.Count()
            Dim dtVersions As DataTable = dwExcalibur.SelectAvVersions(ProductBrandID, CompareDt, Publish)

            '
            ' Create Worksheets in the workbook
            '
            'Me.CreateChangeLogWorksheet(book.Worksheets)
            Me.GenerateWorksheetChangeLog(book.Worksheets, ProductBrandID)
            Me.CreateProgramMatrixWorksheet(book.Worksheets, ProductBrandID, dt)
            Me.OpenDetailedChangeLog(book.Worksheets, ProductBrandID)

            book.Worksheets.Add("DeletedAvs")
            book.Worksheets.Add("DeletedSas")
            book.Worksheets.Add("DeletedParts")

            _DeletedAvRows = book.Worksheets("DeletedAvs").Table.Rows
            _DeletedSaRows = book.Worksheets("DeletedSas").Table.Rows
            _DeletedPartRows = book.Worksheets("DeletedParts").Table.Rows

            '
            ' Loop through the data building the worksheets.
            '
            Dim sLastCategory As String = String.Empty
            Dim sLastAV As String = String.Empty
            Dim sLastSA As String = String.Empty
            Dim sLastPart As String = String.Empty
            Dim bFirstCategory As Boolean = True
            Dim catRow As DataRow
            Dim bDrawCategory As Boolean = False
            catRow = Nothing

            For Each row As DataRow In dt.Rows
                If sLastCategory <> row("FeatureCategory").ToString.Trim Then
                    sLastCategory = row("FeatureCategory").ToString.Trim

                    If bDrawCategory Then
                        If Not bFirstCategory Then
                            Me.CloseCategory(book.Worksheets)
                        Else
                            bFirstCategory = False
                        End If
                        Me.AddNewCategory(book.Worksheets, catRow)
                    End If

                    If _DeletedPartRows.Count > 0 Then
                        AddDeletedRows(book.Worksheets, _DeletedPartRows)
                    End If
                    If _DeletedSaRows.Count > 0 Then
                        AddDeletedRows(book.Worksheets, _DeletedSaRows)
                    End If
                    If _DeletedAvRows.Count > 0 Then
                        AddDeletedRows(book.Worksheets, _DeletedAvRows)
                    End If

                    bDrawCategory = True
                    catRow = row
                End If

                If sLastAV <> row("sortAVNO").ToString.Trim Then
                    If _DeletedPartRows.Count > 0 Then
                        AddDeletedRows(book.Worksheets, _DeletedPartRows)
                    End If
                    If _DeletedSaRows.Count > 0 Then
                        AddDeletedRows(book.Worksheets, _DeletedSaRows)
                    End If
                ElseIf sLastSA <> row("sortsano").ToString.Trim Then
                    If _DeletedPartRows.Count > 0 Then
                        AddDeletedRows(book.Worksheets, _DeletedPartRows)
                    End If
                End If

                If bDrawCategory And row("AvNo").ToString() <> String.Empty Then
                    If Not bFirstCategory Then
                        Me.CloseCategory(book.Worksheets)
                    Else
                        bFirstCategory = False
                    End If
                    Me.AddNewCategory(book.Worksheets, row)
                    bDrawCategory = False
                End If

                If sLastAV <> row("sortAVNO").ToString.Trim And row("sortAVNO").ToString.Trim <> String.Empty Then
                    Me.AddNewAV(book.Worksheets, row, dtVersions)
                    sLastAV = row("sortavno").ToString.Trim
                    sLastSA = row("sortsano").ToString.Trim
                    sLastPart = row("sortcompno").ToString.Trim
                ElseIf sLastSA <> row("sortsano").ToString.Trim And row("sortAVNO").ToString.Trim <> String.Empty And row("SortSANO").ToString.Trim() <> String.Empty Then
                    Me.AddNextSA(book.Worksheets, row)
                    sLastSA = row("sortsano").ToString.Trim
                    sLastPart = row("sortcompno").ToString.Trim
                ElseIf sLastPart <> row("sortcompno").ToString.Trim And row("sortAVNO").ToString.Trim <> String.Empty And row("sortSANO").ToString.Trim <> String.Empty And row("SortCompNo").ToString.ToCharArray <> String.Empty Then
                    Me.AddNextComponent(book.Worksheets, row)
                    sLastPart = row("sortcompno").ToString.Trim
                End If
            Next

            If _DeletedPartRows.Count > 0 Then
                AddDeletedRows(book.Worksheets, _DeletedPartRows)
            End If
            If _DeletedSaRows.Count > 0 Then
                AddDeletedRows(book.Worksheets, _DeletedSaRows)
            End If
            If _DeletedAvRows.Count > 0 Then
                AddDeletedRows(book.Worksheets, _DeletedAvRows)
            End If


            book.Worksheets.Remove(book.Worksheets("DeletedAvs"))
            book.Worksheets.Remove(book.Worksheets("DeletedSas"))
            book.Worksheets.Remove(book.Worksheets("DeletedParts"))

            Me.CloseCategory(book.Worksheets)

            '
            ' Close out the worksheets
            '
            Me.CloseProgramMatrixWorksheet(book.Worksheets)
            Me.CloseDetailedChangeLog(book.Worksheets)


            book.Save(stream)
        End Sub
#End Region

#Region " Generate Styles "
        Private Sub GenerateStyles(ByVal styles As WorksheetStyleCollection)
            '-----------------------------------------------
            ' Default
            '-----------------------------------------------
            Dim [Default] As WorksheetStyle = styles.Add("Default")
            [Default].Name = "Normal"
            [Default].Font.FontName = "Arial"
            [Default].Alignment.Vertical = StyleVerticalAlignment.Bottom
            '-----------------------------------------------
            ' s23
            '-----------------------------------------------
            Dim s23 As WorksheetStyle = styles.Add("s23")
            s23.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s23.NumberFormat = "@"
            '-----------------------------------------------
            ' s24
            '-----------------------------------------------
            Dim s24 As WorksheetStyle = styles.Add("s24")
            s24.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s24.Alignment.WrapText = True
            s24.NumberFormat = "@"
            '-----------------------------------------------
            ' s25
            '-----------------------------------------------
            Dim s25 As WorksheetStyle = styles.Add("s25")
            s25.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s25.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s25.Alignment.WrapText = True
            s25.NumberFormat = "@"
            '-----------------------------------------------
            ' s26
            '-----------------------------------------------
            Dim s26 As WorksheetStyle = styles.Add("s26")
            s26.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s26.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s26.Alignment.WrapText = True
            s26.NumberFormat = "@"
            '-----------------------------------------------
            ' s27
            '-----------------------------------------------
            Dim s27 As WorksheetStyle = styles.Add("s27")
            s27.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s27.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s27.NumberFormat = "@"
            '-----------------------------------------------
            ' s28
            '-----------------------------------------------
            Dim s28 As WorksheetStyle = styles.Add("s28")
            s28.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s28.Alignment.ShrinkToFit = True
            s28.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s28.NumberFormat = "@"
            '-----------------------------------------------
            ' s29
            '-----------------------------------------------
            Dim s29 As WorksheetStyle = styles.Add("s29")
            s29.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s29.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s29.Alignment.WrapText = True
            s29.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
            s29.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s29.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 2)
            s29.NumberFormat = "@"
            '-----------------------------------------------
            ' s30
            '-----------------------------------------------
            Dim s30 As WorksheetStyle = styles.Add("s30")
            s30.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s30.Alignment.Rotate = 90
            s30.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s30.Alignment.WrapText = True
            s30.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
            s30.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s30.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 2)
            s30.NumberFormat = "@"
            '-----------------------------------------------
            ' s31
            '-----------------------------------------------
            Dim s31 As WorksheetStyle = styles.Add("s31")
            s31.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s31.Alignment.WrapText = True
            s31.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
            s31.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s31.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 2)
            s31.NumberFormat = "@"
            '-----------------------------------------------
            ' s32
            '-----------------------------------------------
            Dim s32 As WorksheetStyle = styles.Add("s32")
            s32.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s32.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s32.Alignment.WrapText = True
            s32.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
            s32.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s32.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 2)
            s32.NumberFormat = "@"
            '-----------------------------------------------
            ' s33
            '-----------------------------------------------
            Dim s33 As WorksheetStyle = styles.Add("s33")
            s33.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s33.Alignment.Rotate = 90
            s33.Alignment.ShrinkToFit = True
            s33.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s33.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
            s33.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s33.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 2)
            s33.NumberFormat = "@"
            '-----------------------------------------------
            ' s34
            '-----------------------------------------------
            Dim s34 As WorksheetStyle = styles.Add("s34")
            s34.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s34.Alignment.WrapText = True
            s34.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
            s34.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s34.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 2)
            s34.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 2)
            '-----------------------------------------------
            ' s35
            '-----------------------------------------------
            Dim s35 As WorksheetStyle = styles.Add("s35")
            s35.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s35.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s35.NumberFormat = "@"
            '-----------------------------------------------
            ' s36
            '-----------------------------------------------
            Dim s36 As WorksheetStyle = styles.Add("s36")
            s36.Font.Bold = True
            s36.Font.FontName = "Arial"
            s36.Font.Size = 12
            s36.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s36.Alignment.Indent = 1
            s36.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s36.NumberFormat = "@"
            '-----------------------------------------------
            ' s37
            '-----------------------------------------------
            Dim s37 As WorksheetStyle = styles.Add("s37")
            s37.Font.FontName = "Arial"
            s37.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s37.Alignment.Indent = 1
            s37.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s37.NumberFormat = "@"
            '-----------------------------------------------
            ' s38
            '-----------------------------------------------
            Dim s38 As WorksheetStyle = styles.Add("s38")
            s38.Font.FontName = "Arial"
            s38.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s38.Alignment.Indent = 1
            s38.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s38.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 2)
            s38.NumberFormat = "@"
            '-----------------------------------------------
            ' s39
            '-----------------------------------------------
            Dim s39 As WorksheetStyle = styles.Add("s39")
            s39.Font.FontName = "Arial"
            s39.Font.Color = "#FF0000"
            s39.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s39.Alignment.Vertical = StyleVerticalAlignment.Bottom
            '-----------------------------------------------
            ' s40
            '-----------------------------------------------
            Dim s40 As WorksheetStyle = styles.Add("s40")
            s40.Font.Bold = True
            s40.Font.FontName = "Arial"
            '-----------------------------------------------
            ' s41
            '-----------------------------------------------
            Dim s41 As WorksheetStyle = styles.Add("s41")
            s41.Font.Bold = True
            s41.Font.FontName = "Arial"
            s41.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s41.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s41.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s41.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s41.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s41.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s41.NumberFormat = "m/dd/yy"
            '-----------------------------------------------
            ' s42
            '-----------------------------------------------
            Dim s42 As WorksheetStyle = styles.Add("s42")
            s42.Font.Bold = True
            s42.Font.FontName = "Arial"
            s42.Font.Size = 8
            s42.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s42.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s42.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s42.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s42.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s42.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s42.NumberFormat = "0.0"
            '-----------------------------------------------
            ' s43
            '-----------------------------------------------
            Dim s43 As WorksheetStyle = styles.Add("s43")
            s43.Font.Bold = True
            s43.Font.FontName = "Arial"
            s43.Font.Size = 8
            s43.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s43.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s43.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s43.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s43.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s43.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s43.NumberFormat = "@"
            '-----------------------------------------------
            ' s44
            '-----------------------------------------------
            Dim s44 As WorksheetStyle = styles.Add("s44")
            s44.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s44.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s44.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s44.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s45
            '-----------------------------------------------
            Dim s45 As WorksheetStyle = styles.Add("s45")
            s45.Font.Bold = True
            s45.Font.FontName = "Arial"
            s45.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s45.Alignment.Rotate = 90
            s45.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s45.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s45.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s45.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s45.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s45.NumberFormat = "m/dd/yy"
            '-----------------------------------------------
            ' s46
            '-----------------------------------------------
            Dim s46 As WorksheetStyle = styles.Add("s46")
            s46.Font.Bold = True
            s46.Font.FontName = "Arial"
            s46.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s46.Alignment.Rotate = 90
            s46.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s46.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s46.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s46.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s46.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s46.NumberFormat = "0.0"
            '-----------------------------------------------
            ' s47
            '-----------------------------------------------
            Dim s47 As WorksheetStyle = styles.Add("s47")
            s47.Font.Bold = True
            s47.Font.FontName = "Arial"
            s47.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s47.Alignment.Rotate = 90
            s47.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s47.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s47.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s47.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s47.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s47.NumberFormat = "@"
            '-----------------------------------------------
            ' s48
            '-----------------------------------------------
            Dim s48 As WorksheetStyle = styles.Add("s48")
            s48.Font.Bold = True
            s48.Font.FontName = "Arial"
            s48.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s48.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s48.Alignment.WrapText = True
            s48.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s48.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s48.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s48.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s49
            '-----------------------------------------------
            Dim s49 As WorksheetStyle = styles.Add("s49")
            s49.Font.FontName = "Arial"
            s49.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s49.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s49.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s49.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s49.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s49.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s49.NumberFormat = "m/dd/yy"
            '-----------------------------------------------
            ' s50
            '-----------------------------------------------
            Dim s50 As WorksheetStyle = styles.Add("s50")
            s50.Font.FontName = "Arial"
            s50.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s50.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s50.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s50.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s50.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s50.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s50.NumberFormat = "yyyymmdd"
            '-----------------------------------------------
            ' s51
            '-----------------------------------------------
            Dim s51 As WorksheetStyle = styles.Add("s51")
            s51.Font.FontName = "Arial"
            s51.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s51.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s51.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s51.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s51.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s51.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s51.NumberFormat = "@"
            '-----------------------------------------------
            ' s52
            '-----------------------------------------------
            Dim s52 As WorksheetStyle = styles.Add("s52")
            s52.Font.FontName = "Arial"
            s52.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s52.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s52.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s52.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s53
            '-----------------------------------------------
            Dim s53 As WorksheetStyle = styles.Add("s53")
            s53.Font.FontName = "Arial"
            '-----------------------------------------------
            ' s54
            '-----------------------------------------------
            Dim s54 As WorksheetStyle = styles.Add("s54")
            s54.Font.FontName = "Arial"
            s54.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s54.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s54.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s54.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s54.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s54.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s54.NumberFormat = "m/dd/yy"
            '-----------------------------------------------
            ' s55
            '-----------------------------------------------
            Dim s55 As WorksheetStyle = styles.Add("s55")
            s55.Font.FontName = "Arial"
            s55.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s55.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s55.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s55.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s55.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s55.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s55.NumberFormat = "@"
            '-----------------------------------------------
            ' s56
            '-----------------------------------------------
            Dim s56 As WorksheetStyle = styles.Add("s56")
            s56.Font.FontName = "Arial"
            s56.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s56.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s56.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s56.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s57
            '-----------------------------------------------
            Dim s57 As WorksheetStyle = styles.Add("s57")
            s57.Font.FontName = "Arial"
            s57.Font.Color = "#FF0000"
            '-----------------------------------------------
            ' s58
            '-----------------------------------------------
            Dim s58 As WorksheetStyle = styles.Add("s58")
            s58.Font.Bold = True
            s58.Font.FontName = "Arial"
            s58.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s58.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s58.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s58.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s58.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s58.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s58.NumberFormat = "@"
            '-----------------------------------------------
            ' s59
            '-----------------------------------------------
            Dim s59 As WorksheetStyle = styles.Add("s59")
            s59.Font.Bold = True
            s59.Font.FontName = "Arial"
            s59.Font.Color = "#FF0000"
            s59.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s59.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s59.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s59.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s59.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s59.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s59.NumberFormat = "@"
            '-----------------------------------------------
            ' s60
            '-----------------------------------------------
            Dim s60 As WorksheetStyle = styles.Add("s60")
            s60.Font.FontName = "Arial"
            s60.Font.Color = "#FF0000"
            s60.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s60.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s60.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s60.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s60.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s60.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s60.NumberFormat = "m/dd/yy"
            '-----------------------------------------------
            ' s61
            '-----------------------------------------------
            Dim s61 As WorksheetStyle = styles.Add("s61")
            s61.Font.FontName = "Arial"
            s61.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s61.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s61.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s62
            '-----------------------------------------------
            Dim s62 As WorksheetStyle = styles.Add("s62")
            s62.Font.FontName = "Arial"
            s62.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s62.Alignment.WrapText = True
            s62.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s62.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s62.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s62.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s63
            '-----------------------------------------------
            Dim s63 As WorksheetStyle = styles.Add("s63")
            s63.Font.FontName = "Arial"
            s63.Font.Color = "#FF0000"
            s63.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s63.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s63.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s63.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s63.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s63.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s63.NumberFormat = "yyyymmdd"
            '-----------------------------------------------
            ' s64
            '-----------------------------------------------
            Dim s64 As WorksheetStyle = styles.Add("s64")
            s64.Font.FontName = "Arial"
            s64.Font.Color = "#FF0000"
            s64.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s64.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s64.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s64.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s64.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s64.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s64.NumberFormat = "@"
            '-----------------------------------------------
            ' s65
            '-----------------------------------------------
            Dim s65 As WorksheetStyle = styles.Add("s65")
            s65.Font.FontName = "Arial"
            s65.Font.Color = "#FF0000"
            s65.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s65.Alignment.WrapText = True
            s65.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s65.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s65.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s65.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s66
            '-----------------------------------------------
            Dim s66 As WorksheetStyle = styles.Add("s66")
            s66.Font.FontName = "Arial"
            s66.Font.Color = "#FF0000"
            s66.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s66.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s66.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s66.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s67
            '-----------------------------------------------
            Dim s67 As WorksheetStyle = styles.Add("s67")
            s67.Font.FontName = "Arial"
            s67.Font.Color = "#FF0000"
            s67.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s67.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s67.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s67.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s68
            '-----------------------------------------------
            Dim s68 As WorksheetStyle = styles.Add("s68")
            s68.Font.Bold = True
            s68.Font.Italic = True
            s68.Font.FontName = "Arial"
            s68.Font.Color = "#FF0000"
            s68.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s68.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s68.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s68.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s69
            '-----------------------------------------------
            Dim s69 As WorksheetStyle = styles.Add("s69")
            s69.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s69.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s69.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s69.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s69.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s69.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s69.NumberFormat = "0.0"
            '-----------------------------------------------
            ' s70
            '-----------------------------------------------
            Dim s70 As WorksheetStyle = styles.Add("s70")
            s70.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s70.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s70.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s70.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s70.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s70.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s71
            '-----------------------------------------------
            Dim s71 As WorksheetStyle = styles.Add("s71")
            s71.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s71.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s71.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s72
            '-----------------------------------------------
            Dim s72 As WorksheetStyle = styles.Add("s72")
            s72.Font.Bold = True
            s72.Font.Italic = True
            s72.Font.FontName = "Arial"
            s72.Font.Color = "#FF0000"
            s72.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s72.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s72.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s73
            '-----------------------------------------------
            Dim s73 As WorksheetStyle = styles.Add("s73")
            s73.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s73.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s73.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s73.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s73.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s73.NumberFormat = "0.0"
            '-----------------------------------------------
            ' s74
            '-----------------------------------------------
            Dim s74 As WorksheetStyle = styles.Add("s74")
            s74.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s74.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s74.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s74.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s74.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s75
            '-----------------------------------------------
            Dim s75 As WorksheetStyle = styles.Add("s75")
            s75.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s75.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s75.NumberFormat = "m/dd/yy"
            '-----------------------------------------------
            ' s76
            '-----------------------------------------------
            Dim s76 As WorksheetStyle = styles.Add("s76")
            s76.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s76.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s76.NumberFormat = "0.0"
            '-----------------------------------------------
            ' s77
            '-----------------------------------------------
            Dim s77 As WorksheetStyle = styles.Add("s77")
            s77.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s77.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s77.Alignment.WrapText = True
            s77.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s77.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s77.NumberFormat = "@"
            '-----------------------------------------------
            ' s78
            '-----------------------------------------------
            Dim s78 As WorksheetStyle = styles.Add("s78")
            s78.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s78.Alignment.WrapText = True
            s78.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s78.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s78.NumberFormat = "@"
            '-----------------------------------------------
            ' s79
            '-----------------------------------------------
            Dim s79 As WorksheetStyle = styles.Add("s79")
            s79.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s79.Alignment.ShrinkToFit = True
            s79.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s79.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s79.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s79.NumberFormat = "@"
            '-----------------------------------------------
            ' s80
            '-----------------------------------------------
            Dim s80 As WorksheetStyle = styles.Add("s80")
            s80.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s80.Alignment.WrapText = True
            s80.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s80.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 2)
            s80.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s80.NumberFormat = "@"
            '-----------------------------------------------
            ' s81
            '-----------------------------------------------
            Dim s81 As WorksheetStyle = styles.Add("s81")
            s81.Interior.Color = "#99CCFF"
            s81.Interior.Pattern = StyleInteriorPattern.Solid
            s81.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s81.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s81.Alignment.WrapText = True
            s81.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s81.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s81.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s81.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s81.NumberFormat = "@"
            '-----------------------------------------------
            ' s82
            '-----------------------------------------------
            Dim s82 As WorksheetStyle = styles.Add("s82")
            s82.Font.FontName = "Helv"
            s82.Interior.Color = "#99CCFF"
            s82.Interior.Pattern = StyleInteriorPattern.Solid
            s82.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s82.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s82.Alignment.WrapText = True
            s82.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s82.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s82.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s82.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            's82.NumberFormat = "@"
            '-----------------------------------------------
            ' s83
            '-----------------------------------------------
            Dim s83 As WorksheetStyle = styles.Add("s83")
            s83.Font.FontName = "Helv"
            s83.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s83.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s83.Alignment.WrapText = True
            s83.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s83.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s83.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s83.NumberFormat = "@"
            '-----------------------------------------------
            ' s84
            '-----------------------------------------------
            Dim s84 As WorksheetStyle = styles.Add("s84")
            s84.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s84.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s84.Alignment.WrapText = True
            s84.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s84.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s84.NumberFormat = "@"
            '-----------------------------------------------
            ' s85
            '-----------------------------------------------
            Dim s85 As WorksheetStyle = styles.Add("s85")
            s85.Font.FontName = "Arial"
            s85.Font.Color = "#000000"
            s85.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s85.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s85.Alignment.WrapText = True
            s85.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s85.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s85.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s85.NumberFormat = "@"
            '-----------------------------------------------
            ' s85h
            '-----------------------------------------------
            Dim s85h As WorksheetStyle = styles.Add("s85h")
            s85h.Font.FontName = "Arial"
            s85h.Font.Color = "#FF0000"
            s85h.Interior.Color = "#FFFF99"
            s85h.Interior.Pattern = StyleInteriorPattern.Solid
            s85h.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s85h.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s85h.Alignment.WrapText = True
            s85h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s85h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s85h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s85h.NumberFormat = "@"
            '-----------------------------------------------
            ' s85s
            '-----------------------------------------------
            Dim s85s As WorksheetStyle = styles.Add("s85s")
            s85s.Font.Strikethrough = True
            s85s.Font.FontName = "Arial"
            s85s.Font.Color = "#FF0000"
            s85s.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s85s.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s85s.Alignment.WrapText = True
            s85s.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s85s.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s85s.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s85s.NumberFormat = "@"

            '-----------------------------------------------
            ' s86
            '-----------------------------------------------
            Dim s86 As WorksheetStyle = styles.Add("s86")
            s86.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s86.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s86.Alignment.WrapText = True
            s86.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s86.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s86.NumberFormat = "@"
            '-----------------------------------------------
            ' s87
            '-----------------------------------------------
            Dim s87 As WorksheetStyle = styles.Add("s87")
            s87.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s87.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s87.Alignment.WrapText = True
            s87.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s87.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s87.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s87.NumberFormat = "@"
            '-----------------------------------------------
            ' s88
            '-----------------------------------------------
            Dim s88 As WorksheetStyle = styles.Add("s88")
            s88.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s88.Alignment.WrapText = True
            s88.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s88.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s88.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s88.NumberFormat = "@"
            '-----------------------------------------------
            ' s89
            '-----------------------------------------------
            Dim s89 As WorksheetStyle = styles.Add("s89")
            s89.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s89.Alignment.Indent = 1
            s89.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s89.Alignment.WrapText = True
            s89.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s89.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s89.NumberFormat = "@"
            '-----------------------------------------------
            ' s90
            '-----------------------------------------------
            Dim s90 As WorksheetStyle = styles.Add("s90")
            s90.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s90.Alignment.Indent = 2
            s90.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s90.Alignment.WrapText = True
            s90.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s90.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s90.NumberFormat = "@"
            '-----------------------------------------------
            ' s91
            '-----------------------------------------------
            Dim s91 As WorksheetStyle = styles.Add("s91")
            s91.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s91.Alignment.Indent = 2
            s91.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s91.Alignment.WrapText = True
            s91.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s91.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s91.NumberFormat = "@"
            '-----------------------------------------------
            ' s92
            '-----------------------------------------------
            Dim s92 As WorksheetStyle = styles.Add("s92")
            s92.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s92.Alignment.ShrinkToFit = True
            s92.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s92.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s92.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s92.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s92.NumberFormat = "@"
            '-----------------------------------------------
            ' s93
            '-----------------------------------------------
            Dim s93 As WorksheetStyle = styles.Add("s93")
            s93.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s93.Alignment.ShrinkToFit = True
            s93.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s93.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s93.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s93.NumberFormat = "@"
            '-----------------------------------------------
            ' s94
            '-----------------------------------------------
            Dim s94 As WorksheetStyle = styles.Add("s94")
            s94.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s94.Alignment.ShrinkToFit = True
            s94.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s94.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s94.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s94.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s94.NumberFormat = "@"
            '-----------------------------------------------
            ' s95
            '-----------------------------------------------
            Dim s95 As WorksheetStyle = styles.Add("s95")
            s95.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s95.Alignment.WrapText = True
            s95.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s95.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 2)
            s95.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            '-----------------------------------------------
            ' s96
            '-----------------------------------------------
            Dim s96 As WorksheetStyle = styles.Add("s96")
            s96.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s96.Alignment.WrapText = True
            s96.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s96.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 2)
            s96.NumberFormat = "@"
            '-----------------------------------------------
            ' s97
            '-----------------------------------------------
            Dim s97 As WorksheetStyle = styles.Add("s97")
            s97.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s97.Alignment.WrapText = True
            s97.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s97.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s97.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 2)
            s97.NumberFormat = "@"
            '-----------------------------------------------
            ' s98
            '-----------------------------------------------
            Dim s98 As WorksheetStyle = styles.Add("s98")
            s98.Font.FontName = "Helv"
            s98.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s98.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s98.Alignment.WrapText = True
            s98.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s98.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s98.NumberFormat = "@"
            '-----------------------------------------------
            ' s101
            '-----------------------------------------------
            Dim s101 As WorksheetStyle = styles.Add("s101")
            s101.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s101.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s101.Alignment.WrapText = True
            s101.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s101.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s101.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s101.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s101.NumberFormat = "@"
            '-----------------------------------------------
            ' s103
            '-----------------------------------------------
            Dim s103 As WorksheetStyle = styles.Add("s103")
            s103.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s103.Alignment.WrapText = True
            s103.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s103.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s103.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s103.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s103.NumberFormat = "@"
            '-----------------------------------------------
            ' s105
            '-----------------------------------------------
            Dim s105 As WorksheetStyle = styles.Add("s105")
            s105.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s105.Alignment.ShrinkToFit = True
            s105.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s105.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s105.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s105.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s105.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s105.NumberFormat = "@"
            '-----------------------------------------------
            ' s107
            '-----------------------------------------------
            Dim s107 As WorksheetStyle = styles.Add("s107")
            s107.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s107.Alignment.WrapText = True
            s107.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s107.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s107.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 2)
            s107.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s107.NumberFormat = "@"
            '-----------------------------------------------
            ' s108
            '-----------------------------------------------
            Dim s108 As WorksheetStyle = styles.Add("s108")
            s108.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s108.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s108.Alignment.WrapText = True
            s108.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s108.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s108.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s108.NumberFormat = "@"
            '-----------------------------------------------
            ' s109
            '-----------------------------------------------
            Dim s109 As WorksheetStyle = styles.Add("s109")
            s109.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s109.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s109.Alignment.WrapText = True
            s109.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s109.NumberFormat = "@"
            '-----------------------------------------------
            ' s110
            '-----------------------------------------------
            Dim s110 As WorksheetStyle = styles.Add("s110")
            s110.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s110.Alignment.WrapText = True
            s110.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s110.NumberFormat = "@"
            '-----------------------------------------------
            ' s111
            '-----------------------------------------------
            Dim s111 As WorksheetStyle = styles.Add("s111")
            s111.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s111.Alignment.ShrinkToFit = True
            s111.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s111.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s111.NumberFormat = "@"
            '-----------------------------------------------
            ' s112
            '-----------------------------------------------
            Dim s112 As WorksheetStyle = styles.Add("s112")
            s112.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s112.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s112.Alignment.WrapText = True
            s112.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s112.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s112.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s112.NumberFormat = "@"
            '-----------------------------------------------
            ' s113
            '-----------------------------------------------
            Dim s113 As WorksheetStyle = styles.Add("s113")
            s113.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s113.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s113.Alignment.WrapText = True
            s113.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s113.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s113.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s113.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s113.NumberFormat = "@"
            '-----------------------------------------------
            ' s114
            '-----------------------------------------------
            Dim s114 As WorksheetStyle = styles.Add("s114")
            s114.Font.Bold = True
            s114.Font.FontName = "Arial"
            s114.Interior.Color = "#99CCFF"
            s114.Interior.Pattern = StyleInteriorPattern.Solid
            s114.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s114.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s114.Alignment.WrapText = True
            s114.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s114.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s114.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s114.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s114.NumberFormat = "@"
            '-----------------------------------------------
            ' s115
            '-----------------------------------------------
            Dim s115 As WorksheetStyle = styles.Add("s115")
            s115.Interior.Color = "#99CCFF"
            s115.Interior.Pattern = StyleInteriorPattern.Solid
            s115.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s115.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s115.Alignment.WrapText = True
            s115.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s115.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s115.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s115.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s115.NumberFormat = "@"
            '-----------------------------------------------
            ' s116
            '-----------------------------------------------
            Dim s116 As WorksheetStyle = styles.Add("s116")
            s116.Interior.Color = "#99CCFF"
            s116.Interior.Pattern = StyleInteriorPattern.Solid
            s116.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s116.Alignment.WrapText = True
            s116.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s116.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s116.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s116.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s116.NumberFormat = "@"
            '-----------------------------------------------
            ' s117
            '-----------------------------------------------
            Dim s117 As WorksheetStyle = styles.Add("s117")
            s117.Interior.Color = "#99CCFF"
            s117.Interior.Pattern = StyleInteriorPattern.Solid
            s117.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s117.Alignment.ShrinkToFit = True
            s117.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s117.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s117.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s117.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s117.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s117.NumberFormat = "@"
            '-----------------------------------------------
            ' s118
            '-----------------------------------------------
            Dim s118 As WorksheetStyle = styles.Add("s118")
            s118.Interior.Color = "#99CCFF"
            s118.Interior.Pattern = StyleInteriorPattern.Solid
            s118.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s118.Alignment.WrapText = True
            s118.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s118.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s118.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s118.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s118.NumberFormat = "@"
            '-----------------------------------------------
            ' s118h
            '-----------------------------------------------
            Dim s118h As WorksheetStyle = styles.Add("s118h")
            s118h.Interior.Color = "#FFFF99"
            s118h.Interior.Pattern = StyleInteriorPattern.Solid
            s118h.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s118h.Alignment.WrapText = True
            s118h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s118h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s118h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s118h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s118h.NumberFormat = "@"
            '-----------------------------------------------
            ' s119
            '-----------------------------------------------
            Dim s119 As WorksheetStyle = styles.Add("s119")
            s119.Font.FontName = "Arial"
            '-----------------------------------------------
            ' s120
            '-----------------------------------------------
            Dim s120 As WorksheetStyle = styles.Add("s120")
            s120.Font.FontName = "Arial"
            s120.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s120.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s120.NumberFormat = "Short Date"
            '-----------------------------------------------
            ' s121
            '-----------------------------------------------
            Dim s121 As WorksheetStyle = styles.Add("s121")
            s121.Font.FontName = "Arial"
            s121.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s121.Alignment.Vertical = StyleVerticalAlignment.Bottom
            's121.NumberFormat = "@"
            '-----------------------------------------------
            ' s122
            '-----------------------------------------------
            Dim s122 As WorksheetStyle = styles.Add("s122")
            s122.Font.FontName = "Arial"
            s122.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s122.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s122.NumberFormat = "@"
            '-----------------------------------------------
            ' s123
            '-----------------------------------------------
            Dim s123 As WorksheetStyle = styles.Add("s123")
            s123.Font.FontName = "Arial"
            s123.Font.Color = "#FF0000"
            s123.Interior.Color = "#FFFF99"
            s123.Interior.Pattern = StyleInteriorPattern.Solid
            s123.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s123.Alignment.ShrinkToFit = True
            s123.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s123.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s123.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s123.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s123.NumberFormat = "@"
            '-----------------------------------------------
            ' s124
            '-----------------------------------------------
            Dim s124 As WorksheetStyle = styles.Add("s124")
            s124.Font.Strikethrough = True
            s124.Font.FontName = "Arial"
            s124.Font.Color = "#FF0000"
            '-----------------------------------------------
            ' s125
            '-----------------------------------------------
            Dim s125 As WorksheetStyle = styles.Add("s125")
            s125.Font.Strikethrough = True
            s125.Font.FontName = "Arial"
            s125.Font.Color = "#FF0000"
            s125.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s125.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s125.Alignment.WrapText = True
            s125.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s125.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s125.NumberFormat = "@"
            '-----------------------------------------------
            ' s126
            '-----------------------------------------------
            Dim s126 As WorksheetStyle = styles.Add("s126")
            s126.Font.Strikethrough = True
            s126.Font.FontName = "Arial"
            s126.Font.Color = "#FF0000"
            s126.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s126.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s126.Alignment.WrapText = True
            s126.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s126.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s126.NumberFormat = "@"
            '-----------------------------------------------
            ' s127
            '-----------------------------------------------
            Dim s127 As WorksheetStyle = styles.Add("s127")
            s127.Font.FontName = "Arial"
            s127.Font.Color = "#FF0000"
            s127.Interior.Color = "#FFFF99"
            s127.Interior.Pattern = StyleInteriorPattern.Solid
            s127.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s127.Alignment.Indent = 1
            s127.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s127.Alignment.WrapText = True
            s127.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s127.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s127.NumberFormat = "@"
            '-----------------------------------------------
            ' s128
            '-----------------------------------------------
            Dim s128 As WorksheetStyle = styles.Add("s128")
            s128.Font.FontName = "Arial"
            s128.Font.Color = "#FF0000"
            s128.Interior.Color = "#FFFF99"
            s128.Interior.Pattern = StyleInteriorPattern.Solid
            s128.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s128.Alignment.Indent = 2
            s128.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s128.Alignment.WrapText = True
            s128.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s128.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s128.NumberFormat = "@"
            '-----------------------------------------------
            ' s129
            '-----------------------------------------------
            Dim s129 As WorksheetStyle = styles.Add("s129")
            s129.Font.Strikethrough = True
            s129.Font.FontName = "Arial"
            s129.Font.Color = "#FF0000"
            s129.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s129.Alignment.Indent = 1
            s129.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s129.Alignment.WrapText = True
            s129.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s129.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s129.NumberFormat = "@"
            '-----------------------------------------------
            ' s130
            '-----------------------------------------------
            Dim s130 As WorksheetStyle = styles.Add("s130")
            s130.Font.FontName = "Arial"
            s130.Font.Color = "#FF0000"
            s130.Interior.Color = "#FFFF99"
            s130.Interior.Pattern = StyleInteriorPattern.Solid
            s130.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s130.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s130.Alignment.WrapText = True
            s130.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s130.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s130.NumberFormat = "@"
            '-----------------------------------------------
            ' s131
            '-----------------------------------------------
            Dim s131 As WorksheetStyle = styles.Add("s131")
            s131.Font.FontName = "Arial"
            s131.Font.Color = "#FF0000"
            s131.Interior.Color = "#FFFF99"
            s131.Interior.Pattern = StyleInteriorPattern.Solid
            s131.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s131.Alignment.ShrinkToFit = True
            s131.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s131.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s131.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s131.NumberFormat = "@"
            '-----------------------------------------------
            ' s132
            '-----------------------------------------------
            Dim s132 As WorksheetStyle = styles.Add("s132")
            s132.Font.Strikethrough = True
            s132.Font.FontName = "Arial"
            s132.Font.Color = "#FF0000"
            s132.Alignment.Horizontal = StyleHorizontalAlignment.Center
            s132.Alignment.ShrinkToFit = True
            s132.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s132.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s132.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s132.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s132.NumberFormat = "@"
            '-----------------------------------------------
            ' s133
            '-----------------------------------------------
            Dim s133 As WorksheetStyle = styles.Add("s133")
            s133.Font.FontName = "Arial"
            s133.Font.Color = "#FF0000"
            s133.Interior.Color = "#FFFF99"
            s133.Interior.Pattern = StyleInteriorPattern.Solid
            s133.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s133.Alignment.WrapText = True
            s133.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s133.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 2)
            s133.NumberFormat = "@"
            '-----------------------------------------------
            ' s134
            '-----------------------------------------------
            Dim s134 As WorksheetStyle = styles.Add("s134")
            s134.Font.Strikethrough = True
            s134.Font.FontName = "Arial"
            s134.Font.Color = "#FF0000"
            s134.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s134.Alignment.WrapText = True
            s134.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s134.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s134.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 2)
            s134.NumberFormat = "@"
            '-----------------------------------------------
            ' s140
            '-----------------------------------------------
            Dim s140 As WorksheetStyle = styles.Add("s140")
            s140.Font.FontName = "Helv"
            s140.Font.Color = "#FF0000"
            s140.Interior.Color = "#FFFF99"
            s140.Interior.Pattern = StyleInteriorPattern.Solid
            s140.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s140.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s140.Alignment.WrapText = True
            s140.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
            s140.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s140.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s140.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            's140.NumberFormat = "@"
            '-----------------------------------------------
            ' s141
            '-----------------------------------------------
            Dim s141 As WorksheetStyle = styles.Add("s141")
            s141.Font.FontName = "Arial"
            s141.Font.Color = "#FF0000"
            s141.Interior.Color = "#FFFF99"
            s141.Interior.Pattern = StyleInteriorPattern.Solid
            s141.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s141.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s141.Alignment.WrapText = True
            s141.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s141.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s141.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s141.NumberFormat = "@"
            '-----------------------------------------------
            ' s142
            '-----------------------------------------------
            Dim s142 As WorksheetStyle = styles.Add("s142")
            s142.Font.Strikethrough = True
            s142.Font.FontName = "Arial"
            s142.Font.Color = "#FF0000"
            s142.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s142.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s142.Alignment.WrapText = True
            s142.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s142.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s142.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s142.NumberFormat = "@"
            '-----------------------------------------------
            ' s143
            '-----------------------------------------------
            Dim s143 As WorksheetStyle = styles.Add("s143")
            s143.Font.Strikethrough = True
            s143.Font.FontName = "Arial"
            s143.Font.Color = "#FF0000"
            s143.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s143.Alignment.Indent = 2
            s143.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s143.Alignment.WrapText = True
            s143.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s143.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            s143.NumberFormat = "@"
            '-----------------------------------------------
            ' s200 - Normal
            '-----------------------------------------------
            Dim s200 As WorksheetStyle = styles.Add("s200")
            s200.Font.FontName = "Arial"
            s200.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s200.Alignment.Vertical = StyleVerticalAlignment.Top
            s200.Alignment.WrapText = True
            s200.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s200.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s200.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            's200.NumberFormat = ""
            '-----------------------------------------------
            ' s200h - Highlight
            '-----------------------------------------------
            Dim s200h As WorksheetStyle = styles.Add("s200h")
            s200h.Font.FontName = "Arial"
            s200h.Font.Color = "#FF0000"
            s200h.Interior.Color = "#FFFF99"
            s200h.Interior.Pattern = StyleInteriorPattern.Solid
            s200h.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s200h.Alignment.Vertical = StyleVerticalAlignment.Top
            s200h.Alignment.WrapText = True
            s200h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s200h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s200h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            's200h.NumberFormat = ""
            '-----------------------------------------------
            ' s200s - Strike
            '-----------------------------------------------
            Dim s200s As WorksheetStyle = styles.Add("s200s")
            s200s.Font.Strikethrough = True
            s200s.Font.FontName = "Arial"
            s200s.Font.Color = "#FF0000"
            's200s.Interior.Color = "#FFFF99"
            s200s.Interior.Pattern = StyleInteriorPattern.Solid
            s200s.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s200h.Alignment.Vertical = StyleVerticalAlignment.Top
            s200s.Alignment.WrapText = True
            s200s.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
            s200s.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
            s200s.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            's200s.NumberFormat = ""
            '-----------------------------------------------
            ' s201 - Normal
            '-----------------------------------------------
            Dim s201 As WorksheetStyle = styles.Add("s201")
            s201.Font.FontName = "Arial"
            s201.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s201.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s201.Alignment.WrapText = True
            s201.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s201.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            's201.NumberFormat = "@"
            '-----------------------------------------------
            ' s201h - Highlight
            '-----------------------------------------------
            Dim s201h As WorksheetStyle = styles.Add("s201h")
            s201h.Font.FontName = "Arial"
            s201h.Font.Color = "#FF0000"
            s201h.Interior.Color = "#FFFF99"
            s201h.Interior.Pattern = StyleInteriorPattern.Solid
            s201h.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s201h.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s201h.Alignment.WrapText = True
            s201h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s201h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            's201h.NumberFormat = "@"
            '-----------------------------------------------
            ' s201 - Strike
            '-----------------------------------------------
            Dim s201s As WorksheetStyle = styles.Add("s201s")
            s201s.Font.Strikethrough = True
            s201s.Font.FontName = "Arial"
            s201s.Font.Color = "#FF0000"
            's201s.Interior.Color = "#FFFF99"
            s201s.Interior.Pattern = StyleInteriorPattern.Solid
            s201s.Alignment.Horizontal = StyleHorizontalAlignment.Left
            s201s.Alignment.Vertical = StyleVerticalAlignment.Bottom
            s201s.Alignment.WrapText = True
            s201s.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 2)
            s201s.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
            's201s.NumberFormat = "@"



        End Sub
#End Region

#Region " Generate Change Log "
        Private Sub GenerateWorksheetChangeLog(ByVal sheets As WorksheetCollection, ByVal ProductBrandID As String)

            Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
            Dim dt As DataTable = dwExcalibur.ListScmNames("", ProductBrandID)
            Dim sFamily As String = dt.Rows(0)("Name").ToString.Trim()
            Dim sVersion As String = dt.Rows(0)("Version").ToString.Trim()
            Dim sSeries As String = dt.Rows(0)("SeriesName").ToString.Trim()
            Dim sKmat As String = dt.Rows(0)("KMAT").ToString.Trim()

            Dim saFileName(5) As String
            saFileName(0) = sFamily
            saFileName(1) = sVersion
            saFileName(2) = sSeries
            saFileName(3) = "Program Matrix"
            saFileName(4) = String.Format("{0}{1}{2}", Now.Year.ToString.Trim(), Now.Month.ToString.PadLeft(2, "0"), Now.Day.ToString.PadLeft(2, "0"))
            Dim sPMName As String = String.Format("{0} {1} {2}", saFileName)

            Dim sheet As Worksheet = sheets.Add("Change Log")
            sheet.Names.Add(New WorksheetNamedRange("Print_Area", "='Change Log'!R1C1:R121C4", False))
            sheet.Names.Add(New WorksheetNamedRange("Print_Titles", "='Change Log'!R1:R2", False))
            sheet.Table.FullColumns = 1
            sheet.Table.FullRows = 1
            Dim column0 As WorksheetColumn = sheet.Table.Columns.Add
            column0.Width = 42
            column0.StyleID = "s75"
            Dim column1 As WorksheetColumn = sheet.Table.Columns.Add
            column1.Width = 47
            column1.StyleID = "s76"
            Dim column2 As WorksheetColumn = sheet.Table.Columns.Add
            column2.Width = 19
            column2.StyleID = "s27"
            sheet.Table.Columns.Add(492)
            '-----------------------------------------------
            Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
            Dim cell As WorksheetCell
            cell = Row0.Cells.Add
            cell.StyleID = "s41"
            cell.Data.Type = DataType.String
            cell.Data.Text = "History of Program Matrix Changes:"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row0.Cells.Add
            cell.StyleID = "s42"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row0.Cells.Add
            cell.StyleID = "s43"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row0.Cells.Add
            cell.StyleID = "s44"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
            Row1.Height = 100
            cell = Row1.Cells.Add
            cell.StyleID = "s45"
            cell.Data.Type = DataType.String
            cell.Data.Text = " Date"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row1.Cells.Add
            cell.StyleID = "s46"
            cell.Data.Type = DataType.String
            cell.Data.Text = " Revision"
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row1.Cells.Add
            cell.StyleID = "s47"
            cell.Data.Type = DataType.String
            cell.Data.Text = sPMName
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            cell = Row1.Cells.Add
            cell.StyleID = "s48"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Description of Changes" & Microsoft.VisualBasic.ChrW(10) & "All changes to the matrix are highlighted."
            cell.NamedCell.Add("Print_Titles")
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------

            Dim WsRow As WorksheetRow

            dt = dwExcalibur.SelectAvHistory(ProductBrandID, String.Empty, String.Empty, "1")
            For Each Row As DataRow In dt.Rows
                If Row("pmpublish").ToString.Trim() = String.Empty Then
                    WsRow = sheet.Table.Rows.Add
                    cell = WsRow.Cells.Add
                    cell.StyleID = "s60"
                    cell.NamedCell.Add("Print_Area")
                    cell.Data.Text = FormatExcelDate(Row("last_upd_date").ToString.Trim())
                    cell.Data.Type = DataType.DateTime
                    cell = WsRow.Cells.Add
                    cell.StyleID = "s63"
                    cell.NamedCell.Add("Print_Area")
                    cell.Data.Text = FormatExcelDate(Now)
                    cell.Data.Type = DataType.DateTime
                    cell = WsRow.Cells.Add
                    cell.StyleID = "s64"
                    cell.NamedCell.Add("Print_Area")
                    cell.Data.Text = sVersion
                    cell = WsRow.Cells.Add
                    cell.StyleID = "s66"
                    cell.NamedCell.Add("Print_Area")
                    cell.Data.Text = Row("comments").ToString.Trim()
                Else
                    WsRow = sheet.Table.Rows.Add
                    cell = WsRow.Cells.Add
                    cell.StyleID = "s54"
                    cell.NamedCell.Add("Print_Area")
                    cell.Data.Text = FormatExcelDate(Row("last_upd_date").ToString.Trim())
                    cell.Data.Type = DataType.DateTime
                    cell = WsRow.Cells.Add
                    cell.StyleID = "s50"
                    cell.NamedCell.Add("Print_Area")
                    cell.Data.Text = FormatExcelDate(Row("pmpublish").ToString.Trim())
                    cell.Data.Type = DataType.DateTime
                    cell = WsRow.Cells.Add
                    cell.StyleID = "s58"
                    cell.NamedCell.Add("Print_Area")
                    cell.Data.Text = sVersion
                    cell = WsRow.Cells.Add
                    cell.StyleID = "s56"
                    cell.NamedCell.Add("Print_Area")
                    cell.Data.Text = Row("comments").ToString.Trim()
                End If
            Next

            If Publish Then
                dwExcalibur.SetPMPublish(ProductBrandID)
            End If

            '-----------------------------------------------
            Dim Row118 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row118.Cells.Add
            cell.StyleID = "s60"
            cell.NamedCell.Add("Print_Area")
            cell = Row118.Cells.Add
            cell.StyleID = "s63"
            cell.NamedCell.Add("Print_Area")
            cell = Row118.Cells.Add
            cell.StyleID = "s64"
            cell.NamedCell.Add("Print_Area")
            cell = Row118.Cells.Add
            cell.StyleID = "s66"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row119 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row119.Cells.Add
            cell.StyleID = "s68"
            cell.Data.Type = DataType.String
            cell.Data.Text = "**Please Note:  Changes on this page are manually transcribed.  Therefore, there is a possibility of human error.  "
            cell.NamedCell.Add("Print_Area")
            cell = Row119.Cells.Add
            cell.StyleID = "s69"
            cell.NamedCell.Add("Print_Area")
            cell = Row119.Cells.Add
            cell.StyleID = "s70"
            cell.NamedCell.Add("Print_Area")
            cell = Row119.Cells.Add
            cell.StyleID = "s71"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            Dim Row120 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row120.Cells.Add
            cell.StyleID = "s72"
            cell.Data.Type = DataType.String
            cell.Data.Text = "PLEASE review each individual tab for their changes, highlighted in yellow."
            cell.NamedCell.Add("Print_Area")
            cell = Row120.Cells.Add
            cell.StyleID = "s73"
            cell.NamedCell.Add("Print_Area")
            cell = Row120.Cells.Add
            cell.StyleID = "s74"
            cell.NamedCell.Add("Print_Area")
            cell = Row120.Cells.Add
            cell.StyleID = "s71"
            cell.NamedCell.Add("Print_Area")
            '-----------------------------------------------
            ' Options
            '-----------------------------------------------
            sheet.Options.FreezePanes = True
            sheet.Options.FitToPage = True
            sheet.Options.SplitHorizontal = 2
            sheet.Options.TopRowBottomPane = 2
            sheet.Options.ActivePane = 2
            sheet.Options.ProtectObjects = False
            sheet.Options.ProtectScenarios = False
            sheet.Options.PageSetup.Footer.Data = "&LHP Confidential&CPage &P&R&F" & Microsoft.VisualBasic.ChrW(10) & "&A"
            sheet.Options.PageSetup.PageMargins.Bottom = 0.5!
            sheet.Options.PageSetup.PageMargins.Left = 0.25!
            sheet.Options.PageSetup.PageMargins.Right = 0.25!
            sheet.Options.PageSetup.PageMargins.Top = 0.5!
            sheet.Options.Print.FitHeight = 100
            sheet.Options.Print.ValidPrinterInfo = True
        End Sub
#End Region

#Region " Generate Program Matrix "

#Region " Create PM Worksheet "
        Private Sub CreateProgramMatrixWorksheet(ByVal sheets As WorksheetCollection, ByVal ProductBrandID As String, ByVal dtPMData As DataTable)

            Dim dwExcalibur As HPQ.Excalibur.Data = New HPQ.Excalibur.Data()
            Dim dt As DataTable = dwExcalibur.ListScmNames("", ProductBrandID)
            Dim sFamily As String = dt.Rows(0)("Name").ToString.Trim()
            Dim sVersion As String = dt.Rows(0)("Version").ToString.Trim()
            If _PvCount > 1 Then
                sVersion = sVersion.Substring(0, sVersion.IndexOf(".")) & ".x"
            End If
            Dim sSeries As String = dt.Rows(0)("SeriesName").ToString.Trim()
            Dim sKmat As String = dt.Rows(0)("KMAT").ToString.Trim()
            Dim sProjectCode As String = dt.Rows(0)("ProjectCd").ToString.Trim()
            Dim sCMName As String = dt.Rows(0)("CoordinatorName").ToString.Trim()
            Dim sConfigCode As String = dt.Rows(0)("COnfigCd").ToString.Trim()
            Dim sBrand As String = dt.Rows(0)("Streetname").ToString.Trim()

            'Dim sLogo As String = dt.Rows(0)("Logo").ToString.Trim() 'Removed 12/12/2012 Malichi (TASK:105384)
            Dim sLogo As String = dt.Rows(0)("StreetName3").ToString.Trim()

            Dim bShowSeriesNumberInLogoBadge As Boolean = dt.Rows(0)("ShowSeriesNumberInLogoBadge")
            Dim bSplitSeriesForLogoAndBrand As Boolean = dt.Rows(0)("SplitSeriesForLogoAndBrand")

            If bShowSeriesNumberInLogoBadge Then
                If bSplitSeriesForLogoAndBrand Then
                    sLogo = sLogo & " " & Val(sSeries)
                Else
                    sLogo = sLogo & " " & sSeries
                End If
            End If

            Dim iPvCount As Integer = PvCount

            Dim iAvCount As Int32 = 0
            Dim sLastAvNo As String = String.Empty

            Dim dv As DataView = dtPMData.DefaultView
            dv.Sort = "avno"
            For Each row As DataRow In dv.Table.Rows
                If row("avno").ToString.Trim() <> String.Empty And row("avno").ToString.Trim() <> sLastAvNo Then
                    iAvCount += 1
                    sLastAvNo = row("avno").ToString.Trim()
                End If
            Next

            Dim saFileName(5) As String
            saFileName(0) = sFamily
            saFileName(1) = sVersion
            saFileName(2) = sSeries
            saFileName(3) = "Program Matrix"
            saFileName(4) = String.Format("{0}{1}{2}", Now.Year.ToString.Trim(), Now.Month.ToString.PadLeft(2, "0"), Now.Day.ToString.PadLeft(2, "0"))
            Dim sPMName As String
            If _PvCount > 1 Then
                sPMName = String.Format("{0} {1} {2}", saFileName(0), saFileName(1), saFileName(3))
            Else
                sPMName = String.Format("{0} {1} {2} {3}", saFileName)
            End If

            Dim sheet As Worksheet = sheets.Add("Program Matrix")
            sheet.Names.Add(New WorksheetNamedRange("Print_Titles", "='Program Matrix'!R1:R5", False))
            'sheet.Table.ExpandedColumnCount = 16
            'sheet.Table.ExpandedRowCount = 75
            sheet.Table.FullColumns = 1
            sheet.Table.FullRows = 1
            Dim ColA As WorksheetColumn = sheet.Table.Columns.Add
            ColA.Width = 213
            ColA.StyleID = "s25"

            '
            ' Product Version Columns
            '

            Dim ColB As WorksheetColumn = sheet.Table.Columns.Add
            ColB.Width = 24
            ColB.StyleID = "s26"
            If iPvCount > 1 Then
                ColB.Span = iPvCount - 1
            End If
            Dim ColC As WorksheetColumn = sheet.Table.Columns.Add
            ColC.Width = 278
            ColC.StyleID = "s24"
            Dim ColD As WorksheetColumn = sheet.Table.Columns.Add
            ColD.Width = 88
            ColD.StyleID = "s26"
            Dim ColE As WorksheetColumn = sheet.Table.Columns.Add
            ColE.Width = 77
            ColE.StyleID = "s26"
            Dim ColF As WorksheetColumn = sheet.Table.Columns.Add
            ColF.Width = 77
            ColF.StyleID = "s26"
            Dim ColG As WorksheetColumn = sheet.Table.Columns.Add
            ColG.Width = 77
            ColG.StyleID = "s26"
            Dim ColH As WorksheetColumn = sheet.Table.Columns.Add
            ColH.Width = 77
            ColH.StyleID = "s26"
            Dim ColI As WorksheetColumn = sheet.Table.Columns.Add
            ColI.Width = 24
            ColI.StyleID = "s26"
            Dim ColJ As WorksheetColumn = sheet.Table.Columns.Add
            ColJ.Width = 24
            ColJ.StyleID = "s28"
            Dim ColK As WorksheetColumn = sheet.Table.Columns.Add
            ColK.Width = 30
            ColK.StyleID = "s26"
            Dim ColL As WorksheetColumn = sheet.Table.Columns.Add
            ColL.Width = 24
            ColL.StyleID = "s26"
            Dim ColM As WorksheetColumn = sheet.Table.Columns.Add
            ColM.Width = 119
            ColM.StyleID = "s26"
            Dim ColN As WorksheetColumn = sheet.Table.Columns.Add
            ColN.Width = 24
            ColN.StyleID = "s26"
            Dim ColO As WorksheetColumn = sheet.Table.Columns.Add
            ColO.Width = 24
            ColO.StyleID = "s26"
            Dim ComP As WorksheetColumn = sheet.Table.Columns.Add
            ComP.Width = 24
            ComP.StyleID = "s26"
            Dim ColQ As WorksheetColumn = sheet.Table.Columns.Add
            ColQ.Width = 24
            ColQ.StyleID = "s26"
            Dim ColR As WorksheetColumn = sheet.Table.Columns.Add
            Dim ColS As WorksheetColumn = sheet.Table.Columns.Add
            Dim ColT As WorksheetColumn = sheet.Table.Columns.Add
            Dim ColU As WorksheetColumn = sheet.Table.Columns.Add
            Dim ColV As WorksheetColumn = sheet.Table.Columns.Add
            Dim ColW As WorksheetColumn = sheet.Table.Columns.Add
            Dim ColX As WorksheetColumn = sheet.Table.Columns.Add
            If (BSAM = True) Then
                ColR.Width = 24 'BSAM SKUS
                ColR.StyleID = "s26"
                ColS.Width = 24 'BSAM-B parts
                ColS.StyleID = "s26"
                ColT.Width = 255
                ColT.StyleID = "s24"
                ColU.Width = 81
                ColU.StyleID = "s24"
                ColV.Width = 81
                ColV.StyleID = "s24"
                ColW.Width = 81
                ColW.StyleID = "s24"
                ColX.Width = 81
                ColX.StyleID = "s24"
                Dim ColY As WorksheetColumn = sheet.Table.Columns.Add
                Dim ColZ As WorksheetColumn = sheet.Table.Columns.Add
                ColY.Width = 81
                ColY.StyleID = "s24"
                ColZ.Width = 81
                ColZ.StyleID = "s24"
            Else
                ColR.Width = 255
                ColR.StyleID = "s24"
                ColS.Width = 81
                ColS.StyleID = "s24"
                ColT.Width = 81
                ColT.StyleID = "s24"
                ColU.Width = 81
                ColU.StyleID = "s24"
                ColV.Width = 81
                ColV.StyleID = "s24"
                ColW.Width = 81
                ColW.StyleID = "s24"
                ColX.Width = 81
                ColX.StyleID = "s24"
            End If
            '-----------------------------------------------
            Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
            Row0.Height = 15
            Dim cell As WorksheetCell
            cell = Row0.Cells.Add
            cell.StyleID = "s36"
            cell.Comment.Author = " "
            cell.Comment.Data.Text = String.Format("Time: {0}, Generated by Excalibur", Now.ToString.Trim())
            cell.Data.Text = String.Format("Configuration Manager: {0}", sCMName)
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s36"
            cell.Data.Type = DataType.String
            cell.Data.Text = sPMName
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.Index = 9
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row0.Cells.Add
            cell.StyleID = "s23"
            cell.NamedCell.Add("Print_Titles")
            If (BSAM = True) Then
                cell = Row0.Cells.Add
                cell.StyleID = "s27"
                cell.NamedCell.Add("Print_Titles")
                cell = Row0.Cells.Add
                cell.StyleID = "s23"
                cell.NamedCell.Add("Print_Titles")
            End If
            '-----------------------------------------------
            Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
            Row1.Height = 15
            cell = Row1.Cells.Add
            cell.StyleID = "s36"
            cell.Data.Text = String.Format("KMAT Part Number: {0}", sKmat)
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s36"
            cell.Data.Type = DataType.String
            cell.Data.Text = String.Format("Brand: {0}", sBrand)
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.Index = 9
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row1.Cells.Add
            cell.StyleID = "s23"
            cell.NamedCell.Add("Print_Titles")
            If (BSAM = True) Then
                cell = Row1.Cells.Add
                cell.StyleID = "s27"
                cell.NamedCell.Add("Print_Titles")
                cell = Row1.Cells.Add
                cell.StyleID = "s23"
                cell.NamedCell.Add("Print_Titles")
            End If
            '-----------------------------------------------
            Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
            Row2.Height = 15
            cell = Row2.Cells.Add
            cell.StyleID = "s36"
            cell.Data.Type = DataType.String
            cell.Data.Text = String.Format("Project Code: {0}", sProjectCode)
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s36"
            cell.Data.Type = DataType.String
            cell.Data.Text = String.Format("Logo: {0}", sLogo)
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.Index = 9
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row2.Cells.Add
            cell.StyleID = "s23"
            cell.NamedCell.Add("Print_Titles")
            If (BSAM = True) Then
                cell = Row2.Cells.Add
                cell.StyleID = "s27"
                cell.NamedCell.Add("Print_Titles")
                cell = Row2.Cells.Add
                cell.StyleID = "s23"
                cell.NamedCell.Add("Print_Titles")
            End If
            '-----------------------------------------------
            Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
            Row3.Height = 15
            cell = Row3.Cells.Add
            cell.StyleID = "s36"
            cell.Data.Type = DataType.String
            cell.Data.Text = String.Format("Config Code: {0}", sConfigCode)
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s35"
            cell.Data.Type = DataType.String
            cell.Data.Text = String.Format("AV Count: {0}", iAvCount.ToString.Trim)
            cell.NamedCell.Add("Print_Titles")
            cell.Index = 4 + _PvCount - 1
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s27"
            cell.NamedCell.Add("Print_Titles")
            cell = Row3.Cells.Add
            cell.StyleID = "s23"
            cell.NamedCell.Add("Print_Titles")
            If (BSAM = True) Then
                cell = Row3.Cells.Add
                cell.StyleID = "s27"
                cell.NamedCell.Add("Print_Titles")
                cell = Row3.Cells.Add
                cell.StyleID = "s23"
                cell.NamedCell.Add("Print_Titles")
            End If
            '-----------------------------------------------
            Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
            Row4.Height = 75
            Row4.AutoFitHeight = False
            cell = Row4.Cells.Add
            cell.StyleID = "s29"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Category / Manufacturing Comments"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Product Version"
            cell.NamedCell.Add("Print_Titles")
            If PvCount > 1 Then
                cell.MergeAcross = PvCount - 1
            Else
                cell.MergeAcross = 0
            End If
            cell = Row4.Cells.Add
            cell.StyleID = "s31"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Description"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s32"
            cell.Data.Type = DataType.String
            cell.Data.Text = "AV" & Microsoft.VisualBasic.ChrW(10) & "Level 2"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s32"
            cell.Data.Type = DataType.String
            cell.Data.Text = "SA" & Microsoft.VisualBasic.ChrW(10) & "Level 3"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s32"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Component" & Microsoft.VisualBasic.ChrW(10) & "Level 4"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s32"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Component" & Microsoft.VisualBasic.ChrW(10) & "Level 5"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s32"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Component" & Microsoft.VisualBasic.ChrW(10) & "Level 6"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Quantity"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s33"
            cell.Data.Type = DataType.String
            cell.Data.Text = "SAP Rev."
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "ZWAR = X" & Microsoft.VisualBasic.ChrW(10) & "PRI / ALT"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "ROHS"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s32"
            cell.Data.Type = DataType.String
            cell.Data.Text = "UPC"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "IDS-SKUS"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "IDS-CTO"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "RCTO-SKUS"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s30"
            cell.Data.Type = DataType.String
            cell.Data.Text = "RCTO-CTO"
            cell.NamedCell.Add("Print_Titles")
            If (BSAM = True) Then
                cell = Row4.Cells.Add
                cell.StyleID = "s30"
                cell.Data.Type = DataType.String
                cell.Data.Text = "BSAM SKUS"
                cell.NamedCell.Add("Print_Titles")
                cell = Row4.Cells.Add
                cell.StyleID = "s30"
                cell.Data.Type = DataType.String
                cell.Data.Text = "BSAM" & Microsoft.VisualBasic.ChrW(10) & "-B parts"
                cell.NamedCell.Add("Print_Titles")
            End If
            cell = Row4.Cells.Add
            cell.StyleID = "s34"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Config Rules"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s34"
            cell.Data.Type = DataType.String
            cell.Data.Text = "AVID"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s34"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 1"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s34"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 2"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s34"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 3"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s34"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 4"
            cell.NamedCell.Add("Print_Titles")
            cell = Row4.Cells.Add
            cell.StyleID = "s34"
            cell.Data.Type = DataType.String
            cell.Data.Text = "Group 5"
            cell.NamedCell.Add("Print_Titles")

        End Sub
#End Region

#Region " Add New Category "
        Private Sub AddNewCategory(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow)
            Dim sheet As Worksheet = sheets("Program Matrix")
            Dim Row As WorksheetRow = sheet.Table.Rows.Add
            Dim cell As WorksheetCell
            Row.Cells.Add(dRow("FeatureCategory").ToString.Trim(), DataType.String, "s114")
            For i As Integer = 1 To PvCount
                cell = Row.Cells.Add
                cell.StyleID = "s115"
            Next i
            cell = Row.Cells.Add
            cell.StyleID = "s116"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            If (BSAM = True) Then
                cell = Row.Cells.Add
                cell.StyleID = "s115"
                cell = Row.Cells.Add
                cell.StyleID = "s115"
            End If
            If dRow("FeatureConfigRules").ToString.Trim() <> dRow("aFeatureConfigRules").ToString.Trim() And Not NewMatrix Then 'And Not IsDBNull(dRow("aFeatureConfigRules")) Then
                Row.Cells.Add(dRow("FeatureConfigRules").ToString.Trim(), DataType.String, "s118h")
                AddDetailedChangeLogRow(sheets, dRow, PartLevel.CATEGORY, ChangeType.Change, Columns.FeatureConfig)
            Else
                Row.Cells.Add(dRow("FeatureConfigRules").ToString.Trim(), DataType.String, "s118")
            End If
            'Row.Cells.Add(dRow("FeatureConfigRules").ToString.Trim(), DataType.String, "s118")
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            cell = Row.Cells.Add
            cell.StyleID = "s115"
            '-----------------------------------------------
            Row = sheet.Table.Rows.Add
            If dRow("ManufacturingNotes").ToString.Trim() <> dRow("aManufacturingNotes").ToString.Trim() And Not NewMatrix Then 'And Not IsDBNull(dRow("aManufacturingNotes").ToString.Trim()) Then
                Row.Cells.Add(dRow("ManufacturingNotes").ToString.Trim(), DataType.String, "s140")
                AddDetailedChangeLogRow(sheets, dRow, PartLevel.CATEGORY, ChangeType.Change, Columns.MfgNotes)
            Else
                Row.Cells.Add(dRow("ManufacturingNotes").ToString.Trim(), DataType.String, "s82")
            End If
            For i As Integer = 1 To PvCount
                cell = Row.Cells.Add
                cell.StyleID = "s101"
            Next
            cell = Row.Cells.Add
            cell.StyleID = "s103"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            If (BSAM = True) Then
                cell = Row.Cells.Add
                cell.StyleID = "s101"
                cell = Row.Cells.Add
                cell.StyleID = "s101"
            End If
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s101"
            cell = Row.Cells.Add
            cell.StyleID = "s105"
        End Sub
#End Region

#Region " Add Next AV "
        Private Sub AddNewAV(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow, ByVal dtVersions As DataTable)

            Dim foundRows() As DataRow = dtVersions.Select(String.Format("SortAvNo = '{0}'", dRow("sortAvNo")))
            DrawAvRow(sheets, dRow, foundRows)

        End Sub
#End Region

#Region " Add Next SA "
        Private Sub AddNextSA(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow)

            DrawSARow(sheets, dRow)

        End Sub
#End Region

#Region " Add Next Component "
        Private Sub AddNextComponent(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow)

            DrawCompRow(sheets, dRow)
            DrawCompL5Row(sheets, dRow)
            DrawCompL6Row(sheets, dRow)
        End Sub
#End Region

#Region " Draw AV Row "
        Sub DrawAvRow(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow, ByVal drVersions() As DataRow)
            Dim sheet As Worksheet = sheets("Program Matrix")
            Dim cell As WorksheetCell
            Dim sEmptyCellStyle As String = "s85"
            If dRow("avno").ToString.Trim <> String.Empty Then
                If dRow("aavno").ToString.Trim = String.Empty And Not NewMatrix Then
                    sEmptyCellStyle = "s85h"
                End If

                Dim Row As WorksheetRow = sheet.Table.Rows.Add
                Row.Cells.Add(dRow("AVManufacturingNotes").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "AVManufacturingNotes", sEmptyCellStyle))
                For Each vRow As DataRow In drVersions
                    Row.Cells.Add(vRow("Version").ToString.Trim, DataType.String, GetAVStyleID(sheets, vRow, "version", sEmptyCellStyle, dRow))
                Next
                Row.Cells.Add(dRow("GPGDescription").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "gpgdescription", sEmptyCellStyle))
                Row.Cells.Add(dRow("AvNo").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "avno", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                Row.Cells.Add(dRow("RevisionLevel").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "RevisionLevel", sEmptyCellStyle))
                Row.Cells.Add(dRow("ZWAR").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "ZWAR", sEmptyCellStyle))
                Row.Cells.Add(dRow("ROHS").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "ROHS", sEmptyCellStyle))
                Row.Cells.Add(dRow("upc").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "upc", sEmptyCellStyle))
                Row.Cells.Add(YN2X(dRow, "IDSSKUS"), DataType.String, GetAVStyleID(sheets, dRow, "IDSSKUS", sEmptyCellStyle))
                Row.Cells.Add(YN2X(dRow, "IDSCTO"), DataType.String, GetAVStyleID(sheets, dRow, "IDSCTO", sEmptyCellStyle))
                Row.Cells.Add(YN2X(dRow, "RCTOSKUS"), DataType.String, GetAVStyleID(sheets, dRow, "RCTOSKUS", sEmptyCellStyle))
                Row.Cells.Add(YN2X(dRow, "RCTOCTO"), DataType.String, GetAVStyleID(sheets, dRow, "RCTOCTO", sEmptyCellStyle))
                If (BSAM = True) Then
                    Row.Cells.Add(YN2X(dRow, "bsamskus"), DataType.String, GetAVStyleID(sheets, dRow, "bsamskus", sEmptyCellStyle))
                    Row.Cells.Add(YN2X(dRow, "bsambparts"), DataType.String, GetAVStyleID(sheets, dRow, "bsambparts", sEmptyCellStyle))
                End If
                Row.Cells.Add(dRow("ConfigRules").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "ConfigRules", sEmptyCellStyle))
                Row.Cells.Add(dRow("AvId").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "AvId", sEmptyCellStyle))
                Row.Cells.Add(dRow("Group1").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group1", sEmptyCellStyle))
                Row.Cells.Add(dRow("Group2").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group2", sEmptyCellStyle))
                Row.Cells.Add(dRow("Group3").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group3", sEmptyCellStyle))
                Row.Cells.Add(dRow("Group4").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group4", sEmptyCellStyle))
                Row.Cells.Add(dRow("Group5").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group5", sEmptyCellStyle))

                DrawSARow(sheets, dRow)

            ElseIf dRow("aavno").ToString.Trim <> String.Empty And Not NewMatrix Then

                Dim Row As WorksheetRow = _DeletedAvRows.Add()
                'Dim Row As WorksheetRow = sheet.Table.Rows.Add()
                Row.Cells.Add(dRow("aAVManufacturingNotes").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "AVManufacturingNotes", sEmptyCellStyle))
                For Each vRow As DataRow In drVersions
                    Row.Cells.Add(vRow("aVersion").ToString.Trim, DataType.String, GetAVStyleID(sheets, vRow, "version", sEmptyCellStyle, dRow))
                Next
                If drVersions.Length <> PvCount Then
                    For i As Integer = 1 To PvCount - drVersions.Length
                        cell = Row.Cells.Add
                        cell.StyleID = "s86"
                    Next i
                End If
                Row.Cells.Add(dRow("aGPGDescription").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "gpgdescription", sEmptyCellStyle))
                Row.Cells.Add(dRow("aAvNo").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "avno", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = "s85s"
                cell = Row.Cells.Add
                cell.StyleID = "s85s"
                cell = Row.Cells.Add
                cell.StyleID = "s85s"
                cell = Row.Cells.Add
                cell.StyleID = "s85s"
                Row.Cells.Add(dRow("aQuantity").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "quantity", sEmptyCellStyle))
                Row.Cells.Add(dRow("aRevisionLevel").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "RevisionLevel", sEmptyCellStyle))
                Row.Cells.Add(dRow("aZWAR").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "ZWAR", sEmptyCellStyle))
                Row.Cells.Add(dRow("aROHS").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "ROHS", sEmptyCellStyle))
                Row.Cells.Add(dRow("aupc").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "upc", sEmptyCellStyle))
                Row.Cells.Add(YN2X(dRow, "aIDSSKUS"), DataType.String, GetAVStyleID(sheets, dRow, "IDSSKUS", sEmptyCellStyle))
                Row.Cells.Add(YN2X(dRow, "aIDSCTO"), DataType.String, GetAVStyleID(sheets, dRow, "IDSCTO", sEmptyCellStyle))
                Row.Cells.Add(YN2X(dRow, "aRCTOSKUS"), DataType.String, GetAVStyleID(sheets, dRow, "RCTOSKUS", sEmptyCellStyle))
                Row.Cells.Add(YN2X(dRow, "aRCTOCTO"), DataType.String, GetAVStyleID(sheets, dRow, "RCTOCTO", sEmptyCellStyle))
                If (BSAM = True) Then
                    Row.Cells.Add(YN2X(dRow, "absamskus"), DataType.String, GetAVStyleID(sheets, dRow, "bsamskus", sEmptyCellStyle))
                    Row.Cells.Add(YN2X(dRow, "absambparts"), DataType.String, GetAVStyleID(sheets, dRow, "bsambparts", sEmptyCellStyle))
                End If
                Row.Cells.Add(dRow("aConfigRules").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "ConfigRules", sEmptyCellStyle))
                Row.Cells.Add(dRow("aAvId").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "AvId", sEmptyCellStyle))
                Row.Cells.Add(dRow("aGroup1").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group1", sEmptyCellStyle))
                Row.Cells.Add(dRow("aGroup2").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group2", sEmptyCellStyle))
                Row.Cells.Add(dRow("aGroup3").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group3", sEmptyCellStyle))
                Row.Cells.Add(dRow("aGroup4").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group4", sEmptyCellStyle))
                Row.Cells.Add(dRow("aGroup5").ToString.Trim, DataType.String, GetAVStyleID(sheets, dRow, "Group5", sEmptyCellStyle))
            End If
        End Sub
#End Region

#Region " Draw SA Row "
        Private Sub DrawSARow(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow)
            Dim sheet As Worksheet = sheets("Program Matrix")
            Dim cell As WorksheetCell
            Dim sEmptyCellStyle As String = "s86"
            If dRow("sano").ToString.Trim() <> String.Empty Then 'Draw Normal Row
                If dRow("asano").ToString.Trim() = String.Empty And Not NewMatrix Then
                    sEmptyCellStyle = "s130"
                End If

                Dim Row As WorksheetRow = sheet.Table.Rows.Add
                Row.Cells.Add("", DataType.String, "s84")
                For i As Integer = 1 To PvCount
                    Row.Cells.Add("", DataType.String, sEmptyCellStyle)
                Next i
                Row.Cells.Add(dRow("SAGPGDescription").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sagpgdescription", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                Row.Cells.Add(dRow("sano").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sano", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                Row.Cells.Add(dRow("saquantity").ToString.Trim, DataType.Number, GetSAStyleID(sheets, dRow, "saquantity", sEmptyCellStyle))
                Row.Cells.Add(dRow("sarevisionlevel").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sarevisionlevel", sEmptyCellStyle))
                Row.Cells.Add(dRow("sazwar").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sazwar", sEmptyCellStyle))
                Row.Cells.Add(dRow("sarohs").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sarohs", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                If (BSAM = True) Then
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                End If
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle

                DrawCompRow(sheets, dRow)
                DrawCompL5Row(sheets, dRow)
                DrawCompL6Row(sheets, dRow)

            ElseIf dRow("asano").ToString.Trim <> String.Empty And dRow("avno").ToString.Trim <> String.Empty And Not NewMatrix Then  'Draw Strike Through Row

                Dim Row As WorksheetRow = _DeletedSaRows.Add()
                'Dim Row As WorksheetRow = sheet.Table.Rows.Add()
                cell = Row.Cells.Add
                cell.StyleID = "s84"
                For i As Integer = 1 To PvCount
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                Next i
                Row.Cells.Add(dRow("aSAGPGDescription").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sagpgdescription", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                Row.Cells.Add(dRow("asano").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sano", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                Row.Cells.Add(dRow("asaquantity").ToString.Trim, DataType.Number, GetSAStyleID(sheets, dRow, "saquantity", sEmptyCellStyle))
                Row.Cells.Add(dRow("asarevisionlevel").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sarevisionlevel", sEmptyCellStyle))
                Row.Cells.Add(dRow("asazwar").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sazwar", sEmptyCellStyle))
                Row.Cells.Add(dRow("asarohs").ToString.Trim, DataType.String, GetSAStyleID(sheets, dRow, "sarohs", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                If (BSAM = True) Then
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                End If
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"

            End If
        End Sub
#End Region

#Region " Draw Comp Row "
        Private Sub DrawCompRow(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow)
            Dim sheet As Worksheet = sheets("Program Matrix")
            Dim cell As WorksheetCell
            Dim sEmptyCellStyle As String = "s86"
            If dRow("compno").ToString.Trim() <> String.Empty Then   'Draw Normal Row
                If dRow("acompno").ToString.Trim() = String.Empty And Not NewMatrix Then
                    sEmptyCellStyle = "s130"
                End If

                Dim Row As WorksheetRow = sheet.Table.Rows.Add
                cell = Row.Cells.Add
                cell.StyleID = "s84"
                For i As Integer = 1 To PvCount
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                Next i
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                cell.Data.Text = dRow("compgpgdescription").ToString.Trim
                cell.StyleID = GetCompStyleID(sheets, dRow, "compgpgdescription", sEmptyCellStyle)
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                Row.Cells.Add(dRow("compno").ToString.Trim, DataType.String, GetCompStyleID(sheets, dRow, "compno", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                Row.Cells.Add(dRow("compquantity").ToString.Trim, DataType.Number, GetCompStyleID(sheets, dRow, "compquantity", sEmptyCellStyle))
                Row.Cells.Add(dRow("comprevisionlevel").ToString.Trim, DataType.String, GetCompStyleID(sheets, dRow, "comprevisionlevel", sEmptyCellStyle))
                Row.Cells.Add(dRow("compzwar").ToString.Trim, DataType.String, GetCompStyleID(sheets, dRow, "compzwar", sEmptyCellStyle))
                Row.Cells.Add(dRow("comprohs").ToString.Trim, DataType.String, GetCompStyleID(sheets, dRow, "comprohs", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                If (BSAM = True) Then
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                End If
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
            ElseIf dRow("acompno").ToString.Trim <> String.Empty And dRow("sano").ToString.Trim <> String.Empty And Not NewMatrix Then   'Draw Strike Through Row
                Dim Row As WorksheetRow = _DeletedPartRows.Add()
                'Dim Row As WorksheetRow = sheet.Table.Rows.Add()
                cell = Row.Cells.Add
                cell.StyleID = "s84"
                For i As Integer = 1 To PvCount
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                Next i
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                cell.Data.Text = dRow("acompgpgdescription").ToString.Trim
                cell.StyleID = GetCompStyleID(sheets, dRow, "compgpgdescription", sEmptyCellStyle)
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                'cell.Data.Text = dRow("aavno").ToString.Trim
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                'cell.Data.Text = dRow("asano").ToString.Trim
                cell.StyleID = "s86"
                Row.Cells.Add(dRow("acompno").ToString.Trim, DataType.String, GetCompStyleID(sheets, dRow, "compno", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                Row.Cells.Add(dRow("acompquantity").ToString.Trim, DataType.Number, GetCompStyleID(sheets, dRow, "compquantity", sEmptyCellStyle))
                Row.Cells.Add(dRow("acomprevisionlevel").ToString.Trim, DataType.String, GetCompStyleID(sheets, dRow, "comprevisionlevel", sEmptyCellStyle))
                Row.Cells.Add(dRow("acompzwar").ToString.Trim, DataType.String, GetCompStyleID(sheets, dRow, "compzwar", sEmptyCellStyle))
                Row.Cells.Add(dRow("acomprohs").ToString.Trim, DataType.String, GetCompStyleID(sheets, dRow, "comprohs", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                If (BSAM = True) Then
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                End If
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
            End If
        End Sub
        Private Sub DrawCompL5Row(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow)
            Dim sheet As Worksheet = sheets("Program Matrix")
            Dim cell As WorksheetCell
            Dim sEmptyCellStyle As String = "s86"
            If dRow("compno_L5").ToString.Trim() <> String.Empty Then   'Draw Normal Row
                If dRow("acompno_L5").ToString.Trim() = String.Empty And Not NewMatrix Then
                    sEmptyCellStyle = "s130"
                End If

                Dim Row As WorksheetRow = sheet.Table.Rows.Add
                cell = Row.Cells.Add
                cell.StyleID = "s84"
                For i As Integer = 1 To PvCount
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                Next i
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                cell.Data.Text = dRow("compgpgdescription_L5").ToString.Trim
                cell.StyleID = GetCompL5StyleID(sheets, dRow, "compgpgdescription_L5", sEmptyCellStyle)
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                Row.Cells.Add(dRow("compno_L5").ToString.Trim, DataType.String, GetCompL5StyleID(sheets, dRow, "compno_L5", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                Row.Cells.Add(dRow("compquantity_L5").ToString.Trim, DataType.Number, GetCompL5StyleID(sheets, dRow, "compquantity_L5", sEmptyCellStyle))
                Row.Cells.Add(dRow("comprevisionlevel_L5").ToString.Trim, DataType.String, GetCompL5StyleID(sheets, dRow, "comprevisionlevel_L5", sEmptyCellStyle))
                Row.Cells.Add(dRow("compzwar_L5").ToString.Trim, DataType.String, GetCompL5StyleID(sheets, dRow, "compzwar_L5", sEmptyCellStyle))
                Row.Cells.Add(dRow("comprohs_L5").ToString.Trim, DataType.String, GetCompL5StyleID(sheets, dRow, "comprohs_L5", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                If (BSAM = True) Then
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                End If
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
            ElseIf dRow("acompno_L5").ToString.Trim <> String.Empty And dRow("sano").ToString.Trim <> String.Empty And Not NewMatrix Then   'Draw Strike Through Row
                Dim Row As WorksheetRow = _DeletedPartRows.Add()
                'Dim Row As WorksheetRow = sheet.Table.Rows.Add()
                cell = Row.Cells.Add
                cell.StyleID = "s84"
                For i As Integer = 1 To PvCount
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                Next i
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                cell.Data.Text = dRow("acompgpgdescription_L5").ToString.Trim
                cell.StyleID = GetCompL5StyleID(sheets, dRow, "compgpgdescription_L5", sEmptyCellStyle)
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                'cell.Data.Text = dRow("aavno").ToString.Trim
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                'cell.Data.Text = dRow("asano").ToString.Trim
                cell.StyleID = "s86"
                Row.Cells.Add(dRow("acompno_L5").ToString.Trim, DataType.String, GetCompL5StyleID(sheets, dRow, "compno_L5", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                Row.Cells.Add(dRow("acompquantity_L5").ToString.Trim, DataType.Number, GetCompL5StyleID(sheets, dRow, "compquantity_L5", sEmptyCellStyle))
                Row.Cells.Add(dRow("acomprevisionlevel_L5").ToString.Trim, DataType.String, GetCompL5StyleID(sheets, dRow, "comprevisionlevel_L5", sEmptyCellStyle))
                Row.Cells.Add(dRow("acompzwar_L5").ToString.Trim, DataType.String, GetCompL5StyleID(sheets, dRow, "compzwar_L5", sEmptyCellStyle))
                Row.Cells.Add(dRow("acomprohs_L5").ToString.Trim, DataType.String, GetCompL5StyleID(sheets, dRow, "comprohs_L5", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                If (BSAM = True) Then
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                End If
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
            End If
        End Sub
        Private Sub DrawCompL6Row(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow)
            Dim sheet As Worksheet = sheets("Program Matrix")
            Dim cell As WorksheetCell
            Dim sEmptyCellStyle As String = "s86"
            If dRow("compno_L6").ToString.Trim() <> String.Empty Then   'Draw Normal Row
                If dRow("acompno_L6").ToString.Trim() = String.Empty And Not NewMatrix Then
                    sEmptyCellStyle = "s130"
                End If

                Dim Row As WorksheetRow = sheet.Table.Rows.Add
                cell = Row.Cells.Add
                cell.StyleID = "s84"
                For i As Integer = 1 To PvCount
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                Next i
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                cell.Data.Text = dRow("compgpgdescription_L6").ToString.Trim
                cell.StyleID = GetCompL6StyleID(sheets, dRow, "compgpgdescription_L6", sEmptyCellStyle)
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                Row.Cells.Add(dRow("compno_L6").ToString.Trim, DataType.String, GetCompL6StyleID(sheets, dRow, "compno_L6", sEmptyCellStyle))
                Row.Cells.Add(dRow("compquantity_L6").ToString.Trim, DataType.Number, GetCompL6StyleID(sheets, dRow, "compquantity_L6", sEmptyCellStyle))
                Row.Cells.Add(dRow("comprevisionlevel_L6").ToString.Trim, DataType.String, GetCompL6StyleID(sheets, dRow, "comprevisionlevel_L6", sEmptyCellStyle))
                Row.Cells.Add(dRow("compzwar_L6").ToString.Trim, DataType.String, GetCompL6StyleID(sheets, dRow, "compzwar_L6", sEmptyCellStyle))
                Row.Cells.Add(dRow("comprohs_L6").ToString.Trim, DataType.String, GetCompL6StyleID(sheets, dRow, "comprohs_L6", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                If (BSAM = True) Then
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                    cell = Row.Cells.Add
                    cell.StyleID = sEmptyCellStyle
                End If
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
                cell = Row.Cells.Add
                cell.StyleID = sEmptyCellStyle
            ElseIf dRow("acompno_L6").ToString.Trim <> String.Empty And dRow("sano").ToString.Trim <> String.Empty And Not NewMatrix Then   'Draw Strike Through Row
                Dim Row As WorksheetRow = _DeletedPartRows.Add()
                'Dim Row As WorksheetRow = sheet.Table.Rows.Add()
                cell = Row.Cells.Add
                cell.StyleID = "s84"
                For i As Integer = 1 To PvCount
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                Next i
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                cell.Data.Text = dRow("acompgpgdescription_L6").ToString.Trim
                cell.StyleID = GetCompL6StyleID(sheets, dRow, "compgpgdescription_L6", sEmptyCellStyle)
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String

                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.Data.Type = DataType.String
                cell = Row.Cells.Add
                cell.StyleID = "s86"

                cell = Row.Cells.Add
                cell.StyleID = "s86"
                Row.Cells.Add(dRow("acompno_L6").ToString.Trim, DataType.String, GetCompL6StyleID(sheets, dRow, "compno_L6", sEmptyCellStyle))
                Row.Cells.Add(dRow("acompquantity_L6").ToString.Trim, DataType.Number, GetCompL6StyleID(sheets, dRow, "compquantity_L6", sEmptyCellStyle))
                Row.Cells.Add(dRow("acomprevisionlevel_L6").ToString.Trim, DataType.String, GetCompL6StyleID(sheets, dRow, "comprevisionlevel_L6", sEmptyCellStyle))
                Row.Cells.Add(dRow("acompzwar_L6").ToString.Trim, DataType.String, GetCompL6StyleID(sheets, dRow, "compzwar_L6", sEmptyCellStyle))
                Row.Cells.Add(dRow("acomprohs_L6").ToString.Trim, DataType.String, GetCompL6StyleID(sheets, dRow, "comprohs_L6", sEmptyCellStyle))
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                If (BSAM = True) Then
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                    cell = Row.Cells.Add
                    cell.StyleID = "s86"
                End If
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
                cell = Row.Cells.Add
                cell.StyleID = "s86"
            End If
        End Sub
#End Region

#Region " Close Category "
        Private Sub CloseCategory(ByVal sheets As WorksheetCollection)
            Dim sheet As Worksheet = sheets("Program Matrix")
            Dim cell As WorksheetCell
            Dim Row14 As WorksheetRow = sheet.Table.Rows.Add
            cell = Row14.Cells.Add
            cell.StyleID = "s113"
            For i As Integer = 1 To PvCount
                cell = Row14.Cells.Add
                cell.StyleID = "s77"
            Next i
            cell = Row14.Cells.Add
            cell.StyleID = "s78"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s79"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            If (BSAM = True) Then
                cell = Row14.Cells.Add
                cell.StyleID = "s77"
                cell = Row14.Cells.Add
                cell.StyleID = "s77"
            End If
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s77"
            cell = Row14.Cells.Add
            cell.StyleID = "s105"

        End Sub
#End Region

#Region " Close PM Worksheet "
        Private Sub CloseProgramMatrixWorksheet(ByVal sheets As WorksheetCollection)
            Dim sheet As Worksheet = sheets("Program Matrix")
            '-----------------------------------------------
            ' Options
            '-----------------------------------------------
            sheet.Options.Selected = True
            sheet.Options.FreezePanes = True
            sheet.Options.FitToPage = True
            sheet.Options.SplitHorizontal = 5
            sheet.Options.TopRowBottomPane = 5
            sheet.Options.ActivePane = 2
            sheet.Options.ProtectObjects = False
            sheet.Options.ProtectScenarios = False
            sheet.Options.PageSetup.Layout.Orientation = Orientation.Landscape
            sheet.Options.PageSetup.Layout.CenterHorizontal = True
            sheet.Options.PageSetup.Footer.Data = "&LHP Confidential&CPage &P of &N&R&F" & Microsoft.VisualBasic.ChrW(10) & "&A"
            sheet.Options.PageSetup.Footer.Margin = 0.25!
            sheet.Options.PageSetup.PageMargins.Bottom = 0.5!
            sheet.Options.PageSetup.PageMargins.Left = 0.25!
            sheet.Options.PageSetup.PageMargins.Right = 0.25!
            sheet.Options.PageSetup.PageMargins.Top = 0.5!
            sheet.Options.Print.FitHeight = 100
            sheet.Options.Print.ValidPrinterInfo = True

        End Sub
#End Region

#Region " Add Deleted Rows "
        Sub AddDeletedRows(ByVal Sheets As WorksheetCollection, ByRef Rows As WorksheetRowCollection)
            Dim sheet As Worksheet = Sheets("Program Matrix")
            For Each row As WorksheetRow In Rows
                sheet.Table.Rows.Add(row)
            Next
            Rows.Clear()
        End Sub

#End Region

#End Region

#Region " Generate Detailed Change Log "

#Region " Open Detailed Change Log Worksheet "
        Private Sub OpenDetailedChangeLog(ByVal sheets As WorksheetCollection, ByVal ProductBrandID As String)
            Dim sheet As Worksheet = sheets.Add("Detailed Change Log")
            sheet.Table.FullColumns = 1
            sheet.Table.FullRows = 1
            Dim ColA As WorksheetColumn = sheet.Table.Columns.Add
            ColA.Width = 67
            Dim ColB As WorksheetColumn = sheet.Table.Columns.Add
            ColB.Width = 88
            sheet.Table.Columns.Add(135)
            Dim ColC As WorksheetColumn = sheet.Table.Columns.Add
            ColC.Width = 167
            Dim ColD As WorksheetColumn = sheet.Table.Columns.Add
            ColD.Width = 266
            '-----------------------------------------------
            Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
            Row0.Cells.Add(String.Format("UPDATES SINCE PREVIOUS PUBLISH ON {0}", CompareDt), DataType.String, "s39")
            '-----------------------------------------------
            Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
            Row1.Index = 3
            Row1.Cells.Add("Date", DataType.String, "s40")
            Row1.Cells.Add("Part#", DataType.String, "s40")
            Row1.Cells.Add("Change", DataType.String, "s40")
            Row1.Cells.Add("Detail", DataType.String, "s40")
        End Sub
#End Region

#Region " Add Detailed Change Log Row "

#Region " Supporting Functions"
        Private Function GetColumnEnum(ByVal ColumnName As String) As Columns
            Select Case ColumnName.ToLower
                Case "version"
                    Return Columns.Version
                Case "gpgdescription"
                    Return Columns.Description
                Case "avno"
                    Return Columns.PartNumber
                Case "quantity"
                    Return Columns.Quantity
                Case "revisionlevel"
                    Return Columns.Revision
                Case "zwar"
                    Return Columns.Zwar
                Case "rohs"
                    Return Columns.ROHS
                Case "upc"
                    Return Columns.UPC
                Case "idsskus"
                    Return Columns.IDSSKUS
                Case "idscto"
                    Return Columns.IDSCTO
                Case "rctoskus"
                    Return Columns.RCTOSKUS
                Case "rctocto"
                    Return Columns.RCTOCTO
                Case "configrules"
                    Return Columns.Configuration
                Case "sagpgdescription"
                    Return Columns.Description
                Case "sano"
                    Return Columns.PartNumber
                Case "saquantity"
                    Return Columns.Quantity
                Case "sarevisionlevel"
                    Return Columns.Revision
                Case "sazwar"
                    Return Columns.Zwar
                Case "sarohs"
                    Return Columns.ROHS
                Case "compgpgdescription"
                    Return Columns.Description
                Case "compno"
                    Return Columns.PartNumber
                Case "compquantity"
                    Return Columns.Quantity
                Case "comprevisionlevel"
                    Return Columns.Revision
                Case "comprohs"
                    Return Columns.ROHS
                Case "avmanufacturingnotes"
                    Return Columns.MfgNotes
                Case "group1"
                    Return Columns.Group1
                Case "group2"
                    Return Columns.Group2
                Case "group3"
                    Return Columns.Group3
                Case "group4"
                    Return Columns.Group4
                Case "group5"
                    Return Columns.Group5
                Case "avid"
                    Return Columns.AvId
            End Select
            Return Nothing


        End Function

        Private Enum PartLevel As Integer
            AV = 1
            SA = 2
            COMPONENT = 3
            COMP_L5 = 4
            COMP_L6 = 5
            CATEGORY = 6
            MFG_NOTE = 7
        End Enum

        Private Enum ChangeType As Integer
            Add = 1
            Change = 2
            Remove = 3
        End Enum

        Private Enum Columns As Integer
            DontLog
            Description
            Revision
            Quantity
            ROHS
            UPC
            IDSSKUS
            IDSCTO
            RCTOSKUS
            RCTOCTO
            Configuration
            Zwar
            MfgNotes
            PartNumber
            Version
            FeatureConfig
            Group1
            Group2
            Group3
            Group4
            Group5
            AvId
        End Enum
#End Region

        Private Sub AddDetailedChangeLogRow(ByVal sheets As WorksheetCollection, ByVal dRow As DataRow,
            ByVal Level As PartLevel, ByVal Change As ChangeType, ByVal ColumnChanged As Columns, Optional ByVal avRow As DataRow = Nothing)

            If ColumnChanged = Columns.DontLog Then
                Exit Sub
            End If

            Dim sReportName As String = String.Empty
            Dim sColumnName As String = String.Empty
            Select Case ColumnChanged
                Case Columns.Configuration
                    sReportName = "Config Rules"
                    sColumnName = "ConfigRules"
                Case Columns.Description
                    sReportName = "GPG Description"
                    Select Case Level
                        Case PartLevel.AV
                            sColumnName = "GPGDEscription"
                        Case PartLevel.SA
                            sColumnName = "SAGPGDescription"
                        Case PartLevel.COMPONENT
                            sColumnName = "CompGPGDescription"
                        Case PartLevel.COMP_L5
                            sColumnName = "CompGPGDescription_L5"
                        Case PartLevel.COMP_L6
                            sColumnName = "CompGPGDescription_L6"
                    End Select
                Case Columns.IDSCTO
                    sReportName = "IDS-CTO"
                    sColumnName = "IDSCTO"
                Case Columns.IDSSKUS
                    sReportName = "IDS-SKUS"
                    sColumnName = "IDSSKUS"
                Case Columns.Quantity
                    sReportName = "Quantity"
                    Select Case Level
                        Case PartLevel.AV
                            sColumnName = "Quantity"
                        Case PartLevel.SA
                            sColumnName = "SAQuantity"
                        Case PartLevel.COMPONENT
                            sColumnName = "CompQuantity"
                        Case PartLevel.COMP_L5
                            sColumnName = "CompQuantity_L5"
                        Case PartLevel.COMP_L6
                            sColumnName = "CompQuantity_L6"
                    End Select
                Case Columns.RCTOCTO
                    sReportName = "RCTO-CTO"
                    sColumnName = "RCTOCTO"
                Case Columns.RCTOSKUS
                    sReportName = "RCTO-SKUS"
                    sColumnName = "RCTOSKUS"
                Case Columns.Revision
                    sReportName = "SAP Revision"
                    Select Case Level
                        Case PartLevel.AV
                            sColumnName = "RevisionLevel"
                        Case PartLevel.SA
                            sColumnName = "SARevisionLevel"
                        Case PartLevel.COMPONENT
                            sColumnName = "CompRevisionLevel"
                        Case PartLevel.COMP_L5
                            sColumnName = "CompRevisionLevel_L5"
                        Case PartLevel.COMP_L6
                            sColumnName = "CompRevisionLevel_L6"
                    End Select
                Case Columns.ROHS
                    sReportName = "ROHS"
                    Select Case Level
                        Case PartLevel.AV
                            sColumnName = "ROHS"
                        Case PartLevel.SA
                            sColumnName = "SAROHS"
                        Case PartLevel.COMPONENT
                            sColumnName = "CompROHS"
                        Case PartLevel.COMP_L5
                            sColumnName = "CompROHS_L5"
                        Case PartLevel.COMP_L6
                            sColumnName = "CompROHS_L6"
                    End Select
                Case Columns.UPC
                    sReportName = "UPC"
                    sColumnName = "UPC"
                Case Columns.Zwar
                    sReportName = "ZWAR"
                    Select Case Level
                        Case PartLevel.AV
                            sColumnName = "ZWAR"
                        Case PartLevel.SA
                            sColumnName = "SAZWAR"
                        Case Else
                            sColumnName = "ZWAR"
                    End Select
                Case Columns.PartNumber
                    sReportName = "Part Number"
                    Select Case Level
                        Case PartLevel.AV
                            sColumnName = "avno"
                        Case PartLevel.SA
                            sColumnName = "sano"
                        Case PartLevel.COMPONENT
                            sColumnName = "compno"
                        Case PartLevel.COMP_L5
                            sColumnName = "compno_L5"
                        Case PartLevel.COMP_L6
                            sColumnName = "compno_L6"
                    End Select
                Case Columns.MfgNotes
                    Select Case Level
                        Case PartLevel.CATEGORY
                            sReportName = "Manufacturing Notes"
                            sColumnName = "ManufacturingNotes"
                        Case PartLevel.AV
                            sReportName = "Manufacturing Notes"
                            sColumnName = "AVManufacturingNotes"
                    End Select
                Case Columns.Version
                    sReportName = "Version"
                    sColumnName = "Version"
                Case Columns.FeatureConfig
                    sReportName = "Config Rules"
                    sColumnName = "FeatureConfigRules"
                Case Columns.Group1
                    sReportName = "Group1"
                    sColumnName = "Group1"
                Case Columns.Group2
                    sReportName = "Group2"
                    sColumnName = "Group2"
                Case Columns.Group3
                    sReportName = "Group3"
                    sColumnName = "Group3"
                Case Columns.Group4
                    sReportName = "Group4"
                    sColumnName = "Group4"
                Case Columns.Group5
                    sReportName = "Group5"
                    sColumnName = "Group5"
                Case Columns.AvId
                    sReportName = "AvId"
                    sColumnName = "AvId"
            End Select
            Dim sheet As Worksheet = sheets("Detailed Change Log")

            If (Change <> ChangeType.Change) And Not ((ColumnChanged = Columns.Version And Level = PartLevel.AV) Or
                                                (ColumnChanged = Columns.Description And Level <> PartLevel.AV)) Then
                Exit Sub
            End If

            Dim Row As WorksheetRow = sheet.Table.Rows.Add
            Row.Cells.Add(FormatExcelDate(DateTime.Now()), DataType.DateTime, "s120")
            Select Case Level
                Case PartLevel.AV
                    Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                    Select Case Change
                        Case ChangeType.Add
                            If ColumnChanged = Columns.Version Then
                                Row.Cells.Add(String.Format("Add AV to Version {0}", dRow(sColumnName).ToString.Trim()), DataType.String, "s121")
                                Row.Cells.Add(avRow("GPGDescription").ToString.Trim(), DataType.String, "s121")
                            Else
                                'Row.Cells.Add("Add AV", DataType.String, "s121")
                                'Row.Cells.Add(dRow(sColumnName).ToString.Trim(), DataType.String, "s121")
                            End If
                        Case ChangeType.Change
                            Row.Cells.Add(String.Format("Change AV {0}", sReportName), DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} <= {1}", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim()), DataType.String, "s121")
                        Case ChangeType.Remove
                            If ColumnChanged = Columns.Version Then
                                Row.Cells.Add(String.Format("Delete AV from Version {0}", dRow(sColumnName).ToString.Trim()), DataType.String, "s121")
                                If avRow("GPGDescription").ToString.Trim = String.Empty Then
                                    Row.Cells.Add(String.Format("{0} ({1})", avRow("aGPGDescription").ToString.Trim(), dRow("sortavno").ToString.Trim()), DataType.String, "s121")
                                Else
                                    Row.Cells.Add(String.Format("{0} ({1})", avRow("GPGDescription").ToString.Trim(), dRow("sortavno").ToString.Trim()), DataType.String, "s121")
                                End If
                                'Row.Cells.Add("", DataType.String, "s121")
                            Else
                                Row.Cells.Add("Delete AV", DataType.String, "s121")
                                Row.Cells.Add(String.Format("{0} ({1})", dRow("a" & sColumnName).ToString.Trim(), dRow("sortavno").ToString.Trim()), DataType.String, "s121")
                            End If
                    End Select
                Case PartLevel.SA
                    Select Case Change
                        Case ChangeType.Add
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortsano").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add("Add SA", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow(sColumnName).ToString.Trim(), dRow("sortsano").ToString.Trim()), DataType.String, "s121")
                        Case ChangeType.Change
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortsano").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add(String.Format("Change SA {0}", sReportName), DataType.String, "s121")
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(String.Format("{0} <= {1} ({2})", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim(), dRow("sortsano").ToString.Trim()), DataType.String, "s121")
                            Else
                                Row.Cells.Add(String.Format("{0} <= {1}", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim()), DataType.String, "s121")
                            End If
                        Case ChangeType.Remove
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortsano").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add("Delete SA", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow("a" & sColumnName).ToString.Trim(), dRow("sortsano").ToString.Trim()), DataType.String, "s121")
                    End Select
                Case PartLevel.COMPONENT
                    Select Case Change
                        Case ChangeType.Add
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortcompno").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add("Add Component", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow(sColumnName).ToString.Trim(), dRow("sortcompno").ToString.Trim()), DataType.String, "s121")
                        Case ChangeType.Change
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortcompno").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add(String.Format("Change Component {0}", sReportName), DataType.String, "s121")
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(String.Format("{0} <= {1} ({2})", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim(), dRow("sortcompno").ToString.Trim()), DataType.String, "s121")
                            Else
                                Row.Cells.Add(String.Format("{0} <= {1}", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim()), DataType.String, "s121")
                            End If
                        Case ChangeType.Remove
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortcompno").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add("Delete Component", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow("a" & sColumnName).ToString.Trim(), dRow("sortcompno").ToString.Trim()), DataType.String, "s121")
                    End Select
                Case PartLevel.COMP_L5
                    Select Case Change
                        Case ChangeType.Add
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortcompno_L5").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add("Add Component L5", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow(sColumnName).ToString.Trim(), dRow("sortcompno_L5").ToString.Trim()), DataType.String, "s121")
                        Case ChangeType.Change
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortcompno_L5").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add(String.Format("Change Component {0}", sReportName), DataType.String, "s121")
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(String.Format("{0} <= {1} ({2})", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim(), dRow("sortcompno_L5").ToString.Trim()), DataType.String, "s121")
                            Else
                                Row.Cells.Add(String.Format("{0} <= {1}", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim()), DataType.String, "s121")
                            End If
                        Case ChangeType.Remove
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortcompno_L5").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add("Delete Component L5", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow("a" & sColumnName).ToString.Trim(), dRow("sortcompno_L5").ToString.Trim()), DataType.String, "s121")
                    End Select
                Case PartLevel.COMP_L6
                    Select Case Change
                        Case ChangeType.Add
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortcompno_L6").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add("Add Component L6", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow(sColumnName).ToString.Trim(), dRow("sortcompno_L6").ToString.Trim()), DataType.String, "s121")
                        Case ChangeType.Change
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortcompno_L6").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add(String.Format("Change Component {0}", sReportName), DataType.String, "s121")
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(String.Format("{0} <= {1} ({2})", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim(), dRow("sortcompno_L6").ToString.Trim()), DataType.String, "s121")
                            Else
                                Row.Cells.Add(String.Format("{0} <= {1}", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim()), DataType.String, "s121")
                            End If
                        Case ChangeType.Remove
                            If ColumnChanged <> Columns.Revision Then
                                Row.Cells.Add(dRow("sortavno").ToString.Trim(), DataType.String, "s121")
                            Else
                                Row.Cells.Add(dRow("sortcompno_L6").ToString.Trim(), DataType.String, "s121")
                            End If
                            Row.Cells.Add("Delete Component L6", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow("a" & sColumnName).ToString.Trim(), dRow("sortcompno_L6").ToString.Trim()), DataType.String, "s121")
                    End Select
                Case PartLevel.CATEGORY
                    Select Case Change
                        Case ChangeType.Add
                            Row.Cells.Add(dRow("FeatureCategory").ToString.Trim(), DataType.String, "s121")
                            Row.Cells.Add("Add Category", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow(sColumnName).ToString.Trim(), dRow("sortcompno").ToString.Trim()), DataType.String, "s121")
                        Case ChangeType.Change
                            Row.Cells.Add(dRow("FeatureCategory").ToString.Trim(), DataType.String, "s121")
                            Row.Cells.Add(String.Format("Change Category {0}", sReportName), DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} <= {1}", dRow(sColumnName).ToString.Trim(), dRow("a" & sColumnName).ToString.Trim()), DataType.String, "s121")
                        Case ChangeType.Remove
                            Row.Cells.Add(dRow("FeatureCategory").ToString.Trim(), DataType.String, "s121")
                            Row.Cells.Add("Delete Category", DataType.String, "s121")
                            Row.Cells.Add(String.Format("{0} ({1})", dRow("a" & sColumnName).ToString.Trim(), dRow("sortcompno").ToString.Trim()), DataType.String, "s121")
                    End Select
            End Select
            'cell = Row.Cells.Add
            'cell.StyleID = "s121"

        End Sub
#End Region

#Region " Close Detailed Change Log Worksheet "
        Private Sub CloseDetailedChangeLog(ByVal sheets As WorksheetCollection)

            Dim sheet As Worksheet = sheets("Detailed Change Log")
            '-----------------------------------------------
            ' Options
            '-----------------------------------------------
            sheet.Options.ProtectObjects = False
            sheet.Options.ProtectScenarios = False
            sheet.Options.Print.ValidPrinterInfo = True
            sheet.Options.ProtectObjects = False
            sheet.Options.ProtectScenarios = False
            sheet.Options.PageSetup.Layout.Orientation = Orientation.Landscape
            sheet.Options.PageSetup.Layout.CenterHorizontal = True
            sheet.Options.PageSetup.Footer.Data = "&LHP Confidential&CPage &P of &N&R&F" & Microsoft.VisualBasic.ChrW(10) & "&A"
            sheet.Options.PageSetup.Footer.Margin = 0.25!
            sheet.Options.PageSetup.PageMargins.Bottom = 0.5!
            sheet.Options.PageSetup.PageMargins.Left = 0.25!
            sheet.Options.PageSetup.PageMargins.Right = 0.25!
            sheet.Options.PageSetup.PageMargins.Top = 0.5!
            sheet.Options.Print.FitHeight = 100
            sheet.Options.Print.ValidPrinterInfo = True


        End Sub
#End Region

#End Region

#Region " Convert Y/N to X "
        Private Function YN2X(ByVal dRow As DataRow, ByVal sColumn As String) As String
            If dRow(sColumn).ToString.Trim = "Y" Then
                Return "X"
            Else
                Return String.Empty
            End If
        End Function
#End Region

#Region " GetStyleID "
        Private Function GetAVStyleID(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal column As String, ByVal EmptyCellStyle As String, Optional ByVal avRow As DataRow = Nothing) As String
            Dim rowAv As DataRow
            If IsNothing(avRow) Then
                rowAv = row
            Else
                rowAv = avRow
            End If

            Dim sNormal As String = "s85"
            Dim sHighlight As String = "s85h"
            Dim sStrike As String = "s85s"
            If column.Contains("description") Then
                sNormal = "s88"
                sHighlight = "s141"
                sStrike = "s142"
            End If
            If column.Contains("ConfigRules") Then
                sNormal = "s200"
                sHighlight = "s200h"
                sStrike = "s200s"
            End If
            If column.Contains("ManufacturingNotes") Then
                sNormal = "s201"
                sHighlight = "s201h"
                sStrike = "s201s"
            End If

            If row(column).ToString.Trim() = String.Empty And row("a" & column).ToString.Trim() = String.Empty Then
                If column.Contains("ManufacturingNotes") Or column.Contains("ConfigRules") Then
                    Return sNormal
                End If
                Return EmptyCellStyle
            End If

            If row(column).ToString.Trim() <> row("a" & column).ToString.Trim() And Not NewMatrix Then
                If rowAv("avno").ToString.Trim() = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.AV, ChangeType.Remove, GetColumnEnum(column), avRow)
                    Return sStrike 'Strike Through
                ElseIf rowAv("aavno").ToString.Trim = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.AV, ChangeType.Add, GetColumnEnum(column), avRow)
                    Return sHighlight 'Highlight
                Else
                    AddDetailedChangeLogRow(sheets, row, PartLevel.AV, ChangeType.Change, GetColumnEnum(column), avRow)
                    Return sHighlight 'Highlight
                End If
            Else
                Return sNormal 'Normal
            End If
        End Function

        Private Function GetSAStyleID(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal column As String, ByVal EmptyCellStyle As String) As String
            Dim sNormal As String = "s86"
            Dim sHighlight As String = "s130"
            Dim sStrike As String = "s126"
            If column.Contains("description") Then
                sNormal = "s89"
                sHighlight = "s127"
                sStrike = "s129"
            End If

            If row(column).ToString.Trim() = String.Empty And row("a" & column).ToString.Trim() = String.Empty Then
                Return EmptyCellStyle
            End If

            If row(column).ToString.Trim() <> row("a" & column).ToString.Trim() And Not NewMatrix Then
                If row("sano").ToString.Trim() = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.SA, ChangeType.Remove, GetColumnEnum(column))
                    Return sStrike 'Strike Through
                ElseIf row("asano").ToString.Trim = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.SA, ChangeType.Add, GetColumnEnum(column))
                    Return sHighlight 'Highlight
                Else
                    AddDetailedChangeLogRow(sheets, row, PartLevel.SA, ChangeType.Change, GetColumnEnum(column))
                    Return sHighlight 'Highlight
                End If
            Else
                Return sNormal 'Normal
            End If

        End Function
        Private Function GetCompStyleID(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal column As String, ByVal EmptyCellStyle As String) As String
            Dim sNormal As String = "s86"
            Dim sHighlight As String = "s130"
            Dim sStrike As String = "s126"
            If column.Contains("description") Then
                sNormal = "s91"
                sHighlight = "s128"
                sStrike = "s143"
            End If

            If row(column).ToString.Trim() = String.Empty And row("a" & column).ToString.Trim() = String.Empty Then
                Return EmptyCellStyle
            End If

            If row(column).ToString.Trim() <> row("a" & column).ToString.Trim() And Not NewMatrix Then
                If row("compno").ToString.Trim() = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.COMPONENT, ChangeType.Remove, GetColumnEnum(column))
                    Return sStrike 'Strike Through
                ElseIf row("acompno").ToString.Trim = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.COMPONENT, ChangeType.Add, GetColumnEnum(column))
                    Return sHighlight 'Highlight
                Else
                    AddDetailedChangeLogRow(sheets, row, PartLevel.COMPONENT, ChangeType.Change, GetColumnEnum(column))
                    Return sHighlight 'Highlight
                End If
            Else
                Return sNormal 'Normal
            End If

        End Function
        Private Function GetCompL5StyleID(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal column As String, ByVal EmptyCellStyle As String) As String
            Dim sNormal As String = "s86"
            Dim sHighlight As String = "s130"
            Dim sStrike As String = "s126"
            If column.Contains("description") Then
                sNormal = "s91"
                sHighlight = "s128"
                sStrike = "s143"
            End If

            If row(column).ToString.Trim() = String.Empty And row("a" & column).ToString.Trim() = String.Empty Then
                Return EmptyCellStyle
            End If

            If row(column).ToString.Trim() <> row("a" & column).ToString.Trim() And Not NewMatrix Then
                If row("compno_L5").ToString.Trim() = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.COMP_L5, ChangeType.Remove, GetColumnEnum(column))
                    Return sStrike 'Strike Through
                ElseIf row("acompno_L5").ToString.Trim = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.COMP_L5, ChangeType.Add, GetColumnEnum(column))
                    Return sHighlight 'Highlight 
                Else
                    AddDetailedChangeLogRow(sheets, row, PartLevel.COMP_L5, ChangeType.Change, GetColumnEnum(column))
                    Return sHighlight 'Highlight
                End If
            Else
                Return sNormal 'Normal
            End If

        End Function
        Private Function GetCompL6StyleID(ByVal sheets As WorksheetCollection, ByVal row As DataRow, ByVal column As String, ByVal EmptyCellStyle As String) As String
            Dim sNormal As String = "s86"
            Dim sHighlight As String = "s130"
            Dim sStrike As String = "s126"
            If column.Contains("description") Then
                sNormal = "s91"
                sHighlight = "s128"
                sStrike = "s143"
            End If

            If row(column).ToString.Trim() = String.Empty And row("a" & column).ToString.Trim() = String.Empty Then
                Return EmptyCellStyle
            End If

            If row(column).ToString.Trim() <> row("a" & column).ToString.Trim() And Not NewMatrix Then
                If row("compno_L6").ToString.Trim() = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.COMP_L6, ChangeType.Remove, GetColumnEnum(column))
                    Return sStrike 'Strike Through
                ElseIf row("acompno_L6").ToString.Trim = String.Empty Then
                    AddDetailedChangeLogRow(sheets, row, PartLevel.COMP_L6, ChangeType.Add, GetColumnEnum(column))
                    Return sHighlight 'Highlight
                Else
                    AddDetailedChangeLogRow(sheets, row, PartLevel.COMP_L6, ChangeType.Change, GetColumnEnum(column))
                    Return sHighlight 'Highlight
                End If
            Else
                Return sNormal 'Normal
            End If

        End Function
#End Region

#Region " Format Excel Date "

        Function FormatExcelDate(ByVal dt As Date) As String
      Dim s As StringBuilder = New StringBuilder
      s.Append(dt.Year.ToString.Trim())
      s.Append("-")
      s.Append(dt.Month.ToString.PadLeft(2, "0"))
      s.Append("-")
      s.Append(dt.Day.ToString.PadLeft(2, "0"))
      s.Append("T")
      s.Append(dt.Hour.ToString.PadLeft(2, "0"))
      s.Append(":")
      s.Append(dt.Minute.ToString.PadLeft(2, "0"))
      s.Append(":")
      s.Append(dt.Second.ToString.PadLeft(2, "0"))
      s.Append(".000")

      Return s.ToString.Trim
    End Function


#End Region
  End Class

End Namespace

