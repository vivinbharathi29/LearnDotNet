﻿Imports System
Imports System.Xml
Imports CarlosAg.ExcelXmlWriter
Namespace SCAvActionScorecardRequest
  Public Class SCAvActionScorecardRequest
    Private _FromDate As String
    Public Property FromDate() As String
      Get
        Return _FromDate
      End Get
      Set(ByVal value As String)
        _FromDate = value
      End Set
    End Property

    Private _ToDate As String
    Public Property ToDate() As String
      Get
        Return _ToDate
      End Get
      Set(ByVal value As String)
        _ToDate = value
      End Set
    End Property

    Private _Days As String
    Public Property Days() As String
      Get
        Return _Days
      End Get
      Set(ByVal value As String)
        _Days = value
      End Set
    End Property

    Private _DateRangeType As String
    Public Property DateRangeType() As String
      Get
        Return _DateRangeType
      End Get
      Set(ByVal value As String)
        _DateRangeType = value
      End Set
    End Property

    Private _PVIDs As String
    Public Property PVIDs() As String
      Get
        Return _PVIDs
      End Get
      Set(ByVal value As String)
        _PVIDs = value
      End Set
    End Property

    Private _Status As String
    Public Property Status() As String
      Get
        Return _Status
      End Get
      Set(ByVal value As String)
        _Status = value
      End Set
    End Property

    Public Sub Generate(ByRef stream As System.IO.Stream)
      Dim book As Workbook = New Workbook
      '-----------------------------------------------
      ' Properties
      '-----------------------------------------------
      book.Properties.Author = "Malichi, Jason"
      book.Properties.LastAuthor = "Excalibur"
      book.Properties.Created = New Date(1996, 10, 14, 18, 33, 28, 0)
      book.Properties.LastSaved = New Date(2010, 2, 3, 14, 54, 15, 0)
      book.Properties.Version = "12.00"
      book.ExcelWorkbook.WindowHeight = 9120
      book.ExcelWorkbook.WindowWidth = 12120
      book.ExcelWorkbook.WindowTopX = 120
      book.ExcelWorkbook.WindowTopY = 120
      book.ExcelWorkbook.ProtectWindows = False
      book.ExcelWorkbook.ProtectStructure = False
      '-----------------------------------------------
      ' Generate Styles
      '-----------------------------------------------
      Me.GenerateStyles(book.Styles)
      book.Names.Add(New WorksheetNamedRange("Application_ID", "=AvActionScorecard!R314C2:R316C2", False))
      book.Names.Add(New WorksheetNamedRange("Data", "=AvActionScorecard!R10C1:R310C17", False))
      book.Names.Add(New WorksheetNamedRange("Header", "=AvActionScorecard!R5C2:R9C2", False))
      '-----------------------------------------------
      ' Generate PendingAvActions Worksheet
      '-----------------------------------------------
      Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
      Dim dt As DataTable = dw.SelectAVActionScorecardReport(PVIDs)
      Dim sAverages() As String = GetAverages(dt).Split(",")
      Dim sMarketingAverage As String = sAverages(0)
      Dim sPDMTeamAverage As String = sAverages(1)

      Me.GenerateWorksheet(book.Worksheets, sMarketingAverage, sPDMTeamAverage)
      Dim i As Integer = 0
      Dim row As Data.DataRow
      For Each row In dt.Rows
        Dim sAvNo As String = ""
        Dim sGPGDesc As String = ""
        Dim sPhWebAction As String = ""
        Dim sPCDate As String = ""
        Dim sMarketingInput As String = ""
        Dim sPhWebDate As String = ""
        Dim sRTPDate As String = ""
        Dim sRASDiscDate As String = ""
        Dim sMarketingDate As String = ""
        Dim sPhWebInstructions As String = ""
        Dim sPDMFeedback As String = ""
        Dim sNonActionable As String = ""
        Dim sAVStatus As String = ""
        Dim sGeneralAvailDate As String = ""

        sAvNo = row("AvNo")
        sGPGDesc = IIf(row("GPGDescription") Is DBNull.Value, "", row("GPGDescription"))
        sPhWebAction = row("ActionName")
        sPCDate = IIf(row("PCDate") Is DBNull.Value, "", row("PCDate"))
        sMarketingInput = IIf(row("MarketingInput") Is DBNull.Value, "", row("MarketingInput"))
        sPhWebDate = IIf(row("PhWebDate") Is DBNull.Value, "", row("PhWebDate"))
        sRTPDate = IIf(row("RTPDate") Is DBNull.Value, "", row("RTPDate"))
        sRASDiscDate = IIf(row("RASDiscontinueDt") Is DBNull.Value, "", row("RASDiscontinueDt"))
        sGeneralAvailDate = IIf(row("GeneralAvailDt") Is DBNull.Value, "", row("GeneralAvailDt"))
        sMarketingDate = IIf(row("MarketingDate") Is DBNull.Value, "", row("MarketingDate"))
        sPhWebInstructions = IIf(row("PhWebInstruction") Is DBNull.Value, "", row("PhWebInstruction"))
        sPDMFeedback = IIf(row("PDMFeedback") Is DBNull.Value, "", row("PDMFeedback"))
        sPDMFeedback = sPDMFeedback.Replace("[", "")
        sPDMFeedback = sPDMFeedback.Replace("]", "")
        sNonActionable = IIf(row("NotActionable") Is DBNull.Value, "", row("NotActionable"))
        sAVStatus = row("AVStatus")

        'Geanerate Spreadsheet
        Select Case DateRangeType
          Case 0 'None
            CheckStatus(book.Worksheets, row("DOTSName"), row("Name"), sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, Status, sPhWebInstructions, sPDMFeedback, sNonActionable, sAVStatus, sGeneralAvailDate)
          Case 1 'Date Range

            'If (DateTime.Compare(date1, date2) > 0) Then
            '// which means ("date1 > date2")

            'if (DateTime.Compare(date1, date2) == 0) 
            '//which means ("date1 == date2");

            'If (DateTime.Compare(date1, date2) < 0) Then
            '//which means ("date1 < date2");

            If ((DateTime.Compare(CDate(sPCDate), CDate(FromDate)) > 0) Or (DateTime.Compare(CDate(sPCDate), CDate(FromDate)) = 0)) _
                    And ((DateTime.Compare(CDate(ToDate), CDate(sPCDate)) > 0) Or (DateTime.Compare(CDate(ToDate), CDate(sPCDate)) = 0)) Then
              CheckStatus(book.Worksheets, row("DOTSName"), row("Name"), sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, Status, sPhWebInstructions, sPDMFeedback, sNonActionable, sAVStatus, sGeneralAvailDate)
            End If
          Case 2 'Days
            If ((DateTime.Compare(CDate(sPCDate), Date.Now.AddDays(-Days)) > 0) Or (DateTime.Compare(CDate(sPCDate), Date.Now.AddDays(-Days)) = 0)) Then
              CheckStatus(book.Worksheets, row("DOTSName"), row("Name"), sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, Status, sPhWebInstructions, sPDMFeedback, sNonActionable, sAVStatus, sGeneralAvailDate)
            End If
        End Select
      Next
      book.Save(stream)
    End Sub

    Private Sub CheckStatus(ByVal Sheets As WorksheetCollection, ByVal sProductName As String, ByVal sBrandName As String, ByVal sAvNo As String, ByVal sGPGDesc As String,
                    ByVal sPhWebAction As String, ByVal sPCDate As String, ByVal sMarketingInput As String, ByVal sPhWebDate As String, ByVal sRTPDate As String,
                    ByVal sRASDiscDate As String, ByVal sMarketingDate As String, ByVal Status As String, ByVal sPhWebInstructions As String, ByVal sPDMFeedback As String,
                    ByVal sNonActionable As String, ByVal sAVStatus As String, ByVal sGeneralAvailDate As String)
      Select Case Status
        Case 0 'Pending
          If ((sPhWebDate = "") Or (sPhWebDate Is DBNull.Value.ToString)) And (sAVStatus = "A" Or sAVStatus = "K") Then
            GenerateRow(Sheets, sProductName, sBrandName, sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, sPhWebInstructions, sPDMFeedback, "Pending", sGeneralAvailDate)
          End If
        Case 1 'Completed
          If ((sPhWebDate <> "") Or (Not sPhWebDate Is DBNull.Value.ToString)) And sNonActionable = "False" And (sAVStatus = "A" Or sAVStatus = "K") Then
            GenerateRow(Sheets, sProductName, sBrandName, sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, sPhWebInstructions, sPDMFeedback, "Completed", sGeneralAvailDate)
          End If
        Case 2 'All
          If ((sPhWebDate = "") Or (sPhWebDate Is DBNull.Value.ToString)) And (sAVStatus = "A" Or sAVStatus = "K") Then
            GenerateRow(Sheets, sProductName, sBrandName, sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, sPhWebInstructions, sPDMFeedback, "Pending", sGeneralAvailDate)
          ElseIf ((sPhWebDate <> "") Or (Not sPhWebDate Is DBNull.Value.ToString)) And sNonActionable = "False" And (sAVStatus = "A" Or sAVStatus = "K") Then
            GenerateRow(Sheets, sProductName, sBrandName, sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, sPhWebInstructions, sPDMFeedback, "Completed", sGeneralAvailDate)
          ElseIf sNonActionable = "True" And (sAVStatus = "A" Or sAVStatus = "K") Then
            GenerateRow(Sheets, sProductName, sBrandName, sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, sPhWebInstructions, sPDMFeedback, "Non-Actionable", sGeneralAvailDate)
          ElseIf sAVStatus = "D" Then
            GenerateRow(Sheets, sProductName, sBrandName, sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, sPhWebInstructions, sPDMFeedback, "Deleted", sGeneralAvailDate)
          ElseIf sAVStatus = "O" Then
            GenerateRow(Sheets, sProductName, sBrandName, sAvNo, sGPGDesc, sPhWebAction, sPCDate, sMarketingInput, sPhWebDate, sRTPDate, sRASDiscDate, sMarketingDate, sPhWebInstructions, sPDMFeedback, "Obsoleted", sGeneralAvailDate)
          End If
      End Select
    End Sub

    Private Function GetAverages(ByVal dt As DataTable) As String
      Dim sPCDate As String = ""
      Dim sTimeSpentInMarketing As String = ""
      Dim sTimeSpentInPDMTeam As String = ""
      Dim iMarketingSum As Integer = 0
      Dim iPDMSum As Integer = 0
      Dim iMarketingCount As Integer = 0
      Dim iPDMCount As Integer = 0
      Dim i As Integer = 0
      Dim sAVStatus As String = ""

      Dim row As Data.DataRow
      For Each row In dt.Rows
        If row("AVStatus") = "A" Or row("AVStatus") = "K" Then
          sPCDate = IIf(row("PCDate") Is DBNull.Value, "", row("PCDate"))
          sTimeSpentInMarketing = IIf(row("TimeSpentInMarketing") Is DBNull.Value, "", row("TimeSpentInMarketing"))
          sTimeSpentInPDMTeam = IIf(row("TimeSpentInPDMTeam") Is DBNull.Value, "", row("TimeSpentInPDMTeam"))
          Select Case DateRangeType
            Case 0 'None
              If sTimeSpentInMarketing <> "" Then
                iMarketingSum = iMarketingSum + CInt(sTimeSpentInMarketing)
                iMarketingCount += 1
              End If
              If sTimeSpentInPDMTeam <> "" Then
                iPDMSum = iPDMSum + CInt(sTimeSpentInPDMTeam)
                iPDMCount += 1
              End If
            Case 1 'Date Range
              If FromDate <= sPCDate And ToDate >= sPCDate Then
                If sTimeSpentInMarketing <> "" Then
                  iMarketingSum = iMarketingSum + CInt(sTimeSpentInMarketing)
                  iMarketingCount += 1
                End If
                If sTimeSpentInPDMTeam <> "" Then
                  iPDMSum = iPDMSum + CInt(sTimeSpentInPDMTeam)
                  iPDMCount += 1
                End If
              End If
            Case 2 'Days
              If sPCDate >= Date.Now.AddDays(-Days) Then
                If sTimeSpentInMarketing <> "" Then
                  iMarketingSum = iMarketingSum + CInt(sTimeSpentInMarketing)
                  iMarketingCount += 1
                End If
                If sTimeSpentInPDMTeam <> "" Then
                  iPDMSum = iPDMSum + CInt(sTimeSpentInPDMTeam)
                  iPDMCount += 1
                End If
              End If
          End Select
        End If
      Next

      Dim sMarketingAverage As String = ""
      Dim sPDMTeamAverage As String = ""

      Dim dMarketingAverage As Decimal
      If iMarketingSum <> 0 Then
        dMarketingAverage = iMarketingSum / iMarketingCount
        sMarketingAverage = dMarketingAverage.ToString
      Else
        sMarketingAverage = 0
      End If

      Dim dPDMTeamAverage As Decimal
      If iPDMSum <> 0 Then
        dPDMTeamAverage = iPDMSum / iPDMCount
        sPDMTeamAverage = dPDMTeamAverage.ToString
      Else
        sPDMTeamAverage = 0
      End If

      GetAverages = sMarketingAverage & "," & sPDMTeamAverage
    End Function

#Region " Generate Styles "
    Private Sub GenerateStyles(ByVal styles As WorksheetStyleCollection)
      '-----------------------------------------------
      ' Default
      '-----------------------------------------------
      Dim [Default] As WorksheetStyle = styles.Add("Default")
      [Default].Name = "Normal"
      [Default].Font.FontName = "Arial"
      [Default].Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s16
      '-----------------------------------------------
      Dim s16 As WorksheetStyle = styles.Add("s16")
      s16.Name = "Hyperlink"
      s16.Font.Bold = True
      s16.Font.Underline = UnderlineStyle.[Single]
      s16.Font.FontName = "Arial"
      s16.Font.Size = 8
      s16.Font.Color = "#0000FF"
      s16.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s16.Alignment.Vertical = StyleVerticalAlignment.Center
      '-----------------------------------------------
      ' s17
      '-----------------------------------------------
      Dim s17 As WorksheetStyle = styles.Add("s17")
      s17.Name = "Normal 2"
      s17.Font.FontName = "Arial"
      s17.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s18
      '-----------------------------------------------
      Dim s18 As WorksheetStyle = styles.Add("s18")
      s18.Name = "Normal 3"
      s18.Font.FontName = "Arial"
      s18.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s19
      '-----------------------------------------------
      Dim s19 As WorksheetStyle = styles.Add("s19")
      s19.Name = "Normal_4x4-5x5 Test"
      s19.Font.FontName = "Arial"
      s19.Font.Color = "#000000"
      s19.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s20
      '-----------------------------------------------
      Dim s20 As WorksheetStyle = styles.Add("s20")
      s20.Font.Bold = True
      s20.Font.FontName = "Arial"
      s20.Font.Size = 8
      s20.Interior.Color = "#C0C0C0"
      s20.Interior.Pattern = StyleInteriorPattern.Solid
      s20.Alignment.Vertical = StyleVerticalAlignment.Top
      s20.Alignment.WrapText = True
      s20.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s20.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s20.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s20.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s21
      '-----------------------------------------------
      Dim s21 As WorksheetStyle = styles.Add("s21")
      s21.Font.Bold = True
      s21.Font.FontName = "Arial"
      s21.Font.Size = 8
      s21.Interior.Color = "#C0C0C0"
      s21.Interior.Pattern = StyleInteriorPattern.Solid
      s21.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s21.Alignment.Vertical = StyleVerticalAlignment.Center
      s21.Alignment.WrapText = True
      s21.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s21.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s21.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s21.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s22
      '-----------------------------------------------
      Dim s22 As WorksheetStyle = styles.Add("s22")
      s22.Font.Bold = True
      s22.Font.FontName = "Arial"
      s22.Font.Size = 8
      s22.Interior.Color = "#C0C0C0"
      s22.Interior.Pattern = StyleInteriorPattern.Solid
      s22.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s22.Alignment.Vertical = StyleVerticalAlignment.Center
      s22.Alignment.WrapText = True
      s22.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s22.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s22.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s22.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s23
      '-----------------------------------------------
      Dim s23 As WorksheetStyle = styles.Add("s23")
      s23.Font.Bold = True
      s23.Font.FontName = "Arial"
      s23.Font.Size = 8
      s23.Interior.Color = "#C0C0C0"
      s23.Interior.Pattern = StyleInteriorPattern.Solid
      s23.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s23.Alignment.Vertical = StyleVerticalAlignment.Center
      s23.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s23.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s23.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s23.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s24
      '-----------------------------------------------
      Dim s24 As WorksheetStyle = styles.Add("s24")
      s24.Parent = "s16"
      s24.Interior.Color = "#C0C0C0"
      s24.Interior.Pattern = StyleInteriorPattern.Solid
      s24.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s24.Alignment.Vertical = StyleVerticalAlignment.Center
      s24.Alignment.WrapText = True
      s24.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s24.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s24.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s24.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s25
      '-----------------------------------------------
      Dim s25 As WorksheetStyle = styles.Add("s25")
      s25.Parent = "s16"
      s25.Font.Bold = True
      s25.Font.Underline = UnderlineStyle.[Single]
      s25.Font.FontName = "Arial"
      s25.Font.Size = 8
      s25.Font.Color = "#0000FF"
      s25.Interior.Color = "#C0C0C0"
      s25.Interior.Pattern = StyleInteriorPattern.Solid
      s25.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s25.Alignment.Vertical = StyleVerticalAlignment.Center
      s25.Alignment.WrapText = True
      s25.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s25.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s25.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s25.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s26
      '-----------------------------------------------
      Dim s26 As WorksheetStyle = styles.Add("s26")
      s26.Parent = "s16"
      s26.Interior.Color = "#C0C0C0"
      s26.Interior.Pattern = StyleInteriorPattern.Solid
      s26.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s26.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s26.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s26.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s27
      '-----------------------------------------------
      Dim s27 As WorksheetStyle = styles.Add("s27")
      s27.Font.Bold = True
      s27.Font.FontName = "Arial"
      s27.Font.Size = 8
      s27.Interior.Color = "#C0C0C0"
      s27.Interior.Pattern = StyleInteriorPattern.Solid
      s27.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s27.Alignment.WrapText = True
      s27.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s27.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s27.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s28
      '-----------------------------------------------
      Dim s28 As WorksheetStyle = styles.Add("s28")
      s28.Font.Bold = True
      s28.Font.FontName = "Arial"
      s28.Font.Size = 8
      s28.Interior.Color = "#C0C0C0"
      s28.Interior.Pattern = StyleInteriorPattern.Solid
      s28.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s28.Alignment.Vertical = StyleVerticalAlignment.Center
      s28.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s28.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s28.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s28.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s29
      '-----------------------------------------------
      Dim s29 As WorksheetStyle = styles.Add("s29")
      s29.Interior.Color = "#C0C0C0"
      s29.Interior.Pattern = StyleInteriorPattern.Solid
      '-----------------------------------------------
      ' s30
      '-----------------------------------------------
      Dim s30 As WorksheetStyle = styles.Add("s30")
      s30.Interior.Color = "#C0C0C0"
      s30.Interior.Pattern = StyleInteriorPattern.Solid
      s30.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s31
      '-----------------------------------------------
      Dim s31 As WorksheetStyle = styles.Add("s31")
      s31.Font.FontName = "Arial"
      s31.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s32
      '-----------------------------------------------
      Dim s32 As WorksheetStyle = styles.Add("s32")
      s32.Font.FontName = "Arial"
      s32.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s33
      '-----------------------------------------------
      Dim s33 As WorksheetStyle = styles.Add("s33")
      '-----------------------------------------------
      ' s34
      '-----------------------------------------------
      Dim s34 As WorksheetStyle = styles.Add("s34")
      s34.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s34.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s34.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s34.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s34.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s34.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s34.NumberFormat = "@"
      '-----------------------------------------------
      ' s35
      '-----------------------------------------------
      Dim s35 As WorksheetStyle = styles.Add("s35")
      s35.Font.FontName = "Arial"
      s35.Font.Size = 8
      s35.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s35.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s35.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s35.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s35.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s35.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s35.NumberFormat = "@"
      '-----------------------------------------------
      ' s36
      '-----------------------------------------------
      Dim s36 As WorksheetStyle = styles.Add("s36")
      s36.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s36.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s36.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s36.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s36.NumberFormat = "@"
      '-----------------------------------------------
      ' s37
      '-----------------------------------------------
      Dim s37 As WorksheetStyle = styles.Add("s37")
      s37.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s37.Alignment.Vertical = StyleVerticalAlignment.Center
      s37.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s37.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s37.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s37.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s37.NumberFormat = "@"
      '-----------------------------------------------
      ' s37r
      '-----------------------------------------------
      Dim s37r As WorksheetStyle = styles.Add("s37r")
      s37r.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s37r.Alignment.Vertical = StyleVerticalAlignment.Center
      s37r.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s37r.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s37r.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s37r.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s37r.NumberFormat = "@"
      s37r.Font.Color = "#FF0000"
      '-----------------------------------------------
      ' s38
      '-----------------------------------------------
      Dim s38 As WorksheetStyle = styles.Add("s38")
      s38.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s39
      '-----------------------------------------------
      Dim s39 As WorksheetStyle = styles.Add("s39")
      s39.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s40
      '-----------------------------------------------
      Dim s40 As WorksheetStyle = styles.Add("s40")
      s40.Interior.Color = "#C0C0C0"
      s40.Interior.Pattern = StyleInteriorPattern.Solid
      s40.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s41
      '-----------------------------------------------
      Dim s41 As WorksheetStyle = styles.Add("s41")
      s41.Font.Bold = True
      s41.Font.Italic = True
      s41.Font.FontName = "Symbol"
      s41.Interior.Color = "#C0C0C0"
      s41.Interior.Pattern = StyleInteriorPattern.Solid
      s41.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s42
      '-----------------------------------------------
      Dim s42 As WorksheetStyle = styles.Add("s42")
      s42.Interior.Color = "#C0C0C0"
      s42.Interior.Pattern = StyleInteriorPattern.Solid
      s42.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s42.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s43
      '-----------------------------------------------
      Dim s43 As WorksheetStyle = styles.Add("s43")
      s43.Font.Bold = True
      s43.Font.Italic = True
      s43.Font.FontName = "Symbol"
      s43.Interior.Color = "#C0C0C0"
      s43.Interior.Pattern = StyleInteriorPattern.Solid
      s43.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s43.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s44
      '-----------------------------------------------
      Dim s44 As WorksheetStyle = styles.Add("s44")
      s44.Interior.Color = "#C0C0C0"
      s44.Interior.Pattern = StyleInteriorPattern.Solid
      '-----------------------------------------------
      ' s45
      '-----------------------------------------------
      Dim s45 As WorksheetStyle = styles.Add("s45")
      s45.Interior.Color = "#C0C0C0"
      s45.Interior.Pattern = StyleInteriorPattern.Solid
      s45.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s46
      '-----------------------------------------------
      Dim s46 As WorksheetStyle = styles.Add("s46")
      s46.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s46.Alignment.WrapText = True
      s46.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s46.NumberFormat = "@"
      '-----------------------------------------------
      ' s47
      '-----------------------------------------------
      Dim s47 As WorksheetStyle = styles.Add("s47")
      s47.NumberFormat = "@"
      '-----------------------------------------------
      ' s48
      '-----------------------------------------------
      Dim s48 As WorksheetStyle = styles.Add("s48")
      s48.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s48.Alignment.Vertical = StyleVerticalAlignment.Top
      s48.Alignment.WrapText = True
      s48.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s48.NumberFormat = "@"
      '-----------------------------------------------
      ' s49
      '-----------------------------------------------
      Dim s49 As WorksheetStyle = styles.Add("s49")
      s49.Parent = "s19"
      s49.Font.FontName = "Arial"
      s49.Font.Color = "#FFFFFF"
      s49.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s49.Alignment.WrapText = True
      s49.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1, "#C0C0C0")
      s49.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1, "#C0C0C0")
      s49.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1, "#C0C0C0")
      s49.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1, "#C0C0C0")
      '-----------------------------------------------
      ' s50
      '-----------------------------------------------
      Dim s50 As WorksheetStyle = styles.Add("s50")
      s50.Parent = "s17"
      s50.Font.FontName = "Arial"
      s50.Font.Color = "#FFFFFF"
      s50.NumberFormat = "@"
      '-----------------------------------------------
      ' s51
      '-----------------------------------------------
      Dim s51 As WorksheetStyle = styles.Add("s51")
      s51.Parent = "s19"
      s51.Font.FontName = "Arial"
      s51.Font.Color = "#FFFFFF"
      s51.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s51.Alignment.WrapText = True
      s51.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1, "#C0C0C0")
      s51.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1, "#C0C0C0")
      '-----------------------------------------------
      ' s52
      '-----------------------------------------------
      Dim s52 As WorksheetStyle = styles.Add("s52")
      s52.Parent = "s19"
      s52.Font.FontName = "Arial"
      s52.Font.Color = "#FFFFFF"
      s52.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s52.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s52.Alignment.WrapText = True
      s52.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1, "#C0C0C0")
      s52.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1, "#C0C0C0")
      s52.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1, "#C0C0C0")
      s52.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1, "#C0C0C0")
      '-----------------------------------------------
      ' s53
      '-----------------------------------------------
      Dim s53 As WorksheetStyle = styles.Add("s53")
      s53.Parent = "s18"
      s53.Font.FontName = "Arial"
      s53.Font.Color = "#FFFFFF"
      s53.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s53.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s55
      '-----------------------------------------------
      Dim s55 As WorksheetStyle = styles.Add("s55")
      s55.Parent = "s18"
      s55.Font.FontName = "Arial"
      s55.Font.Color = "#FFFFFF"
      s55.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s55.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s56
      '-----------------------------------------------
      Dim s56 As WorksheetStyle = styles.Add("s56")
      s56.Font.FontName = "Arial"
      s56.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s57
      '-----------------------------------------------
      Dim s57 As WorksheetStyle = styles.Add("s57")
      s57.Font.FontName = "Arial"
      s57.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s58
      '-----------------------------------------------
      Dim s58 As WorksheetStyle = styles.Add("s58")
      s58.Parent = "s19"
      s58.Font.FontName = "Arial"
      s58.Font.Color = "#FFFFFF"
      s58.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s58.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s58.Alignment.WrapText = True
      s58.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1, "#C0C0C0")
      s58.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1, "#C0C0C0")
      '-----------------------------------------------
      ' s59
      '-----------------------------------------------
      Dim s59 As WorksheetStyle = styles.Add("s59")
      s59.Font.FontName = "Arial"
      s59.Font.Color = "#FF0000"
      '-----------------------------------------------
      ' s60
      '-----------------------------------------------
      Dim s60 As WorksheetStyle = styles.Add("s60")
      s60.Font.FontName = "Arial"
      s60.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s61
      '-----------------------------------------------
      Dim s61 As WorksheetStyle = styles.Add("s61")
      s61.Font.FontName = "Arial"
      s61.Font.Color = "#FFFFFF"
      s61.NumberFormat = "@"
      '-----------------------------------------------
      ' s62
      '-----------------------------------------------
      Dim s62 As WorksheetStyle = styles.Add("s62")
      s62.Font.FontName = "Arial"
      s62.Font.Size = 8
      s62.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s67
      '-----------------------------------------------
      Dim s67 As WorksheetStyle = styles.Add("s67")
      s67.Font.Bold = True
      s67.Font.FontName = "Arial"
      s67.Font.Size = 14
      s67.Interior.Color = "#C0C0C0"
      s67.Interior.Pattern = StyleInteriorPattern.Solid
      s67.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s67.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s70
      '-----------------------------------------------
      Dim s70 As WorksheetStyle = styles.Add("s70")
      s70.Font.Bold = True
      s70.Font.Italic = True
      s70.Font.FontName = "Symbol"
      s70.Interior.Color = "#C0C0C0"
      s70.Interior.Pattern = StyleInteriorPattern.Solid
      s70.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s70.Alignment.WrapText = True
      '-----------------------------------------------
      ' s79
      '-----------------------------------------------
      Dim s79 As WorksheetStyle = styles.Add("s79")
      s79.Font.Bold = True
      s79.Font.FontName = "Arial"
      s79.Interior.Color = "#C0C0C0"
      s79.Interior.Pattern = StyleInteriorPattern.Solid
      '-----------------------------------------------
      ' s86
      '-----------------------------------------------
      Dim s86 As WorksheetStyle = styles.Add("s86")
      s86.Interior.Color = "#C0C0C0"
      s86.Interior.Pattern = StyleInteriorPattern.Solid
      s86.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s86.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s86.NumberFormat = "Fixed"

    End Sub
#End Region

#Region " Open Worksheet "
    Private Sub GenerateWorksheet(ByVal sheets As WorksheetCollection, ByVal sMarketingAverage As String, ByVal sPDMTeamAverage As String)
      Dim sheet As Worksheet = sheets.Add("AvActionScorecard")
      sheet.Table.ExpandedColumnCount = 34
      'sheet.Table.ExpandedRowCount = 2529
      sheet.Table.FullColumns = 1
      sheet.Table.FullRows = 1
      sheet.Table.Columns.Add(150)
      sheet.Table.Columns.Add(125)
      sheet.Table.Columns.Add(80)
      sheet.Table.Columns.Add(250)
      sheet.Table.Columns.Add(250)
      sheet.Table.Columns.Add(250)
      sheet.Table.Columns.Add(125)
      sheet.Table.Columns.Add(250)
      sheet.Table.Columns.Add(125)
      sheet.Table.Columns.Add(125)
      sheet.Table.Columns.Add(125)
      sheet.Table.Columns.Add(125)
      sheet.Table.Columns.Add(125)
      'sheet.Table.Columns.Add(47)
      'Dim column7 As WorksheetColumn = sheet.Table.Columns.Add
      'column7.Width = 50
      'column7.Span = 1
      'Dim column8 As WorksheetColumn = sheet.Table.Columns.Add
      'column8.Index = 10
      'column8.Width = 53
      'sheet.Table.Columns.Add(85)
      'sheet.Table.Columns.Add(191)
      'sheet.Table.Columns.Add(531)
      'Dim column12 As WorksheetColumn = sheet.Table.Columns.Add
      'column12.Width = 35
      'column12.Span = 1
      'Dim column13 As WorksheetColumn = sheet.Table.Columns.Add
      'column13.Index = 16
      'column13.Width = 182
      'sheet.Table.Columns.Add(33)
      'sheet.Table.Columns.Add(61)
      'sheet.Table.Columns.Add(53)
      'sheet.Table.Columns.Add(97)
      'Dim column18 As WorksheetColumn = sheet.Table.Columns.Add
      'column18.Index = 24
      'column18.Width = 282
      'Dim column19 As WorksheetColumn = sheet.Table.Columns.Add
      'column19.Index = 30
      'column19.Width = 94
      '-----------------------------------------------
      Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
      Row0.Height = 18
      Dim cell As WorksheetCell
      cell = Row0.Cells.Add
      cell.StyleID = "s67"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Excalibur - AvAction Scorecard Report"
      cell.MergeAcross = 12
      'cell = Row0.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row0.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row0.Cells.Add
      'cell.StyleID = "s30"
      '-----------------------------------------------
      Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
      Row1.Height = 12
      Row1.AutoFitHeight = False
      Row1.Cells.Add("Average Days In Marketing:", DataType.[String], "s79")
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell.Data.Type = DataType.Number
      cell.Data.Text = sMarketingAverage
      'cell.Data.Text = "1.8836291913214991"
      'cell.Formula = "=AVERAGE(K5:K511)"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      cell = Row1.Cells.Add
      cell.StyleID = "s86"
      '-----------------------------------------------
      Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
      Row2.Height = 12
      Row2.AutoFitHeight = False
      Row2.Cells.Add("Average Days In PDM Team:", DataType.[String], "s79")
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell.Data.Type = DataType.Number
      cell.Data.Text = sPDMTeamAverage
      'cell.Data.Text = "10.465483234714004"
      'cell.Formula = "=AVERAGE(L5:L511)"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      cell = Row2.Cells.Add
      cell.StyleID = "s86"
      '-----------------------------------------------
      Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
      Row4.Height = 13
      Row4.AutoFitHeight = False
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell.NamedCell.Add("Header")
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s43"
      '-----------------------------------------------
      Dim Row9 As WorksheetRow = sheet.Table.Rows.Add
      Row9.Height = 39
      Row9.AutoFitHeight = False
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Product"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Product Brand"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "AV No."
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "GPG Description"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "PhWeb Action"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Special Instructions"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Status"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "PDM Feedback"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Requested Date"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Marketing Date"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "PDM Date"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Target RTP Date"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add

      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Target DISC Date"
      cell.NamedCell.Add("Data")
      cell = Row9.Cells.Add
    End Sub
#End Region

#Region " Add Row "
    Sub GenerateRow(ByVal Sheets As WorksheetCollection, ByVal sProductName As String, ByVal sBrandName As String, ByVal sAvNo As String, ByVal sGPGDesc As String,
                    ByVal sPhWebAction As String, ByVal sPCDate As String, ByVal sMarketingInput As String, ByVal sPhWebDate As String, ByVal sRTPDate As String,
                    ByVal sRASDiscDate As String, ByVal sMarketingDate As String, ByVal sPhWebInstructions As String, ByVal sPDMFeedback As String, ByVal sStatus As String,
                    ByVal sGeneralAvailDate As String)
      Dim cell As New WorksheetCell
      Dim sheet As Worksheet = Sheets("AvActionScorecard")
      Dim Row10 As WorksheetRow = sheet.Table.Rows.Add
      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sProductName
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sBrandName
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sAvNo
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sGPGDesc
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sPhWebAction
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sPhWebInstructions
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sStatus
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sPDMFeedback
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sPCDate
      cell.NamedCell.Add("Data")

      If sMarketingDate = "1/1/1900" Then
        sMarketingDate = ""
      End If
      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      If sMarketingInput = "Complete" Then
        cell.Data.Text = sMarketingDate
      Else
        cell.Data.Text = sMarketingInput
      End If
      cell.NamedCell.Add("Data")

      If sPhWebDate = "1/1/1900" Then
        sPhWebDate = ""
      End If
      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      If sPhWebDate <> "" Then
        cell.Data.Text = sPhWebDate
      Else
        cell.Data.Text = "Pending"
      End If
      cell.NamedCell.Add("Data")

      If sRTPDate = "1/1/1900" Then
        sRTPDate = ""
      End If
      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sRTPDate
      cell.NamedCell.Add("Data")

      If sRASDiscDate = "1/1/1900" Then
        sRASDiscDate = ""
      End If
      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = sRASDiscDate
      cell.NamedCell.Add("Data")
    End Sub
#End Region

  End Class
End Namespace

