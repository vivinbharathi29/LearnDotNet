﻿Imports System
Imports System.Xml
Imports CarlosAg.ExcelXmlWriter

Namespace ImageBOMRequest
  Public Class ImageBOMRequest
    Private _brandId As String

    Public Property BrandId() As String
      Get
        Return _brandId
      End Get
      Set(ByVal value As String)
        _brandId = value
      End Set
    End Property

    Private _userName As String

    Public Property UserName() As String
      Get
        Return _userName
      End Get
      Set(ByVal value As String)
        _userName = value
      End Set
    End Property

    Private _ItemNumber As String
    Public Property ItemNumber() As String
      Get
        Return _ItemNumber
      End Get
      Set(ByVal value As String)
        _ItemNumber = value
      End Set
    End Property

    Public Sub Generate(ByRef stream As System.IO.Stream)
      Dim book As Workbook = New Workbook
      '-----------------------------------------------
      ' Properties
      '-----------------------------------------------
      book.Properties.Author = "Koppel, Lori"
      book.Properties.LastAuthor = "Excalibur"
      book.Properties.Created = New Date(1996, 10, 14, 18, 33, 28, 0)
      book.Properties.LastSaved = New Date(2010, 2, 3, 14, 54, 15, 0)
      book.Properties.Version = "12.00"
      book.ExcelWorkbook.WindowHeight = 9120
      book.ExcelWorkbook.WindowWidth = 12120
      book.ExcelWorkbook.WindowTopX = 120
      book.ExcelWorkbook.WindowTopY = 120
      book.ExcelWorkbook.ProtectWindows = False
      book.ExcelWorkbook.ProtectStructure = False
      '-----------------------------------------------
      ' Generate Styles
      '-----------------------------------------------
      Me.GenerateStyles(book.Styles)
      book.Names.Add(New WorksheetNamedRange("Application_ID", "=ImageBOM!R314C2:R316C2", False))
      book.Names.Add(New WorksheetNamedRange("Data", "=ImageBOM!R10C1:R310C17", False))
      book.Names.Add(New WorksheetNamedRange("Header", "=ImageBOM!R5C2:R9C2", False))
      '-----------------------------------------------
      ' Generate HPRPN Worksheet
      '-----------------------------------------------
      Dim dw As HPQ.Excalibur.Data = New HPQ.Excalibur.Data
      Dim dt As DataTable = dw.SelectBOMExportDetail(BrandId)
      Me.GenerateWorksheet(book.Worksheets)
      Dim i As Integer = 0
      Dim row As Data.DataRow
      For Each row In dt.Rows
        Dim AVNo As String = ""
        Dim ZWAR As String = ""
        Dim GPGDescription As String = ""
        AVNo = row("AVNo")
        ZWAR = row("SKU1") & row("SKU2") & row("SKU3")
        GPGDescription = row("GPGDescription")
        GenerateBaseRow(book.Worksheets, AVNo, GPGDescription)
        GenerateSecondaryRow(book.Worksheets, ZWAR)
      Next
      'Me.CloseHPRPNWorksheet(book.Worksheets)
      book.Save(stream)
    End Sub

#Region " Generate Styles "
    Private Sub GenerateStyles(ByVal styles As WorksheetStyleCollection)
      '-----------------------------------------------
      ' Default
      '-----------------------------------------------
      Dim [Default] As WorksheetStyle = styles.Add("Default")
      [Default].Name = "Normal"
      [Default].Font.FontName = "Arial"
      [Default].Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s16
      '-----------------------------------------------
      Dim s16 As WorksheetStyle = styles.Add("s16")
      s16.Name = "Hyperlink"
      s16.Font.Bold = True
      s16.Font.Underline = UnderlineStyle.[Single]
      s16.Font.FontName = "Arial"
      s16.Font.Size = 14
      s16.Interior.Color = "#C0C0C0"
      s16.Interior.Pattern = StyleInteriorPattern.Solid
      s16.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s16.Alignment.Vertical = StyleVerticalAlignment.Center
      '-----------------------------------------------
      ' s17
      '-----------------------------------------------
      Dim s17 As WorksheetStyle = styles.Add("s17")
      s17.Name = "Normal 2"
      s17.Font.FontName = "Arial"
      s17.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s18
      '-----------------------------------------------
      Dim s18 As WorksheetStyle = styles.Add("s18")
      s18.Name = "Normal 3"
      s18.Font.FontName = "Arial"
      s18.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s19
      '-----------------------------------------------
      Dim s19 As WorksheetStyle = styles.Add("s19")
      s19.Name = "Normal_4x4-5x5 Test"
      s19.Font.FontName = "Arial"
      s19.Font.Color = "#000000"
      s19.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s20
      '-----------------------------------------------
      Dim s20 As WorksheetStyle = styles.Add("s20")
      s20.Font.Bold = True
      s20.Font.FontName = "Arial"
      's20.Font.Size = 8
      s20.Interior.Color = "#C0C0C0"
      s20.Interior.Pattern = StyleInteriorPattern.Solid
      s20.Alignment.Vertical = StyleVerticalAlignment.Top
      s20.Alignment.WrapText = True
      's20.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      's20.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      's20.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      's20.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s21
      '-----------------------------------------------
      Dim s21 As WorksheetStyle = styles.Add("s21")
      s21.Font.Bold = True
      s21.Font.FontName = "Arial"
      s21.Font.Size = 8
      s21.Interior.Color = "#C0C0C0"
      s21.Interior.Pattern = StyleInteriorPattern.Solid
      s21.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s21.Alignment.Vertical = StyleVerticalAlignment.Center
      s21.Alignment.WrapText = True
      s21.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s21.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s21.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s21.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s22
      '-----------------------------------------------
      Dim s22 As WorksheetStyle = styles.Add("s22")
      s22.Font.Bold = True
      s22.Font.FontName = "Arial"
      s22.Font.Size = 8
      s22.Interior.Color = "#C0C0C0"
      s22.Interior.Pattern = StyleInteriorPattern.Solid
      s22.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s22.Alignment.Vertical = StyleVerticalAlignment.Center
      s22.Alignment.WrapText = True
      s22.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s22.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s22.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s22.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s23
      '-----------------------------------------------
      Dim s23 As WorksheetStyle = styles.Add("s23")
      s23.Font.Bold = True
      s23.Font.FontName = "Arial"
      s23.Font.Size = 8
      s23.Interior.Color = "#C0C0C0"
      s23.Interior.Pattern = StyleInteriorPattern.Solid
      s23.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s23.Alignment.Vertical = StyleVerticalAlignment.Center
      s23.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s23.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s23.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s23.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s24
      '-----------------------------------------------
      Dim s24 As WorksheetStyle = styles.Add("s24")
      s24.Parent = "s16"
      s24.Interior.Color = "#C0C0C0"
      s24.Interior.Pattern = StyleInteriorPattern.Solid
      s24.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s24.Alignment.Vertical = StyleVerticalAlignment.Center
      s24.Alignment.WrapText = True
      s24.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s24.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s24.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s24.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s25
      '-----------------------------------------------
      Dim s25 As WorksheetStyle = styles.Add("s25")
      s25.Parent = "s16"
      s25.Font.Bold = True
      s25.Font.Underline = UnderlineStyle.[Single]
      s25.Font.FontName = "Arial"
      s25.Font.Size = 8
      s25.Font.Color = "#0000FF"
      s25.Interior.Color = "#C0C0C0"
      s25.Interior.Pattern = StyleInteriorPattern.Solid
      s25.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s25.Alignment.Vertical = StyleVerticalAlignment.Center
      s25.Alignment.WrapText = True
      s25.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s25.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s25.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s25.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s26
      '-----------------------------------------------
      Dim s26 As WorksheetStyle = styles.Add("s26")
      s26.Parent = "s16"
      s26.Interior.Color = "#C0C0C0"
      s26.Interior.Pattern = StyleInteriorPattern.Solid
      s26.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s26.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s26.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s26.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s27
      '-----------------------------------------------
      Dim s27 As WorksheetStyle = styles.Add("s27")
      s27.Font.Bold = True
      s27.Font.FontName = "Arial"
      s27.Font.Size = 8
      s27.Interior.Color = "#C0C0C0"
      s27.Interior.Pattern = StyleInteriorPattern.Solid
      s27.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s27.Alignment.WrapText = True
      s27.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s27.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s27.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s28
      '-----------------------------------------------
      Dim s28 As WorksheetStyle = styles.Add("s28")
      s28.Font.Bold = True
      s28.Font.FontName = "Arial"
      s28.Font.Size = 8
      s28.Interior.Color = "#C0C0C0"
      s28.Interior.Pattern = StyleInteriorPattern.Solid
      s28.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s28.Alignment.Vertical = StyleVerticalAlignment.Center
      s28.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s28.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s28.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s28.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s29
      '-----------------------------------------------
      Dim s29 As WorksheetStyle = styles.Add("s29")
      s29.Interior.Color = "#C0C0C0"
      s29.Interior.Pattern = StyleInteriorPattern.Solid
      '-----------------------------------------------
      ' s30
      '-----------------------------------------------
      Dim s30 As WorksheetStyle = styles.Add("s30")
      s30.Interior.Color = "#C0C0C0"
      s30.Interior.Pattern = StyleInteriorPattern.Solid
      s30.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s31
      '-----------------------------------------------
      Dim s31 As WorksheetStyle = styles.Add("s31")
      s31.Font.FontName = "Arial"
      s31.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s32
      '-----------------------------------------------
      Dim s32 As WorksheetStyle = styles.Add("s32")
      s32.Font.FontName = "Arial"
      s32.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s33
      '-----------------------------------------------
      Dim s33 As WorksheetStyle = styles.Add("s33")
      '-----------------------------------------------
      ' s34
      '-----------------------------------------------
      Dim s34 As WorksheetStyle = styles.Add("s34")
      s34.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s34.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s34.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s34.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s34.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s34.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s34.NumberFormat = "@"
      '-----------------------------------------------
      ' s35
      '-----------------------------------------------
      Dim s35 As WorksheetStyle = styles.Add("s35")
      s35.Font.FontName = "Arial"
      s35.Font.Size = 8
      s35.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s35.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s35.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s35.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s35.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s35.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s35.NumberFormat = "@"
      '-----------------------------------------------
      ' s36
      '-----------------------------------------------
      Dim s36 As WorksheetStyle = styles.Add("s36")
      s36.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s36.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s36.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s36.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s36.NumberFormat = "@"
      '-----------------------------------------------
      ' s36b
      '-----------------------------------------------
      Dim s36b As WorksheetStyle = styles.Add("s36b")
      s36b.Font.Bold = True
      s36b.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s36b.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s36b.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s36b.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s36b.NumberFormat = "@"
      '-----------------------------------------------
      ' s37
      '-----------------------------------------------
      Dim s37 As WorksheetStyle = styles.Add("s37")
      s37.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s37.Alignment.Vertical = StyleVerticalAlignment.Center
      s37.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s37.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s37.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s37.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s37.NumberFormat = "@"
      '-----------------------------------------------
      ' s37r
      '-----------------------------------------------
      Dim s37r As WorksheetStyle = styles.Add("s37r")
      s37r.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s37r.Alignment.Vertical = StyleVerticalAlignment.Center
      s37r.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s37r.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s37r.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s37r.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s37r.NumberFormat = "@"
      s37r.Font.Color = "#FF0000"
      '-----------------------------------------------
      ' s37b
      '-----------------------------------------------
      Dim s37b As WorksheetStyle = styles.Add("s37b")
      s37b.Font.Bold = True
      s37b.Alignment.Horizontal = StyleHorizontalAlignment.Center
      s37b.Alignment.Vertical = StyleVerticalAlignment.Center
      s37b.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s37b.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s37b.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s37b.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s37b.NumberFormat = "@"
      '-----------------------------------------------
      ' s38
      '-----------------------------------------------
      Dim s38 As WorksheetStyle = styles.Add("s38")
      s38.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s39
      '-----------------------------------------------
      Dim s39 As WorksheetStyle = styles.Add("s39")
      s39.Font.FontName = "Arial"
      '-----------------------------------------------
      ' s40
      '-----------------------------------------------
      Dim s40 As WorksheetStyle = styles.Add("s40")
      s40.Interior.Color = "#C0C0C0"
      s40.Interior.Pattern = StyleInteriorPattern.Solid
      s40.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s41
      '-----------------------------------------------
      Dim s41 As WorksheetStyle = styles.Add("s41")
      s41.Font.Bold = True
      s41.Font.Italic = True
      s41.Font.FontName = "Symbol"
      s41.Interior.Color = "#C0C0C0"
      s41.Interior.Pattern = StyleInteriorPattern.Solid
      s41.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s42
      '-----------------------------------------------
      Dim s42 As WorksheetStyle = styles.Add("s42")
      s42.Interior.Color = "#C0C0C0"
      s42.Interior.Pattern = StyleInteriorPattern.Solid
      s42.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s42.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s43
      '-----------------------------------------------
      Dim s43 As WorksheetStyle = styles.Add("s43")
      s43.Font.Bold = True
      s43.Font.Italic = True
      s43.Font.FontName = "Symbol"
      s43.Interior.Color = "#C0C0C0"
      s43.Interior.Pattern = StyleInteriorPattern.Solid
      s43.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s43.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s44
      '-----------------------------------------------
      Dim s44 As WorksheetStyle = styles.Add("s44")
      s44.Interior.Color = "#C0C0C0"
      s44.Interior.Pattern = StyleInteriorPattern.Solid
      '-----------------------------------------------
      ' s45
      '-----------------------------------------------
      Dim s45 As WorksheetStyle = styles.Add("s45")
      s45.Interior.Color = "#C0C0C0"
      s45.Interior.Pattern = StyleInteriorPattern.Solid
      s45.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      '-----------------------------------------------
      ' s46
      '-----------------------------------------------
      Dim s46 As WorksheetStyle = styles.Add("s46")
      s46.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s46.Alignment.WrapText = True
      s46.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s46.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s46.NumberFormat = "@"
      '-----------------------------------------------
      ' s47
      '-----------------------------------------------
      Dim s47 As WorksheetStyle = styles.Add("s47")
      s47.NumberFormat = "@"
      '-----------------------------------------------
      ' s48
      '-----------------------------------------------
      Dim s48 As WorksheetStyle = styles.Add("s48")
      s48.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s48.Alignment.Vertical = StyleVerticalAlignment.Top
      s48.Alignment.WrapText = True
      s48.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1)
      s48.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1)
      s48.NumberFormat = "@"
      '-----------------------------------------------
      ' s49
      '-----------------------------------------------
      Dim s49 As WorksheetStyle = styles.Add("s49")
      s49.Parent = "s19"
      s49.Font.FontName = "Arial"
      s49.Font.Color = "#FFFFFF"
      s49.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s49.Alignment.WrapText = True
      s49.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1, "#C0C0C0")
      s49.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1, "#C0C0C0")
      s49.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1, "#C0C0C0")
      s49.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1, "#C0C0C0")
      '-----------------------------------------------
      ' s50
      '-----------------------------------------------
      Dim s50 As WorksheetStyle = styles.Add("s50")
      s50.Parent = "s17"
      s50.Font.FontName = "Arial"
      s50.Font.Color = "#FFFFFF"
      s50.NumberFormat = "@"
      '-----------------------------------------------
      ' s51
      '-----------------------------------------------
      Dim s51 As WorksheetStyle = styles.Add("s51")
      s51.Parent = "s19"
      s51.Font.FontName = "Arial"
      s51.Font.Color = "#FFFFFF"
      s51.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s51.Alignment.WrapText = True
      s51.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1, "#C0C0C0")
      s51.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1, "#C0C0C0")
      '-----------------------------------------------
      ' s52
      '-----------------------------------------------
      Dim s52 As WorksheetStyle = styles.Add("s52")
      s52.Parent = "s19"
      s52.Font.FontName = "Arial"
      s52.Font.Color = "#FFFFFF"
      s52.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s52.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s52.Alignment.WrapText = True
      s52.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1, "#C0C0C0")
      s52.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1, "#C0C0C0")
      s52.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1, "#C0C0C0")
      s52.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1, "#C0C0C0")
      '-----------------------------------------------
      ' s53
      '-----------------------------------------------
      Dim s53 As WorksheetStyle = styles.Add("s53")
      s53.Parent = "s18"
      s53.Font.FontName = "Arial"
      s53.Font.Color = "#FFFFFF"
      s53.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s53.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s55
      '-----------------------------------------------
      Dim s55 As WorksheetStyle = styles.Add("s55")
      s55.Parent = "s18"
      s55.Font.FontName = "Arial"
      s55.Font.Color = "#FFFFFF"
      s55.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s55.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s56
      '-----------------------------------------------
      Dim s56 As WorksheetStyle = styles.Add("s56")
      s56.Font.FontName = "Arial"
      s56.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s57
      '-----------------------------------------------
      Dim s57 As WorksheetStyle = styles.Add("s57")
      s57.Font.FontName = "Arial"
      s57.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s58
      '-----------------------------------------------
      Dim s58 As WorksheetStyle = styles.Add("s58")
      s58.Parent = "s19"
      s58.Font.FontName = "Arial"
      s58.Font.Color = "#FFFFFF"
      s58.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s58.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s58.Alignment.WrapText = True
      s58.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1, "#C0C0C0")
      s58.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1, "#C0C0C0")
      '-----------------------------------------------
      ' s59
      '-----------------------------------------------
      Dim s59 As WorksheetStyle = styles.Add("s59")
      s59.Font.FontName = "Arial"
      s59.Font.Color = "#FF0000"
      '-----------------------------------------------
      ' s60
      '-----------------------------------------------
      Dim s60 As WorksheetStyle = styles.Add("s60")
      s60.Font.FontName = "Arial"
      s60.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s61
      '-----------------------------------------------
      Dim s61 As WorksheetStyle = styles.Add("s61")
      s61.Font.FontName = "Arial"
      s61.Font.Color = "#FFFFFF"
      s61.NumberFormat = "@"
      '-----------------------------------------------
      ' s62
      '-----------------------------------------------
      Dim s62 As WorksheetStyle = styles.Add("s62")
      s62.Font.FontName = "Arial"
      s62.Font.Size = 8
      s62.Font.Color = "#FFFFFF"
      '-----------------------------------------------
      ' s67
      '-----------------------------------------------
      Dim s67 As WorksheetStyle = styles.Add("s67")
      s67.Font.Bold = True
      s67.Font.FontName = "Arial"
      s67.Font.Size = 14
      s67.Interior.Color = "#C0C0C0"
      s67.Interior.Pattern = StyleInteriorPattern.Solid
      s67.Alignment.Horizontal = StyleHorizontalAlignment.Left
      s67.Alignment.Vertical = StyleVerticalAlignment.Bottom
      '-----------------------------------------------
      ' s70
      '-----------------------------------------------
      Dim s70 As WorksheetStyle = styles.Add("s70")
      s70.Font.Bold = True
      s70.Font.Italic = True
      s70.Font.FontName = "Symbol"
      s70.Interior.Color = "#C0C0C0"
      s70.Interior.Pattern = StyleInteriorPattern.Solid
      s70.Alignment.Vertical = StyleVerticalAlignment.Bottom
      s70.Alignment.WrapText = True
    End Sub
#End Region

#Region " Open HPRPN Worksheet "
    Private Sub GenerateWorksheet(ByVal sheets As WorksheetCollection)
      Dim sheet As Worksheet = sheets.Add("ImageBOM")
      sheet.Table.ExpandedColumnCount = 30
      'sheet.Table.ExpandedRowCount = 2529
      sheet.Table.FullColumns = 1
      sheet.Table.FullRows = 1
      sheet.Table.Columns.Add(75)
      sheet.Table.Columns.Add(149)
      sheet.Table.Columns.Add(46)
      sheet.Table.Columns.Add(149)
      sheet.Table.Columns.Add(46)
      sheet.Table.Columns.Add(46)
      sheet.Table.Columns.Add(100)
      sheet.Table.Columns.Add(200)
      'Dim column7 As WorksheetColumn = sheet.Table.Columns.Add
      'column7.Width = 50
      'column7.Span = 1
      'Dim column8 As WorksheetColumn = sheet.Table.Columns.Add
      'column8.Index = 10
      'column8.Width = 53
      'sheet.Table.Columns.Add(85)
      'sheet.Table.Columns.Add(191)
      'sheet.Table.Columns.Add(531)
      'Dim column12 As WorksheetColumn = sheet.Table.Columns.Add
      'column12.Width = 35
      'column12.Span = 1
      'Dim column13 As WorksheetColumn = sheet.Table.Columns.Add
      'column13.Index = 16
      'column13.Width = 182
      'sheet.Table.Columns.Add(33)
      'sheet.Table.Columns.Add(61)
      'sheet.Table.Columns.Add(53)
      'sheet.Table.Columns.Add(97)
      'Dim column18 As WorksheetColumn = sheet.Table.Columns.Add
      'column18.Index = 24
      'column18.Width = 282
      'Dim column19 As WorksheetColumn = sheet.Table.Columns.Add
      'column19.Index = 30
      'column19.Width = 94
      '-----------------------------------------------
      Dim Row0 As WorksheetRow = sheet.Table.Rows.Add
      Row0.Height = 18
      Dim cell As WorksheetCell
      cell = Row0.Cells.Add
      cell.StyleID = "s16"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "HOU NPI BOMS - PSG"
      cell.HRef = "mailto:HOU%20NPI%20BOMS-PSG" '& _
      '" Product Data Standards for PMG/Material Type ver 1.8.doc"
      'cell.Data.Text = "Request Pan-HP Product Number - Revision H 9/21/2009 rev. A"
      cell.MergeAcross = 7
      'cell = Row0.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row0.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row0.Cells.Add
      'cell.StyleID = "s30"
      '-----------------------------------------------
      Dim Row1 As WorksheetRow = sheet.Table.Rows.Add
      cell = Row1.Cells.Add
      cell.StyleID = "s40"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "INSTRUCTIONS: Save request. Click address above & attach file to email."
      cell.MergeAcross = 7
      'cell = Row1.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row1.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row1.Cells.Add
      'cell.StyleID = "s30"
      '-----------------------------------------------
      Dim Row10 As WorksheetRow = sheet.Table.Rows.Add
      Row10.Height = 13
      Row10.AutoFitHeight = False
      cell = Row10.Cells.Add
      cell.StyleID = "s29"
      cell = Row10.Cells.Add
      cell.StyleID = "s29"
      cell.NamedCell.Add("Header")
      cell = Row10.Cells.Add
      cell.StyleID = "s29"
      cell = Row10.Cells.Add
      cell.StyleID = "s29"
      cell = Row10.Cells.Add
      cell.StyleID = "s29"
      cell = Row10.Cells.Add
      cell.StyleID = "s29"
      cell = Row10.Cells.Add
      cell.StyleID = "s29"
      cell = Row10.Cells.Add
      cell.StyleID = "s29"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s43"
      '-----------------------------------------------
      Dim Row2 As WorksheetRow = sheet.Table.Rows.Add
      cell = Row2.Cells.Add
      cell.StyleID = "s20"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Date:"
      cell.NamedCell.Add("Data")

      cell = Row2.Cells.Add
      cell.StyleID = "s40"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = Date.Today
      cell.MergeAcross = 6
      cell.NamedCell.Add("Data")
      'cell = Row2.Cells.Add
      'cell.StyleID = "s40"
      'cell = Row2.Cells.Add
      'cell.StyleID = "s40"
      'cell = Row2.Cells.Add
      'cell.StyleID = "s42"
      '-----------------------------------------------
      'Dim Row3 As WorksheetRow = sheet.Table.Rows.Add
      'cell = Row3.Cells.Add
      'cell.StyleID = "s40"
      'cell.Data.Type = DataType.[String]
      'cell.Data.Text = Date.Today
      'cell.MergeAcross = 7
      '-----------------------------------------------
      Dim Row4 As WorksheetRow = sheet.Table.Rows.Add
      Row4.Height = 13
      Row4.AutoFitHeight = False
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell.NamedCell.Add("Header")
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      cell = Row4.Cells.Add
      cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row4.Cells.Add
      'cell.StyleID = "s43"
      ''-----------------------------------------------
      Dim Row5 As WorksheetRow = sheet.Table.Rows.Add
      cell = Row5.Cells.Add
      cell.StyleID = "s20"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Requestor:"
      'cell.MergeAcross = 7

      cell = Row5.Cells.Add
      cell.StyleID = "s40"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = UserName
      cell.MergeAcross = 6
      cell.NamedCell.Add("Data")
      'cell = Row5.Cells.Add
      'cell.StyleID = "s40"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s40"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s42"
      '-----------------------------------------------
      'Dim Row6 As WorksheetRow = sheet.Table.Rows.Add
      'cell = Row6.Cells.Add
      'cell.StyleID = "s40"
      'cell.Data.Type = DataType.[String]
      'cell.Data.Text = "UserName"
      'cell.MergeAcross = 7
      '-----------------------------------------------
      Dim Row7 As WorksheetRow = sheet.Table.Rows.Add
      Row7.Height = 13
      Row4.AutoFitHeight = False
      cell = Row7.Cells.Add
      cell.StyleID = "s29"
      cell = Row7.Cells.Add
      cell.StyleID = "s29"
      cell.NamedCell.Add("Header")
      cell = Row7.Cells.Add
      cell.StyleID = "s29"
      cell = Row7.Cells.Add
      cell.StyleID = "s29"
      cell = Row7.Cells.Add
      cell.StyleID = "s29"
      cell = Row7.Cells.Add
      cell.StyleID = "s29"
      cell = Row7.Cells.Add
      cell.StyleID = "s29"
      cell = Row7.Cells.Add
      cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s43"
      ''-----------------------------------------------
      Dim Row8 As WorksheetRow = sheet.Table.Rows.Add
      cell = Row8.Cells.Add
      cell.StyleID = "s20"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Product Type:"

      cell = Row8.Cells.Add
      cell.StyleID = "s40"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "PSG Notebook"
      cell.MergeAcross = 6
      cell.NamedCell.Add("Data")
      'cell.MergeAcross = 7
      'cell = Row8.Cells.Add
      'cell.StyleID = "s40"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s40"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s42"
      '-----------------------------------------------
      'Dim Row9 As WorksheetRow = sheet.Table.Rows.Add
      'cell = Row9.Cells.Add
      'cell.StyleID = "s40"
      'cell.Data.Type = DataType.[String]
      'cell.Data.Text = "PSG Notebook"
      'cell.MergeAcross = 7
      'cell = Row9.Cells.Add
      'cell.StyleID = "s40"
      'cell = Row9.Cells.Add
      'cell.StyleID = "s40"
      'cell = Row9.Cells.Add
      'cell.StyleID = "s42"
      '-----------------------------------------------
      '-----------------------------------------------
      Dim Row11 As WorksheetRow = sheet.Table.Rows.Add
      Row11.Height = 13
      Row11.AutoFitHeight = False
      cell = Row11.Cells.Add
      cell.StyleID = "s29"
      cell = Row11.Cells.Add
      cell.StyleID = "s29"
      cell.NamedCell.Add("Header")
      cell = Row11.Cells.Add
      cell.StyleID = "s29"
      cell = Row11.Cells.Add
      cell.StyleID = "s29"
      cell = Row11.Cells.Add
      cell.StyleID = "s29"
      cell = Row11.Cells.Add
      cell.StyleID = "s29"
      cell = Row11.Cells.Add
      cell.StyleID = "s29"
      cell = Row11.Cells.Add
      cell.StyleID = "s29"
      'cell = Row11.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row11.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row11.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row11.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row11.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row11.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row11.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row11.Cells.Add
      'cell.StyleID = "s41"
      'cell = Row11.Cells.Add
      'cell.StyleID = "s43"
      '-----------------------------------------------
      'Dim Row5 As WorksheetRow = sheet.Table.Rows.Add
      'Row5.Height = 27
      'Row5.AutoFitHeight = false
      'cell = Row5.Cells.Add
      'cell.StyleID = "s20"
      'cell.Data.Type = DataType.[String]
      'cell.Data.Text = "Project Number"&Global.Microsoft.VisualBasic.ChrW(10)&"(Required)"
      'cell.Comment.Author = "Sue Schultz"
      'cell.Comment.Data.Text = "A valid project number is required. To request a project number, contact Mamie Wa"& _ 
      '    "shington for the correct procedure. "&Global.Microsoft.VisualBasic.ChrW(10)&Global.Microsoft.VisualBasic.ChrW(10)&"Do not use a number starting with 009xx; t"& _ 
      '    "hose numbers signal alias project number. "&Global.Microsoft.VisualBasic.ChrW(10)&Global.Microsoft.VisualBasic.ChrW(10)&"To request alias product/part number"& _ 
      '    "s, go to Excel Request Forms > Alias Request Form."
      'cell = Row5.Cells.Add
      'cell.StyleID = "s34"
      'cell.NamedCell.Add("Header")
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row5.Cells.Add
      'cell.StyleID = "s30"
      ''-----------------------------------------------
      'Dim Row6 As WorksheetRow = sheet.Table.Rows.Add
      'Row6.Height = 27
      'Row6.AutoFitHeight = false
      'cell = Row6.Cells.Add
      'cell.StyleID = "s22"
      'cell.Data.Type = DataType.[String]
      'cell.Data.Text = "Lab/Office "&Global.Microsoft.VisualBasic.ChrW(10)&"(Required)"
      'cell.Comment.Author = "Patrick McMahon"
      'cell.Comment.Data.Text = "Click once to display a list of the Lab/Office values. "&Global.Microsoft.VisualBasic.ChrW(10)&Global.Microsoft.VisualBasic.ChrW(10)&"Enter the code designati"& _ 
      '    "ng the site that has accepted responsibility to perform one or more of the PPR a"& _ 
      '    "reas of responsibility as designated by the PPR business unit:"&Global.Microsoft.VisualBasic.ChrW(10)&"-Material master "& _ 
      '    "creation/maintenance"&Global.Microsoft.VisualBasic.ChrW(10)&"-BOM creation/maintenance"&Global.Microsoft.VisualBasic.ChrW(10)&"-Document master creation/mainten"& _ 
      '    "ance"&Global.Microsoft.VisualBasic.ChrW(10)&"-Facilitation of the Engineering Change process"&Global.Microsoft.VisualBasic.ChrW(10)&Global.Microsoft.VisualBasic.ChrW(10)&"A business unit with PPR m"& _ 
      '    "ay function as a Lab/Office, but a Lab/Office cannot have PPR."
      'cell = Row6.Cells.Add
      'cell.StyleID = "s35"
      'cell.NamedCell.Add("Header")
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row6.Cells.Add
      'cell.StyleID = "s30"
      ''-----------------------------------------------
      'Dim Row7 As WorksheetRow = sheet.Table.Rows.Add
      'Row7.Height = 27
      'Row7.AutoFitHeight = false
      'cell = Row7.Cells.Add
      'cell.StyleID = "s23"
      'cell.Data.Type = DataType.[String]
      'cell.Data.Text = "PPR (Required)"
      'cell.Comment.Author = "malikbas"
      'cell.Comment.Data.Text = "Click once to display a list of the Product Part Responsibility (PPR) Values. "&Global.Microsoft.VisualBasic.ChrW(10)&Global.Microsoft.VisualBasic.ChrW(10)&"P"& _ 
      '    "PR designates the set of responsibilities given to an HP business or design grou"& _ 
      '    "p that intends to bring a product to market and to support it throughout the pro"& _ 
      '    "duct life cycle.  "&Global.Microsoft.VisualBasic.ChrW(10)&Global.Microsoft.VisualBasic.ChrW(10)&"The business group with PPR has these responsibilities throu"& _ 
      '    "ghout the life cycle, although they may delegate some responsibilities:"&Global.Microsoft.VisualBasic.ChrW(10)&"-Design "& _ 
      '    "control"&Global.Microsoft.VisualBasic.ChrW(10)&"-Change control"&Global.Microsoft.VisualBasic.ChrW(10)&"-Manufacturing responsibility"&Global.Microsoft.VisualBasic.ChrW(10)&"-Documentation responsibil"& _ 
      '    "ity"&Global.Microsoft.VisualBasic.ChrW(10)&"-Regulatory and reliability responsibility"&Global.Microsoft.VisualBasic.ChrW(10)&"-Product support responsibility"&Global.Microsoft.VisualBasic.ChrW(10)&"-"& _ 
      '    "Product discontinuance and obsolescence responsibility"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s35"
      'cell.NamedCell.Add("Header")
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s30"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row7.Cells.Add
      'cell.StyleID = "s38"
      ''-----------------------------------------------
      'Dim Row8 As WorksheetRow = sheet.Table.Rows.Add
      'Row8.Height = 27
      'Row8.AutoFitHeight = false
      'cell = Row8.Cells.Add
      'cell.StyleID = "s27"
      'cell.Data.Type = DataType.[String]
      'cell.Data.Text = "Product Category"&Global.Microsoft.VisualBasic.ChrW(10)&"(Required)"
      'cell.Comment.Author = "Patrick McMahon"
      'cell.Comment.Data.Text = "Product Category is Required. "&Global.Microsoft.VisualBasic.ChrW(10)&Global.Microsoft.VisualBasic.ChrW(10)&"Click in the box to the right and choose one of t"& _ 
      '    "he valid selections."
      'cell = Row8.Cells.Add
      'cell.StyleID = "s46"
      'cell.NamedCell.Add("Header")
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s29"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s45"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s44"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s30"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s38"
      'cell = Row8.Cells.Add
      'cell.StyleID = "s38"
      '-----------------------------------------------
      Dim Row12 As WorksheetRow = sheet.Table.Rows.Add
      Row12.Height = 25
      Row12.AutoFitHeight = False
      cell = Row12.Cells.Add
      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = ""
      cell.NamedCell.Add("Data")
      cell = Row12.Cells.Add
      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Bom"
      cell.NamedCell.Add("Data")
      cell = Row12.Cells.Add
      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Item No."
      cell.NamedCell.Add("Data")
      cell = Row12.Cells.Add
      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Bom Structure"
      cell.NamedCell.Add("Data")
      cell = Row12.Cells.Add
      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Qty"
      cell.NamedCell.Add("Data")
      cell = Row12.Cells.Add
      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Flag"
      cell.NamedCell.Add("Data")
      cell = Row12.Cells.Add
      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Usage Percentage"
      cell.NamedCell.Add("Data")
      cell = Row12.Cells.Add
      cell.StyleID = "s21"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Comments"
      cell.NamedCell.Add("Data")
      cell = Row12.Cells.Add
    End Sub
#End Region

#Region " Add Base Row "
    Sub GenerateBaseRow(ByVal Sheets As WorksheetCollection, ByVal AVNo As String, ByVal GPGDescription As String)
      Dim cell As New WorksheetCell
      Dim sheet As Worksheet = Sheets("ImageBOM")
      Dim Row10 As WorksheetRow = sheet.Table.Rows.Add
      cell = Row10.Cells.Add
      cell.StyleID = "s37b"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "New"
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s37b"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = AVNo
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36b"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = GPGDescription
      cell.NamedCell.Add("Data")
    End Sub
#End Region

#Region " Add Secondary Row "
    Sub GenerateSecondaryRow(ByVal Sheets As WorksheetCollection, ByVal ZWAR As String)
      Dim cell As New WorksheetCell
      Dim sheet As Worksheet = Sheets("ImageBOM")
      Dim Row10 As WorksheetRow = sheet.Table.Rows.Add
      cell = Row10.Cells.Add
      cell.StyleID = "s37"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = ""
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s37"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "Add"
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s37"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = ItemNumber
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s37"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = ZWAR
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s37"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "1"
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s37"
      cell.Data.Type = DataType.[String]
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s37"
      cell.Data.Type = DataType.[String]
      cell.Data.Text = "100"
      cell.NamedCell.Add("Data")

      cell = Row10.Cells.Add
      cell.StyleID = "s36"
      cell.NamedCell.Add("Data")

      'cell = Row10.Cells.Add
      'cell.StyleID = "s36"
      'cell.NamedCell.Add("Data")

      'cell = Row10.Cells.Add
      'cell.StyleID = "s36"
      'cell.Data.Type = DataType.[String]
      'cell.Data.Text = "C2"
      'cell.NamedCell.Add("Data")

      'cell = Row10.Cells.Add
      'cell.StyleID = "s36"
      'cell.NamedCell.Add("Data")

      'cell = Row10.Cells.Add
      'cell.StyleID = "s36"
      'cell.NamedCell.Add("Data")

      'cell = Row10.Cells.Add
      'cell.StyleID = "s48"
      'cell.Data.Type = DataType.String
      'cell.Data.Text = sGPGDesc
      'cell.NamedCell.Add("Data")


      'cell = Row10.Cells.Add
      'cell.StyleID = "s48"
      'cell.NamedCell.Add("Data")
      'cell = Row10.Cells.Add
      'cell.StyleID = "s36"
      'cell.NamedCell.Add("Data")
      'cell = Row10.Cells.Add
      'cell.StyleID = "s36"
      'cell.NamedCell.Add("Data")
      'cell = Row10.Cells.Add
      'cell.StyleID = "s36"
      'cell.NamedCell.Add("Data")
      'cell = Row10.Cells.Add
      'cell.StyleID = "s36"
      'cell.NamedCell.Add("Data")
      'cell = Row10.Cells.Add
      'cell.StyleID = "s39"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s39"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s39"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s39"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s39"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s39"
      'cell = Row10.Cells.Add
      'cell.StyleID = "s39"
    End Sub
#End Region

  End Class
End Namespace