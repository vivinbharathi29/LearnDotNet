﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;

namespace SkuToScrew
{
    public class SkuToScrew
    {
        #region ' Properties '


        private string _ServiceFamilyName = String.Empty;
        public string ServiceFamilyName
        {
            get { return _ServiceFamilyName; }
            set { _ServiceFamilyName = value; }
        }

        private string _serviceFamilyPn = string.Empty;
        public string ServiceFamilyPn
        {
            get
            {
                return _serviceFamilyPn;
            }
            set { _serviceFamilyPn = value; }
        }

        private string _Kmat = string.Empty;
        public string Kmat
        {
            get
            {
                return _Kmat;
            }
            set { _Kmat = value; }
        }

        private string _RegionName = string.Empty;
        public string RegionName
        {
            get
            {
                return _RegionName;
            }
            set { _RegionName = value; }
        }


        #endregion


        public void GenerateSkuToScrew(Stream SkuToScrewStream, ref string ErrorMessage, ref int numFiles)
        {
            GenerateDataRowSkuToScrew(SkuToScrewStream, ref ErrorMessage, ref numFiles);
        }


        private void GenerateDataRowSkuToScrew(Stream SkuToScrewStream, ref string ErrorMessage, ref int numFiles)
        {
            var dwExcalibur = new HPQ.Excalibur.Data();

            DataTable dt = dwExcalibur.SelectSKuToScrew(ServiceFamilyPn, RegionName, Kmat);

            int numRows = dt.Rows.Count;

            if (numRows == 0)
            {
                ErrorMessage = "SkuToScrew - No Data - Zero Rows Returned DataBase:  " + ServiceFamilyPn + ". ";
            }
            else
            {
                if (numRows < 200000) // one file
                {
                    CreateCSV(dt, SkuToScrewStream);
                }
                else
                {
                    ErrorMessage = "SkuToScrew - Big File - " + ServiceFamilyPn + ". ";

                    if (numRows < 400000)
                    {
                        numFiles = 2;
                        return;
                    }

                    if (numRows < 600000)
                    {
                        numFiles = 3;
                        return;
                    }

                    if (numRows < 800000)
                    {
                        numFiles = 4;
                        return;
                    }

                    if (numRows < 1000000)
                    {
                        numFiles = 5;
                        return;
                    }

                    if (numRows < 1200000)
                    {
                        numFiles = 6;
                        return;
                    }
                }
            }
        }

        public void Generate2SkuToScrew(Stream SkuToScrewStream, Stream SkuToScrewStream1, ref string ErrorMessage, ref int numFiles)
        {
            var dwExcalibur = new HPQ.Excalibur.Data();

            DataTable dt = dwExcalibur.SelectSKuToScrew(ServiceFamilyPn, RegionName, Kmat);
            if (dt.Rows.Count > 200000)
            {
                if (numFiles == 2) Create2CSV(dt, SkuToScrewStream, SkuToScrewStream1);
            }
        }

        public void Generate3SkuToScrew(Stream SkuToScrewStream, Stream SkuToScrewStream1, Stream SkuToScrewStream2, ref string ErrorMessage, ref int numFiles)
        {
            var dwExcalibur = new HPQ.Excalibur.Data();

            DataTable dt = dwExcalibur.SelectSKuToScrew(ServiceFamilyPn, RegionName, Kmat);
            if (dt.Rows.Count > 200000)
            {
                if (numFiles == 3) Create3CSV(dt, SkuToScrewStream, SkuToScrewStream1, SkuToScrewStream2);
            }
        }

        public void Generate4SkuToScrew(Stream SkuToScrewStream, Stream SkuToScrewStream1, Stream SkuToScrewStream2, Stream SkuToScrewStream3, ref string ErrorMessage, ref int numFiles)
        {
            var dwExcalibur = new HPQ.Excalibur.Data();

            DataTable dt = dwExcalibur.SelectSKuToScrew(ServiceFamilyPn, RegionName, Kmat);
            if (dt.Rows.Count > 200000)
            {
                if (numFiles == 4) Create4CSV(dt, SkuToScrewStream, SkuToScrewStream1, SkuToScrewStream2, SkuToScrewStream3);
            }
        }

        public void Generate5SkuToScrew(Stream SkuToScrewStream, Stream SkuToScrewStream1, Stream SkuToScrewStream2, Stream SkuToScrewStream3, Stream SkuToScrewStream4, ref string ErrorMessage, ref int numFiles)
        {
            var dwExcalibur = new HPQ.Excalibur.Data();

            DataTable dt = dwExcalibur.SelectSKuToScrew(ServiceFamilyPn, RegionName, Kmat);
            if (dt.Rows.Count > 200000)
            {
                if (numFiles == 5) Create5CSV(dt, SkuToScrewStream, SkuToScrewStream1, SkuToScrewStream2, SkuToScrewStream3, SkuToScrewStream4);
            }
        }

        public void Generate6SkuToScrew(Stream SkuToScrewStream, Stream SkuToScrewStream1, Stream SkuToScrewStream2, Stream SkuToScrewStream3, Stream SkuToScrewStream4, Stream SkuToScrewStream5, ref string ErrorMessage, ref int numFiles)
        {
            var dwExcalibur = new HPQ.Excalibur.Data();

            DataTable dt = dwExcalibur.SelectSKuToScrew(ServiceFamilyPn, RegionName, Kmat);
            if (dt.Rows.Count > 200000)
            {
                if (numFiles == 6) Create6CSV(dt, SkuToScrewStream, SkuToScrewStream1, SkuToScrewStream2, SkuToScrewStream3, SkuToScrewStream4, SkuToScrewStream5);
            }
        }


        private void CreateCSV(DataTable dt, Stream SkuToScrewStream)
        {
            var result = new StringBuilder();
            foreach (DataColumn column in dt.Columns)
            {
                result.Append(column.ColumnName);
                result.Append(",");
            }

            result.Remove(--result.Length, 0);
            result.Append(Environment.NewLine);

            foreach (DataRow row in dt.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    string itemAsString = item.ToString().Trim();
                    itemAsString = Escape(itemAsString);
                    result.Append(itemAsString + ",");
                }

                result.Remove(--result.Length, 0);
                result.Append(Environment.NewLine);
            }

            string s = result.ToString();

            s = s.TrimEnd(new char[] { '\r', '\n' });


            StreamWriter sw = new StreamWriter(SkuToScrewStream);
            sw.Write(s.ToString());
            sw.Flush();
        }

        private void Create2CSV(DataTable dt, Stream SkuToScrewStream, Stream SkuToScrewStream1)
        {
            var result = new StringBuilder();
            var resultFile2 = new StringBuilder();
            foreach (DataColumn column in dt.Columns)
            {
                result.Append(column.ColumnName);
                result.Append(",");

                resultFile2.Append(column.ColumnName);
                resultFile2.Append(",");
            }

            result.Remove(--result.Length, 0);
            result.Append(Environment.NewLine);

            resultFile2.Remove(--result.Length, 0);
            resultFile2.Append(Environment.NewLine);

            int numRows = 0;
            foreach (DataRow row in dt.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    string itemAsString = item.ToString().Trim();
                    itemAsString = Escape(itemAsString);
                    if (numRows < 200000)
                    {
                        result.Append(itemAsString + ",");
                    }
                    else
                    {
                        resultFile2.Append(itemAsString + ",");
                    }
                }

                if (numRows < 200000)
                {

                    result.Remove(--result.Length, 0);
                    result.Append(Environment.NewLine);
                }
                else
                {
                    resultFile2.Remove(--resultFile2.Length, 0);
                    resultFile2.Append(Environment.NewLine);
                }

                numRows++;
            }

            string s = result.ToString();
            s = s.TrimEnd(new char[] { '\r', '\n' });

            StreamWriter sw = new StreamWriter(SkuToScrewStream);
            sw.Write(s.ToString());
            sw.Flush();

            if (numRows > 200000)
            {
                string sFile2 = resultFile2.ToString();
                sFile2 = sFile2.TrimEnd(new char[] { '\r', '\n' });

                StreamWriter sw1 = new StreamWriter(SkuToScrewStream1);
                sw1.Write(sFile2.ToString());
                sw1.Flush();
            }
        }

        private void Create3CSV(DataTable dt, Stream SkuToScrewStream, Stream SkuToScrewStream1, Stream SkuToScrewStream2)
        {
            var result = new StringBuilder();
            var resultFile2 = new StringBuilder();
            var resultFile3 = new StringBuilder();

            foreach (DataColumn column in dt.Columns)
            {
                result.Append(column.ColumnName);
                result.Append(",");

                resultFile2.Append(column.ColumnName);
                resultFile2.Append(",");

                resultFile3.Append(column.ColumnName);
                resultFile3.Append(",");
            }

            result.Remove(--result.Length, 0);
            result.Append(Environment.NewLine);

            resultFile2.Remove(--result.Length, 0);
            resultFile2.Append(Environment.NewLine);

            resultFile3.Remove(--result.Length, 0);
            resultFile3.Append(Environment.NewLine);

            int numRows = 0;
            foreach (DataRow row in dt.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    string itemAsString = item.ToString().Trim();
                    itemAsString = Escape(itemAsString);
                    if (numRows < 200000)
                    {
                        result.Append(itemAsString + ",");
                    }
                    else
                    {
                        resultFile2.Append(itemAsString + ",");
                    }
                }

                if (numRows < 200000)
                {

                    result.Remove(--result.Length, 0);
                    result.Append(Environment.NewLine);
                }
                else
                {
                    if (numRows < 400000)
                    {
                        resultFile2.Remove(--resultFile2.Length, 0);
                        resultFile2.Append(Environment.NewLine);
                    }
                    else
                    {
                        resultFile3.Remove(--resultFile3.Length, 0);
                        resultFile3.Append(Environment.NewLine);
                    }
                }

                numRows++;
            }

            string s = result.ToString();
            s = s.TrimEnd(new char[] { '\r', '\n' });

            StreamWriter sw = new StreamWriter(SkuToScrewStream);
            sw.Write(s.ToString());
            sw.Flush();

            if (numRows > 200000)
            {
                string sFile2 = resultFile2.ToString();
                sFile2 = sFile2.TrimEnd(new char[] { '\r', '\n' });

                StreamWriter sw2 = new StreamWriter(SkuToScrewStream1);
                sw2.Write(sFile2.ToString());
                sw2.Flush();
            }

            if (numRows > 400000)
            {
                string sFile3 = resultFile3.ToString();
                sFile3 = sFile3.TrimEnd(new char[] { '\r', '\n' });

                StreamWriter sw3 = new StreamWriter(SkuToScrewStream2);
                sw3.Write(sFile3.ToString());
                sw3.Flush();
            }
        }

        private void Create4CSV(DataTable dt, Stream SkuToScrewStream, Stream SkuToScrewStream1, Stream SkuToScrewStream2, Stream SkuToScrewStream3)
        {
            var result = new StringBuilder();
            var resultFile2 = new StringBuilder();
            var resultFile3 = new StringBuilder();
            var resultFile4 = new StringBuilder();

            foreach (DataColumn column in dt.Columns)
            {
                result.Append(column.ColumnName);
                result.Append(",");

                resultFile2.Append(column.ColumnName);
                resultFile2.Append(",");

                resultFile3.Append(column.ColumnName);
                resultFile3.Append(",");

                resultFile4.Append(column.ColumnName);
                resultFile4.Append(",");
            }

            result.Remove(--result.Length, 0);
            result.Append(Environment.NewLine);

            resultFile2.Remove(--result.Length, 0);
            resultFile2.Append(Environment.NewLine);

            resultFile3.Remove(--result.Length, 0);
            resultFile3.Append(Environment.NewLine);

            resultFile4.Remove(--result.Length, 0);
            resultFile4.Append(Environment.NewLine);

            int numRows = 0;
            foreach (DataRow row in dt.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    string itemAsString = item.ToString().Trim();
                    itemAsString = Escape(itemAsString);
                    if (numRows < 200000)
                    {
                        result.Append(itemAsString + ",");
                    }
                    else
                    {
                        resultFile2.Append(itemAsString + ",");
                    }
                }

                if (numRows < 200000) //one file
                {

                    result.Remove(--result.Length, 0);
                    result.Append(Environment.NewLine);
                }
                else
                {
                    if (numRows < 400000) // 2 files
                    {
                        resultFile2.Remove(--resultFile2.Length, 0);
                        resultFile2.Append(Environment.NewLine);
                    }

                    if (numRows < 600000) // 3 files                      
                    {
                        resultFile3.Remove(--resultFile3.Length, 0);
                        resultFile3.Append(Environment.NewLine);
                    }

                    if (numRows < 800000) // 4 files                      
                    {
                        resultFile4.Remove(--resultFile4.Length, 0);
                        resultFile4.Append(Environment.NewLine);
                    }
                }

                numRows++;
            }

            if (numRows < 200000) //one file
            {
                string s = result.ToString();
                s = s.TrimEnd(new char[] { '\r', '\n' });

                StreamWriter sw = new StreamWriter(SkuToScrewStream);
                sw.Write(s.ToString());
                sw.Flush();
            }
            else
            {
                if (numRows < 400000) // 2 files
                {
                    string sFile2 = resultFile2.ToString();
                    sFile2 = sFile2.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw2 = new StreamWriter(SkuToScrewStream1);
                    sw2.Write(sFile2.ToString());
                    sw2.Flush();
                }
                if (numRows < 600000) // 3 files                      
                {
                    string sFile3 = resultFile3.ToString();
                    sFile3 = sFile3.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw3 = new StreamWriter(SkuToScrewStream2);
                    sw3.Write(sFile3.ToString());
                    sw3.Flush();
                }
                if (numRows < 800000) // 4 files                      
                {
                    string sFile4 = resultFile4.ToString();
                    sFile4 = sFile4.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw4 = new StreamWriter(SkuToScrewStream3);
                    sw4.Write(sFile4.ToString());
                    sw4.Flush();
                }
            }
        }

        private void Create5CSV(DataTable dt, Stream SkuToScrewStream, Stream SkuToScrewStream1, Stream SkuToScrewStream2, Stream SkuToScrewStream3, Stream SkuToScrewStream4)
        {
            var result = new StringBuilder();
            var resultFile2 = new StringBuilder();
            var resultFile3 = new StringBuilder();
            var resultFile4 = new StringBuilder();
            var resultFile5 = new StringBuilder();

            foreach (DataColumn column in dt.Columns)
            {
                result.Append(column.ColumnName);
                result.Append(",");

                resultFile2.Append(column.ColumnName);
                resultFile2.Append(",");

                resultFile3.Append(column.ColumnName);
                resultFile3.Append(",");

                resultFile4.Append(column.ColumnName);
                resultFile4.Append(",");

                resultFile5.Append(column.ColumnName);
                resultFile5.Append(",");
            }

            result.Remove(--result.Length, 0);
            result.Append(Environment.NewLine);

            resultFile2.Remove(--result.Length, 0);
            resultFile2.Append(Environment.NewLine);

            resultFile3.Remove(--result.Length, 0);
            resultFile3.Append(Environment.NewLine);

            resultFile4.Remove(--result.Length, 0);
            resultFile4.Append(Environment.NewLine);

            resultFile5.Remove(--result.Length, 0);
            resultFile5.Append(Environment.NewLine);

            int numRows = 0;
            foreach (DataRow row in dt.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    string itemAsString = item.ToString().Trim();
                    itemAsString = Escape(itemAsString);
                    if (numRows < 200000)
                    {
                        result.Append(itemAsString + ",");
                    }
                    else
                    {
                        resultFile2.Append(itemAsString + ",");
                    }
                }

                if (numRows < 200000) //one file
                {

                    result.Remove(--result.Length, 0);
                    result.Append(Environment.NewLine);
                }
                else
                {
                    if ((numRows > 200000) && (numRows < 400000)) // 2 files
                    {
                        resultFile2.Remove(--resultFile2.Length, 0);
                        resultFile2.Append(Environment.NewLine);
                    }

                    if ((numRows < 600000) && (numRows < 600000)) // 3 files                      
                    {
                        resultFile3.Remove(--resultFile3.Length, 0);
                        resultFile3.Append(Environment.NewLine);
                    }

                    if ((numRows < 800000) && (numRows < 600000)) // 4 files                      
                    {
                        resultFile4.Remove(--resultFile4.Length, 0);
                        resultFile4.Append(Environment.NewLine);
                    }

                    if ((numRows < 1000000) && (numRows < 800000)) // 5 files                      
                    {
                        resultFile5.Remove(--resultFile5.Length, 0);
                        resultFile5.Append(Environment.NewLine);
                    }
                }

                numRows++;
            }

            if (numRows < 200000) //one file
            {
                string s = result.ToString();
                s = s.TrimEnd(new char[] { '\r', '\n' });

                StreamWriter sw = new StreamWriter(SkuToScrewStream);
                sw.Write(s.ToString());
                sw.Flush();
            }
            else
            {
                if ((numRows > 200000) && (numRows < 400000))  // 2 files
                {
                    string sFile2 = resultFile2.ToString();
                    sFile2 = sFile2.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw2 = new StreamWriter(SkuToScrewStream1);
                    sw2.Write(sFile2.ToString());
                    sw2.Flush();
                }
                if ((numRows < 600000) && (numRows < 600000))// 3 files                      
                {
                    string sFile3 = resultFile3.ToString();
                    sFile3 = sFile3.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw3 = new StreamWriter(SkuToScrewStream2);
                    sw3.Write(sFile3.ToString());
                    sw3.Flush();
                }
                if ((numRows < 800000) && (numRows < 600000)) // 4 files                      
                {
                    string sFile4 = resultFile4.ToString();
                    sFile4 = sFile4.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw4 = new StreamWriter(SkuToScrewStream3);
                    sw4.Write(sFile4.ToString());
                    sw4.Flush();
                }

                if ((numRows < 1000000) && (numRows < 800000)) // 5 files                      
                {
                    string sFile5 = resultFile5.ToString();
                    sFile5 = sFile5.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw5 = new StreamWriter(SkuToScrewStream4);
                    sw5.Write(sFile5.ToString());
                    sw5.Flush();
                }
            }
        }

        private void Create6CSV(DataTable dt, Stream SkuToScrewStream, Stream SkuToScrewStream1, Stream SkuToScrewStream2, Stream SkuToScrewStream3, Stream SkuToScrewStream4, Stream SkuToScrewStream5)
        {
            var result = new StringBuilder();
            var resultFile2 = new StringBuilder();
            var resultFile3 = new StringBuilder();
            var resultFile4 = new StringBuilder();
            var resultFile5 = new StringBuilder();
            var resultFile6 = new StringBuilder();

            foreach (DataColumn column in dt.Columns)
            {
                result.Append(column.ColumnName);
                result.Append(",");

                resultFile2.Append(column.ColumnName);
                resultFile2.Append(",");

                resultFile3.Append(column.ColumnName);
                resultFile3.Append(",");

                resultFile4.Append(column.ColumnName);
                resultFile4.Append(",");

                resultFile5.Append(column.ColumnName);
                resultFile5.Append(",");

                resultFile6.Append(column.ColumnName);
                resultFile6.Append(",");
            }

            result.Remove(--result.Length, 0);
            result.Append(Environment.NewLine);

            resultFile2.Remove(--result.Length, 0);
            resultFile2.Append(Environment.NewLine);

            resultFile3.Remove(--result.Length, 0);
            resultFile3.Append(Environment.NewLine);

            resultFile4.Remove(--result.Length, 0);
            resultFile4.Append(Environment.NewLine);

            resultFile5.Remove(--result.Length, 0);
            resultFile5.Append(Environment.NewLine);

            resultFile6.Remove(--result.Length, 0);
            resultFile6.Append(Environment.NewLine);

            int numRows = 0;
            foreach (DataRow row in dt.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    string itemAsString = item.ToString().Trim();
                    itemAsString = Escape(itemAsString);
                    if (numRows < 200000)
                    {
                        result.Append(itemAsString + ",");
                    }
                    else
                    {
                        resultFile2.Append(itemAsString + ",");
                    }
                }

                if (numRows < 200000) //one file
                {

                    result.Remove(--result.Length, 0);
                    result.Append(Environment.NewLine);
                }
                else
                {
                    if ((numRows >= 200000) && (numRows < 400000)) // 2 files
                    {
                        resultFile2.Remove(--resultFile2.Length, 0);
                        resultFile2.Append(Environment.NewLine);
                    }

                    if ((numRows >= 400000) && (numRows < 600000)) // 3 files                      
                    {
                        resultFile3.Remove(--resultFile3.Length, 0);
                        resultFile3.Append(Environment.NewLine);
                    }

                    if ((numRows >= 600000) && (numRows < 800000)) // 4 files                      
                    {
                        resultFile4.Remove(--resultFile4.Length, 0);
                        resultFile4.Append(Environment.NewLine);
                    }

                    if ((numRows >= 800000) && (numRows < 1000000)) // 5 files                      
                    {
                        resultFile5.Remove(--resultFile5.Length, 0);
                        resultFile5.Append(Environment.NewLine);
                    }

                    if ((numRows >= 1000000) && (numRows < 1200000)) // 6 files                      
                    {
                        resultFile6.Remove(--resultFile6.Length, 0);
                        resultFile6.Append(Environment.NewLine);
                    }
                }

                numRows++;
            }

            if (numRows < 200000) //one file
            {
                string s = result.ToString();
                s = s.TrimEnd(new char[] { '\r', '\n' });

                StreamWriter sw = new StreamWriter(SkuToScrewStream);
                sw.Write(s.ToString());
                sw.Flush();
            }
            else
            {
                if ((numRows >= 200000) && (numRows < 400000))  // 2 files
                {
                    string sFile2 = resultFile2.ToString();
                    sFile2 = sFile2.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw2 = new StreamWriter(SkuToScrewStream1);
                    sw2.Write(sFile2.ToString());
                    sw2.Flush();
                }
                if ((numRows >= 400000) && (numRows < 600000))// 3 files                      
                {
                    string sFile3 = resultFile3.ToString();
                    sFile3 = sFile3.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw3 = new StreamWriter(SkuToScrewStream2);
                    sw3.Write(sFile3.ToString());
                    sw3.Flush();
                }
                if ((numRows >= 600000) && (numRows < 800000)) // 4 files                      
                {
                    string sFile4 = resultFile4.ToString();
                    sFile4 = sFile4.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw4 = new StreamWriter(SkuToScrewStream3);
                    sw4.Write(sFile4.ToString());
                    sw4.Flush();
                }

                if ((numRows >= 800000) && (numRows < 1000000)) // 5 files                      
                {
                    string sFile5 = resultFile5.ToString();
                    sFile5 = sFile5.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw5 = new StreamWriter(SkuToScrewStream4);
                    sw5.Write(sFile5.ToString());
                    sw5.Flush();
                }

                if ((numRows >= 1000000) && (numRows < 1200000)) // 6 files                      
                {
                    string sFile6 = resultFile6.ToString();
                    sFile6 = sFile6.TrimEnd(new char[] { '\r', '\n' });

                    StreamWriter sw6 = new StreamWriter(SkuToScrewStream5);
                    sw6.Write(sFile6.ToString());
                    sw6.Flush();
                }
            }
        }

        private const string COMMA = ",";
        private const string SEMICOLON = ";";
        private const string QUOTE = "\"";
        private const string ESCAPED_QUOTE = "\"\"";
        private static char[] CHARACTERS_THAT_MUST_BE_QUOTED = { '"', '\n' };

        public static string Escape(string s)
        {

            if (s.Contains(COMMA))
                s = s.Replace(COMMA, " ");

            if (s.Contains(SEMICOLON))
                s = s.Replace(SEMICOLON, " ");

            if (s.Contains(QUOTE))
                s = s.Replace(QUOTE, ESCAPED_QUOTE);

            if (s.IndexOfAny(CHARACTERS_THAT_MUST_BE_QUOTED) > -1)
                s = QUOTE + s + QUOTE;

            return s;
        }

    }


}
