using HPQ.Data;
using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;

namespace HPQ.Excalibur
{
    public class Data
    {

        public DataTable ListNewAvDescriptions(string BrandID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_ListNewAvDescriptions");

            dw.CreateParameter(cmd, "@p_BrandID", SqlDbType.Int, BrandID);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable ListScmNames(string ProductVersionID, string ProductBrandID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_ListScmNames");

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.Int, ProductVersionID);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);

            return dw.ExecuteCommandTable(cmd);
        }


        public DataTable SelectAvHistory(string ProductBrandID, string AvHistoryID, string ShowOnSCM, string ShowOnPM)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectAvHistory");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);
            dw.CreateParameter(cmd, "@p_AvHistoryID", SqlDbType.Int, AvHistoryID);
            dw.CreateParameter(cmd, "@p_ShowOnSCM", SqlDbType.Bit, ShowOnSCM);
            dw.CreateParameter(cmd, "@p_ShowOnPM", SqlDbType.Bit, ShowOnPM);
            dw.CreateParameter(cmd, "@p_ShowAll", SqlDbType.Bit, "");
            dw.CreateParameter(cmd, "@p_ShowDays", SqlDbType.Int, "");

            return dw.ExecuteCommandTable(cmd);
        }


        public DataTable SelectWorkingScmDetail(string ProductBrandID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectWorkingScmDetail");
            cmd.CommandTimeout = 3600;

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectKMAT(string ProductBrandID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectKmat");

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.Int, "");
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectKMAT(string ProductVersionID, string ProductBrandID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectKmat");

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.Int, ProductVersionID);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectProgramMatrix(string ProductBrandID, string CompareDt, bool Publish)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectProgramMatrix");
            cmd.CommandTimeout = 600;

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);
            dw.CreateParameter(cmd, "@p_CompareDt", SqlDbType.DateTime, CompareDt);
            dw.CreateParameter(cmd, "@p_Publish", SqlDbType.Bit, Publish.ToString());

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectKmatVersions(string ProductBrandId)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectKmatVersions");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandId);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectAvVersions(string ProductBrandId, string CompareDt, bool Publish)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectAvVersions");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandId);
            dw.CreateParameter(cmd, "@p_LastPublishDt", SqlDbType.DateTime, CompareDt);
            dw.CreateParameter(cmd, "@p_Publish", SqlDbType.Bit, Publish.ToString());

            return dw.ExecuteCommandTable(cmd);
        }

        public int SetPMPublish(string ProductBrandID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SetPMPublish");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        public DataTable SelectSparesMatrix(string ServiceFamilyPn, string CompareDt, bool Publish)
        {
            DataWrapper dw = new DataWrapper();

            SqlCommand cmd = dw.CreateCommand("usp_SelectSparesMatrix");
            cmd.CommandTimeout = 600;

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);
            dw.CreateParameter(cmd, "@p_Publish", SqlDbType.Bit, Publish.ToString());
            dw.CreateParameter(cmd, "@p_CompareDt", SqlDbType.DateTime, CompareDt);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectSpbDetails(string ServiceFamilyPn)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectSpbDetails");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);

            return dw.ExecuteCommandTable(cmd);
        }


        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, false)]
        public int InsertSpbChangeLog(string ServiceFamilyPartNo, string ExportDateTime, string SpareKitNo,
            string HpPartNo, string BomLevel, string ColumnChanged, string ChangeDetail)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_InsertSpbChangeLog");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.VarChar, ServiceFamilyPartNo, 10);
            dw.CreateParameter(cmd, "@p_ExportDateTime", SqlDbType.DateTime, ExportDateTime);
            dw.CreateParameter(cmd, "@p_SpareKitNo", SqlDbType.VarChar, SpareKitNo, 50);
            dw.CreateParameter(cmd, "@p_HpPartNo", SqlDbType.VarChar, HpPartNo, 50);
            dw.CreateParameter(cmd, "@p_BomLevel", SqlDbType.VarChar, BomLevel, 50);
            dw.CreateParameter(cmd, "@p_ColumnChanged", SqlDbType.VarChar, ColumnChanged, 50);
            dw.CreateParameter(cmd, "@p_ChangeDetails", SqlDbType.VarChar, ChangeDetail, 50);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        public DataTable SelectSpbChangeLog(string PartnerId, string DateDiffDays)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectSpbChanges");

            dw.CreateParameter(cmd, "@p_PartnerID", SqlDbType.Int, PartnerId);
            dw.CreateParameter(cmd, "@p_DateDiffDays", SqlDbType.Int, DateDiffDays);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectBOMExportDetail(string ProductBrandId)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectBOMExportDetail");

            dw.CreateParameter(cmd, "@BID", SqlDbType.Int, ProductBrandId.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectImagesWithAVNo(string KMAT)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectImagesWithAVNo");

            dw.CreateParameter(cmd, "@p_KMAT", SqlDbType.VarChar, KMAT.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectDocKitsByKMAT(string KMAT)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectDocKitsByKMAT");

            dw.CreateParameter(cmd, "@p_KMAT", SqlDbType.VarChar, KMAT.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectCOAsByKMAT(string KMAT)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectCOAsByKMAT");

            dw.CreateParameter(cmd, "@p_KMAT", SqlDbType.VarChar, KMAT.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectACAdaptersByKMAT(string KMAT)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectACAdaptersByKMAT");

            dw.CreateParameter(cmd, "@p_KMAT", SqlDbType.VarChar, KMAT.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectPhWebAvActionItems(String UserID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectPhWebAvActionItems2");

            dw.CreateParameter(cmd, "@UserID", SqlDbType.Int, UserID);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectPhWebAvActionItems(String UserID, String AutoInputOnly)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectPhWebAvActionItems2");

            dw.CreateParameter(cmd, "@UserID", SqlDbType.Int, UserID);
            dw.CreateParameter(cmd, "@AutoInputOnly", SqlDbType.Int, AutoInputOnly);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectHWKitsByKMAT(string KMAT)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectHWKitsByKMAT");

            dw.CreateParameter(cmd, "@p_KMAT", SqlDbType.VarChar, KMAT.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectPowerCords()
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectPowerCords");

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectKeyboardsByKMAT(string KMAT)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectKeyboardsByKMAT");

            dw.CreateParameter(cmd, "@p_KMAT", SqlDbType.VarChar, KMAT.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectACAdapters(string PVID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectACAdapters");

            dw.CreateParameter(cmd, "@p_PVID", SqlDbType.Int, PVID.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectKeyboards(string PVID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectKeyboards");

            dw.CreateParameter(cmd, "@p_PVID", SqlDbType.Int, PVID.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectPendingAvActions(string PVID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectPendingAvActions");

            dw.CreateParameter(cmd, "@p_PVID", SqlDbType.Int, PVID.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectAVActionScorecardReport(string PVIDs)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectAVActionScorecardReport");

            dw.CreateParameter(cmd, "@p_PVIDs", SqlDbType.VarChar, PVIDs.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectAVsOriginatedByDCR(string BusinessID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectAVsOriginatedByDCR");

            dw.CreateParameter(cmd, "@p_BusinessID", SqlDbType.Int, BusinessID.ToString());

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectSpbVersions(string ServiceFamilyPn)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectSpbVersions");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectSpareKitVersions(string ServiceFamilyPn, string CompareDt, bool Publish)
        {
            return SelectSpareKitVersions(ServiceFamilyPn, string.Empty, CompareDt, Publish);
        }

        public DataTable SelectSpareKitVersions(string ServiceFamilyPn, string SpareKitPn, string CompareDt, bool Publish)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectSpareKitVersions");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);
            dw.CreateParameter(cmd, "@p_SpareKitPn", SqlDbType.Char, SpareKitPn, 10);
            dw.CreateParameter(cmd, "@p_CompareDt", SqlDbType.DateTime, CompareDt);
            dw.CreateParameter(cmd, "@p_Publish", SqlDbType.Bit, Publish.ToString());

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectSKuToScrew(string ServiceFamilyPn, string Region, string Kmat)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectSkuToScrew");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);
            dw.CreateParameter(cmd, "@p_Region", SqlDbType.VarChar, Region, 50);
            if (Kmat != string.Empty) dw.CreateParameter(cmd, "@p_Kmat", SqlDbType.Char, Kmat, 10);
            return dw.ExecuteCommandTable(cmd);
        }
        public DataTable SelectRslHeader(string ServiceFamilyPn)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectRslHeader");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectRslSpareKitAvMappings(string ServiceFamilyPn, string ProductBrandId)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectRslSpareKitAvMapping");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.VarChar, ServiceFamilyPn, 10);
            dw.CreateParameter(cmd, "@p_ProductBrandId", SqlDbType.Int, ProductBrandId);

            return dw.ExecuteCommandTable(cmd);
        }
        #region ' Select RSL Data for Export '

        public DataTable SelectRslDetailsForExport(string ProductVersionId, bool PublishRsl, string CompareDt)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectRslDetailsForExport");

            dw.CreateParameter(cmd, "@p_ProductVersionId", SqlDbType.Int, ProductVersionId);
            dw.CreateParameter(cmd, "@p_Publish", SqlDbType.Bit, PublishRsl.ToString());
            dw.CreateParameter(cmd, "@p_LastPublishDt", SqlDbType.DateTime, CompareDt);

            return dw.ExecuteCommandTable(cmd);
        }
        #endregion

        #region ' Select RSL Change Log '
        public DataTable SelectRslChangeLog(string ServiceFamilyPn)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectRslHistory");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.VarChar, ServiceFamilyPn, 1000);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectRslChangeLog(string ServiceFamilyPn, string SinceLastPublish)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectRslHistory");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.VarChar, ServiceFamilyPn, 1000);
            dw.CreateParameter(cmd, "@p_SinceLastPublish", SqlDbType.Int, SinceLastPublish);

            return dw.ExecuteCommandTable(cmd);
        }

        #endregion

        public DataTable SelectRslAvChangeLog(string ServiceFamilyPn, string CompareDt)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectRslAvMappingChangeLog");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.VarChar, ServiceFamilyPn, 10);
            dw.CreateParameter(cmd, "@p_LastPublishDt", SqlDbType.DateTime, CompareDt);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable ListServiceFamilyDetails()
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_ListServiceFamilyDetails");

            return dw.ExecuteCommandTable(cmd);
        }

        public int InsertRslPublish(string ServiceFamilyPn, string UserName)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_InsertRslPublish");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);
            dw.CreateParameter(cmd, "@p_UserName", SqlDbType.VarChar, UserName, 50);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        public DataTable ListServiceFamilyBrands(string ServiceFamilyPn)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_ListServiceFamilyBrands");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);

            return dw.ExecuteCommandTable(cmd);
        }

        public string GetServiceFamilyPn(string ProductVersionId)
        {
            DataWrapper dw = new DataWrapper();

            return dw.ExecuteCommandScalarSP("usp_GetServiceFamilyPn", new SqlParameter("@p_ProductVersionId", ProductVersionId)).ToString();
        }
        public DateTime GetRslLastPublishDt(string ServiceFamilyPn)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectRslLastPublishDt");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.VarChar, ServiceFamilyPn, 10);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            DateTime returnValue = DateTime.MinValue;
            DateTime.TryParse(dt.Rows[0]["RslLastPublishDt"].ToString(), out returnValue);
            return returnValue;
        }

        public DataTable SelectBrandLocalizationData(string ProductBrandID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectBrandLocalizationData");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);

            return dw.ExecuteCommandTable(cmd);
        }

        public Int32 InsertScmPublishEvent(string ProductBrandID, string UserName)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_InsertScmPublishEvent");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);
            dw.CreateParameter(cmd, "@p_UserName", SqlDbType.VarChar, UserName, 50);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        public Int32 InsertScmScitPublishEvent(string ProductBrandId, string UserName)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_InsertScmScitPublishEvent");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandId);
            dw.CreateParameter(cmd, "@p_UserName", SqlDbType.VarChar, UserName, 50);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        public Int32 SetSCMPublishDt(string ProductBrandID, string UserName)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SetScmPublishDt");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);
            dw.CreateParameter(cmd, "@p_UserName", SqlDbType.VarChar, UserName, 50);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        public DataTable SelectSystemTeam(string ProductVersionID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectSystemTeam");

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.Int, ProductVersionID);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectAvHistory(string ProductBrandID, string AvHistoryID, string ShowOnSCM, string ShowOnPM, string ShowAll, string ShowDays)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectAvHistory");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);
            dw.CreateParameter(cmd, "@p_AvHistoryID", SqlDbType.Int, AvHistoryID);
            dw.CreateParameter(cmd, "@p_ShowOnSCM", SqlDbType.Bit, ShowOnSCM);
            dw.CreateParameter(cmd, "@p_ShowOnPM", SqlDbType.Bit, ShowOnPM);
            dw.CreateParameter(cmd, "@p_ShowAll", SqlDbType.Bit, ShowAll);
            dw.CreateParameter(cmd, "@p_ShowDays", SqlDbType.Int, ShowDays);

            return dw.ExecuteCommandTable(cmd);
        }

        public static DataTable SelectAvHistory_ByRegionView(string ProductBrandID, string RegionID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectAvHistory_ByRegionView");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);
            dw.CreateParameter(cmd, "@p_GeoID", SqlDbType.Int, RegionID);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectScmDetail(string ProductVersionID, string ProductBrandID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectScmDetail");
            cmd.CommandTimeout = 600;

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.Int, ProductVersionID);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectScmDetailByStatus(string ProductVersionID, string ProductBrandID, string Status)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectScmDetail");
            cmd.CommandTimeout = 600;

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.Int, ProductVersionID);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);
            dw.CreateParameter(cmd, "@p_Status", SqlDbType.VarChar, Status, 1);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectInitialOfferingExportData(string BusinessID, string Publish)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectInitialOfferingExportData");

            dw.CreateParameter(cmd, "@p_BusinessID", SqlDbType.Int, BusinessID);
            dw.CreateParameter(cmd, "@p_Publish", SqlDbType.Bit, Publish);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectInitialOfferingSubassemblyReport(string BusinessID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectInitialOfferingSubassemblyReport");

            dw.CreateParameter(cmd, "@p_BusinessID", SqlDbType.Int, BusinessID);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable GetMDAComplianceData(string ProductVersionID, string OSFamilyID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("rpt_MDACompliance");

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.Int, ProductVersionID);
            dw.CreateParameter(cmd, "@p_OSFamilyID", SqlDbType.Int, OSFamilyID);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable ListProducts(string MinimumStatusID, string MaximumStatusID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_ListProducts");

            dw.CreateParameter(cmd, "@p_MinimumStatusID", SqlDbType.Int, MinimumStatusID);
            dw.CreateParameter(cmd, "@p_MaximumStatusID", SqlDbType.Int, MaximumStatusID);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectImageSkuMatrix(string ProductVersionID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectImageTestMatrix");

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.Int, ProductVersionID);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectCommodityGuidanceProductsByProgram(string ProductProgram)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectCommodityGuidanceProductsByProgram");

            dw.CreateParameter(cmd, "@p_ProductProgram", SqlDbType.Int, ProductProgram);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectCommodityGuidanceReport(string ProgramID, string FeatureCategoryIDs)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectCommodityGuidanceReport");

            dw.CreateParameter(cmd, "@p_ProgramID", SqlDbType.Int, ProgramID);
            dw.CreateParameter(cmd, "@p_FeatureCategoryIDs", SqlDbType.VarChar, FeatureCategoryIDs);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        public DataTable SelectCommodityGuidanceProductData(string ProgramID, string FeatureCategoryIDs)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectCommodityGuidanceProductData");

            dw.CreateParameter(cmd, "@p_ProgramID", SqlDbType.Int, ProgramID);
            dw.CreateParameter(cmd, "@p_FeatureCategoryIDs", SqlDbType.VarChar, FeatureCategoryIDs);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            return dt;
        }

        #region ' For Spb Soluction '
        public string GetSpbLastPublishDt(string ServiceFamilyPn)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_GetSpbLastPublishDt");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);

            string returnValue = dw.ExecuteCommandScalar(cmd).ToString();

            return returnValue;
        }

        public DataTable ListPartners(int ReportType)
        {
            DataTable dt = ListPartners(ReportType.ToString(), string.Empty);
            return dt;
        }

        [DataObjectMethodAttribute(DataObjectMethodType.Select, true)]
        public DataTable ListPartners(string ReportType, string PartnerTypeId)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("spListPartners");

            dw.CreateParameter(cmd, "@ReportType", SqlDbType.Int, ReportType);
            dw.CreateParameter(cmd, "@PartnerTypeId", SqlDbType.Int, PartnerTypeId);

            return dw.ExecuteCommandTable(cmd);
        }

        public DataTable SelectKmatsInServiceFamilyPnRegion(string ServiceFamilyPn, string Region)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectKmatServicefamilyPnRegion");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);
            dw.CreateParameter(cmd, "@p_Region", SqlDbType.VarChar, Region, 50);
            return dw.ExecuteCommandTable(cmd);
        }

        public int UpdateSkuToScrewPublishDate(string ServiceFamilyPn)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_UpdateSkuToScrewPublishDate");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        public DateTime GetSKuToScrewPublishDate(string ServiceFamilyPn)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectSkuToScrewPublishDate");

            dw.CreateParameter(cmd, "@p_ServiceFamilyPn", SqlDbType.Char, ServiceFamilyPn, 10);

            DataTable dt = dw.ExecuteCommandTable(cmd);
            DateTime returnValue = DateTime.MinValue;
            DateTime.TryParse(dt.Rows[0]["SkuToScrewLastPublishDate"].ToString(), out returnValue);
            return returnValue;

        }

        #endregion

        #region ' Supplychain '
        public static DataTable SelectScmDetail_RegionAndPlatformsView_WithOutCats(string ProductVersionID, string ProductBrandID, string GeoID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectScmDetail_RegionAndPlatformsView_ByGeoID");
            cmd.CommandTimeout = 600;

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.VarChar, ProductVersionID, 8000);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.VarChar, ProductBrandID, 8000);
            dw.CreateParameter(cmd, "@p_GeoID", SqlDbType.Int, GeoID);

            return dw.ExecuteCommandTable(cmd);
        }

        public static DataTable SelectScmDetail_RegionAndPlatformsView_Plants_WithOutCats(string ProductVersionID, string ProductBrandID, string GeoID, string Plants)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectScmDetail_RegionAndPlatformsView_ByGeoID_PlantView");
            cmd.CommandTimeout = 600;

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.VarChar, ProductVersionID, 8000);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.VarChar, ProductBrandID, 8000);
            dw.CreateParameter(cmd, "@p_Status", SqlDbType.VarChar, "A", 1);
            dw.CreateParameter(cmd, "@p_Status2", SqlDbType.Char, "", 1);
            dw.CreateParameter(cmd, "@p_Categories", SqlDbType.Char, "", 1);
            dw.CreateParameter(cmd, "@p_GeoID", SqlDbType.Int, GeoID);
            dw.CreateParameter(cmd, "@p_Plants", SqlDbType.Int, Plants);

            return dw.ExecuteCommandTable(cmd);
        }

        public static DataTable SelectScmDetail_RegionAndPlatformsView_MktCamps_WithOutCats(string ProductVersionID, string ProductBrandID, string GeoID, string MktCamps)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectScmDetail_RegionAndPlatformsView_ByGeoID_MktCampView");
            cmd.CommandTimeout = 600;

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.VarChar, ProductVersionID, 8000);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.VarChar, ProductBrandID, 8000);
            dw.CreateParameter(cmd, "@p_Status", SqlDbType.Char, "A", 1);
            dw.CreateParameter(cmd, "@p_Status2", SqlDbType.Char, "", 1);
            dw.CreateParameter(cmd, "@p_Categories", SqlDbType.Char, "", 1);
            dw.CreateParameter(cmd, "@p_GeoID", SqlDbType.Int, GeoID);
            dw.CreateParameter(cmd, "@MktCampID", SqlDbType.Int, MktCamps);

            return dw.ExecuteCommandTable(cmd);
        }

        public static DataTable SelectScmDetailByStatus_RegionAndPlatformsView(string ProductVersionID, string ProductBrandID, string Status, string GeoID)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_SelectScmDetail_RegionAndPlatformsView_ByGeoID");
            cmd.CommandTimeout = 600;

            dw.CreateParameter(cmd, "@p_ProductVersionID", SqlDbType.Int, ProductVersionID);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);
            dw.CreateParameter(cmd, "@p_Status", SqlDbType.VarChar, Status, 1);

            return dw.ExecuteCommandTable(cmd);
        }

        #endregion

        #region For XmlSCMUploader

        public int GetProductBrandSortWeight(string ProductBrandId)
        {
            int weight = 0;
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_GetProductBrandSortWeight");
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandId);
            int.TryParse(dw.ExecuteCommandScalar(cmd).ToString(), out weight);

            return weight;
        }


        public int UpdateKmat(string ProductBrandId, string Kmat, string EzcKmat, string ProjectCd, string PlantCd, string SalesOrg, string LastUpdUser)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_UpdateKmat");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandId);
            dw.CreateParameter(cmd, "@p_Kmat", SqlDbType.VarChar, Kmat, 10);
            dw.CreateParameter(cmd, "@p_EzcKmat", SqlDbType.VarChar, EzcKmat, 10);
            dw.CreateParameter(cmd, "@p_ProjectCd", SqlDbType.VarChar, ProjectCd, 15);
            dw.CreateParameter(cmd, "@p_PlantCd", SqlDbType.VarChar, PlantCd, 15);
            dw.CreateParameter(cmd, "@p_SalesOrg", SqlDbType.VarChar, SalesOrg, 50);
            dw.CreateParameter(cmd, "@p_LastUpdUser", SqlDbType.VarChar, LastUpdUser, 50);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        public int UpdateAvFeatureDetail(string ProductBrandId, string FeatureCategoryId, string ConfigRules, string ManufacturingNotes, string MarketingDescription, string ChangeNotes, string LastUpdUser)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_UpdateAvFeatureDetail");

            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandId);
            dw.CreateParameter(cmd, "@p_FeatureCategoryID", SqlDbType.Int, FeatureCategoryId);
            dw.CreateParameter(cmd, "@p_ConfigRules", SqlDbType.VarChar, ConfigRules, 2000);
            dw.CreateParameter(cmd, "@p_ManufacturingNotes", SqlDbType.VarChar, ManufacturingNotes, 2000);
            dw.CreateParameter(cmd, "@p_MarketingDescription", SqlDbType.Char, MarketingDescription, 2000);
            dw.CreateParameter(cmd, "@p_ChangeNotes", SqlDbType.VarChar, ChangeNotes, 2000);
            dw.CreateParameter(cmd, "@p_LastUpdUser", SqlDbType.VarChar, LastUpdUser, 50);

            return dw.ExecuteCommandNonQuery(cmd);

        }

        public long InsertAvDetail(string FeatureCategoryId, string AvNo, string GpgDescription, string MarketingDescription, string ShowOnScm, string LastUpdUser)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_InsertAvDetail");
            int returnVal = 0;

            dw.CreateParameter(cmd, "@p_AvNo", SqlDbType.VarChar, AvNo, 18);
            dw.CreateParameter(cmd, "@p_FeatureCategoryID", SqlDbType.Int, FeatureCategoryId);
            dw.CreateParameter(cmd, "@p_GPGDescription", SqlDbType.VarChar, GpgDescription, 50);
            dw.CreateParameter(cmd, "@p_MarketingDescription", SqlDbType.VarChar, MarketingDescription, 40);
            dw.CreateParameter(cmd, "@p_ShowOnScm", SqlDbType.Bit, ShowOnScm);
            dw.CreateParameter(cmd, "@p_Last_Upd_User", SqlDbType.VarChar, LastUpdUser, 50);
            dw.CreateParameter(cmd, "@p_AvDetailID", SqlDbType.Int, string.Empty, ParameterDirection.Output);

            returnVal = dw.ExecuteCommandNonQuery(cmd);

            return Convert.ToInt64(cmd.Parameters["@p_AvDetailID"].Value);
        }

        public int UpdateAvProductDetail(string AvDetailId, string ProductBrandId,
                    string Status, string ProgramVersion, string ConfigRules, string ManufacturingNotes,
                    string IdsSkus, string IdsCto, string RctoSkus, string RctoCto, string SortOrder,
                    string ChangeNotes, string ShowOnScm, string GSEndDt, string LastUpdUser, string SDFFlag, string PhWebInstruction,
                    string AvId, string Group1, string Group2, string Group3, string Group4, string Group5, string BsamSkus, string BsamParts)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_UpdateAvDetail_ProductBrand");

            dw.CreateParameter(cmd, "@p_AvDetailID", SqlDbType.Int, AvDetailId);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandId);
            dw.CreateParameter(cmd, "@p_Status", SqlDbType.Char, Status, 1);
            dw.CreateParameter(cmd, "@p_ProgramVersion", SqlDbType.VarChar, ProgramVersion, 5);
            dw.CreateParameter(cmd, "@p_ConfigRules", SqlDbType.VarChar, ConfigRules, 2000);
            dw.CreateParameter(cmd, "@p_ManufacturingNotes", SqlDbType.VarChar, ManufacturingNotes, 2000);
            dw.CreateParameter(cmd, "@p_IdsSkus_YN", SqlDbType.Char, IdsSkus, 1);
            dw.CreateParameter(cmd, "@p_IdsCto_YN", SqlDbType.Char, IdsCto, 1);
            dw.CreateParameter(cmd, "@p_RctoSkus_YN", SqlDbType.Char, RctoSkus, 1);
            dw.CreateParameter(cmd, "@p_RctoCto_YN", SqlDbType.Char, RctoCto, 1);
            dw.CreateParameter(cmd, "@p_SortOrder", SqlDbType.Int, SortOrder);
            dw.CreateParameter(cmd, "@p_ChangeNotes", SqlDbType.VarChar, ChangeNotes, 800);
            dw.CreateParameter(cmd, "@p_ShowOnScm", SqlDbType.Bit, ShowOnScm);
            dw.CreateParameter(cmd, "@p_GSEndDt", SqlDbType.DateTime, GSEndDt);
            dw.CreateParameter(cmd, "@p_Last_Upd_User", SqlDbType.VarChar, LastUpdUser, 50);
            dw.CreateParameter(cmd, "@p_SDFFlag", SqlDbType.Bit, SDFFlag, 1);
            dw.CreateParameter(cmd, "@p_PhWebInstruction", SqlDbType.VarChar, PhWebInstruction, 2000);
            dw.CreateParameter(cmd, "@p_AvId", SqlDbType.VarChar, AvId, 2000);
            dw.CreateParameter(cmd, "@p_Group1", SqlDbType.VarChar, Group1, 2000);
            dw.CreateParameter(cmd, "@p_Group2", SqlDbType.VarChar, Group2, 2000);
            dw.CreateParameter(cmd, "@p_Group3", SqlDbType.VarChar, Group3, 2000);
            dw.CreateParameter(cmd, "@p_Group4", SqlDbType.VarChar, Group4, 2000);
            dw.CreateParameter(cmd, "@p_Group5", SqlDbType.VarChar, Group5, 2000);
            dw.CreateParameter(cmd, "@p_BSAMSkus_YN", SqlDbType.Char, BsamSkus, 1);
            dw.CreateParameter(cmd, "@p_BSAMBparts_YN", SqlDbType.Char, BsamParts, 1);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        public int DeleteAvProductBrand(string AvDetailID, string ProductBrandID, string UserName)
        {
            DataWrapper dw = new DataWrapper();
            SqlCommand cmd = dw.CreateCommand("usp_DeleteAvDetail_ProductBrand");

            dw.CreateParameter(cmd, "@p_AvDetailID", SqlDbType.Int, AvDetailID);
            dw.CreateParameter(cmd, "@p_ProductBrandID", SqlDbType.Int, ProductBrandID);
            dw.CreateParameter(cmd, "@p_UserName", SqlDbType.VarChar, UserName, 50);

            return dw.ExecuteCommandNonQuery(cmd);
        }

        #endregion

    }
}
