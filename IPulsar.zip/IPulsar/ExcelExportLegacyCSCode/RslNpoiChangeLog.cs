﻿using NPOI.HPSF;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using System;
using System.Data;
using System.IO;

namespace RslExport
{
    public class RslNpoiChangeLog
    {
        int iRowNumber = 4;

        #region ' Properties '

        private string _partnerId = string.Empty;
        public string PartnerId
        {
            get { return _partnerId; }
            set { _partnerId = value; }
        }

        private string _dateDiffDays = String.Empty;
        public string DateDiffDays
        {
            get { return _dateDiffDays; }
            set { _dateDiffDays = value; }
        }

        private string _partnerName = String.Empty;
        public string PartnerName
        {
            get { return _partnerName; }
            set { _partnerName = value; }
        }

        private string _ServiceFamilyPartNo = String.Empty;
        public string ServiceFamilyPartNo
        {
            get { return _ServiceFamilyPartNo; }
            set { _ServiceFamilyPartNo = value; }
        }
        #endregion

        public void GenerateNpoi(Stream RslStream, string FileName)
        {
            HSSFWorkbook hssfWorkBook = new HSSFWorkbook();

            InitializeWorkbook(hssfWorkBook);

            //book.ExcelWorkbook.WindowHeight = 8580
            //book.ExcelWorkbook.WindowWidth = 7680
            //book.ExcelWorkbook.WindowTopX = -15
            //book.ExcelWorkbook.WindowTopY = -15
            //book.ExcelWorkbook.ProtectWindows = False
            //book.ExcelWorkbook.ProtectStructure = False

            // Create the Sheet
            ISheet sheetChangeLog = (HSSFSheet)hssfWorkBook.CreateSheet("Change Log");

            GenerateChangeLogWorksheet(sheetChangeLog, hssfWorkBook);


           var dwExcalibur = new HPQ.Excalibur.Data();
            DataTable dt = dwExcalibur.ListServiceFamilyDetails();
            foreach (DataRow row in dt.Rows)
            {
                if (PartnerId == row["PartnerId"].ToString())
                {
                    ServiceFamilyPartNo = row["ServiceFamilyPn"].ToString();
                    GenerateDataRowChangeLog(sheetChangeLog, hssfWorkBook);
                }
            }

            //sheet.Options.Selected = True
            //sheet.Options.ProtectObjects = False
            //sheet.Options.ProtectScenarios = False
            //sheet.Options.PageSetup.Footer.Data = "&LHP Confidential&CPage &P of &N&RDate Printed: &D"

            sheetChangeLog.SetMargin(MarginType.BottomMargin, 0.75);
            sheetChangeLog.SetMargin(MarginType.LeftMargin, 0.70);
            sheetChangeLog.SetMargin(MarginType.RightMargin, 0.70);
            sheetChangeLog.SetMargin(MarginType.TopMargin, 0.75);
            //sheetChangeLog.SetMargin(MarginType.HeaderMargin, 0.3);
            //sheetChangeLog.SetMargin(MarginType.FooterMargin, 0.25);

            WriteToFile(RslStream, hssfWorkBook);
        }

        private void GenerateChangeLogWorksheet(ISheet sheet, HSSFWorkbook hssfWorkBook)
        {
            //Column Styles
            ICellStyle StyleArialBold_Top_Thick = hssfWorkBook.CreateCellStyle();
            ICellStyle StyleArialBold_Botton_Thick = hssfWorkBook.CreateCellStyle();
            ICellStyle CellRSLStyle_Restricted = hssfWorkBook.CreateCellStyle();
            ICellStyle CellRSLStyle_ReportGenerated = hssfWorkBook.CreateCellStyle();
            ICellStyle CellRSLStyle_Arial_Bold = hssfWorkBook.CreateCellStyle();

            IFont FontArialBold = hssfWorkBook.CreateFont();
            IFont FontArialBold_Red = hssfWorkBook.CreateFont();

            FontArialBold.FontName = "Arial";
            FontArialBold_Red.FontName = "Arial";
            FontArialBold.Boldweight = (short)FontBoldWeight.BOLD;
            FontArialBold_Red.Boldweight = (short)FontBoldWeight.BOLD;

            StyleArialBold_Top_Thick = GenerateCellStyles("StylesArialBold_Top_Thick", StyleArialBold_Top_Thick, FontArialBold, hssfWorkBook);
            StyleArialBold_Botton_Thick = GenerateCellStyles("StylesArialBold_Botton_Thick", StyleArialBold_Botton_Thick, FontArialBold, hssfWorkBook);
            CellRSLStyle_Restricted = GenerateCellStyles("Restricted", CellRSLStyle_Restricted, FontArialBold_Red, hssfWorkBook);
            CellRSLStyle_ReportGenerated = GenerateCellStyles("Generated", CellRSLStyle_ReportGenerated, FontArialBold, hssfWorkBook);
            CellRSLStyle_Arial_Bold = GenerateCellStyles("Bold", CellRSLStyle_Arial_Bold, FontArialBold, hssfWorkBook);

            sheet.SetColumnWidth(0, 6000);//ChangeDt
            sheet.SetColumnWidth(1, 5000);//HP Part No
            sheet.SetColumnWidth(2, 8000);// Level
            sheet.SetColumnWidth(3, 7000);//Column
            sheet.SetColumnWidth(4, 20000);//Details

            //1st Row - This is the 1st header row.
            CreateRow(sheet, 0);

            //WorksheetCell cell;
            CreateCell(sheet, 0, 0, CellType.STRING);
            ReturnCell(sheet, 0, 0).SetCellValue(String.Format("{0} Rsl Change Log {1}", PartnerName, DateTime.Now.ToShortDateString()));//sTitleBlockValue
            ReturnCell(sheet, 0, 0).CellStyle = CellRSLStyle_Arial_Bold;

            CreateCell(sheet, 0, 1, CellType.STRING);
            ReturnCell(sheet, 0, 1).SetCellValue(string.Empty);
            CreateCell(sheet, 0, 2, CellType.STRING);
            ReturnCell(sheet, 0, 2).SetCellValue(string.Empty);

            sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, 2));

            CreateRow(sheet, 1); //RConfidential
            CreateCell(sheet, 1, 0, CellType.STRING);
            ReturnCell(sheet, 1, 0).SetCellValue("HP - Restricted");
            ReturnCell(sheet, 1, 0).CellStyle = CellRSLStyle_Restricted;

            CreateCell(sheet, 1, 1, CellType.STRING);//Report Generated
            ReturnCell(sheet, 1, 1).SetCellValue("Report Generated " + DateTime.Now.ToString());
            ReturnCell(sheet, 1, 1).CellStyle = CellRSLStyle_ReportGenerated;

            CreateRow(sheet, 2);
            CreateCell(sheet, 2, 0, CellType.STRING);
            ReturnCell(sheet, 2, 0).SetCellValue("Change Log");
            ReturnCell(sheet, 2, 0).CellStyle = StyleArialBold_Top_Thick;

            CreateCell(sheet, 2, 1, CellType.STRING);
            ReturnCell(sheet, 2, 1).CellStyle = StyleArialBold_Top_Thick;
            CreateCell(sheet, 2, 2, CellType.STRING);
            ReturnCell(sheet, 2, 2).CellStyle = StyleArialBold_Top_Thick;
            CreateCell(sheet, 2, 3, CellType.STRING);
            ReturnCell(sheet, 2, 3).CellStyle = StyleArialBold_Top_Thick;
            CreateCell(sheet, 2, 4, CellType.STRING);
            ReturnCell(sheet, 2, 4).CellStyle = StyleArialBold_Top_Thick;

            sheet.AddMergedRegion(new CellRangeAddress(2, 2, 0, 4));

            CreateRow(sheet, 3);
            CreateCell(sheet, 3, 0, CellType.STRING);
            ReturnCell(sheet, 3, 0).SetCellValue("");
            ReturnCell(sheet, 3, 0).CellStyle = StyleArialBold_Botton_Thick;

            CreateCell(sheet, 3, 1, CellType.STRING);
            ReturnCell(sheet, 3, 1).SetCellValue("HP Part No");
            ReturnCell(sheet, 3, 1).CellStyle = StyleArialBold_Botton_Thick;

            CreateCell(sheet, 3, 2, CellType.STRING);
            ReturnCell(sheet, 3, 2).SetCellValue("Level");
            ReturnCell(sheet, 3, 2).CellStyle = StyleArialBold_Botton_Thick;

            CreateCell(sheet, 3, 3, CellType.STRING);
            ReturnCell(sheet, 3, 3).SetCellValue("Column");
            ReturnCell(sheet, 3, 3).CellStyle = StyleArialBold_Botton_Thick;

            CreateCell(sheet, 3, 4, CellType.STRING);
            ReturnCell(sheet, 3, 4).SetCellValue("Details");
            ReturnCell(sheet, 3, 4).CellStyle = StyleArialBold_Botton_Thick;

        }

        private void GenerateDataRowChangeLog(ISheet sheetChangeLog, HSSFWorkbook hssfWorkBook)
        {
            var dwExcalibur = new HPQ.Excalibur.Data();
            DataTable dt = dwExcalibur.SelectRslChangeLog(ServiceFamilyPartNo, "1");

            string sLastDotsName = String.Empty;

            //Fonts Types
            IFont FontArial = hssfWorkBook.CreateFont();
            IFont FontArial_Bold = hssfWorkBook.CreateFont();

            FontArial.FontName = "Arial";
            FontArial_Bold.FontName = "Arial";
            FontArial_Bold.Boldweight = (short)FontBoldWeight.BOLD;

            // Style
            ICellStyle CellRSLStyle_Arial_Center = hssfWorkBook.CreateCellStyle();
            ICellStyle CellRSLStyle_Arial_Left = hssfWorkBook.CreateCellStyle();
            ICellStyle CellRSLStyle_Arial_PlatformRow = hssfWorkBook.CreateCellStyle();

            CellRSLStyle_Arial_Center = GenerateCellStyles("StylesArial_Center", CellRSLStyle_Arial_Center, FontArial, hssfWorkBook);
            CellRSLStyle_Arial_Left = GenerateCellStyles("StylesArial_Left", CellRSLStyle_Arial_Left, FontArial, hssfWorkBook);
            CellRSLStyle_Arial_PlatformRow = GenerateCellStyles("StylesArial_PlatformRow", CellRSLStyle_Arial_PlatformRow, FontArial_Bold, hssfWorkBook);

            if (dt.Rows.Count > 0)
            {

                //int iRowNumber = 4;
                foreach (DataRow row in dt.Rows)
                {
                    if (sLastDotsName != row["dotsname"].ToString())
                    {
                        //AddPlatformRow(sheet, ClRow["DotsName"]);
                        CreateRow(sheetChangeLog, iRowNumber);
                        CreateCell(sheetChangeLog, iRowNumber, 0, CellType.STRING);
                        ReturnCell(sheetChangeLog, iRowNumber, 0).SetCellValue(row["DotsName"].ToString());
                        ReturnCell(sheetChangeLog, iRowNumber, 0).CellStyle = CellRSLStyle_Arial_PlatformRow;//Cell.MergeAcross = 4;

                        CreateCell(sheetChangeLog, iRowNumber, 1, CellType.STRING);
                        ReturnCell(sheetChangeLog, iRowNumber, 1).SetCellValue(string.Empty);
                        ReturnCell(sheetChangeLog, iRowNumber, 1).CellStyle = CellRSLStyle_Arial_PlatformRow;
                        CreateCell(sheetChangeLog, iRowNumber, 2, CellType.STRING);
                        ReturnCell(sheetChangeLog, iRowNumber, 2).SetCellValue(string.Empty);
                        ReturnCell(sheetChangeLog, iRowNumber, 2).CellStyle = CellRSLStyle_Arial_PlatformRow;
                        CreateCell(sheetChangeLog, iRowNumber, 3, CellType.STRING);
                        ReturnCell(sheetChangeLog, iRowNumber, 3).SetCellValue(string.Empty);
                        ReturnCell(sheetChangeLog, iRowNumber, 3).CellStyle = CellRSLStyle_Arial_PlatformRow;
                        CreateCell(sheetChangeLog, iRowNumber, 4, CellType.STRING);
                        ReturnCell(sheetChangeLog, iRowNumber, 4).SetCellValue(string.Empty);
                        ReturnCell(sheetChangeLog, iRowNumber, 4).CellStyle = CellRSLStyle_Arial_PlatformRow;

                        sLastDotsName = row["dotsname"].ToString();

                        iRowNumber++;
                    }

                    CreateRow(sheetChangeLog, iRowNumber);

                    CreateCell(sheetChangeLog, iRowNumber, 0, CellType.STRING);
                    ReturnCell(sheetChangeLog, iRowNumber, 0).SetCellValue(row["ChangeDt"].ToString());
                    ReturnCell(sheetChangeLog, iRowNumber, 0).CellStyle = CellRSLStyle_Arial_Left;

                    CreateCell(sheetChangeLog, iRowNumber, 1, CellType.STRING);
                    ReturnCell(sheetChangeLog, iRowNumber, 1).SetCellValue(row["SpareKitNo"].ToString());
                    ReturnCell(sheetChangeLog, iRowNumber, 1).CellStyle = CellRSLStyle_Arial_Left;

                    CreateCell(sheetChangeLog, iRowNumber, 2, CellType.STRING);
                    ReturnCell(sheetChangeLog, iRowNumber, 2).SetCellValue(row["Description"].ToString());
                    ReturnCell(sheetChangeLog, iRowNumber, 2).CellStyle = CellRSLStyle_Arial_Left;

                    CreateCell(sheetChangeLog, iRowNumber, 3, CellType.STRING);
                    ReturnCell(sheetChangeLog, iRowNumber, 3).SetCellValue(row["ColumnChanged"].ToString());
                    ReturnCell(sheetChangeLog, iRowNumber, 3).CellStyle = CellRSLStyle_Arial_Left;

                    CreateCell(sheetChangeLog, iRowNumber, 4, CellType.STRING);
                    ReturnCell(sheetChangeLog, iRowNumber, 4).SetCellValue(row["ChangeTypeDesc"].ToString());
                    ReturnCell(sheetChangeLog, iRowNumber, 4).CellStyle = CellRSLStyle_Arial_Left;

                    iRowNumber++;
                }
            }
        }

        static HSSFWorkbook InitializeWorkbook(HSSFWorkbook hssfWorkBook)
        {
            //create a entry of DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();

            //dsi.Properties
            dsi.Company = "Excalibur Team";
            hssfWorkBook.DocumentSummaryInformation = dsi;

            //create a entry of SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Author = "Excalibur";
            si.LastAuthor = "Excalibur";
            si.CreateDateTime = DateTime.Now;
            si.LastSaveDateTime = DateTime.Now;
            si.RevNumber = "1.00";
            si.Subject = "Rsl Export";

            hssfWorkBook.SummaryInformation = si;

            return hssfWorkBook;
        }

        private ICellStyle GenerateCellStyles(string Style, ICellStyle CellRslStyle, IFont FontRsl, HSSFWorkbook hssfWorkBook)
        {
            switch (Style)
            {
                case "StylesArialBold_Top_Thick":
                    CellRslStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRslStyle.Alignment = HorizontalAlignment.CENTER;
                    CellRslStyle.BorderTop = BorderStyle.THICK;
                    CellRslStyle.BorderBottom = BorderStyle.THIN;
                    break;
                case "StylesArialBold_Botton_Thick":
                    CellRslStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRslStyle.Alignment = HorizontalAlignment.CENTER;
                    CellRslStyle.BorderBottom = BorderStyle.THICK;
                    CellRslStyle.BorderTop = BorderStyle.THIN;
                    break;
                case "StylesArial_Center":
                    CellRslStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRslStyle.Alignment = HorizontalAlignment.CENTER;
                    CellRslStyle.BorderBottom = BorderStyle.DOTTED;
                    break;
                case "StylesArial_Left":
                    CellRslStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRslStyle.Alignment = HorizontalAlignment.LEFT;
                    CellRslStyle.BorderBottom = BorderStyle.DOTTED;
                    break;
                case "StylesArial_PlatformRow":
                    CellRslStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRslStyle.Alignment = HorizontalAlignment.LEFT;
                    CellRslStyle.BorderBottom = BorderStyle.THIN;
                    break;
                case "Bold":
                    break;
                case "Restricted":
                    FontRsl.Boldweight = (short)FontBoldWeight.BOLD;
                    FontRsl.Color = IndexedColors.RED.Index;
                    break;
                case "Generated":
                    FontRsl.Boldweight = (short)FontBoldWeight.BOLD;
                    break;
            }


            CellRslStyle.SetFont(FontRsl);
            return CellRslStyle;
        }

        static void WriteToFile(Stream RslStream, HSSFWorkbook hssfWorkBook)
        {
            //Write the stream data of workbook to the root directory
            hssfWorkBook.Write(RslStream);
        }

        #region #NPOI Utility Functions

        public void CreateRow(ISheet sheet1, int row)
        {
            sheet1.CreateRow(row);
        }

        static void CreateCell(ISheet sheet1, int row, int cell, CellType Type)
        {
            sheet1.GetRow(row).CreateCell(cell, Type);
        }

        static ICell ReturnCell(ISheet sheet1, int row, int cell)
        {
            return sheet1.GetRow(row).GetCell(cell);
        }

        #endregion


    }
}
