﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using HPQ.Data;

namespace SpbGlobalExportNpoi
{
    public class SpbData
    {
        public DataTable SelectGlobalSpbPublished()
        {
            DataWrapper dw = new DataWrapper();

            SqlCommand cmd = dw.CreateCommand("usp_SelectGlobalSpbPublished");
            cmd.CommandTimeout = 2400;

            return dw.ExecuteCommandTable(cmd);
        }




        public string GetSpbLatestPublishDt()
        {
            DataWrapper dw = new DataWrapper();
            string strSql = "SELECT MAX(SpbLastPublishDt) FROM ServiceFamilyDetails WITH (NOLOCK);";
            return dw.ExecuteCommandScalar(strSql).ToString();
        }


        public string GetSpbLastPublishDt()
        {
            DataWrapper dw = new DataWrapper();
            string strSql = "DECLARE @v_SpbLatestPublishDt DATETIME;"
                            + "SELECT @v_SpbLatestPublishDt = MAX(ExportTime) FROM DW_EXCALIBUR.dbo.SPB_Archive WITH (NOLOCK);"
                            + "SELECT MAX(ExportTime) FROM DW_EXCALIBUR.dbo.SPB_Archive WITH (NOLOCK) "
                            + " WHERE ExportTime BETWEEN DATEADD(day, -8, @v_SpbLatestPublishDt) AND DATEADD(day, -1, @v_SpbLatestPublishDt);";


            return dw.ExecuteCommandScalar(strSql).ToString();

        }



    }
}
