﻿using NPOI.HPSF;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using System;
using System.Data;
using System.IO;


namespace RslExport
{
    public class RslExportNpoi
    {

        #region ' Properties '
       
        private string _productPpcLine = string.Empty;
        public string ProductPpcLine
        {
            get { return _productPpcLine; }
            set { _productPpcLine = value; }
        }

        private bool _newMatrix = false;
        public bool NewMatrix
        {
            get { return _newMatrix; }
            set { _newMatrix = value; }
        }

        private bool _publish = false;
        public bool Publish
        {
            get { return _publish; }
            set { _publish = value; }
        }

        private string _productVersionId = string.Empty;
        public string ProductVersionId
        {
            get { return _productVersionId; }
            set { _productVersionId = value; }
        }

        private string _serviceFamilyPn = string.Empty;
        public string ServiceFamilyPn
        {
            get
            {
                if (_serviceFamilyPn == string.Empty)
                {
                    var dw = new HPQ.Excalibur.Data();
                    _serviceFamilyPn = dw.GetServiceFamilyPn(ProductVersionId);
                }
                return _serviceFamilyPn;
            }
            set { _serviceFamilyPn = value; }
        }

        private DateTime _lastPublishDt = DateTime.MinValue;
        public DateTime LastPublishDt
        {
            get
            {
                if (_lastPublishDt == DateTime.MinValue)
                {
                    DateTime.TryParse(_compareDt, out _lastPublishDt);
                }

                if (_lastPublishDt == DateTime.MinValue)
                {
                    var dw = new HPQ.Excalibur.Data();
                    _lastPublishDt = dw.GetRslLastPublishDt(ServiceFamilyPn);
                }
                return _lastPublishDt;
            }
            set { _lastPublishDt = value; }
        }


        private string _compareDt = string.Empty;
        public string CompareDt
        {
            get
            {
                if (string.IsNullOrEmpty(_compareDt))
                {
                    return "1/1/1973";
                }
                return _compareDt;
            }
            set { _compareDt = value; }
        }

        private string _exportTime = string.Empty;
        private string ExportTime
        {
            get { return _exportTime; }
            set { _exportTime = value; }
        }

        private string _userName = string.Empty;
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        private string _selfRepairDoc = string.Empty;
        public string SelfRepairDoc
        {
            get { return _selfRepairDoc; }
            set { _selfRepairDoc = value; }
        }

        private string _ProjectCd = string.Empty;
        public string ProjectCd
        {
            get { return _ProjectCd; }
            set { _ProjectCd = value; }
        }

        private string _ProductDivision = string.Empty;
        public string ProductDivision
        {
            get { return _ProductDivision; }
            set { _ProductDivision = value; }
        }

        private int _CommentCellIdx;
        public int CommentCellIdx
        {
            get { return _CommentCellIdx; }
            set { _CommentCellIdx = value; }
        }
        #endregion


        public void GenerateRSLNpoi(Stream RslStream, string FileName, ref  string ErrorMessage)
        {
            try
            {

            HSSFWorkbook hssfWorkBook = new HSSFWorkbook();

            InitializeWorkbook(hssfWorkBook);

            // Create the Sheets
            ISheet sheetChangeLog = (HSSFSheet)hssfWorkBook.CreateSheet("ChangeLog");
            ISheet sheetRSL = (HSSFSheet)hssfWorkBook.CreateSheet("RSL");
            ISheet sheetAvChangeLog = (HSSFSheet)hssfWorkBook.CreateSheet("AvChangeLog");

            GenerateWorksheetChangeLog(sheetChangeLog, hssfWorkBook);
            GenerateWorksheetRSL(sheetRSL, hssfWorkBook,ref ErrorMessage);
            GenerateWorksheetSheetBrands(hssfWorkBook);
            GenerateWorksheetAvChangeLog(sheetAvChangeLog, hssfWorkBook);

            hssfWorkBook.GetSheet("ChangeLog").IsSelected = false; 
            hssfWorkBook.GetSheet("RSL").IsSelected = true;
            hssfWorkBook.SetActiveSheet(1);
           

            var dwExcalibur = new HPQ.Excalibur.Data();
            if (Publish) dwExcalibur.InsertRslPublish(ServiceFamilyPn, UserName);

            WriteToFile(RslStream,hssfWorkBook);

            }
            catch (Exception ex)
            {
                throw new Exception("Err in GenerateRSLNpoi: " + ServiceFamilyPn + ". " + ex.ToString());
            }
        }

  #region ' ChangeLog '

        private void GenerateWorksheetChangeLog(ISheet sheet, HSSFWorkbook hssfWorkBook)
        {
            sheet.DefaultRowHeight = 15;

            //Set Column Widths
            sheet.SetColumnWidth(0,3000);
            sheet.SetColumnWidth(1,4000);
            sheet.SetColumnWidth(2, 15000);
            sheet.SetColumnWidth(3, 6000);
            sheet.SetColumnWidth(4, 15000);

            //Column Styles
            ICellStyle StyleArial12Bold_GreyBackground = hssfWorkBook.CreateCellStyle();
            IFont FontArial12Bold = hssfWorkBook.CreateFont();

            FontArial12Bold.FontName = "Arial";
            FontArial12Bold.FontHeightInPoints = 12;
            FontArial12Bold.Boldweight = (short)FontBoldWeight.BOLD;
            
            StyleArial12Bold_GreyBackground = GenerateCellStyles("StyleArial12Bold_GreyBackground", StyleArial12Bold_GreyBackground, FontArial12Bold, hssfWorkBook);
       
            //1st Row - This is the 1st header row.
            CreateRow(sheet, 0);
       
            //WorksheetCell cell;
            CreateCell(sheet, 0, 0, CellType.STRING);
            ReturnCell(sheet, 0, 0).SetCellValue("Date");
            //ReturnCell(sheet, 0, 0).CellStyle = GenerateStyles("Default", true, hssfWorkBook);
            ReturnCell(sheet, 0, 0).CellStyle = StyleArial12Bold_GreyBackground;

            CreateCell(sheet, 0, 1, CellType.STRING);
            ReturnCell(sheet, 0, 1).SetCellValue("Part Number");
            ReturnCell(sheet, 0, 1).CellStyle = StyleArial12Bold_GreyBackground;
                          
            CreateCell(sheet, 0, 2, CellType.STRING);
            ReturnCell(sheet, 0, 2).SetCellValue("Description");
            ReturnCell(sheet, 0, 2).CellStyle = StyleArial12Bold_GreyBackground;
           
            CreateCell(sheet, 0, 3, CellType.STRING);
            ReturnCell(sheet, 0, 3).SetCellValue("Column");
            ReturnCell(sheet, 0, 3).CellStyle = StyleArial12Bold_GreyBackground;
                 
            CreateCell(sheet, 0, 4, CellType.STRING);
            ReturnCell(sheet, 0, 4).SetCellValue("Details");
            ReturnCell(sheet, 0, 4).CellStyle = StyleArial12Bold_GreyBackground;
                
            GenerateDataRowChangeLog(sheet, hssfWorkBook);
            
            //Close
            //sheet.Options.Selected = false;
            //sheet.Options.ProtectObjects = false;
            //sheet.Options.ProtectScenarios = false;

            sheet.SetMargin(MarginType.BottomMargin, 0.75);
            sheet.SetMargin(MarginType.LeftMargin, 0.70);
            sheet.SetMargin(MarginType.RightMargin, 0.70);
            sheet.SetMargin(MarginType.TopMargin, 0.75);

            //sheet.SetMargin(MarginType.HeaderMargin, 0.3);
            //sheet.SetMargin(MarginType.FooterMargin, 0.3);
            
        }

        void GenerateDataRowChangeLog(ISheet sheetChangeLog, HSSFWorkbook hssfWorkBook)
        {
            //  Populate the Worksheets
            var dwExcalibur = new HPQ.Excalibur.Data();
            DataTable dtChangeLog = dwExcalibur.SelectRslChangeLog(ServiceFamilyPn);

            if (dtChangeLog.Rows.Count > 0)
            {
                //Column Styles
                ICellStyle StyleArial10 = hssfWorkBook.CreateCellStyle();
                IFont FontArial = hssfWorkBook.CreateFont();

                StyleArial10.VerticalAlignment = VerticalAlignment.BOTTOM;
                FontArial.FontName = "Arial";
                FontArial.FontHeightInPoints = 10;

                StyleArial10.SetFont(FontArial);

                int iRowNumber = 1;
                foreach (DataRow row in dtChangeLog.Rows)
                {
                    string sChangeDt = "";
                    string sSpareKitNo = "";
                    string sDescription = "";
                    string sColumnChanged = "";

                    if (row["ChangeDt"].ToString() == "")
                        sChangeDt = "";
                    else
                        sChangeDt = row["ChangeDt"].ToString();

                    if (row["SpareKitNo"].ToString() == "")
                        sSpareKitNo = "";
                    else
                        sSpareKitNo = row["SpareKitNo"].ToString();

                    if (row["Description"].ToString() == "")
                        sDescription = "";
                    else
                        sDescription = row["Description"].ToString();

                    if (row["ColumnChanged"].ToString() == "")
                        sColumnChanged = "";
                    else
                        sColumnChanged = row["ColumnChanged"].ToString();

                    CreateRow(sheetChangeLog, iRowNumber);
                    CreateCell(sheetChangeLog, iRowNumber, 0, CellType.STRING);
                    DateTime ChangeDate = Convert.ToDateTime(sChangeDt);
                    ReturnCell(sheetChangeLog, iRowNumber, 0).SetCellValue(ChangeDate.ToString("d"));
                    ReturnCell(sheetChangeLog, iRowNumber, 0).CellStyle = StyleArial10;

                    CreateCell(sheetChangeLog, iRowNumber, 1, CellType.STRING);
                    ReturnCell(sheetChangeLog, iRowNumber, 1).SetCellValue(sSpareKitNo);
                    ReturnCell(sheetChangeLog, iRowNumber, 1).CellStyle = StyleArial10;

                    CreateCell(sheetChangeLog, iRowNumber, 2, CellType.STRING);
                    ReturnCell(sheetChangeLog, iRowNumber, 2).SetCellValue(sDescription);
                    ReturnCell(sheetChangeLog, iRowNumber, 2).CellStyle = StyleArial10;

                    CreateCell(sheetChangeLog, iRowNumber, 3, CellType.STRING);
                    ReturnCell(sheetChangeLog, iRowNumber, 3).SetCellValue(sColumnChanged);
                    ReturnCell(sheetChangeLog, iRowNumber, 3).CellStyle = StyleArial10;

                    CreateCell(sheetChangeLog, iRowNumber, 4, CellType.STRING);
                    ReturnCell(sheetChangeLog, iRowNumber, 4).CellStyle = StyleArial10;

                    string sOldValue = row["OldValue"].ToString();
                    string sNewValue = row["NewValue"].ToString();
                    string sChangeType = row["ChangeType"].ToString();

                    int changeType = 0;

                    int.TryParse(sChangeType, out changeType);
                    if ((changeType == 5) || (changeType == 1))
                    {
                        string sChangeTypeDescription = row["ChangeTypeDesc"].ToString();
                        ReturnCell(sheetChangeLog, iRowNumber, 4).SetCellValue(sChangeTypeDescription);
                    }
                    else
                    {
                        if ((!string.IsNullOrEmpty(sOldValue)) || (!string.IsNullOrEmpty(sNewValue)))
                        {
                            ReturnCell(sheetChangeLog, iRowNumber, 4).SetCellValue(string.Format("{0} --> {1}", sOldValue, sNewValue));
                        }
                    }

                    iRowNumber++;
                }
            }
            dtChangeLog = null;
        }

  #endregion

  #region ' AvChangeLog '

        private void GenerateWorksheetAvChangeLog(ISheet sheet, HSSFWorkbook hssfWorkBook)
        {
            sheet.DefaultRowHeight = 15;

            //Set Column Widths            
            sheet.SetColumnWidth(0, 3000);
            sheet.SetColumnWidth(1, 3500);
            sheet.SetColumnWidth(2, 12000);
            sheet.SetColumnWidth(3, 3500);
            sheet.SetColumnWidth(4, 3500);

            //Column Styles
            ICellStyle StyleArial12Bold_GreyBackground = hssfWorkBook.CreateCellStyle();
            IFont FontArial12Bold = hssfWorkBook.CreateFont();

            FontArial12Bold.FontName = "Arial";
            FontArial12Bold.FontHeightInPoints = 12;
            FontArial12Bold.Boldweight = (short)FontBoldWeight.BOLD;

            StyleArial12Bold_GreyBackground = GenerateCellStyles("StyleArial12Bold_GreyBackground", StyleArial12Bold_GreyBackground, FontArial12Bold, hssfWorkBook);
              
            //1st Row - This is the 1st header row.
            CreateRow(sheet, 0);

            //WorksheetCell cells;
            CreateCell(sheet, 0, 0,CellType.STRING);
            ReturnCell(sheet, 0, 0).SetCellValue("Date");
            ReturnCell(sheet, 0, 0).CellStyle = StyleArial12Bold_GreyBackground;
          
            CreateCell(sheet, 0, 1,CellType.STRING);
            ReturnCell(sheet, 0, 1).SetCellValue("Kit Number");
            ReturnCell(sheet, 0, 1).CellStyle = StyleArial12Bold_GreyBackground;
          
            CreateCell(sheet, 0, 2,CellType.STRING);
            ReturnCell(sheet, 0, 2).SetCellValue("Description");
            ReturnCell(sheet, 0, 2).CellStyle = StyleArial12Bold_GreyBackground;
          
            CreateCell(sheet, 0, 3, CellType.STRING);
            ReturnCell(sheet, 0, 3).SetCellValue("Column");
            ReturnCell(sheet, 0, 3).CellStyle = StyleArial12Bold_GreyBackground;
          
            CreateCell(sheet, 0, 4, CellType.STRING);
            ReturnCell(sheet, 0, 4).SetCellValue("Av Number");
            ReturnCell(sheet, 0, 4).CellStyle = StyleArial12Bold_GreyBackground;

            GenerateDataRowAvChangeLog(sheet, hssfWorkBook);
                    
            //Close
            //sheet.Options.Selected = false;
            //sheet.Options.ProtectObjects = false;
            //sheet.Options.ProtectScenarios = false;

           sheet.SetMargin(MarginType.BottomMargin, 0.75);
           sheet.SetMargin(MarginType.LeftMargin, 0.70);
           sheet.SetMargin(MarginType.RightMargin, 0.70);
           sheet.SetMargin(MarginType.TopMargin, 0.75);

           //Setup the Header and Footer Margins    
           //sheet.SetMargin(MarginType.HeaderMargin, 0.30);
           //sheet.SetMargin(MarginType.FooterMargin, 0.30);
            
        }
        
        void GenerateDataRowAvChangeLog(ISheet sheetAvChangeLog,  HSSFWorkbook hssfWorkBook)
        {
           //  Get Data
            var dwExcalibur = new HPQ.Excalibur.Data();
            DataTable dtAvChangeLog = dwExcalibur.SelectRslAvChangeLog(ServiceFamilyPn, CompareDt);

            if (dtAvChangeLog.Rows.Count > 0)
            {
                //Column Styles
                ICellStyle StyleArial10 = hssfWorkBook.CreateCellStyle();

                IFont FontArial10 = hssfWorkBook.CreateFont();
                FontArial10.FontName = "Arial";
                FontArial10.FontHeightInPoints = 10;

                StyleArial10.VerticalAlignment = VerticalAlignment.BOTTOM;
                StyleArial10.SetFont(FontArial10);

                int iRowNumber = 1;
                foreach (DataRow row in dtAvChangeLog.Rows)
                {
                    CreateRow(sheetAvChangeLog, iRowNumber);

                    CreateCell(sheetAvChangeLog, iRowNumber, 0, CellType.STRING);
                    DateTime DateUpdate = Convert.ToDateTime(row["LastUpdDate"].ToString());
                    ReturnCell(sheetAvChangeLog, iRowNumber, 0).SetCellValue(DateUpdate.ToString("d"));
                    ReturnCell(sheetAvChangeLog, iRowNumber, 0).CellStyle = StyleArial10;

                    CreateCell(sheetAvChangeLog, iRowNumber, 1, CellType.STRING);
                    ReturnCell(sheetAvChangeLog, iRowNumber, 1).SetCellValue(row["SpareKitNo"].ToString());
                    ReturnCell(sheetAvChangeLog, iRowNumber, 1).CellStyle = StyleArial10;

                    CreateCell(sheetAvChangeLog, iRowNumber, 2, CellType.STRING);
                    ReturnCell(sheetAvChangeLog, iRowNumber, 2).SetCellValue(row["Description"].ToString());
                    ReturnCell(sheetAvChangeLog, iRowNumber, 2).CellStyle = StyleArial10;

                    CreateCell(sheetAvChangeLog, iRowNumber, 3, CellType.STRING);
                    ReturnCell(sheetAvChangeLog, iRowNumber, 3).SetCellValue(row["AvNo"].ToString());
                    ReturnCell(sheetAvChangeLog, iRowNumber, 3).CellStyle = StyleArial10;

                    CreateCell(sheetAvChangeLog, iRowNumber, 4, CellType.STRING);
                    ReturnCell(sheetAvChangeLog, iRowNumber, 4).CellStyle = StyleArial10;

                    if (row["Status"].ToString().Equals("A"))
                    {
                        ReturnCell(sheetAvChangeLog, iRowNumber, 4).SetCellValue("Added");
                    }
                    else
                    {
                        ReturnCell(sheetAvChangeLog, iRowNumber, 4).SetCellValue("Deleted");
                    }

                    iRowNumber++;
                }
            }
            dtAvChangeLog = null;
    
        }

  #endregion

  #region ' Brands '

       private void GenerateWorksheetSheetBrands(HSSFWorkbook hssfWorkBook)
       {
           var dwExcalibur = new HPQ.Excalibur.Data(); 
           DataTable dtBrands = dwExcalibur.ListServiceFamilyBrands(ServiceFamilyPn);
          
           foreach (DataRow row in dtBrands.Rows)
           {
               string brandName = row["BrandNameAbbreviation"].ToString();
               // Excel have names with less than 31 characters in the sheets names
               if (brandName.Length > 31)
               {
                   brandName = brandName.Substring(0, 30);
               }

               string productBrandId = row["ProductBrandId"].ToString();

               DataTable dtBrandMapping = dwExcalibur.SelectRslSpareKitAvMappings(ServiceFamilyPn, productBrandId);
               GenerateWorkSheetBrand(brandName, hssfWorkBook, dtBrandMapping);


               // CLOSE
               //         sheet.Options.Selected = true;
               //         sheet.Options.ProtectObjects = false;
               //         sheet.Options.ProtectScenarios = false;
               //         sheet.Options.PageSetup.Header.Margin = 0.3F;
               //         sheet.Options.PageSetup.Footer.Margin = 0.3F;

               //sheet.SetMargin(MarginType.BottomMargin, 0.75);
               //sheet.SetMargin(MarginType.LeftMargin, 0.70);
               //sheet.SetMargin(MarginType.RightMargin, 0.70);
               //sheet.SetMargin(MarginType.TopMargin, 0.75);
               //dtBrandMapping = null;
           }

           dtBrands = null;
       }

       private void GenerateWorkSheetBrand(string Brand, HSSFWorkbook hssfWorkBook, DataTable dtBrandMapping)
       {
           var dwExcalibur = new HPQ.Excalibur.Data();
           DataTable dt = dwExcalibur.SelectRslDetailsForExport(ProductVersionId, Publish, CompareDt);

           ISheet sheetBrand = (HSSFSheet)hssfWorkBook.CreateSheet(Brand); // excel just take 31 characters for the name
           sheetBrand.DefaultRowHeight = 15;

           //Set Column Widths
           sheetBrand.SetColumnWidth(0, 4000);//61
           sheetBrand.SetColumnWidth(1, 15000);//259
           
           if (dtBrandMapping.Columns.Count > 2)
           {
               int ColNumber = 2;
               for (int i = 2; i < dtBrandMapping.Columns.Count; i++)
               {
                   sheetBrand.SetColumnWidth(ColNumber, 6000);//80
                   ColNumber++;
               }
           }

           IFont FontArial12Bold = hssfWorkBook.CreateFont();
           FontArial12Bold.FontName = "Arial";
           FontArial12Bold.FontHeightInPoints = 12;
           FontArial12Bold.Boldweight = (short)FontBoldWeight.BOLD;

           ICellStyle StyleArial12Bold_GreyBackground = hssfWorkBook.CreateCellStyle();
           StyleArial12Bold_GreyBackground = GenerateCellStyles("StyleArial12Bold_GreyBackground", StyleArial12Bold_GreyBackground, FontArial12Bold, hssfWorkBook);
           

           ////1st Row - This is the 1st header row.
           CreateRow(sheetBrand, 0);
           
           ////WorksheetCell cell;
           CreateCell(sheetBrand, 0, 0, CellType.STRING);
           ReturnCell(sheetBrand, 0, 0).SetCellValue("SPS PN#");
           ReturnCell(sheetBrand, 0, 0).CellStyle = StyleArial12Bold_GreyBackground; 

           CreateCell(sheetBrand, 0, 1, CellType.STRING);
           ReturnCell(sheetBrand, 0, 1).SetCellValue("SPS Description");
           ReturnCell(sheetBrand, 0, 1).CellStyle = StyleArial12Bold_GreyBackground;

           if (dtBrandMapping.Columns.Count > 2)
           {
               int ColNum = 2;
               string ColumnName = string.Empty;
               for (int i = 2; i < dtBrandMapping.Columns.Count; i++)
               {
                   // Do not paint the columns CategoryId, CategoryName, SortOrder,SparekitId,Id
                   ColumnName = dtBrandMapping.Columns[i].ColumnName.ToString();
                   if (!((ColumnName == "CategoryId") || (ColumnName == "CategoryName") || (ColumnName == "sortOrder") || (ColumnName == "SpareKitId") || (ColumnName == "ID")))
                   {
                       CreateCell(sheetBrand, 0, ColNum, CellType.STRING);
                       ReturnCell(sheetBrand, 0, ColNum).SetCellValue(ColumnName);
                       ReturnCell(sheetBrand, 0, ColNum).CellStyle = StyleArial12Bold_GreyBackground;
                       ColNum++;
                   }
               }
           }


           //  Populate the Worksheets
           GenerateDataRowBrand(sheetBrand, dtBrandMapping, hssfWorkBook);

       }
        
       void GenerateDataRowBrand(ISheet sheetBrand, DataTable dtBrandMapping, HSSFWorkbook hssfWorkBook)
       {

           IFont BrandFont = hssfWorkBook.CreateFont();
           IFont BrandFontStrike = hssfWorkBook.CreateFont();
           ICellStyle StyleBrandYellow = hssfWorkBook.CreateCellStyle();
           ICellStyle StyleBrandYellowStrike = hssfWorkBook.CreateCellStyle();

           BrandFont.FontName = "Arial";
           BrandFont.FontHeightInPoints = 10;

           BrandFontStrike.FontName = "Arial";
           BrandFontStrike.FontHeightInPoints = 10;

           StyleBrandYellow = GenerateCellStyles("StyleBrandYellow", StyleBrandYellow, BrandFont, hssfWorkBook);
           StyleBrandYellowStrike = GenerateCellStyles("StyleBrandYellowStrike", StyleBrandYellowStrike, BrandFontStrike, hssfWorkBook);
          
           int iRowNumber = 1; 
           foreach (DataRow row in dtBrandMapping.Rows)
           {
               CreateRow(sheetBrand, iRowNumber);
               
               CreateCell(sheetBrand, iRowNumber, 0, CellType.STRING);
               ReturnCell(sheetBrand, iRowNumber, 0).SetCellValue(row["SpareKitNo"].ToString());

               CreateCell(sheetBrand, iRowNumber, 1, CellType.STRING);
               ReturnCell(sheetBrand, iRowNumber, 1).SetCellValue(row["Description"].ToString());

               if (row.Table.Columns.Count > 2)
               {
                   int Cellnumber = 2;
                   string ColumnName = string.Empty;
              
                   for (int i = 2; i < dtBrandMapping.Columns.Count; i++)
                   {
                       // Do not paint the columns CategoryId, CategoryName, SortOrder,SparekitId,Id
                       ColumnName = dtBrandMapping.Columns[i].ColumnName.ToString();
                       if (!((ColumnName == "CategoryId") || (ColumnName == "CategoryName") || (ColumnName == "sortOrder") || (ColumnName == "SpareKitId") || (ColumnName == "ID")))
                       {

                           CreateCell(sheetBrand, iRowNumber, Cellnumber, CellType.STRING);

                           string cellData = row[i].ToString();

                           if (!String.IsNullOrEmpty(cellData) && cellData.Contains(":"))
                           {
                               string[] dataArray = cellData.Split(':');
                               string avNo = dataArray[0];
                               string status = dataArray[1];

                               DateTime lastUpdDate = DateTime.MinValue;
                               DateTime.TryParse(dataArray[2], out lastUpdDate);
                               ReturnCell(sheetBrand, iRowNumber, Cellnumber).SetCellValue(avNo);

                               if (status.Equals("A") && lastUpdDate >= LastPublishDt)
                                   ReturnCell(sheetBrand, iRowNumber, Cellnumber).CellStyle = StyleBrandYellow;
                               //else if (status.Equals("A") && lastUpdDate < LastPublishDt)
                               //    ReturnCell(sheetChangeLog, iRowNumber, Cellnumber).CellStyle=;// "s3743");
                               else if (status.Equals("D"))
                                   ReturnCell(sheetBrand, iRowNumber, Cellnumber).CellStyle = StyleBrandYellowStrike;

                           }
                           else if (!String.IsNullOrEmpty(cellData))
                           {
                               ReturnCell(sheetBrand, iRowNumber, Cellnumber).SetCellValue(cellData);
                               //ReturnCell(sheetChangeLog, iRowNumber, Cellnumber).CellStyle = GenerateStyles("s3743", false, hssfWorkBook);

                           }
                           else
                           {
                               ReturnCell(sheetBrand, iRowNumber, Cellnumber).SetCellValue(string.Empty);
                               // ReturnCell(sheetChangeLog, iRowNumber, Cellnumber).CellStyle = GenerateStyles("s3743", false, hssfWorkBook);
                           }
                           Cellnumber++;
                       }
                   }
               }

               iRowNumber++;
           }
       }

  #endregion

  #region ' RSL '

        private void GenerateWorksheetRSL(ISheet sheet, HSSFWorkbook hssfWorkBook, ref  string ErrorMessage)
        {
            GenerarateRSLHeader(sheet, hssfWorkBook);

            GenerateDataRowRSL(sheet, hssfWorkBook,ref  ErrorMessage);

            GenerateHPRestricted(sheet, hssfWorkBook);

            //sheet.Options.Selected = true;
            //sheet.Options.FreezePanes = true;
            //sheet.Options.SplitHorizontal = 9;
            //sheet.Options.TopRowBottomPane = 9;
            //sheet.Options.SplitVertical = 5;
            //sheet.Options.LeftColumnRightPane = 5;
            //sheet.Options.ActivePane = 0;
            //sheet.Options.ProtectObjects = false;
            //sheet.Options.ProtectScenarios = false;
            //sheet.Options.Print.ValidPrinterInfo = true;
        }

        private void GenerateHPRestricted(ISheet sheetRSL, HSSFWorkbook hssfWorkBook)
       {
           //Fonts Types
            IFont FontVerdana_13_Red= hssfWorkBook.CreateFont();
            FontVerdana_13_Red.FontName = "verdana";
            FontVerdana_13_Red.FontHeightInPoints = 13;

            IFont FontVerdana_13 = hssfWorkBook.CreateFont();
            FontVerdana_13.FontName = "verdana";
            FontVerdana_13.FontHeightInPoints = 13;

            // Styles
            ICellStyle CellRSLStyle_Restricted= hssfWorkBook.CreateCellStyle();
            CellRSLStyle_Restricted = GenerateCellStyles("Restricted", CellRSLStyle_Restricted, FontVerdana_13_Red, hssfWorkBook);
            
            ICellStyle CellRSLStyle_ReportGenerated = hssfWorkBook.CreateCellStyle();
            CellRSLStyle_ReportGenerated = GenerateCellStyles("Generated", CellRSLStyle_ReportGenerated, FontVerdana_13, hssfWorkBook);

            //CreateRow(sheetRSL, 7);
            CreateCell(sheetRSL, 7, 0, CellType.STRING);//Restricted
            ReturnCell(sheetRSL, 7,0).SetCellValue("HP - Restricted");
            ReturnCell(sheetRSL, 7,0).CellStyle = CellRSLStyle_Restricted;

            CreateCell(sheetRSL, 7,1, CellType.STRING);//Report Generated
            ReturnCell(sheetRSL, 7,1).SetCellValue("Report Generated " + DateTime.Now.ToString());
            ReturnCell(sheetRSL, 7,1).CellStyle = CellRSLStyle_ReportGenerated;

       }       

        private void GenerarateRSLHeader(ISheet sheet, HSSFWorkbook hssfWorkBook)
        {
            var dwExcalibur = new HPQ.Excalibur.Data();
            DataTable dtProductVersions = dwExcalibur.SelectSpbVersions(this.ServiceFamilyPn);
            DataTable dtHeader = dwExcalibur.SelectRslHeader(this.ServiceFamilyPn);
            DataRow dRow = dtHeader.Rows[0];

            ProductDivision = dRow["Division"].ToString();

            //Fonts Types
            IFont FontArial_12_Bold = hssfWorkBook.CreateFont();
            FontArial_12_Bold.FontName = "Arial";
            FontArial_12_Bold.FontHeightInPoints = 12;

            // Style
            ICellStyle CellRSLStyle_Arial12_Bold = hssfWorkBook.CreateCellStyle();
            CellRSLStyle_Arial12_Bold = GenerateCellStyles("StylesArial12Bold", CellRSLStyle_Arial12_Bold, FontArial_12_Bold, hssfWorkBook);

            ICellStyle CellRSLStyle_Arial12_Bold_NoBottonMargin = hssfWorkBook.CreateCellStyle();
            CellRSLStyle_Arial12_Bold_NoBottonMargin = GenerateCellStyles("StylesColumTitleBoldNoBottonMargin", CellRSLStyle_Arial12_Bold_NoBottonMargin, FontArial_12_Bold, hssfWorkBook);
         
            ICellStyle CellRSLStyle_Arial12_Rotate_Bold = hssfWorkBook.CreateCellStyle();
            CellRSLStyle_Arial12_Rotate_Bold = GenerateCellStyles("StylesColumTitleRotateBold", CellRSLStyle_Arial12_Rotate_Bold, FontArial_12_Bold, hssfWorkBook);

            ICellStyle CellRSLStyle_Arial12_Rotate_Bold_NoTopMargin = hssfWorkBook.CreateCellStyle();
            CellRSLStyle_Arial12_Rotate_Bold_NoTopMargin = GenerateCellStyles("StylesColumTitleRotateBoldNoTopMargin", CellRSLStyle_Arial12_Rotate_Bold_NoTopMargin, FontArial_12_Bold, hssfWorkBook);
                     
          
            //Set Column Widths
            sheet.SetColumnWidth(0, 8000);//Part type
            sheet.SetColumnWidth(1, 4000);//Spare Part Number
            sheet.SetColumnWidth(2, 1200);//Rev
            sheet.SetColumnWidth(3, 2000);//CrossPlatStatus
            sheet.SetColumnWidth(4, 15000);//Spare Kit Description
            sheet.SetColumnWidth(5, 4000);//MFG Sub Assembly
            sheet.SetColumnWidth(6, 4000);//Service Sub Assembly #
            sheet.SetColumnWidth(7, 3500);//First Service Date
            sheet.SetColumnWidth(8, 2000);//CSR- User Replaceable
            sheet.SetColumnWidth(9, 1200);//Disposition
            sheet.SetColumnWidth(10, 2000);//New Spare Part
            ////column10.Span = 3;
            sheet.SetColumnWidth(11, 1200);//Warranty
            ////column11.Index = 15;
            ////column11.StyleID = "s147";
            ////column11.Span = 3;
            sheet.SetColumnWidth(12, 1500);//Local Stock
            sheet.SetColumnWidth(13, 1500);//PPC Product
            sheet.SetColumnWidth(14, 1000);//NA
            sheet.SetColumnWidth(15, 1000);//LA
            sheet.SetColumnWidth(16, 1000);//APJ
            sheet.SetColumnWidth(17, 1000);//EMEA

            int ColNumber;

            if (ProductDivision == "2")// Division 2 - Desktops
            {
                sheet.SetColumnWidth(18, 5000);//Part Supplier (ODM/OEM)
                ColNumber = 19;
            }
            else // Division 1 - Notebooks 
            {
                 ColNumber = 18;               
            }

            ////Versions
            foreach (DataRow drVersion in dtProductVersions.Rows)
            {
                sheet.SetColumnWidth(ColNumber, 1500);
                ColNumber++;
            }
            //Comment
            sheet.SetColumnWidth(ColNumber, 10000);

            //1st Row - This is the 1st header row.
            CreateRow(sheet, 0);

            //WorksheetCell cells;
            CreateCell(sheet, 0, 0, CellType.STRING);
            ReturnCell(sheet, 0, 0).SetCellValue("Revision:");
            ReturnCell(sheet, 0, 0).CellStyle = CellRSLStyle_Arial12_Bold; 

            CreateCell(sheet, 0, 1, CellType.NUMERIC);
            DateTime ActualDate = DateTime.Now;
            ReturnCell(sheet, 0, 1).SetCellValue(ActualDate.ToString("d"));
            ReturnCell(sheet, 0, 1).CellStyle = CellRSLStyle_Arial12_Bold; 

            CreateRow(sheet, 1);
            sheet.GetRow(1).HeightInPoints = 15;
             //Row1.AutoFitHeight = false;
                  
             CreateCell(sheet, 1, 0, CellType.STRING);
             ReturnCell(sheet, 1, 0).SetCellValue("Project Code:");
             ReturnCell(sheet, 1, 0).CellStyle = CellRSLStyle_Arial12_Bold; 

             CreateCell(sheet, 1, 1, CellType.NUMERIC);
             ReturnCell(sheet, 1, 1).SetCellValue(dRow["ProjectNumber"].ToString());
             ReturnCell(sheet, 1, 1).CellStyle = CellRSLStyle_Arial12_Bold; 
             //cell.MergeAcross = 3;

             CreateRow(sheet, 2);
             //Row1.Height = 15;
             //Row1.AutoFitHeight = false;
             CreateCell(sheet, 2, 0, CellType.STRING);
             ReturnCell(sheet, 2, 0).SetCellValue("ODM:");
             ReturnCell(sheet, 2, 0).CellStyle = CellRSLStyle_Arial12_Bold; 

             CreateCell(sheet, 2, 1, CellType.STRING);
             ReturnCell(sheet, 2, 1).SetCellValue(dRow["OdmName"].ToString());
             ReturnCell(sheet, 2, 1).CellStyle = CellRSLStyle_Arial12_Bold; 
             //cell.MergeAcross = 3;

             CreateRow(sheet, 3);
             //Row1.Height = 15;
             //Row1.AutoFitHeight = false;
             CreateCell(sheet, 3, 0, CellType.STRING);
             ReturnCell(sheet, 3, 0).SetCellValue("Family Spares:");
             ReturnCell(sheet, 3, 0).CellStyle = CellRSLStyle_Arial12_Bold; 

             CreateCell(sheet, 3, 1, CellType.STRING);
             ReturnCell(sheet, 3, 1).SetCellValue(dRow["ServiceFamilyPn"].ToString());
             ReturnCell(sheet, 3, 1).CellStyle = CellRSLStyle_Arial12_Bold; 
             //cell.MergeAcross = 3;

             CreateRow(sheet, 4);
             
             //Row1.AutoFitHeight = false;
             CreateCell(sheet, 4, 0, CellType.STRING);
             ReturnCell(sheet, 4, 0).SetCellValue("GPLM Contact:");
             ReturnCell(sheet, 4, 0).CellStyle = CellRSLStyle_Arial12_Bold; 
               
             CreateCell(sheet, 4, 1, CellType.STRING);
             ReturnCell(sheet, 4, 1).SetCellValue(dRow["GplmName"].ToString());
             ReturnCell(sheet, 4, 1).CellStyle = CellRSLStyle_Arial12_Bold; 
             //cell.MergeAcross = 3;

             CreateRow(sheet, 5);
             //Row1.Height = 15;
             //Row1.AutoFitHeight = false;
             CreateCell(sheet, 5, 0, CellType.STRING);
             ReturnCell(sheet, 5, 0).SetCellValue("Self Repair Doc:");
             ReturnCell(sheet, 5, 0).CellStyle = CellRSLStyle_Arial12_Bold; 

             CreateCell(sheet, 5, 1, CellType.STRING);
             ReturnCell(sheet, 5, 1).SetCellValue(dRow["SelfRepairDoc"].ToString());
             ReturnCell(sheet, 5, 1).CellStyle = CellRSLStyle_Arial12_Bold; 
             //cell.MergeAcross = 3;
                
             CreateRow(sheet, 6);
             //Row1.Height = 15;
             //Row1.AutoFitHeight = false;
             CreateCell(sheet, 6, 0, CellType.STRING);
             ReturnCell(sheet, 6, 0).SetCellValue("Family Code Name:");
             ReturnCell(sheet, 6, 0).CellStyle = CellRSLStyle_Arial12_Bold;

             CreateCell(sheet, 6, 1, CellType.STRING);
             ReturnCell(sheet, 6, 1).SetCellValue(dRow["FamilyName"].ToString());
             ReturnCell(sheet, 6, 1).CellStyle = CellRSLStyle_Arial12_Bold;

             //GEO
             CreateRow(sheet, 7);
             CreateCell(sheet, 7, 14, CellType.STRING);//merge Cell
             ReturnCell(sheet, 7, 14).SetCellValue("GEO");
             CreateCell(sheet, 7, 15, CellType.STRING);//merge Cell
             CreateCell(sheet, 7, 16, CellType.STRING);//merge Cell
             CreateCell(sheet, 7, 17, CellType.STRING);//merge Cell
             
             ReturnCell(sheet, 7, 14).CellStyle = CellRSLStyle_Arial12_Bold_NoBottonMargin;
             ReturnCell(sheet, 7, 15).CellStyle = CellRSLStyle_Arial12_Bold_NoBottonMargin;
             ReturnCell(sheet, 7, 16).CellStyle = CellRSLStyle_Arial12_Bold_NoBottonMargin;
             ReturnCell(sheet, 7, 17).CellStyle = CellRSLStyle_Arial12_Bold_NoBottonMargin;
 
             sheet.AddMergedRegion(new CellRangeAddress(7, 7, 14, 17));
            
             // Row 7 HPRestricted Comemnt

             //Columns Tables Names
             CreateRow(sheet, 8);
             sheet.GetRow(8).HeightInPoints = 80;               
             //Row8.AutoFitHeight = false;

             CreateCell(sheet, 8, 0, CellType.STRING);
             ReturnCell(sheet, 8, 0).SetCellValue("Part Type");
             ReturnCell(sheet, 8, 0).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;

             CreateCell(sheet, 8, 1, CellType.STRING);
             ReturnCell(sheet, 8, 1).SetCellValue("Spare Part Number");
             ReturnCell(sheet, 8, 1).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;

             CreateCell(sheet, 8, 2, CellType.STRING);
             ReturnCell(sheet, 8, 2).SetCellValue("Rev");
             ReturnCell(sheet, 8, 2).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;

             CreateCell(sheet, 8, 3, CellType.STRING);
             ReturnCell(sheet, 8, 3).SetCellValue("CrossPlant Status");
             ReturnCell(sheet, 8, 3).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;

             CreateCell(sheet, 8, 4, CellType.STRING);
             ReturnCell(sheet, 8, 4).SetCellValue("Spare Kit Description");
             ReturnCell(sheet, 8, 4).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;

             CreateCell(sheet, 8, 5, CellType.STRING);
             ReturnCell(sheet, 8, 5).SetCellValue("MFG Sub Assembly #");
             ReturnCell(sheet, 8, 5).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;

             CreateCell(sheet, 8, 6, CellType.STRING);
             ReturnCell(sheet, 8, 6).SetCellValue("Service Sub Assembly #");
             ReturnCell(sheet, 8, 6).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;

             CreateCell(sheet, 8, 7, CellType.STRING);
             ReturnCell(sheet, 8, 7).SetCellValue("First Service Date (FSD)");
             ReturnCell(sheet, 8, 7).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;   //"s127"; "s129- Date Format";
             //cellStyle.DataFormat = HSSFDataFormat.GetBuiltinFormat("#,#0.0")
             //cellStyle.DataFormat = HSSFDataFormat.GetBuiltinFormat("mm-dd-yy");
            
             CreateCell(sheet, 8, 8, CellType.STRING);
             ReturnCell(sheet, 8, 8).SetCellValue(" CSR - User Replaceable");
             ReturnCell(sheet, 8, 8).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;

             //The patriarch is a container 
            HSSFPatriarch patr = (HSSFPatriarch)sheet.CreateDrawingPatriarch(); 

            //create a comment 
            IComment Comment = patr.CreateCellComment(new HSSFClientAnchor(0, 0, 0, 0, 0, 8,30, 25));
            string msg = "\nEURP Level A\nEURP Level B\nEURP Level C\nEURP Level D\nNo\n\nEURP Level A Skills  – Th" +
                "ose parts that are easily replaceable by non-trained personnel.  These parts are" +
                " normally accessible and replaceable without opening the system enclosure.\nSome " +
                "examples include: Mice, Keyboards, Hot Swappable components, options plugged int" +
                "o external system ports (serial, parallel, USB, etc).\n\nEURP Level B Skills – The" +
                "se parts are accessible and replaceable without opening the system enclosure and" +
                " do not need a tool.\nThese are generally repairable parts or controlled disposal" +
                " parts that must be returned to HP or HP’s designated repair vendor.\n\nThe End-User" +
                " requires a minimal knowledge on how and when to replace the defective part.  \n\n" +
                "EURP Level C Skills - May require tools to open the access panels, and/or to rep" +
                "lace the defective spare. These are repairable parts that must be returned to HP" +
                " or HP’s designated repair vendor. \n\nThe End-User requires a limited knowledge on " +
                "how to service the system, and be familiar with the operating system.\n\nEURP Leve" +
                "l D Skills - :  Will almost always require tools to open the access panels, and/" +
                "or to replace the defective spare.These are repairable parts that must be return" +
                "ed to HP or HP’s designated repair vendor. \n\nThe End-User requires extensive knowl" +
                "edge on how to service the system, and be familiar with the operating system.  \n" +
                "\nNo - The technician must be trained on HP hardware, or have extensive experienc" +
                "e with HP hardware.  In some cases the technician must be an Accredited HP Techn" +
                "ician.\n";
            Comment.String = new HSSFRichTextString(msg);
            Comment.Author = "Peter Lapointe";
            ReturnCell(sheet, 8, 8).CellComment = Comment;

            CreateCell(sheet, 8, 9, CellType.STRING);
            ReturnCell(sheet, 8, 9).SetCellValue("Disposition");
            ReturnCell(sheet, 8, 9).CellStyle = CellRSLStyle_Arial12_Rotate_Bold; 
                
            //create a comment 
            IComment Comment9 = patr.CreateCellComment(new HSSFClientAnchor(0, 0, 0, 0, 0, 9, 1, 15));
                
            Comment9.String = new HSSFRichTextString("\n1 = Disposable\n2 = Repairable\n3 = Return to Vendor\n4 = Repair/Exchange ONLY\n\n\n");
            Comment9.Author = "Valued Employee";
            ReturnCell(sheet, 8, 9).CellComment = Comment9;

            CreateCell(sheet, 8, 10, CellType.STRING);
            ReturnCell(sheet, 8, 10).SetCellValue(" New Spare Part ");
            ReturnCell(sheet, 8, 10).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;

            CreateCell(sheet, 8, 11, CellType.STRING);
            ReturnCell(sheet, 8, 11).SetCellValue(" Warranty Labour Tier");
            ReturnCell(sheet, 8, 11).CellStyle = CellRSLStyle_Arial12_Rotate_Bold; 
               
            //create a comment 
            IComment Comment11= patr.CreateCellComment(new HSSFClientAnchor(0, 0, 0, 0, 0, 11, 1, 20));
            Comment11.String = new HSSFRichTextString("\nA = 0 - 5 minutes\nB = 5 - 10 minutes\nC = 15 - 30 minutes\nD = No Reimbursement\n\nThis information is provided by the GSF-PSM ");
            Comment11.Author = "Peter Lapointe";
            ReturnCell(sheet, 8, 11).CellComment = Comment11;

            CreateCell(sheet, 8, 12, CellType.STRING);
            ReturnCell(sheet, 8, 12).SetCellValue("Local Stock Advise");
            ReturnCell(sheet, 8, 12).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;
             
            //create a comment 
            IComment Comment12 = patr.CreateCellComment(new HSSFClientAnchor(0, 0, 0, 0, 0, 12, 2, 20));
            Comment12.String = new HSSFRichTextString("\n1 - Don\'t stock local (non SPOF and not likely to fail)\n2 - Stock Strategically (" +
                                                                         "non SPOF and likely to fail)\n3 - Stock Local (SPOF and not likely to fail)\n4 - S" +
                                                                        "tock Local Critical (SPOF and likely to fail)\n");
            Comment12.Author = "Justin Elder";
            ReturnCell(sheet, 8, 12).CellComment = Comment12;

            CreateCell(sheet, 8, 13, CellType.STRING);
            ReturnCell(sheet, 8, 13).SetCellValue("PPC Product Line");
            ReturnCell(sheet, 8, 13).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;//"s129";s129.NumberFormat = "d\\-mmm\\-yyyy"

            CreateCell(sheet, 8, 14, CellType.STRING);
            ReturnCell(sheet, 8, 14).SetCellValue("NA");
            ReturnCell(sheet, 8, 14).CellStyle = CellRSLStyle_Arial12_Rotate_Bold_NoTopMargin; //s130.NumberFormat = "Fixed";

            CreateCell(sheet, 8, 15, CellType.STRING);
            ReturnCell(sheet, 8, 15).SetCellValue("LA");
            ReturnCell(sheet, 8, 15).CellStyle = CellRSLStyle_Arial12_Rotate_Bold_NoTopMargin;//s130.NumberFormat = "Fixed";
                
            CreateCell(sheet, 8, 16, CellType.STRING);
            ReturnCell(sheet, 8, 16).SetCellValue("APJ");
            ReturnCell(sheet, 8, 16).CellStyle = CellRSLStyle_Arial12_Rotate_Bold_NoTopMargin; ////"s130";   s130.NumberFormat = "Fixed";
                                
            CreateCell(sheet, 8, 17, CellType.STRING);
            ReturnCell(sheet, 8, 17).SetCellValue("EMEA");
            ReturnCell(sheet, 8, 17).CellStyle = CellRSLStyle_Arial12_Rotate_Bold_NoTopMargin; //s130.NumberFormat = "Fixed";

            int CellNumber;

            if (ProductDivision == "2")// Division 2 - Desktops
            {
                CreateCell(sheet, 8, 18, CellType.STRING);
                ReturnCell(sheet, 8, 18).SetCellValue("Part Supplier (ODM/OEM)");
                ReturnCell(sheet, 8, 18).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;
                CellNumber = 19;
            }
            else// Division 1 - Notebooks 
            {
                CellNumber = 18;         
            }

            foreach (DataRow drVersion in dtProductVersions.Rows)
            {
                CreateCell(sheet, 8, CellNumber, CellType.STRING);
                ReturnCell(sheet, 8, CellNumber).SetCellValue(drVersion["Version"].ToString().Trim());
                ReturnCell(sheet, 8, CellNumber).CellStyle = CellRSLStyle_Arial12_Rotate_Bold; //  s132.NumberFormat = "Fixed";
              
                CellNumber++;
            }
        
            CreateCell(sheet, 8, CellNumber, CellType.STRING);
            ReturnCell(sheet, 8, CellNumber).SetCellValue("Comment");
            ReturnCell(sheet, 8, CellNumber).CellStyle = CellRSLStyle_Arial12_Rotate_Bold;  //"s132";   s132.NumberFormat = "Fixed";
            CommentCellIdx = CellNumber;

            dtProductVersions = null;
            dtHeader = null;
        }

        private void GenerateDataRowRSL(ISheet sheetRSL, HSSFWorkbook hssfWorkBook, ref  string ErrorMessage)
        {
            int emptyCellCnt = 0;
            var dwExcalibur = new HPQ.Excalibur.Data();
            DataTable dtVersions = dwExcalibur.SelectSpareKitVersions(ServiceFamilyPn, CompareDt, Publish); 
            DataTable dt = dwExcalibur.SelectRslDetailsForExport(ProductVersionId, Publish, CompareDt);
            DataRow[] drVersions;

            if (dt.Rows.Count == 0)
            {
                ErrorMessage = "RSL - No Data - Zero Rows Returned:  " + ServiceFamilyPn + ". ";
                //throw new ApplicationException("RSL- No Data -Zero Rows Returned:  " + ServiceFamilyPn + ". ");
            }
            else //if (dt.Rows.Count > 0)
            {

                //Fonts Types
                IFont FontArial = hssfWorkBook.CreateFont();
                FontArial.FontName = "Arial";
                FontArial.FontHeightInPoints = 10;

                // Style
                ICellStyle CellRSLStyle_Arial_AllMargin = hssfWorkBook.CreateCellStyle();
                ICellStyle CellRSLStyle_Arial_AllMargin_Yellow = hssfWorkBook.CreateCellStyle();

                CellRSLStyle_Arial_AllMargin = GenerateCellStyles("StyleArialAllMargin", CellRSLStyle_Arial_AllMargin, FontArial, hssfWorkBook);
                CellRSLStyle_Arial_AllMargin_Yellow = GenerateCellStyles("StyleArialAllMargin_h", CellRSLStyle_Arial_AllMargin_Yellow, FontArial, hssfWorkBook);

                ICellStyle CellRSLStyle_Arial_AllMargin_AligCenter = hssfWorkBook.CreateCellStyle();
                ICellStyle CellRSLStyle_Arial_AllMargin_AligCenter_Yellow = hssfWorkBook.CreateCellStyle();

                CellRSLStyle_Arial_AllMargin_AligCenter = GenerateCellStyles("StyleArial_AllMargin_AligCenter", CellRSLStyle_Arial_AllMargin_AligCenter, FontArial, hssfWorkBook);
                CellRSLStyle_Arial_AllMargin_AligCenter_Yellow = GenerateCellStyles("StyleArial_AllMargin_AligCenter_h", CellRSLStyle_Arial_AllMargin_AligCenter_Yellow, FontArial, hssfWorkBook);

                ICellStyle CellRSLStyle_Arial_AllMargin_Solid_Color = hssfWorkBook.CreateCellStyle();
                ICellStyle CellRSLStyle_Arial_AllMargin_Solid_Color_Yellow = hssfWorkBook.CreateCellStyle();
                CellRSLStyle_Arial_AllMargin_Solid_Color = GenerateCellStyles("StyleArialAllMargin_Solid_Color", CellRSLStyle_Arial_AllMargin_Solid_Color, FontArial, hssfWorkBook);
                CellRSLStyle_Arial_AllMargin_Solid_Color_Yellow = GenerateCellStyles("StyleArialAllMargin_Solid_Color_h", CellRSLStyle_Arial_AllMargin_Solid_Color_Yellow, FontArial, hssfWorkBook);

                int iRowNumber = 9;
                foreach (DataRow row in dt.Rows)
                {
                    drVersions = dtVersions.Select(String.Format("SpareKitId = '{0}'", row["SpareKitId"]));
                    CreateRow(sheetRSL, iRowNumber);

                    CreateCell(sheetRSL, iRowNumber, 0, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 0).SetCellValue(row["CategoryName"].ToString());
                    string Style = GetCellStyle(row, string.Empty, "StyleArialAllMargin");
                    if (Style == "StyleArialAllMargin")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 0).CellStyle = CellRSLStyle_Arial_AllMargin;
                    }
                    else if (Style == "StyleArialAllMarginh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 0).CellStyle = CellRSLStyle_Arial_AllMargin_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 1, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 1).SetCellValue(row["SpareKitNo"].ToString());
                    Style = GetCellStyle(row, string.Empty, "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 1).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 1).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 2, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 2).SetCellValue(row["Revision"].ToString());
                    Style = GetCellStyle(row, "bRevision", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 2).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 2).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 3, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 3).SetCellValue(row["CrossPlantStatus"].ToString());
                    Style = GetCellStyle(row, "bCrossPlantStatus", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 3).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 3).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 4, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 4).SetCellValue(row["Description"].ToString());
                    Style = GetCellStyle(row, "bDescription", "StyleArialAllMargin");
                    if (Style == "StyleArialAllMargin")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 4).CellStyle = CellRSLStyle_Arial_AllMargin;
                    }
                    else if (Style == "StyleArialAllMarginh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 4).CellStyle = CellRSLStyle_Arial_AllMargin_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 5, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 5).SetCellValue(row["MfgSubAssembly"].ToString());
                    Style = GetCellStyle(row, "bMfgSubAssembly", "StyleArialAllMargin");
                    if (Style == "StyleArialAllMargin")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 5).CellStyle = CellRSLStyle_Arial_AllMargin;
                    }
                    else if (Style == "StyleArialAllMarginh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 5).CellStyle = CellRSLStyle_Arial_AllMargin_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 6, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 6).SetCellValue(row["SvcSubAssembly"].ToString());
                    Style = GetCellStyle(row, "bSvcSubAssembly", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 6).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 6).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 7, CellType.STRING);
                    if (row["FirstServiceDt"] == DBNull.Value)
                    {
                        ReturnCell(sheetRSL, iRowNumber, 7).SetCellValue(string.Empty);
                        Style = GetCellStyle(row, string.Empty, "StyleArial_AllMargin_AligCenter");
                    }
                    else
                    {   //DateTime
                        string sChangeDt = row["FirstServiceDt"].ToString();
                        DateTime ChangeDate = Convert.ToDateTime(sChangeDt);
                        ReturnCell(sheetRSL, iRowNumber, 7).SetCellValue(ChangeDate.ToString("d"));
                        Style = GetCellStyle(row, "bFirstServiceDt", "StyleArial_AllMargin_AligCenter");
                    }

                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 7).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 7).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 8, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 8).SetCellValue(row["CsrLevel"].ToString());
                    Style = GetCellStyle(row, "bCsrLevelId", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 8).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 8).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 9, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 9).SetCellValue(row["Disposition"].ToString() == "0" ? string.Empty : row["Disposition"].ToString());
                    Style = GetCellStyle(row, "bDisposition", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 9).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 9).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 10, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 10).SetCellValue((row["ProjectCd"].ToString() != ProjectCd) ? "N" : "Y");
                    Style = GetCellStyle(row, string.Empty, "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 10).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 10).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 11, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 11).SetCellValue(row["WarrantyTier"].ToString() == "0" ? string.Empty : row["WarrantyTier"].ToString());
                    Style = GetCellStyle(row, "bWarrantyTier", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 11).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 11).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 12, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 12).SetCellValue(row["LocalStockAdvice"].ToString() == "0" ? string.Empty : row["LocalStockAdvice"].ToString());
                    Style = GetCellStyle(row, "bLocalStockAdvice", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 12).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 12).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 13, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 13).SetCellValue(row["PpcProductLine"].ToString());
                    Style = GetCellStyle(row, "bPpcProductLine", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 13).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 13).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }
                    CreateCell(sheetRSL, iRowNumber, 14, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 14).SetCellValue(Convert.ToBoolean(row["GeoNa"]) ? "X" : string.Empty);
                    Style = GetCellStyle(row, "bGeoNa", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 14).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 14).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 15, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 15).SetCellValue(Convert.ToBoolean(row["GeoLa"]) ? "X" : string.Empty);
                    Style = GetCellStyle(row, "bGeoLa", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 15).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 15).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 16, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 16).SetCellValue(Convert.ToBoolean(row["GeoApj"]) ? "X" : string.Empty);
                    Style = GetCellStyle(row, "bGeoApj", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 16).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 16).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    CreateCell(sheetRSL, iRowNumber, 17, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, 17).SetCellValue(Convert.ToBoolean(row["GeoEmea"]) ? "X" : string.Empty);
                    Style = GetCellStyle(row, "bGeoEmea", "StyleArial_AllMargin_AligCenter");
                    if (Style == "StyleArial_AllMargin_AligCenter")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 17).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                    }
                    else if (Style == "StyleArial_AllMargin_AligCenterh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, 17).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                    }

                    int IColNumber;

                    if (ProductDivision == "2")// Division=2 Desktops
                    {
                        CreateCell(sheetRSL, iRowNumber, 18, CellType.STRING);
                        ReturnCell(sheetRSL, iRowNumber, 18).SetCellValue(row["supplier"].ToString());
                        Style = GetCellStyle(row, string.Empty, "StyleArial_AllMargin_AligCenter");
                        if (Style == "StyleArial_AllMargin_AligCenter")
                        {
                            ReturnCell(sheetRSL, iRowNumber, 18).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                        }
                        else if (Style == "StyleArial_AllMargin_AligCenterh")
                        {
                            ReturnCell(sheetRSL, iRowNumber, 18).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                        }
                        
                        IColNumber = 19;
                    }
                    else // Division=1 Notebookos
                    {
                        IColNumber = 18;
                    }


                    //Versions
                    foreach (DataRow vRow in drVersions)
                    {
                        CreateCell(sheetRSL, iRowNumber, IColNumber, CellType.STRING);
                        //ReturnCell(sheetRSL, iRowNumber, IColNumber).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                        string VersionData = vRow["VersionSupported"].ToString();

                        if (String.IsNullOrEmpty(VersionData))
                        {
                            ReturnCell(sheetRSL, iRowNumber, IColNumber).SetCellValue(string.Empty);

                            Style = GetCellStyle(row, string.Empty, "StyleArial_AllMargin_AligCenter");
                            if (Style == "StyleArial_AllMargin_AligCenter")
                            {
                                ReturnCell(sheetRSL, iRowNumber, IColNumber).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                            }
                            else if (Style == "StyleArial_AllMargin_AligCenterh")
                            {
                                ReturnCell(sheetRSL, iRowNumber, IColNumber).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                            }
                        }
                        else
                        {
                            ReturnCell(sheetRSL, iRowNumber, IColNumber).SetCellValue("X");
                            Style = GetCellStyle(LastPublishDt < DateTime.Parse(vRow["VersionSupported"].ToString()), "StyleArial_AllMargin_AligCenter");
                            if (Style == "StyleArial_AllMargin_AligCenter")
                            {
                                ReturnCell(sheetRSL, iRowNumber, IColNumber).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                            }
                            else if (Style == "StyleArial_AllMargin_AligCenterh")
                            {
                                ReturnCell(sheetRSL, iRowNumber, IColNumber).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                            }
                        }


                        IColNumber++;
                    }

                    emptyCellCnt = CommentCellIdx - IColNumber;
                    for (int i = 0; i < emptyCellCnt; i++)
                    {
                        CreateCell(sheetRSL, iRowNumber, IColNumber, CellType.STRING);
                        ReturnCell(sheetRSL, iRowNumber, IColNumber).SetCellValue(string.Empty);
                        Style = GetCellStyle(row, string.Empty, "StyleArial_AllMargin_AligCenter");
                        if (Style == "StyleArial_AllMargin_AligCenter")
                        {
                            ReturnCell(sheetRSL, iRowNumber, IColNumber).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter;
                        }
                        else if (Style == "StyleArial_AllMargin_AligCenterh")
                        {
                            ReturnCell(sheetRSL, iRowNumber, IColNumber).CellStyle = CellRSLStyle_Arial_AllMargin_AligCenter_Yellow;
                        }
                        IColNumber++;
                    }

                    CreateCell(sheetRSL, iRowNumber, IColNumber, CellType.STRING);
                    ReturnCell(sheetRSL, iRowNumber, IColNumber).SetCellValue(row["Comments"].ToString());

                    Style = GetCellStyle(row, string.Empty, "StyleArialAllMargin_Solid_Color");

                    if (Style == "StyleArialAllMargin_Solid_Color")
                    {
                        ReturnCell(sheetRSL, iRowNumber, IColNumber).CellStyle = CellRSLStyle_Arial_AllMargin_Solid_Color;
                    }
                    else if (Style == "StyleArialAllMargin_Solid_Colorh")
                    {
                        ReturnCell(sheetRSL, iRowNumber, IColNumber).CellStyle = CellRSLStyle_Arial_AllMargin_Solid_Color_Yellow;
                    }

                    iRowNumber++;
                   }
                }
                dtVersions = null;
                dt = null;

               // return iRowNumber;
            }  

  #endregion


        private ICellStyle GenerateCellStyles(string Style, ICellStyle CellRSLStyle, IFont FontRSL, HSSFWorkbook hssfWorkBook)
        {
            switch (Style)
            {
                case "StylesArial12Bold":
                    CellRSLStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRSLStyle.Alignment = HorizontalAlignment.LEFT;
                    FontRSL.Boldweight = (short)FontBoldWeight.BOLD;                   
                    break;
                case "StylesColumTitleRotateBold":
                    CellRSLStyle.Rotation = 90;
                    CellRSLStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRSLStyle.Alignment = HorizontalAlignment.CENTER;
                    CellRSLStyle.WrapText = true;
                    CellRSLStyle.BorderBottom = BorderStyle.THIN;
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;
                    FontRSL.Boldweight = (short)FontBoldWeight.BOLD;                  
                    ////s126.NumberFormat = "@";
                    break;
                case "StylesColumTitleRotateBoldNoTopMargin":
                    CellRSLStyle.Rotation = 90;
                    CellRSLStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRSLStyle.WrapText = true;
                    CellRSLStyle.BorderBottom = BorderStyle.THIN;
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    FontRSL.Boldweight = (short)FontBoldWeight.BOLD;
                   
                    break;
                case "StylesColumTitleBoldNoBottonMargin":
                    CellRSLStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    //CellRSLStyle.Alignment = HorizontalAlignment.CENTER;
                    CellRSLStyle.WrapText = true;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    FontRSL.Boldweight = (short)FontBoldWeight.BOLD;                
                    break;
                case "StyleArialAllMargin_Solid_Color":
                    CellRSLStyle.BorderBottom = BorderStyle.THIN;
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;                   
                    break;
                case "StyleArialAllMargin_Solid_Color_h":
                    CellRSLStyle.BorderBottom = BorderStyle.THIN;
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;
                    CellRSLStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellRSLStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArialAllMargin": 
                    CellRSLStyle.BorderBottom = BorderStyle.THIN; 
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;
                    CellRSLStyle.WrapText= true; 
                    break;
                case "StyleArialAllMargin_h":
                    CellRSLStyle.BorderBottom = BorderStyle.THIN;
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;
                    CellRSLStyle.WrapText = true;
                    CellRSLStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellRSLStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                 case "StyleArial_AllMargin_WrapText_AligCenter":
                    //CellRSLStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    //CellRSLStyle.Alignment = HorizontalAlignment.CENTER;
                    CellRSLStyle.BorderBottom = BorderStyle.THIN;
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;
                    CellRSLStyle.WrapText = true;                   
                    break;
                case "StyleArial_AllMargin_WrapText_AligCenter_h":
                    //CellRSLStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    //CellRSLStyle.Alignment = HorizontalAlignment.CENTER;
                    CellRSLStyle.BorderBottom = BorderStyle.THIN;
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;
                    CellRSLStyle.WrapText = true;
                    CellRSLStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellRSLStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArial_AllMargin_AligCenter":
                    CellRSLStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRSLStyle.Alignment = HorizontalAlignment.CENTER;
                    CellRSLStyle.BorderBottom = BorderStyle.THIN; 
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;
                    CellRSLStyle.WrapText = true; 
                    break;
                case "StyleArial_AllMargin_AligCenter_h":
                    CellRSLStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellRSLStyle.Alignment = HorizontalAlignment.CENTER;
                    CellRSLStyle.BorderBottom = BorderStyle.THIN;
                    CellRSLStyle.BorderLeft = BorderStyle.THIN;
                    CellRSLStyle.BorderRight = BorderStyle.THIN;
                    CellRSLStyle.BorderTop = BorderStyle.THIN;
                    CellRSLStyle.WrapText = true;
                    CellRSLStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellRSLStyle.FillForegroundColor = IndexedColors.YELLOW.Index;                   
                    break;
                case "StyleArial12Bold_GreyBackground":
                    //FontRSL.Color = IndexedColors.BLACK.Index;
                    CellRSLStyle.VerticalAlignment = VerticalAlignment.BOTTOM;         
                    CellRSLStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellRSLStyle.FillForegroundColor = IndexedColors.GREY_25_PERCENT.Index;
                    break;
                case "StyleBrandYellow": //3743h
                    CellRSLStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellRSLStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                   // FontRSL.Color = IndexedColors.BLACK.Index;
                    break;
                case "StyleBrandYellowStrike":
                    CellRSLStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellRSLStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    FontRSL.Color = IndexedColors.RED.Index;
                    FontRSL.IsStrikeout = true;
                    break;
                case "Restricted":
                    FontRSL.Boldweight = (short)FontBoldWeight.BOLD;
                    FontRSL.Color = IndexedColors.RED.Index;
                    break;
                case "Generated":
                    FontRSL.Boldweight = (short)FontBoldWeight.BOLD;
                    break;           
                 
            }

            CellRSLStyle.SetFont(FontRSL);   
            return CellRSLStyle;
        }

 #region ' GetCellStyle
        private string GetCellStyle(bool ChangedBit, string Style)
        {
            if (ChangedBit)
                return string.Format("{0}h", Style);
            else
                return Style;
        }

        private string GetCellStyle(DataRow Row, string Column, string Style)
        {
            int changeType = 0;

            if (int.TryParse(Row["ChangeType"].ToString(), out changeType))
            {
                if (changeType == 1)
                    return string.Format("{0}h", Style);
            }

            if (string.IsNullOrEmpty(Column))
                return Style;

            object ChangedBit = Row[Column];

            if (ChangedBit == DBNull.Value)
                return Style;

            return GetCellStyle(Convert.ToBoolean(ChangedBit), Style);
        }
 #endregion
        
        static HSSFWorkbook InitializeWorkbook(HSSFWorkbook hssfWorkBook)
        {
            //create a entry of DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();
            
            //dsi.Properties
            dsi.Company = "Excalibur Team";
            hssfWorkBook.DocumentSummaryInformation = dsi;
            
            //create a entry of SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Author = "Excalibur";
            si.LastAuthor = "Excalibur";
            si.CreateDateTime = DateTime.Now;
            si.LastSaveDateTime = DateTime.Now;
            si.RevNumber = "1.00";
            si.Subject = "RSL Export";
            
            hssfWorkBook.SummaryInformation = si;


            return hssfWorkBook;
        }

        static void WriteToFile(Stream RslStream, HSSFWorkbook hssfWorkBook)
        {
           //Write the stream data of workbook to the root directory
           // FileStream file = new FileStream(@"c:\\RslExport.xls", FileMode.Create);
           // hssfWorkBook.Write(file);
            //file.Close();
     
            hssfWorkBook.Write(RslStream);
            
        }
             
  #region #NPOI Utility Functions
        public void CreateRow(ISheet sheet1, int row)
        {
            sheet1.CreateRow(row);
        }

        static void CreateCell(ISheet sheet1, int row, int cell,CellType Type)
        {
            sheet1.GetRow(row).CreateCell(cell, Type);
        }

        static ICell ReturnCell(ISheet sheet1, int row, int cell)
        {
            return sheet1.GetRow(row).GetCell(cell);
        }
#endregion

    }
}

