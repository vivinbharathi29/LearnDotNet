﻿using NPOI.HPSF;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;


namespace SpbGlobalExportNpoi
{
    public class SpbGlobalNpoi
    {
        public int iRowChangeLogNumber = 4;
        public int iRowSPBRowNumber = 6;

        ICellStyle CellSPBStyle_Restricted;
        ICellStyle CellSPBStyle_ReportGenerated;
        ICellStyle StyleArialBold_Top_Thick;
        ICellStyle StyleArialBold_Botton_Thick;
        ICellStyle CellSPBStyle_Arial_Bold;

        //Bold Blue - SpareKit - Level 2
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Blue;
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Blue_Center;
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Yellow;
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center;
        //ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Strike;

        //Light Blue - Sa - Level 3
        ICellStyle CellSPBStyle_Arial_AllMargin_Grey;
        ICellStyle CellSPBStyle_Arial_AllMargin_Grey_SkyBlue;
        ICellStyle CellSPBStyle_Arial_AllMargin_Grey_Yellow;

        ICellStyle CellSPBStyle_Arial_AllMargin;
        ICellStyle CellSPBStyle_Arial_AllMargin_Center;
        ICellStyle CellSPBStyle_Arial_AllMargin_SkyBlue;
        ICellStyle CellSPBStyle_Arial_AllMargin_Center_SkyBlue;
        ICellStyle CellSPBStyle_Arial_AllMargin_Yellow;
        ICellStyle CellSPBStyle_Arial_AllMargin_Center_Yellow;

        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike;
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike;

        ICellStyle CellSPBStyle_Arial_AllMargin_Grey_Strike;
        ICellStyle CellSPBStyle_Arial_AllMargin_Strike;
        ICellStyle CellSPBStyle_Arial_AllMargin_Center_Strike;

        #region ' Properties '

        private bool _newMatrix = false;
        public bool NewMatrix
        {
            get { return _newMatrix; }
            set { _newMatrix = value; }
        }

        private bool _publish = false;
        public bool Publish
        {
            get { return _publish; }
            set { _publish = value; }
        }

        private string _serviceFamilyPn = string.Empty;
        public string ServiceFamilyPn
        {
            get
            {
                return _serviceFamilyPn;
            }
            set { _serviceFamilyPn = value; }
        }

        private string _compareDt = string.Empty;
        public string CompareDt
        {
            get
            {
                DateTime dt;
                if (DateTime.TryParse(_compareDt, out dt))
                {
                    return _compareDt;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _compareDt = value; }
        }

        private string _exportTime = string.Empty;
        public string ExportTime
        {
            get { return _exportTime; }
            set { _exportTime = value; }
        }

        #endregion


        #region "GlobalSpb"

        public void GenGlobalSpbExcel(Stream SpbStream, ref string ErrorMessage)
        {
            try
            {

                // Create Workbook
                HSSFWorkbook hssfWorkBook = new HSSFWorkbook();
                InitializeWorkbook(hssfWorkBook);
                GenerateStyles(hssfWorkBook);

                int intSheetCnt = 0;
                int intSameSheetCnt = 0;
                ISheet sheetSPB;
                string strSheetName = string.Empty;
                string strLastOdmName = string.Empty;

                strSheetName = "Global SPB";

                // Create the Sheets
                sheetSPB = (HSSFSheet)hssfWorkBook.CreateSheet(strSheetName);
                hssfWorkBook.GetSheetAt(intSheetCnt).IsSelected = true;
                hssfWorkBook.GetSheet(strSheetName).IsActive = true;

                intSheetCnt++;

                //Header
                GenGlobalSpbHeader(sheetSPB, hssfWorkBook);

                //Row start from
                iRowSPBRowNumber = 2;

                sheetSPB.SetMargin(MarginType.BottomMargin, 0.5);
                sheetSPB.SetMargin(MarginType.LeftMargin, 0.25);
                sheetSPB.SetMargin(MarginType.RightMargin, 0.25);
                sheetSPB.SetMargin(MarginType.TopMargin, 0.5);

                try
                {
                    SpbData dwExcalibur = new SpbData();
                    DataTable dt;
                    try
                    {
                        Console.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "  Start reading data from database.");
                        dt = dwExcalibur.SelectGlobalSpbPublished();
                        Console.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "  Finish reading data from database.");
                    }
                    catch (Exception err)
                    {
                        Console.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "  Error - reading data from database.");
                        ErrorMessage += err.Message;
                        dt = new DataTable();
                    }

                    if (dt.Rows.Count == 0)
                    {
                        ErrorMessage += "SPB - No Data - Zero Rows Returned from Published SPB Data. ";
                    }
                    else
                    {
                        string sLastSpareKit = String.Empty;
                        string sLastSA = String.Empty;
                        string sLastPart = String.Empty;
                        string SpsKitPn = String.Empty;
                        string SaPn = String.Empty;
                        string PartPn = String.Empty;
                        string XplantStatus = String.Empty;

                        Console.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "  Start filling data into Excel file.");

                        foreach (DataRow row in dt.Rows)
                        {
                            SpsKitPn = row["SpsKitPn"].ToString().Trim();
                            SaPn = row["SaPn"].ToString().Trim();
                            PartPn = row["PartPn"].ToString().Trim();
                            XplantStatus = row["SpsXplantStatus"].ToString().Trim();
                            string SpsKitDelCat = row["SpsKitDelCat"].ToString().Trim();

                            if ((iRowSPBRowNumber > 60000) && (sLastSpareKit != SpsKitPn) && (SpsKitPn != String.Empty))
                            {
                                intSameSheetCnt++;
                                sheetSPB = (HSSFSheet)hssfWorkBook.CreateSheet(strSheetName + "-" + (intSameSheetCnt + 1).ToString());
                                hssfWorkBook.GetSheetAt(intSheetCnt - 1).IsSelected = false;
                                hssfWorkBook.GetSheetAt(intSheetCnt).IsSelected = true;
                                intSheetCnt++;

                                //Header
                                GenGlobalSpbHeader(sheetSPB, hssfWorkBook);

                                //Row start from
                                iRowSPBRowNumber = 2;

                                sheetSPB.SetMargin(MarginType.BottomMargin, 0.5);
                                sheetSPB.SetMargin(MarginType.LeftMargin, 0.25);
                                sheetSPB.SetMargin(MarginType.RightMargin, 0.25);
                                sheetSPB.SetMargin(MarginType.TopMargin, 0.5);

                                Console.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "  a new worksheet created.");
                            }

                            if ((XplantStatus != "C1") && (XplantStatus != "C6") && (XplantStatus != "C9")) // Also exclude on Stored Procedure
                            {
                                if ((sLastSpareKit != SpsKitPn) && (SpsKitPn != String.Empty))
                                {
                                    AddSpareKitRow(hssfWorkBook, sheetSPB, row);
                                    sLastSpareKit = SpsKitPn;
                                    sLastSA = SaPn;
                                    sLastPart = PartPn;

                                }

                                else if ((sLastSA != SaPn) && (SaPn != String.Empty))
                                {
                                    AddSaRow(hssfWorkBook, sheetSPB, row);
                                    sLastSA = SaPn;
                                    sLastPart = PartPn;

                                }

                                else if ((sLastPart != PartPn) && (PartPn != String.Empty))
                                {
                                    AddPartRow(hssfWorkBook, sheetSPB, row);
                                    sLastPart = PartPn;

                                }

                            }

                        }

                        dt = null;
                        Console.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "  complete filling data into Excel file.");
                    }


                }
                catch (Exception ex)
                {
                    throw new Exception("SPB-Err in GenerateDataRowSPB " + ex.ToString());
                }



                if (intSheetCnt > 0)
                {
                    hssfWorkBook.GetSheetAt(intSheetCnt - 1).IsSelected = false;
                    hssfWorkBook.SetActiveSheet(0);
                }

                WriteToFile(SpbStream, hssfWorkBook);
            }
            catch (Exception ex)
            {
                throw new Exception("Err in GenGlobalSpbExcel: " + ServiceFamilyPn + ". " + ex.ToString());
            }
        }




        private void GenGlobalSpbHeader(ISheet sheet, HSSFWorkbook hssfWorkBook)
        {
            // //Set Column Widths
            sheet.SetColumnWidth(0, 6000);//PartType
            sheet.SetColumnWidth(1, 2000);//Level
            sheet.SetColumnWidth(2, 5000);//OSSP Orderable
            sheet.SetColumnWidth(3, 2000);//Line Item
            sheet.SetColumnWidth(4, 4500);//Spare Kit PN
            sheet.SetColumnWidth(5, 1500);//Rev
            sheet.SetColumnWidth(6, 2000);//CrossPlatStatus
            sheet.SetColumnWidth(7, 1500);//Qty
            sheet.SetColumnWidth(8, 1500);//PriAltGen
            sheet.SetColumnWidth(9, 5000);//HP 6-3 Component
            sheet.SetColumnWidth(10, 10000);//"HP Part Description"
            sheet.SetColumnWidth(11, 2000);//PL (GPG division code)
            sheet.SetColumnWidth(12, 4500);//ODM Part Number
            sheet.SetColumnWidth(13, 12000);//ODM Part Description
            sheet.SetColumnWidth(14, 5000);//ODM Bulk Part Number
            sheet.SetColumnWidth(15, 5000);//ODM Production MOQ
            sheet.SetColumnWidth(16, 5000);//ODM Post-Production MOQ
            sheet.SetColumnWidth(17, 5000);//Part Supplier (ODM/OEM)
            sheet.SetColumnWidth(18, 5000);//Model / Mfg Pn
            sheet.SetColumnWidth(19, 5000);//Comment

            //Fonts Types
            IFont FontArial_10_Bold = hssfWorkBook.CreateFont();
            FontArial_10_Bold.FontName = "Arial";
            FontArial_10_Bold.FontHeightInPoints = 10;

            // Style
            ICellStyle CellSPBStyle_Arial10_Bold_Center = hssfWorkBook.CreateCellStyle();
            ICellStyle CellSPBStyle_Arial10_Bold_Right = hssfWorkBook.CreateCellStyle();
            ICellStyle CellSPBStyle_Arial10_Bold_Left = hssfWorkBook.CreateCellStyle();
            ICellStyle CellSPBStyle_Arial10_Bold_WrapText = hssfWorkBook.CreateCellStyle();

            CellSPBStyle_Arial10_Bold_Center = GenerateCellStyles("StylesArial10Bold_Center", CellSPBStyle_Arial10_Bold_Center, FontArial_10_Bold, hssfWorkBook);
            CellSPBStyle_Arial10_Bold_Right = GenerateCellStyles("StylesArial10Bold_Right", CellSPBStyle_Arial10_Bold_Right, FontArial_10_Bold, hssfWorkBook);
            CellSPBStyle_Arial10_Bold_Left = GenerateCellStyles("StylesArial10Bold_Left", CellSPBStyle_Arial10_Bold_Left, FontArial_10_Bold, hssfWorkBook);
            CellSPBStyle_Arial10_Bold_WrapText = GenerateCellStyles("StylesArial10Bold_Wrap", CellSPBStyle_Arial10_Bold_WrapText, FontArial_10_Bold, hssfWorkBook);

            //1st Row - This is the 1st header row.
            CreateRow(sheet, 0);
            //WorksheetCell cells;

            CreateCell(sheet, 0, 0, CellType.STRING);


            // Row 1  Hp Restricted
            GenerateHPRestricted(1, sheet, hssfWorkBook);

            // Row 0 Title
            IFont FontVerdana_14 = hssfWorkBook.CreateFont();
            FontVerdana_14.FontName = "verdana";
            FontVerdana_14.FontHeightInPoints = 14;
            ICellStyle CellSPBStyle_ReportGenerated = hssfWorkBook.CreateCellStyle();
            CellSPBStyle_ReportGenerated = GenerateCellStyles("Generated", CellSPBStyle_ReportGenerated, FontVerdana_14, hssfWorkBook);
            ReturnCell(sheet, 0, 0).CellStyle = CellSPBStyle_ReportGenerated;
            ReturnCell(sheet, 0, 0).SetCellValue("Global SPB");

            int intHeaderRow = 2;
            int intColumnCount = 20; // intColumnCount-1 = the index of the last column

            CreateRow(sheet, intHeaderRow);
            sheet.GetRow(intHeaderRow).HeightInPoints = 38;

            List<String> lstColumnName = new List<String>();
            List<ICellStyle> lstCellSPBStyle = new List<ICellStyle>();
            lstColumnName.Add("Part Type");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_Left);
            lstColumnName.Add("Level");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_Center);
            lstColumnName.Add("OSSP Orderable PN Yes/No");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("Line Item");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("Spare Kit PN");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_Left);
            lstColumnName.Add("Rev");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("Cross Plant Status");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("Qty");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_Center);
            lstColumnName.Add("Pri Alt Gen");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("HP 6-3 Component or SA PN");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("HP Part Description");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_Left);
            lstColumnName.Add("PL");   //PL = GPG division code
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_Center);
            lstColumnName.Add("ODM Part Number");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("ODM Part Description");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("ODM Bulk Part Number");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("ODM Production MOQ");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("ODM Post-Production MOQ");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("Part Supplier (ODM/OEM)");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("Model / Mfg Pn");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_WrapText);
            lstColumnName.Add("Comment");
            lstCellSPBStyle.Add(CellSPBStyle_Arial10_Bold_Left);

            for (int i = 0; i <= intColumnCount - 1; i++)
            {
                CreateCell(sheet, intHeaderRow, i, CellType.STRING);
                ReturnCell(sheet, intHeaderRow, i).SetCellValue(lstColumnName[i]);
                ReturnCell(sheet, intHeaderRow, i).CellStyle = lstCellSPBStyle[i];
            }

            //The patriarch is a container 
            HSSFPatriarch patr = (HSSFPatriarch)sheet.CreateDrawingPatriarch();


            string msgLevel = "Level 2 = HP Spare Kit \n\n Level 3 = HP Sub-Assembly or Component  \n\n Level 4 = HP component PN";
            string msgPriAltGen = "Primary/Alternate designation simply means use one of the items listed.  Primary does not mean preferred.";
            string msgPL = "GPG Division Code";

            //create a comment 
            IComment CommentLevel = patr.CreateCellComment(new HSSFClientAnchor(0, 0, 0, 0, 0, 2, 3, 8));
            CommentLevel.String = new HSSFRichTextString(msgLevel);
            CommentLevel.Author = " ";
            ReturnCell(sheet, intHeaderRow, 1).CellComment = CommentLevel;

            IComment CommentPriAltGen = patr.CreateCellComment(new HSSFClientAnchor(0, 0, 0, 0, 0, 2, 3, 8));
            CommentPriAltGen.String = new HSSFRichTextString(msgPriAltGen);
            CommentPriAltGen.Author = " ";
            ReturnCell(sheet, intHeaderRow, 8).CellComment = CommentPriAltGen;

            IComment CommentPL = patr.CreateCellComment(new HSSFClientAnchor(0, 0, 0, 0, 0, 2, 3, 8));
            CommentPL.String = new HSSFRichTextString(msgPL);
            CommentPL.Author = " ";
            ReturnCell(sheet, intHeaderRow, 11).CellComment = CommentPL;

            sheet.CreateFreezePane(0, 3);

        }







        #endregion //"GlobalSpb"



        #region 'SPB DATA -Row'

        private void AddSpareKitRow(HSSFWorkbook hssfWorkBook, ISheet sheetSPB, DataRow drow)
        {
            try
            {
                if (ValidRow(drow, BomLevelEnum.Kit))
                {
                    int intColIdx = 0;

                    iRowSPBRowNumber++;
                    CreateRow(sheetSPB, iRowSPBRowNumber);

                    sheetSPB.GetRow(iRowSPBRowNumber).HeightInPoints = 16;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Part Type
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsKitDelCat"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsKitDelCat", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.NUMERIC);//Level
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("2");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Ossp Orderable
                    if (drow["SpsKitOsspOrderable"].ToString() == "")
                    {
                        ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("FG");
                    }
                    else
                    {
                        string sSpsKitOsspOrderable = (bool)drow["SpsKitOsspOrderable"] ? "Yes" : "No";

                        if (sSpsKitOsspOrderable == "Yes")
                        {
                            ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(sSpsKitOsspOrderable);
                        }
                        else
                        {
                            ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("FG");
                        }
                    }
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center); //+ WrapText

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Line Item
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//HP Spare Kit Pn
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsKitPn"].ToString().Trim());
                    string skit = drow["SpsKitPn"].ToString().Trim();
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsKitPn", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Rev
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsKitRev"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsKitRev", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center); //+ WrapText

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//XPlant
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsXplantStatus"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsXPlantStatus", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);//+ WrapText

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Qty
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsQty"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);// Pri Alt Gen
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//HP Pn
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);// HP Description
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsKitDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsKitDescription", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//PL (GPG division code) 
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsDivision"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsDivision", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Odm Pn
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsOdmPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmPartNo", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Odm Description
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsOdmPartDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmPartDescription", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Odm Bulk Pn
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsOdmBulkPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmBulkPartNo", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Odm Production Moq
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsOdmProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmProductionMoq", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Odm Post-Production Moq
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsOdmPostProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmPostProductionMoq", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//sparekit Supplier
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsSupplier"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Model
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsModel"].ToString().Trim());
                    //ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Comments
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsComments"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsComments", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    if (drow["SaPn"].ToString() != String.Empty)
                    {
                        string SaXplantStatus = drow["SaXplantStatus"].ToString().Trim();
                        if ((SaXplantStatus != "C1") && (SaXplantStatus != "C6"))
                        {
                            AddSaRow(hssfWorkBook, sheetSPB, drow);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddSpareKitRow" + ex.ToString());
            }
        }


        private void AddSaRow(HSSFWorkbook hssfWorkBook, ISheet sheetSPB, DataRow drow)
        {
            try
            {
                if ((drow["SaPn"].ToString() != String.Empty) && (ValidRow(drow, BomLevelEnum.SubAssembly)))
                {
                    int intColIdx = 0;
                    iRowSPBRowNumber++;
                    CreateRow(sheetSPB, iRowSPBRowNumber);
                    sheetSPB.GetRow(iRowSPBRowNumber).HeightInPoints = 16;

                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Part Type
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsKitDelCat"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Grey);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Level                
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("3");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Center);//s46

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);

                    string sSaOsspOrderable = (bool)drow["SaOsspOrderable"] ? "Yes" : "No";

                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(sSaOsspOrderable);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOsspOrderable", CellSPBStyle_Arial_AllMargin_Center);//s47

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaBomItemNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaBomItemNo", CellSPBStyle_Arial_AllMargin_Center);//s47

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsKitPn"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SpsKitPn", CellSPBStyle_Arial_AllMargin_Grey);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaRev"].ToString());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaRev", CellSPBStyle_Arial_AllMargin_Center);//s79

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaXplantStatus"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaXPlantStatus", CellSPBStyle_Arial_AllMargin_Center);//s79

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaQty"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaQty", CellSPBStyle_Arial_AllMargin_Center);//s79

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaPriAlt"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaPriAlt", CellSPBStyle_Arial_AllMargin_Center);//s79

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaPn"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaPn", CellSPBStyle_Arial_AllMargin);//s60

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaDescription", CellSPBStyle_Arial_AllMargin);//s60

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//PL (GPG division code) 
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaDivision"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaDivision", CellSPBStyle_Arial_AllMargin_Center);//s60

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaOdmPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmPartNo", CellSPBStyle_Arial_AllMargin);//s60

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaOdmPartDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmPartDescription", CellSPBStyle_Arial_AllMargin);//s60

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaOdmBulkPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmBulkPartNo", CellSPBStyle_Arial_AllMargin);//s60

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaOdmProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmProductionMoq", CellSPBStyle_Arial_AllMargin);//s60

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaOdmPostProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmPostProductionMoq", CellSPBStyle_Arial_AllMargin);//s60

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaSupplier"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "PartSupplier", CellSPBStyle_Arial_AllMargin);//s60

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);//Model
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SaComments"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaComments", CellSPBStyle_Arial_AllMargin);//s60

                    if (drow["PartPn"].ToString() != String.Empty)
                    {
                        string PartXPlantStatus = drow["PartXPlantStatus"].ToString().Trim();
                        if ((PartXPlantStatus != "C1") && (PartXPlantStatus != "C6"))
                        {
                            AddPartRow(hssfWorkBook, sheetSPB, drow);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddSaRow" + ex.ToString());
            }
        }


        private void AddPartRow(HSSFWorkbook hssfWorkBook, ISheet sheetSPB, DataRow drow)
        {

            try
            {
                if ((drow["PartPn"].ToString() != String.Empty) && (ValidRow(drow, BomLevelEnum.Part)))
                {
                    int intColIdx = 0;
                    iRowSPBRowNumber++;
                    CreateRow(sheetSPB, iRowSPBRowNumber);
                    sheetSPB.GetRow(iRowSPBRowNumber).HeightInPoints = 15;

                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsKitDelCat"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "SpsKitDelCat", CellSPBStyle_Arial_AllMargin_Grey);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue("4");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);

                    string sPartOsspOrderable = (bool)drow["PartOsspOrderable"] ? "Yes" : "No";

                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(sPartOsspOrderable);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOsspOrderable", CellSPBStyle_Arial_AllMargin_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartBomItemNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartBomItemNo", CellSPBStyle_Arial_AllMargin_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["SpsKitPn"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "SpsKitPn", CellSPBStyle_Arial_AllMargin_Grey);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartRev"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartRev", CellSPBStyle_Arial_AllMargin_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartXplantStatus"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartXPlantStatus", CellSPBStyle_Arial_AllMargin_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartQty"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartQty", CellSPBStyle_Arial_AllMargin_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartPriAlt"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartPriAlt", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartPn"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartPn", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartDescription", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartDivision"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartDivision", CellSPBStyle_Arial_AllMargin_Center);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartOdmPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmPartNo", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartOdmPartDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmPartDescription", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartOdmBulkPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmBulkPartNo", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartOdmProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmProductionMoq", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartOdmPostProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmPostProductionMoq", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartSupplier"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartSupplier", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartModel"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartModel", CellSPBStyle_Arial_AllMargin);

                    intColIdx++;
                    CreateCell(sheetSPB, iRowSPBRowNumber, intColIdx, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).SetCellValue(drow["PartComments"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, intColIdx).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartComments", CellSPBStyle_Arial_AllMargin);

                }


            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddPartRow" + ex.ToString());
            }
        }

        private bool ValidRow(DataRow drow, BomLevelEnum BomLevel)
        {
            string sKitMatlType = drow["SpsMatlType"].ToString().Trim();
            string sSaMatlType = drow["SaMatlType"].ToString().Trim();
            string sPartMatlType = drow["PartMatlType"].ToString().Trim();
            bool bValidType = false;

            string sKitXplantStatus = drow["SpsXplantStatus"].ToString().Trim();
            string sSaXplantStatus = drow["SaXplantStatus"].ToString().Trim();
            string sPartXplantStatus = drow["PartXplantStatus"].ToString().Trim();
            bool bValidStatus = false;

            switch (BomLevel)
            {
                case BomLevelEnum.Kit:
                    bValidType = ValidMaterial(sKitMatlType);
                    bValidStatus = ValidStatus(sKitXplantStatus);
                    break;
                case BomLevelEnum.SubAssembly:
                    bValidType = (ValidMaterial(sKitMatlType) && ValidMaterial(sSaMatlType));
                    bValidStatus = (ValidStatus(sKitXplantStatus) && ValidStatus(sSaXplantStatus));
                    break;
                case BomLevelEnum.Part:
                    bValidType = (ValidMaterial(sKitMatlType) && ValidMaterial(sSaMatlType) && ValidMaterial(sPartMatlType));
                    bValidStatus = (ValidStatus(sKitXplantStatus) && ValidStatus(sSaXplantStatus) && ValidStatus(sPartXplantStatus));
                    break;
            }

            return bValidType && bValidStatus;
        }

        private enum ChangeType : int
        {
            Add = 1,
            Change = 2,
            Remove = 3
        };

        private enum BomLevelEnum : int
        {
            Kit,
            SubAssembly,
            Part
        }

        private bool ValidMaterial(string MatlType)
        {
            switch (MatlType.ToUpper().Trim())
            {
                case "HALB":
                    return true;
                case "FERT":
                    return true;
                case "ROH":
                    return true;
                default:
                    return false;
            }
        }

        private bool ValidStatus(string XplantStatus)
        {
            switch (XplantStatus.ToUpper().Trim())
            {
                case "C2":
                    return true;
                case "C5":
                    return true;
                default:
                    return true;
            }
        }

        #endregion

        private void GenerateHPRestricted(int row, ISheet sheetSPB, HSSFWorkbook hssfWorkBook)
        {
            SpbData dwExcalibur = new SpbData();
            string strLatestPublishDt = string.Empty;
            try
            {
                strLatestPublishDt = (Convert.ToDateTime(dwExcalibur.GetSpbLatestPublishDt())).ToString("MM/dd/yyyy");
                Console.WriteLine("Data Source date: " + strLatestPublishDt);
            }
            catch (Exception ex)
            {
                strLatestPublishDt = "";
                throw;
            }

            //Fonts Types
            IFont FontVerdana_13_Red = hssfWorkBook.CreateFont();
            FontVerdana_13_Red.FontName = "verdana";
            FontVerdana_13_Red.FontHeightInPoints = 13;

            IFont FontVerdana_13 = hssfWorkBook.CreateFont();
            FontVerdana_13.FontName = "verdana";
            FontVerdana_13.FontHeightInPoints = 13;

            // Styles
            ICellStyle CellSPBStyle_Restricted = hssfWorkBook.CreateCellStyle();
            CellSPBStyle_Restricted = GenerateCellStyles("Restricted", CellSPBStyle_Restricted, FontVerdana_13_Red, hssfWorkBook);

            ICellStyle CellSPBStyle_ReportGenerated = hssfWorkBook.CreateCellStyle();
            CellSPBStyle_ReportGenerated = GenerateCellStyles("Generated", CellSPBStyle_ReportGenerated, FontVerdana_13, hssfWorkBook);

            CreateRow(sheetSPB, row);//RConfidential
            CreateCell(sheetSPB, row, 0, CellType.STRING);
            ReturnCell(sheetSPB, row, 0).SetCellValue("HP - Restricted");
            ReturnCell(sheetSPB, row, 0).CellStyle = CellSPBStyle_Restricted;

            CreateCell(sheetSPB, row, 1, CellType.STRING);//Report Generated
            ReturnCell(sheetSPB, row, 1).SetCellValue("SPB Published " + strLatestPublishDt);
            ReturnCell(sheetSPB, row, 1).CellStyle = CellSPBStyle_ReportGenerated;

        }

        static HSSFWorkbook InitializeWorkbook(HSSFWorkbook hssfWorkBook)
        {
            //create a entry of DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();

            //dsi.Properties
            dsi.Company = "Pulsar Team";
            hssfWorkBook.DocumentSummaryInformation = dsi;

            //create a entry of SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Author = "Pulsar Team";
            si.LastAuthor = "Pulsar Team";
            si.CreateDateTime = DateTime.Now;
            si.LastSaveDateTime = DateTime.Now;
            si.RevNumber = "1.00";
            si.Subject = "SPB Global Report Export";

            hssfWorkBook.SummaryInformation = si;

            return hssfWorkBook;
        }

        #region ' CellStyle'

        private void GenerateStyles(HSSFWorkbook hssfWorkBook)
        {
            try
            {
                // FONT  Styles
                IFont FontArialBold_Red = hssfWorkBook.CreateFont();

                IFont FontArial = hssfWorkBook.CreateFont();
                IFont FontArial_Strike = hssfWorkBook.CreateFont();
                IFont FontArial_Bold = hssfWorkBook.CreateFont();
                IFont FontArial_Bold_Strike = hssfWorkBook.CreateFont();
                IFont FontArial_Grey = hssfWorkBook.CreateFont();
                IFont FontArial_Grey_Strike = hssfWorkBook.CreateFont();

                FontArial.FontName = "Arial";
                FontArial_Strike.FontName = "Arial";
                FontArial_Grey.FontName = "Arial";
                FontArial_Grey_Strike.FontName = "Arial";


                FontArial_Bold.FontName = "Arial";
                FontArial_Bold.Boldweight = (short)FontBoldWeight.BOLD;

                FontArial_Bold_Strike.FontName = "Arial";
                FontArial_Bold_Strike.Boldweight = (short)FontBoldWeight.BOLD;

                FontArialBold_Red.FontName = "Arial";
                FontArialBold_Red.Boldweight = (short)FontBoldWeight.BOLD;

                //Column Styles
                CellSPBStyle_Restricted = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_ReportGenerated = hssfWorkBook.CreateCellStyle();

                StyleArialBold_Top_Thick = hssfWorkBook.CreateCellStyle();
                StyleArialBold_Botton_Thick = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_Bold = hssfWorkBook.CreateCellStyle();

                StyleArialBold_Top_Thick = GenerateCellStyles("StylesArialBold_Top_Thick", StyleArialBold_Top_Thick, FontArial_Bold, hssfWorkBook);
                StyleArialBold_Botton_Thick = GenerateCellStyles("StylesArialBold_Botton_Thick", StyleArialBold_Botton_Thick, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Restricted = GenerateCellStyles("Restricted", CellSPBStyle_Restricted, FontArialBold_Red, hssfWorkBook);
                CellSPBStyle_ReportGenerated = GenerateCellStyles("Generated", CellSPBStyle_ReportGenerated, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Arial_Bold = GenerateCellStyles("Bold", CellSPBStyle_Arial_Bold, FontArial_Bold, hssfWorkBook);

                //Bold Blue - SpareKit - Level 2
                CellSPBStyle_Arial_AllMargin_Bold_Blue = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Center = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Yellow = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center = hssfWorkBook.CreateCellStyle();

                CellSPBStyle_Arial_AllMargin_Bold_Blue = GenerateCellStyles("StyleArialAllMargin_Bold_Blue", CellSPBStyle_Arial_AllMargin_Bold_Blue, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Center = GenerateCellStyles("StyleArialAllMargin_Bold_Blue_Center", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Bold_Yellow = GenerateCellStyles("StyleArialAllMargin_Bold_Yellow", CellSPBStyle_Arial_AllMargin_Bold_Yellow, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center = GenerateCellStyles("StyleArialAllMargin_Bold_Yellow_Center", CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center, FontArial_Bold, hssfWorkBook);

                //Light Blue - Sa - Level 3
                CellSPBStyle_Arial_AllMargin_Grey = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Grey = GenerateCellStyles("StyleArialAllMargin_Grey", CellSPBStyle_Arial_AllMargin_Grey, FontArial_Grey, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Grey_SkyBlue = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Grey_SkyBlue = GenerateCellStyles("StyleArialAllMargin_SkyBlue_Grey", CellSPBStyle_Arial_AllMargin_Grey_SkyBlue, FontArial_Grey, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Grey_Yellow = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Grey_Yellow = GenerateCellStyles("StyleArialAllMargin_Grey_Yellow", CellSPBStyle_Arial_AllMargin_Grey_Yellow, FontArial_Grey, hssfWorkBook);

                CellSPBStyle_Arial_AllMargin = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin = GenerateCellStyles("StyleArialAllMargin", CellSPBStyle_Arial_AllMargin, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Center = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Center = GenerateCellStyles("StyleArialAllMargin_Center", CellSPBStyle_Arial_AllMargin_Center, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_SkyBlue = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_SkyBlue = GenerateCellStyles("StyleArialAllMargin_SkyBlue", CellSPBStyle_Arial_AllMargin_SkyBlue, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Center_SkyBlue = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Center_SkyBlue = GenerateCellStyles("StyleArialAllMargin_SkyBlue_Center", CellSPBStyle_Arial_AllMargin_Center_SkyBlue, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Yellow = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Yellow = GenerateCellStyles("StyleArialAllMargin_Yellow", CellSPBStyle_Arial_AllMargin_Yellow, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Center_Yellow = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Center_Yellow = GenerateCellStyles("StyleArialAllMargin_Yellow_Center", CellSPBStyle_Arial_AllMargin_Center_Yellow, FontArial, hssfWorkBook);

                //strike
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike = GenerateCellStyles("StyleArialAllMargin_Bold_Blue_Strike", CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike, FontArial_Bold_Strike, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike = GenerateCellStyles("StyleArialAllMargin_Bold_Blue_Center_Strike", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike, FontArial_Bold_Strike, hssfWorkBook);

                CellSPBStyle_Arial_AllMargin_Grey_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Grey_Strike = GenerateCellStyles("StyleArialAllMargin_Grey_Strike", CellSPBStyle_Arial_AllMargin_Grey_Strike, FontArial_Grey_Strike, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Strike = GenerateCellStyles("StyleArialAllMargin_Strike", CellSPBStyle_Arial_AllMargin_Strike, FontArial_Strike, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Center_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Center_Strike = GenerateCellStyles("StyleArialAllMargin_Center_Strike", CellSPBStyle_Arial_AllMargin_Center_Strike, FontArial_Strike, hssfWorkBook);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GenerateStyles: " + ex.ToString());
            }
        }

        private ICellStyle GenerateCellStyles(string Style, ICellStyle CellSPBStyle, IFont FontSPB, HSSFWorkbook hssfWorkBook)
        {
            switch (Style)
            {
                case "StylesArialBold_Top_Thick":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderTop = BorderStyle.THICK;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    break;
                case "StylesArialBold_Botton_Thick":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THICK;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    break;
                case "StylesArial10Bold_Center":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    //CellSPBStyle.BorderBottom = BorderStyle.DOTTED; 
                    break;
                case "StylesArial10Bold_Right":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.RIGHT;
                    //CellSPBStyle.BorderBottom = BorderStyle.DOTTED; 
                    break;
                case "StylesArial10Bold_Left": //s27 //s42
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.LEFT;
                    // CellSPBStyle.BorderBottom = BorderStyle.DOTTED; 
                    break;
                case "StylesArial10Bold_Wrap":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.WrapText = true;
                    break;
                case "Restricted":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    FontSPB.Color = IndexedColors.RED.Index;
                    break;
                case "Generated":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    break;
                case "StyleArialAllMargin_Bold_Blue":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    break;
                case "StyleArialAllMargin_Bold_Blue_Center":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    break;
                case "StyleArialAllMargin_Bold_Yellow":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArialAllMargin_Bold_Yellow_Center":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArialAllMargin_Grey":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    FontSPB.Color = IndexedColors.GREY_50_PERCENT.Index;
                    break;
                case "StyleArialAllMargin_SkyBlue_Grey":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    //CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    CellSPBStyle.FillForegroundColor = GetColour(System.Drawing.Color.FromArgb(219, 238, 243), hssfWorkBook);
                    CellSPBStyle.FillForegroundColor = GetColour(System.Drawing.Color.FromArgb(219, 238, 243), hssfWorkBook);
                    FontSPB.Color = IndexedColors.GREY_50_PERCENT.Index;
                    break;
                case "StyleArialAllMargin_Grey_Yellow":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    FontSPB.Color = IndexedColors.GREY_50_PERCENT.Index;
                    break;
                case "StyleArialAllMargin":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    break;
                case "StyleArialAllMargin_Yellow":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArialAllMargin_SkyBlue":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    //CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    CellSPBStyle.FillForegroundColor = GetColour(System.Drawing.Color.FromArgb(219, 238, 243), hssfWorkBook);
                    break;
                case "StyleArialAllMargin_Center":
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    break;
                case "StyleArialAllMargin_Yellow_Center":
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArialAllMargin_SkyBlue_Center":
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    //CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    CellSPBStyle.FillForegroundColor = GetColour(System.Drawing.Color.FromArgb(219, 238, 243), hssfWorkBook);
                    break;
                case "StyleArialAllMargin_Bold_Blue_Strike":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    FontSPB.IsStrikeout = true;
                    break;
                case "StyleArialAllMargin_Bold_Blue_Center_Strike":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    FontSPB.IsStrikeout = true;
                    break;
                case "StyleArialAllMargin_Strike":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    FontSPB.IsStrikeout = true;
                    break;
                case "StyleArialAllMargin_Grey_Strike":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    FontSPB.Color = IndexedColors.GREY_50_PERCENT.Index;
                    FontSPB.IsStrikeout = true;
                    break;
                case "StyleArialAllMargin_Center_Strike":
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    FontSPB.IsStrikeout = true;
                    break;

            }

            CellSPBStyle.SetFont(FontSPB);
            return CellSPBStyle;
        }


        private short GetColour(System.Drawing.Color SystemColour, HSSFWorkbook hssfWorkBook)
        {
            HSSFPalette XlPalette = hssfWorkBook.GetCustomPalette();

            NPOI.HSSF.Util.HSSFColor XlColour = XlPalette.FindColor(SystemColour.R, SystemColour.G, SystemColour.B);

            if (XlColour == null)
            {
                //Available colour palette entries: 65 to 32766 (0-64=standard palette; 64=auto, 32767=unspecified)
                if (NPOI.HSSF.Record.PaletteRecord.STANDARD_PALETTE_SIZE < 255)
                {
                    if (NPOI.HSSF.Record.PaletteRecord.STANDARD_PALETTE_SIZE < 64) NPOI.HSSF.Record.PaletteRecord.STANDARD_PALETTE_SIZE = 64;
                    NPOI.HSSF.Record.PaletteRecord.STANDARD_PALETTE_SIZE += 1;
                    XlColour = XlPalette.AddColor(SystemColour.R, SystemColour.G, SystemColour.B);
                }
                else
                {
                    XlColour = XlPalette.FindSimilarColor(SystemColour.R, SystemColour.G, SystemColour.B);
                }

                return XlColour.GetIndex();
            }
            else
            {
                return XlColour.GetIndex();
            }

        }


        private ICellStyle GetStyleSparekit(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName, ICellStyle CellStyle)
        {
            ICellStyle SelectedStyle = CellStyle;

            string Style = GetSpareKitStyleType(hssfWorkBook, row, ColumnName);


            switch (Style)
            {
                case "Normal":
                    SelectedStyle = CellStyle;
                    break;
                case "Highlight":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Bold_Blue) SelectedStyle = CellSPBStyle_Arial_AllMargin_Bold_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Bold_Blue_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center;
                    break;
                case "Strike":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Bold_Blue) SelectedStyle = CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Bold_Blue_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike;
                    break;
                case "Default":
                    SelectedStyle = CellStyle;
                    break;
            }

            return SelectedStyle;

        }


        /// <summary>
        /// ?????
        /// </summary>
        /// <param name="hssfWorkBook"></param>
        /// <param name="row"></param>
        /// <param name="ColumnName"></param>
        /// <returns></returns>
        private string GetSpareKitStyleType(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName)
        {
            string sNormal = "Normal";

            return sNormal;
        }

        private ICellStyle GetStyleSA(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName, ICellStyle CellStyle)
        {
            ICellStyle SelectedStyle = CellStyle;

            string Style = GetSAStyleType(hssfWorkBook, row, ColumnName);

            switch (Style)
            {
                case "Normal":
                    SelectedStyle = CellStyle;
                    break;
                case "Highlight":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_Yellow;
                    break;
                case "Halb":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_SkyBlue;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_SkyBlue;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_SkyBlue;
                    break;
                case "Strike":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_Strike;
                    break;
                case "Default":
                    SelectedStyle = CellStyle;
                    break;
            }

            return SelectedStyle;
        }

        private string GetSAStyleType(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName)
        {
            string sNormal = "Normal";
            string sHalb = "Halb"; // lightblue

            if (row["SaMatlType"].ToString().ToUpper().Trim() == "HALB") return sHalb;

            if (NewMatrix) return sNormal;

            if (ColumnName == String.Empty) return sNormal;
            if (ColumnName.Contains("SpsKitPn")) return sNormal;
            if (ColumnName.Contains("SpsKitDelCat")) return sNormal;

            return sNormal;

        }

        private ICellStyle GetPartStyle(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName, ICellStyle CellStyle)
        {
            ICellStyle SelectedStyle = CellStyle;

            string Style = GetPartStyleType(hssfWorkBook, row, ColumnName);

            switch (Style)
            {
                case "Normal":
                    SelectedStyle = CellStyle;
                    break;
                case "Highlight":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_Yellow;
                    break;
                case "Strike":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_Strike;
                    break;
                case "Default":
                    SelectedStyle = CellStyle;
                    break;
            }
            return SelectedStyle;
        }

        private string GetPartStyleType(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName)
        {
            string sNormal = "Normal";

            return sNormal;

        }

        #endregion

        static void WriteToFile(Stream SpbStream, HSSFWorkbook hssfWorkBook)
        {
            //Write the stream data of workbook to local HD
            hssfWorkBook.Write(SpbStream);
        }

        #region #NPOI Utility Functions

        public void CreateRow(ISheet sheetSelect, int row)
        {
            sheetSelect.CreateRow(row);
        }

        static void CreateCell(ISheet sheetSelect, int row, int cell, CellType Type)
        {
            sheetSelect.GetRow(row).CreateCell(cell, Type);
        }

        static ICell ReturnCell(ISheet sheetSelect, int row, int cell)
        {
            return sheetSelect.GetRow(row).GetCell(cell);
        }

        #endregion


    }
}
