﻿using System;
using System.Data;
using System.Text;
using System.Xml;
using CarlosAg.ExcelXmlWriter;

namespace RslExport
{


    public class Rsl
    {

        #region ' Properties '
        private string _productPpcLine = string.Empty;
        public string ProductPpcLine
        {
            get { return _productPpcLine; }
            set { _productPpcLine = value; }
        }

        private bool _newMatrix = false;
        public bool NewMatrix
        {
            get { return _newMatrix; }
            set { _newMatrix = value; }
        }

        private bool _publish = false;
        public bool Publish
        {
            get { return _publish; }
            set { _publish = value; }
        }

        private string _productVersionId = string.Empty;
        public string ProductVersionId
        {
            get { return _productVersionId; }
            set { _productVersionId = value; }
        }

        private string _serviceFamilyPn = string.Empty;
        public string ServiceFamilyPn
        {
            get
            {
                if (_serviceFamilyPn == string.Empty)
                {
                    HPQ.Excalibur.Data dw = new HPQ.Excalibur.Data();
                    _serviceFamilyPn = dw.GetServiceFamilyPn(ProductVersionId);
                }
                return _serviceFamilyPn;
            }
            set { _serviceFamilyPn = value; }
        }

        private DateTime _lastPublishDt = DateTime.MinValue;
        public DateTime LastPublishDt
        {
            get
            {
                if (_lastPublishDt == DateTime.MinValue)
                {
                    DateTime.TryParse(_compareDt, out _lastPublishDt);
                }

                if (_lastPublishDt == DateTime.MinValue)
                {
                    HPQ.Excalibur.Data dw = new HPQ.Excalibur.Data();
                    _lastPublishDt = dw.GetRslLastPublishDt(ServiceFamilyPn);
                }
                return _lastPublishDt;
            }
            set { _lastPublishDt = value; }
        }


        private string _compareDt = string.Empty;
        public string CompareDt
        {
            get
            {
                if (string.IsNullOrEmpty(_compareDt))
                {
                    return "1/1/1973";
                }
                return _compareDt;
            }
            set { _compareDt = value; }
        }

        private string _exportTime = string.Empty;
        private string ExportTime
        {
            get { return _exportTime; }
            set { _exportTime = value; }
        }

        private string _userName = string.Empty;
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        private string _selfRepairDoc = string.Empty;
        public string SelfRepairDoc
        {
            get { return _selfRepairDoc; }
            set { _selfRepairDoc = value; }
        }

        private string _ProjectCd = string.Empty;
        public string ProjectCd
        {
            get { return _ProjectCd; }
            set { _ProjectCd = value; }
        }

        private int _CommentCellIdx;
        public int CommentCellIdx
        {
            get { return _CommentCellIdx; }
            set { _CommentCellIdx = value; }
        }
        #endregion

        #region ' Generate '
        public void Generate(System.IO.Stream RslStream, string FileName)
        {
            Workbook book = new Workbook();
            // -----------------------------------------------
            //  Properties
            // -----------------------------------------------
            book.Properties.Author = "PSG Mobile Excalibur";
            book.Properties.LastAuthor = "PSG Mobile Excalibur";
            book.Properties.Created = DateTime.Now;
            book.Properties.LastSaved = DateTime.Now;
            book.Properties.Company = "HP";
            book.Properties.Version = "12.00";
            book.ExcelWorkbook.ActiveSheetIndex = 1;
            // -----------------------------------------------
            //  Generate Styles
            // -----------------------------------------------
            this.GenerateStyles(book.Styles);

            // -----------------------------------------------
            //  Get The RSL Data
            // -----------------------------------------------
            HPQ.Excalibur.Data dwExcalibur = new HPQ.Excalibur.Data();
            DataTable dt = dwExcalibur.SelectRslDetailsForExport(ProductVersionId, Publish, CompareDt);
            DataTable dtVersions = dwExcalibur.SelectSpareKitVersions(ServiceFamilyPn, CompareDt, Publish);
            DataTable dtBrands = dwExcalibur.ListServiceFamilyBrands(ServiceFamilyPn);
            DataRow[] drVersions;

            // -----------------------------------------------
            //  Generate Preliminary RSL Worksheet
            // -----------------------------------------------
            this.GenerateWorksheetChangeLog(book.Worksheets);
            this.OpenWorksheetRSL(book.Worksheets);
            foreach (DataRow row in dtBrands.Rows)
            {
                string brandName = row["BrandNameAbbreviation"].ToString();

                // Excel have names with less than 31 characters in the sheets names
                if (brandName.Length>31)
                {
                    brandName= brandName.Substring(0, 30);
                }

                string productBrandId = row["ProductBrandId"].ToString();
                DataTable dtBrandMapping = dwExcalibur.SelectRslSpareKitAvMappings(ServiceFamilyPn, productBrandId);
                this.GenerateWorksheetMapping(book.Worksheets, brandName, dtBrandMapping);

                foreach (DataRow mapping in dtBrandMapping.Rows)
                {
                    this.AddWorksheetMappingRow(book.Worksheets, brandName, mapping);
                }

                this.CloseWorksheetMappingRow(book.Worksheets, brandName);
            }
            this.GenerateWorksheetAvChangeLog(book.Worksheets);
            // -----------------------------------------------
            //  Populate the Worksheets
            // -----------------------------------------------
            if (Publish) dwExcalibur.InsertRslPublish(ServiceFamilyPn, UserName);
            //if (Publish) dwExcalibur.SetRslLastPublishDt(ServiceFamilyPn, DateTime.Now);

            foreach (DataRow row in dt.Rows)
            {
                drVersions = dtVersions.Select(String.Format("SpareKitId = '{0}'", row["SpareKitId"]));
                AddPrimaryRslRow(book.Worksheets, row, drVersions);               
            }

            AddHPConfidential(book.Worksheets["RSL"]);
          
            dt = null;
            dtVersions = null;

            dt = dwExcalibur.SelectRslChangeLog(ServiceFamilyPn);
            foreach (DataRow row in dt.Rows)
            {
                AddChangeLogRow(book.Worksheets, row);
            }

            dt = dwExcalibur.SelectRslAvChangeLog(ServiceFamilyPn, CompareDt);
            foreach (DataRow row in dt.Rows)
            {
                AddAvChangeLogRow(book.Worksheets, row);
            }

            // -----------------------------------------------
            //  Close the Worksheets
            // -----------------------------------------------
            this.CloseChangeLog(book.Worksheets);
            this.CloseAvChangeLog(book.Worksheets);
            this.CloseWorksheetPrimaryRsl(book.Worksheets);
            book.Save(RslStream);
        }

        // Add label HPConfidential and time Executed to the report
        private void AddHPConfidential(Worksheet RSLSheet)
        {
            RSLSheet.Table.Rows.Add();
            WorksheetRow RConfidential = RSLSheet.Table.Rows.Add(); 
            RConfidential.Cells.Add("HP - Confidential", DataType.String, "sHPConfidential");

            WorksheetRow RConfidentialCreated = RSLSheet.Table.Rows.Add();
            RConfidentialCreated.Cells.Add("Report Generated " + DateTime.Now.ToString(), DataType.String, "sTimeExecuted");                
        }

        #endregion

        #region ' Generate Styles '
        private void GenerateStyles(WorksheetStyleCollection styles)
        {
            // -----------------------------------------------
            //  Default
            // -----------------------------------------------
            WorksheetStyle Default = styles.Add("Default");
            Default.Name = "Normal";
            Default.Font.FontName = "Calibri";
            Default.Font.Size = 11;
            Default.Font.Color = "#000000";
            Default.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            // -----------------------------------------------
            //  s62
            // -----------------------------------------------
            WorksheetStyle s62 = styles.Add("s62");
            s62.Name = "Normal 2";
            s62.Font.FontName = "Arial";
            s62.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            // -----------------------------------------------
            //  s63
            // -----------------------------------------------
            WorksheetStyle s63 = styles.Add("s63");
            s63.Name = "Normal 38";
            s63.Font.FontName = "Arial";
            s63.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            // -----------------------------------------------
            //  s64
            // -----------------------------------------------
            WorksheetStyle s64 = styles.Add("s64");
            s64.Name = "Normal_Spares Listing_1";
            s64.Font.FontName = "Arial";
            s64.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            // -----------------------------------------------
            //  s65
            // -----------------------------------------------
            WorksheetStyle s65 = styles.Add("s65");
            s65.Name = "Normal_Spares Listing_2";
            s65.Font.FontName = "Helv";
            s65.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            // -----------------------------------------------
            //  s66
            // -----------------------------------------------
            WorksheetStyle s66 = styles.Add("s66");
            s66.Name = "Normal_Spares Listing_3";
            s66.Font.FontName = "Arial";
            s66.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            // -----------------------------------------------
            //  m46240640
            // -----------------------------------------------
            WorksheetStyle m46240640 = styles.Add("m46240640");
            m46240640.Parent = "s62";
            m46240640.Font.Bold = true;
            m46240640.Font.FontName = "Arial";
            m46240640.Font.Size = 11;
            m46240640.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            m46240640.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            m46240640.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            m46240640.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            m46240640.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            m46240640.NumberFormat = "@";
            // -----------------------------------------------
            //  s70
            // -----------------------------------------------
            WorksheetStyle s70 = styles.Add("s70");
            s70.Parent = "s63";
            s70.Font.Bold = true;
            s70.Font.FontName = "Arial";
            s70.Font.Size = 12;
            s70.Alignment.Horizontal = StyleHorizontalAlignment.Left;
            s70.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            // -----------------------------------------------
            //  s73
            // -----------------------------------------------
            WorksheetStyle s73 = styles.Add("s73");
            s73.Parent = "s62";
            s73.Font.FontName = "Arial";
            s73.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s73.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s73.NumberFormat = "d\\-mmm\\-yyyy";
            // -----------------------------------------------
            //  s74
            // -----------------------------------------------
            WorksheetStyle s74 = styles.Add("s74");
            s74.Parent = "s62";
            s74.Font.FontName = "Arial";
            s74.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s74.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            // -----------------------------------------------
            //  s75
            // -----------------------------------------------
            WorksheetStyle s75 = styles.Add("s75");
            s75.Parent = "s62";
            s75.Font.FontName = "Arial";
            // -----------------------------------------------
            //  s76
            // -----------------------------------------------
            WorksheetStyle s76 = styles.Add("s76");
            s76.Parent = "s63";
            s76.Font.Bold = true;
            s76.Font.Underline = UnderlineStyle.Single;
            s76.Font.FontName = "Arial";
            s76.Font.Size = 12;
            s76.Font.Color = "#0000FF";
            s76.Alignment.Horizontal = StyleHorizontalAlignment.Left;
            s76.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            // -----------------------------------------------
            //  s77
            // -----------------------------------------------
            WorksheetStyle s77 = styles.Add("s77");
            s77.Parent = "s62";
            s77.Font.FontName = "Arial";
            s77.Alignment.Horizontal = StyleHorizontalAlignment.Left;
            s77.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s77.NumberFormat = "@";
            // -----------------------------------------------
            //  s99
            // -----------------------------------------------
            WorksheetStyle s99 = styles.Add("s99");
            s99.Parent = "s62";
            s99.Font.FontName = "Arial";
            s99.Alignment.WrapText = true;
            s99.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s99.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s99.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s99.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            // -----------------------------------------------
            //  s99h
            // -----------------------------------------------
            WorksheetStyle s99h = styles.Add("s99h");
            s99h.Parent = "s62";
            s99h.Font.FontName = "Arial";
            s99h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s99h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s99h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s99h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s99h.Interior.Pattern = StyleInteriorPattern.Solid;
            s99h.Interior.Color = "#FFFF00";
            // -----------------------------------------------
            //  s101
            // -----------------------------------------------
            WorksheetStyle s101 = styles.Add("s101");
            s101.Parent = "s64";
            s101.Font.FontName = "Arial";
            s101.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s101.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s101.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s101.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            // -----------------------------------------------
            //  s101h
            // -----------------------------------------------
            WorksheetStyle s101h = styles.Add("s101h");
            s101h.Parent = "s64";
            s101h.Font.FontName = "Arial";
            s101h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s101h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s101h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s101h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s101h.Interior.Pattern = StyleInteriorPattern.Solid;
            s101h.Interior.Color = "#FFFF00";
            // -----------------------------------------------
            //  s102
            // -----------------------------------------------
            WorksheetStyle s102 = styles.Add("s102");
            s102.Parent = "s62";
            s102.Font.FontName = "Arial";
            s102.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s102.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s102.Alignment.WrapText = true;
            s102.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s102.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s102.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s102.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            // -----------------------------------------------
            //  s102h
            // -----------------------------------------------
            WorksheetStyle s102h = styles.Add("s102h");
            s102h.Parent = "s62";
            s102h.Font.FontName = "Arial";
            s102h.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s102h.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s102h.Alignment.WrapText = true;
            s102h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s102h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s102h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s102h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s102h.Interior.Pattern = StyleInteriorPattern.Solid;
            s102h.Interior.Color = "#FFFF00";
            // -----------------------------------------------
            //  s103
            // -----------------------------------------------
            WorksheetStyle s103 = styles.Add("s103");
            s103.Parent = "s62";
            s103.Font.FontName = "Arial";
            s103.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s103.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s103.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s103.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s103.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s103.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            // -----------------------------------------------
            //  s103h
            // -----------------------------------------------
            WorksheetStyle s103h = styles.Add("s103h");
            s103h.Parent = "s62";
            s103h.Font.FontName = "Arial";
            s103h.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s103h.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s103h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s103h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s103h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s103h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s103h.Interior.Pattern = StyleInteriorPattern.Solid;
            s103h.Interior.Color = "#FFFF00";
            // -----------------------------------------------
            //  s104
            // -----------------------------------------------
            WorksheetStyle s104 = styles.Add("s104");
            s104.Parent = "s62";
            s104.Font.FontName = "Arial";
            s104.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s104.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s104.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s104.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s104.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s104.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s104.NumberFormat = "Short Date";
            // -----------------------------------------------
            //  s104h
            // -----------------------------------------------
            WorksheetStyle s104h = styles.Add("s104h");
            s104h.Parent = "s62";
            s104h.Font.FontName = "Arial";
            s104h.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s104h.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s104h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s104h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s104h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s104h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s104h.NumberFormat = "Short Date";
            s104h.Interior.Pattern = StyleInteriorPattern.Solid;
            s104h.Interior.Color = "#FFFF00";
            // -----------------------------------------------
            //  s106
            // -----------------------------------------------
            WorksheetStyle s106 = styles.Add("s106");
            s106.Parent = "s64";
            s106.Font.FontName = "Arial";
            s106.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s106.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s106.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s106.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s106.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s106.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            // -----------------------------------------------
            //  s108
            // -----------------------------------------------
            WorksheetStyle s108 = styles.Add("s108");
            s108.Parent = "s65";
            s108.Font.FontName = "Arial";
            s108.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s108.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s108.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s108.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            // -----------------------------------------------
            //  s109
            // -----------------------------------------------
            WorksheetStyle s109 = styles.Add("s109");
            s109.Parent = "s65";
            s109.Font.FontName = "Arial";
            s109.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s109.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s109.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s109.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s109.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s109.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            // -----------------------------------------------
            //  s110
            // -----------------------------------------------
            WorksheetStyle s110 = styles.Add("s110");
            s110.Parent = "s62";
            s110.Font.FontName = "Arial";
            s110.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s110.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s110.Alignment.WrapText = true;
            s110.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s110.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s110.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s110.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s110.NumberFormat = "@";
            // -----------------------------------------------
            //  s112
            // -----------------------------------------------
            WorksheetStyle s112 = styles.Add("s112");
            s112.Parent = "s66";
            s112.Font.FontName = "Arial";
            s112.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s112.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s112.Alignment.WrapText = true;
            s112.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s112.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s112.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s112.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s112.NumberFormat = "@";
            // -----------------------------------------------
            //  s116
            // -----------------------------------------------
            WorksheetStyle s116 = styles.Add("s116");
            s116.Parent = "s63";
            s116.Font.Bold = true;
            s116.Font.FontName = "Arial";
            s116.Font.Size = 12;
            s116.Alignment.Horizontal = StyleHorizontalAlignment.Left;
            s116.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s116.NumberFormat = "d\\-mmm\\-yyyy";
            // -----------------------------------------------
            //  s126
            // -----------------------------------------------
            WorksheetStyle s126 = styles.Add("s126");
            s126.Parent = "s62";
            s126.Font.Bold = true;
            s126.Font.FontName = "Arial";
            s126.Font.Size = 12;
            s126.Alignment.Horizontal = StyleHorizontalAlignment.Left;
            s126.Alignment.Rotate = 90;
            s126.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s126.Alignment.WrapText = true;
            s126.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s126.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s126.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s126.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s126.NumberFormat = "@";
            // -----------------------------------------------
            //  s127
            // -----------------------------------------------
            WorksheetStyle s127 = styles.Add("s127");
            s127.Parent = "s62";
            s127.Font.Bold = true;
            s127.Font.FontName = "Arial";
            s127.Font.Size = 12;
            s127.Font.Color = "#000000";
            s127.Alignment.Horizontal = StyleHorizontalAlignment.Left;
            s127.Alignment.Rotate = 90;
            s127.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s127.Alignment.WrapText = true;
            s127.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s127.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s127.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s127.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s127.NumberFormat = "@";
            // -----------------------------------------------
            //  s128
            // -----------------------------------------------
            WorksheetStyle s128 = styles.Add("s128");
            s128.Parent = "s62";
            s128.Font.Bold = true;
            s128.Font.FontName = "Arial";
            s128.Font.Size = 12;
            s128.Font.Color = "#000000";
            s128.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s128.Alignment.Rotate = 90;
            s128.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s128.Alignment.WrapText = true;
            s128.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s128.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s128.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s128.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s128.NumberFormat = "@";
            // -----------------------------------------------
            //  s129
            // -----------------------------------------------
            WorksheetStyle s129 = styles.Add("s129");
            s129.Parent = "s62";
            s129.Font.Bold = true;
            s129.Font.FontName = "Arial";
            s129.Font.Size = 12;
            s129.Font.Color = "#000000";
            s129.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s129.Alignment.Rotate = 90;
            s129.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s129.Alignment.WrapText = true;
            s129.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s129.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s129.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s129.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s129.NumberFormat = "d\\-mmm\\-yyyy";
            // -----------------------------------------------
            //  s130
            // -----------------------------------------------
            WorksheetStyle s130 = styles.Add("s130");
            s130.Parent = "s62";
            s130.Font.Bold = true;
            s130.Font.FontName = "Arial";
            s130.Font.Size = 12;
            s130.Font.Color = "#000000";
            s130.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s130.Alignment.Rotate = 90;
            s130.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s130.Alignment.WrapText = true;
            s130.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s130.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s130.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s130.NumberFormat = "Fixed";
            // -----------------------------------------------
            //  s131
            // -----------------------------------------------
            WorksheetStyle s131 = styles.Add("s131");
            s131.Parent = "s62";
            s131.Font.Bold = true;
            s131.Font.FontName = "Arial";
            s131.Font.Size = 12;
            s131.Alignment.Horizontal = StyleHorizontalAlignment.Left;
            s131.Alignment.Rotate = 90;
            s131.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s131.Alignment.WrapText = true;
            s131.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s131.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s131.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s131.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s131.NumberFormat = "0.0";
            // -----------------------------------------------
            //  s132
            // -----------------------------------------------
            WorksheetStyle s132 = styles.Add("s132");
            s132.Parent = "s62";
            s132.Font.Bold = true;
            s132.Font.FontName = "Arial";
            s132.Font.Size = 12;
            s132.Font.Color = "#000000";
            s132.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s132.Alignment.Rotate = 90;
            s132.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s132.Alignment.WrapText = true;
            s132.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s132.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s132.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s132.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s132.NumberFormat = "Fixed";
            // -----------------------------------------------
            //  s147
            // -----------------------------------------------
            WorksheetStyle s147 = styles.Add("s147");
            s147.Parent = "s62";
            s147.Font.FontName = "Arial";
            // -----------------------------------------------
            //  s148
            // -----------------------------------------------
            WorksheetStyle s148 = styles.Add("s148");
            s148.Parent = "s62";
            s148.Font.FontName = "Arial";
            s148.Font.Size = 11;
            s148.Alignment.Horizontal = StyleHorizontalAlignment.Left;
            s148.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s148.NumberFormat = "@";
            // -----------------------------------------------
            //  s149
            // -----------------------------------------------
            WorksheetStyle s149 = styles.Add("s149");
            s149.Parent = "s62";
            s149.Font.FontName = "Arial";
            s149.Font.Size = 11;
            s149.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s149.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s149.NumberFormat = "d\\-mmm\\-yyyy";
            // -----------------------------------------------
            //  s150
            // -----------------------------------------------
            WorksheetStyle s150 = styles.Add("s150");
            s150.Parent = "s62";
            s150.Font.FontName = "Arial";
            s150.Font.Size = 11;
            s150.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s150.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s150.NumberFormat = "@";
            // -----------------------------------------------
            //  s151
            // -----------------------------------------------
            WorksheetStyle s151 = styles.Add("s151");
            s151.Parent = "s62";
            s151.Font.FontName = "Arial";
            s151.Font.Size = 11;
            s151.Alignment.Horizontal = StyleHorizontalAlignment.Center;
            s151.Alignment.Vertical = StyleVerticalAlignment.Bottom;
            s151.Alignment.WrapText = true;
            s151.NumberFormat = "@";
            // -----------------------------------------------
            //  s3746
            // -----------------------------------------------
            WorksheetStyle s3746 = styles.Add("s3746");
            s3746.NumberFormat = "Short Date";


            // -----------------------------------------------
            //  s152
            // -----------------------------------------------
            WorksheetStyle s152 = styles.Add("s152");
            s152.Parent = "s64";
            s152.Font.FontName = "Arial";
            s152.Font.Color = "#0000FF";
            s152.Font.Underline = UnderlineStyle.Single;
            s152.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s152.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s152.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s152.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            // -----------------------------------------------
            //  s152h
            // -----------------------------------------------
            WorksheetStyle s152h = styles.Add("s152h");
            s152h.Parent = "s64";
            s152h.Font.FontName = "Arial";
            s152h.Font.Color = "#0000FF";
            s152h.Font.Underline = UnderlineStyle.Single;
            s152h.Borders.Add(StylePosition.Bottom, LineStyleOption.Continuous, 1);
            s152h.Borders.Add(StylePosition.Left, LineStyleOption.Continuous, 1);
            s152h.Borders.Add(StylePosition.Right, LineStyleOption.Continuous, 1);
            s152h.Borders.Add(StylePosition.Top, LineStyleOption.Continuous, 1);
            s152h.Interior.Pattern = StyleInteriorPattern.Solid;
            s152h.Interior.Color = "#FFFF00";

            //
            // Av Mapping Styles
            //

            // -----------------------------------------------
            //  s3740
            // -----------------------------------------------
            WorksheetStyle s3740 = styles.Add("s3740");
            s3740.Font.Bold = true;
            s3740.Font.FontName = "Calibri";
            s3740.Font.Size = 11;
            s3740.Font.Color = "#000000";
            s3740.Interior.Color = "#BFBFBF";
            s3740.Interior.Pattern = StyleInteriorPattern.Solid;
            // -----------------------------------------------
            //  s3743
            // -----------------------------------------------
            WorksheetStyle s3743 = styles.Add("s3743");
            // -----------------------------------------------
            //  s3743h
            // -----------------------------------------------
            WorksheetStyle s3743h = styles.Add("s3743h");
            s3743h.Interior.Color = "#FFFF00";
            s3743h.Interior.Pattern = StyleInteriorPattern.Solid;
            // -----------------------------------------------
            //  s3743s
            // -----------------------------------------------
            WorksheetStyle s3743s = styles.Add("s3743s");
            s3743s.Interior.Color = "#FFFF00";
            s3743s.Interior.Pattern = StyleInteriorPattern.Solid;
            s3743s.Font.Strikethrough = true;
            s3743s.Font.Color = "#FF0000";
            // -----------------------------------------------
            //  sHPConfidential
            // -----------------------------------------------
            WorksheetStyle sHPConfidential = styles.Add("sHPConfidential");
            sHPConfidential.Font.Bold = true;
            sHPConfidential.Font.FontName = "verdana";
            sHPConfidential.Font.Size = 13;
            sHPConfidential.Font.Color = "#FF0000";
            // -----------------------------------------------
            //  sTimeExecuted
            // -----------------------------------------------
            WorksheetStyle sTimeExecuted = styles.Add("sTimeExecuted");
            sTimeExecuted.Font.Bold = true;
            sTimeExecuted.Font.FontName = "verdana";

        }
        #endregion

        #region ' RSL Worksheet '
        #region ' Generate RSL Worksheet '
        private void OpenWorksheetRSL(WorksheetCollection sheets)
        {
            HPQ.Excalibur.Data dwExcalibur = new HPQ.Excalibur.Data();
            DataTable dtHeader = dwExcalibur.SelectRslHeader(this.ServiceFamilyPn);
            DataTable dtProductVersions = dwExcalibur.SelectSpbVersions(this.ServiceFamilyPn);           
            DataRow dRow = dtHeader.Rows[0];

            Worksheet sheet = sheets.Add("RSL");
            //sheet.Table.ExpandedColumnCount = 20 + dtProductVersions.Rows.Count - 1;
            //sheet.Table.FullColumns = 1;
            //sheet.Table.FullRows = 1;
            sheet.Table.StyleID = "s147";
            WorksheetColumn column0 = sheet.Table.Columns.Add();
            column0.Width = 148;
            column0.StyleID = "s147";
            WorksheetColumn column1 = sheet.Table.Columns.Add();
            column1.Width = 72;
            column1.StyleID = "s147";
            WorksheetColumn column2 = sheet.Table.Columns.Add();
            column2.Width = 21;
            column2.StyleID = "s147";
            WorksheetColumn column3 = sheet.Table.Columns.Add();
            column3.Width = 36;
            column3.StyleID = "s147";
            WorksheetColumn column4 = sheet.Table.Columns.Add();
            column4.Width = 260;
            column4.StyleID = "s147";
            WorksheetColumn column5 = sheet.Table.Columns.Add();
            column5.Width = 36;
            column5.StyleID = "s147";
            WorksheetColumn column6 = sheet.Table.Columns.Add();
            column6.Width = 59;
            column6.StyleID = "s147";
            WorksheetColumn column7 = sheet.Table.Columns.Add();
            column7.Width = 49;
            column7.StyleID = "s147";
            WorksheetColumn column8 = sheet.Table.Columns.Add();
            column8.Width = 36;
            column8.StyleID = "s147";
            WorksheetColumn column9 = sheet.Table.Columns.Add();
            column9.Width = 21;
            column9.StyleID = "s147";
            WorksheetColumn column10 = sheet.Table.Columns.Add();
            column10.Width = 36;
            column10.StyleID = "s147";
            column10.Span = 3;
            WorksheetColumn column11 = sheet.Table.Columns.Add();
            column11.Index = 15;
            column11.Width = 21;
            column11.StyleID = "s147";
            column11.Span = 3;
            WorksheetColumn versionColumn;
            foreach (DataRow drow in dtProductVersions.Rows)
            {
                versionColumn = sheet.Table.Columns.Add();
                versionColumn.Width = 30;
                versionColumn.StyleID = "s147";
            }
            WorksheetColumn column12 = sheet.Table.Columns.Add();
            //column12.Index = 20;
            column12.Width = 200;
            column12.StyleID = "s147";
            // -----------------------------------------------
            WorksheetRow Row0 = sheet.Table.Rows.Add();
            Row0.Height = 15;
            Row0.AutoFitHeight = false;
            Row0.Cells.Add("Revision:", DataType.String, "s70");
            WorksheetCell cell;
            cell = Row0.Cells.Add();
            cell.StyleID = "s116";
            cell.Data.Type = DataType.DateTime;
            cell.Data.Text = FormatExcelDate(DateTime.Now);
            cell.MergeAcross = 3;
            cell = Row0.Cells.Add();
            cell.StyleID = "s147";
            cell = Row0.Cells.Add();
            cell.StyleID = "s73";
            cell = Row0.Cells.Add();
            cell.StyleID = "s73";
            cell = Row0.Cells.Add();
            cell.StyleID = "s74";
            cell = Row0.Cells.Add();
            cell.StyleID = "s74";
            cell = Row0.Cells.Add();
            cell.StyleID = "s74";
            cell = Row0.Cells.Add();
            cell.StyleID = "s74";
            cell = Row0.Cells.Add();
            cell.StyleID = "s74";
            cell = Row0.Cells.Add();
            cell.StyleID = "s74";
            cell = Row0.Cells.Add();
            cell.StyleID = "s75";
            cell = Row0.Cells.Add();
            cell.StyleID = "s75";
            cell = Row0.Cells.Add();
            cell.StyleID = "s75";
            cell = Row0.Cells.Add();
            cell.StyleID = "s75";
            // -----------------------------------------------
            WorksheetRow Row1 = sheet.Table.Rows.Add();
            Row1.Height = 15;
            Row1.AutoFitHeight = false;
            Row1.Cells.Add("Project Code:", DataType.String, "s70");
            cell = Row1.Cells.Add();
            cell.StyleID = "s70";
            cell.Data.Type = DataType.Number;
            cell.Data.Text = dRow["ProjectNumber"].ToString();
            ProjectCd = dRow["ProjectNumber"].ToString();
            cell.MergeAcross = 3;
            cell = Row1.Cells.Add();
            cell.StyleID = "s147";
            cell = Row1.Cells.Add();
            cell.StyleID = "s77";
            cell = Row1.Cells.Add();
            cell.StyleID = "s73";
            cell = Row1.Cells.Add();
            cell.StyleID = "s74";
            cell = Row1.Cells.Add();
            cell.StyleID = "s74";
            cell = Row1.Cells.Add();
            cell.StyleID = "s74";
            cell = Row1.Cells.Add();
            cell.StyleID = "s74";
            cell = Row1.Cells.Add();
            cell.StyleID = "s74";
            cell = Row1.Cells.Add();
            cell.StyleID = "s74";
            cell = Row1.Cells.Add();
            cell.StyleID = "s75";
            cell = Row1.Cells.Add();
            cell.StyleID = "s75";
            cell = Row1.Cells.Add();
            cell.StyleID = "s75";
            cell = Row1.Cells.Add();
            cell.StyleID = "s75";
            // -----------------------------------------------
            WorksheetRow Row2 = sheet.Table.Rows.Add();
            Row2.Height = 15;
            Row2.AutoFitHeight = false;
            Row2.Cells.Add("ODM:", DataType.String, "s70");
            cell = Row2.Cells.Add();
            cell.StyleID = "s70";
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["OdmName"].ToString();
            cell.MergeAcross = 3;
            cell = Row2.Cells.Add();
            cell.StyleID = "s147";
            cell = Row2.Cells.Add();
            cell.StyleID = "s77";
            cell = Row2.Cells.Add();
            cell.StyleID = "s73";
            cell = Row2.Cells.Add();
            cell.StyleID = "s74";
            cell = Row2.Cells.Add();
            cell.StyleID = "s74";
            cell = Row2.Cells.Add();
            cell.StyleID = "s74";
            cell = Row2.Cells.Add();
            cell.StyleID = "s74";
            cell = Row2.Cells.Add();
            cell.StyleID = "s74";
            cell = Row2.Cells.Add();
            cell.StyleID = "s74";
            cell = Row2.Cells.Add();
            cell.StyleID = "s75";
            cell = Row2.Cells.Add();
            cell.StyleID = "s75";
            cell = Row2.Cells.Add();
            cell.StyleID = "s75";
            cell = Row2.Cells.Add();
            cell.StyleID = "s75";
            // -----------------------------------------------
            WorksheetRow Row3 = sheet.Table.Rows.Add();
            Row3.Height = 15;
            Row3.AutoFitHeight = false;
            Row3.Cells.Add("Family Spares:", DataType.String, "s70");
            cell = Row3.Cells.Add();
            cell.StyleID = "s70";
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["ServiceFamilyPn"].ToString();
            cell.MergeAcross = 3;
            cell = Row3.Cells.Add();
            cell.StyleID = "s147";
            cell = Row3.Cells.Add();
            cell.StyleID = "s77";
            cell = Row3.Cells.Add();
            cell.StyleID = "s73";
            cell = Row3.Cells.Add();
            cell.StyleID = "s74";
            cell = Row3.Cells.Add();
            cell.StyleID = "s74";
            cell = Row3.Cells.Add();
            cell.StyleID = "s74";
            cell = Row3.Cells.Add();
            cell.StyleID = "s74";
            cell = Row3.Cells.Add();
            cell.StyleID = "s74";
            cell = Row3.Cells.Add();
            cell.StyleID = "s74";
            cell = Row3.Cells.Add();
            cell.StyleID = "s75";
            cell = Row3.Cells.Add();
            cell.StyleID = "s75";
            cell = Row3.Cells.Add();
            cell.StyleID = "s75";
            cell = Row3.Cells.Add();
            cell.StyleID = "s75";
            // -----------------------------------------------
            WorksheetRow Row4 = sheet.Table.Rows.Add();
            Row4.Height = 15;
            Row4.AutoFitHeight = false;
            Row4.Cells.Add("GPLM Contact:", DataType.String, "s70");
            cell = Row4.Cells.Add();
            cell.StyleID = "s70";
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["GplmName"].ToString();
            cell.MergeAcross = 3;
            cell = Row4.Cells.Add();
            cell.StyleID = "s147";
            cell = Row4.Cells.Add();
            cell.StyleID = "s77";
            cell = Row4.Cells.Add();
            cell.StyleID = "s73";
            cell = Row4.Cells.Add();
            cell.StyleID = "s74";
            cell = Row4.Cells.Add();
            cell.StyleID = "s74";
            cell = Row4.Cells.Add();
            cell.StyleID = "s74";
            cell = Row4.Cells.Add();
            cell.StyleID = "s74";
            cell = Row4.Cells.Add();
            cell.StyleID = "s74";
            cell = Row4.Cells.Add();
            cell.StyleID = "s74";
            cell = Row4.Cells.Add();
            cell.StyleID = "s75";
            cell = Row4.Cells.Add();
            cell.StyleID = "s75";
            cell = Row4.Cells.Add();
            cell.StyleID = "s75";
            cell = Row4.Cells.Add();
            cell.StyleID = "s75";
            // -----------------------------------------------
            WorksheetRow Row5 = sheet.Table.Rows.Add();
            Row5.Height = 19;
            Row5.AutoFitHeight = false;
            Row5.Cells.Add("Self Repair Doc:", DataType.String, "s70");
            cell = Row5.Cells.Add();
            cell.StyleID = "s70";
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["SelfRepairDoc"].ToString();
            cell.MergeAcross = 3;
            cell = Row5.Cells.Add();
            cell.StyleID = "s147";
            cell = Row5.Cells.Add();
            cell.StyleID = "s148";
            cell = Row5.Cells.Add();
            cell.StyleID = "s149";
            cell = Row5.Cells.Add();
            cell.StyleID = "s150";
            cell = Row5.Cells.Add();
            cell.StyleID = "s150";
            cell = Row5.Cells.Add();
            cell.StyleID = "s150";
            cell = Row5.Cells.Add();
            cell.StyleID = "s150";
            cell = Row5.Cells.Add();
            cell.StyleID = "s150";
            cell = Row5.Cells.Add();
            cell.StyleID = "s150";
            cell = Row5.Cells.Add();
            cell.StyleID = "s147";
            cell = Row5.Cells.Add();
            cell.StyleID = "s147";
            cell = Row5.Cells.Add();
            cell.StyleID = "s147";
            cell = Row5.Cells.Add();
            cell.StyleID = "s147";
            // -----------------------------------------------
            WorksheetRow Row6 = sheet.Table.Rows.Add();
            Row6.Height = 19;
            Row6.AutoFitHeight = false;
            Row6.Cells.Add("Family Code Name:", DataType.String, "s70");
            cell = Row6.Cells.Add();
            cell.StyleID = "s70";
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["FamilyName"].ToString();
            cell.MergeAcross = 3;
            cell = Row6.Cells.Add();
            cell.StyleID = "s76";
            cell = Row6.Cells.Add();
            cell.StyleID = "s148";
            cell = Row6.Cells.Add();
            cell.StyleID = "s149";
            cell = Row6.Cells.Add();
            cell.StyleID = "s150";
            cell = Row6.Cells.Add();
            cell.StyleID = "s150";
            cell = Row6.Cells.Add();
            cell.StyleID = "s150";
            cell = Row6.Cells.Add();
            cell.StyleID = "s150";
            cell = Row6.Cells.Add();
            cell.StyleID = "s150";
            cell = Row6.Cells.Add();
            cell.StyleID = "s150";
            // -----------------------------------------------
            WorksheetRow Row7 = sheet.Table.Rows.Add();
            Row7.Height = 15;
            Row7.AutoFitHeight = false;
            cell = Row7.Cells.Add();
            cell.StyleID = "s70";
            cell = Row7.Cells.Add();
            cell.StyleID = "s76";
            cell = Row7.Cells.Add();
            cell.StyleID = "s151";
            cell = Row7.Cells.Add();
            cell.StyleID = "s151";
            cell = Row7.Cells.Add();
            cell.StyleID = "s76";
            cell = Row7.Cells.Add();
            cell.StyleID = "s76";
            cell = Row7.Cells.Add();
            cell.StyleID = "s148";
            cell = Row7.Cells.Add();
            cell.StyleID = "s149";
            cell = Row7.Cells.Add();
            cell.StyleID = "s150";
            cell = Row7.Cells.Add();
            cell.StyleID = "s150";
            cell = Row7.Cells.Add();
            cell.StyleID = "s150";
            cell = Row7.Cells.Add();
            cell.StyleID = "s150";
            cell = Row7.Cells.Add();
            cell.StyleID = "s150";
            cell = Row7.Cells.Add();
            cell.StyleID = "s150";
            cell = Row7.Cells.Add();
            cell.StyleID = "m46240640";
            cell.Data.Type = DataType.String;
            cell.Data.Text = "GEO";
            cell.MergeAcross = 3;
            // -----------------------------------------------
            WorksheetRow Row8 = sheet.Table.Rows.Add();
            Row8.Height = 78;
            Row8.AutoFitHeight = false;
            Row8.Cells.Add("Part Type", DataType.String, "s126");
            Row8.Cells.Add("Spare Part Number", DataType.String, "s126");
            Row8.Cells.Add("Rev", DataType.String, "s127");
            Row8.Cells.Add("CrossPlant Status", DataType.String, "s127");
            Row8.Cells.Add("Spare Kit Description", DataType.String, "s128");
            Row8.Cells.Add("MFG Sub Assembly #", DataType.String, "s127");
            Row8.Cells.Add("Service Sub Assembly #", DataType.String, "s127");
            Row8.Cells.Add("First Service Date (FSD)", DataType.String, "s129");
            cell = Row8.Cells.Add();
            cell.StyleID = "s128";
            cell.Data.Type = DataType.String;
            cell.Data.Text = " CSR - User Replaceable";
            cell.Comment.Author = "Peter Lapointe";
            cell.Comment.Data.Text = "EURP Level A\nEURP Level B\nEURP Level C\nEURP Level D\nNo\n\nEURP Level A Skills  – Th" +
                "ose parts that are easily replaceable by non-trained personnel.  These parts are" +
                " normally accessible and replaceable without opening the system enclosure.\nSome " +
                "examples include: Mice, Keyboards, Hot Swappable components, options plugged int" +
                "o external system ports (serial, parallel, USB, etc).\n\nEURP Level B Skills – The" +
                "se parts are accessible and replaceable without opening the system enclosure and" +
                " do not need a tool.\nThese are generally repairable parts or controlled disposal" +
                " parts that must be returned to HP or HP’s designated repair vendor.The End-User" +
                " requires a minimal knowledge on how and when to replace the defective part.  \n\n" +
                "EURP Level C Skills - May require tools to open the access panels, and/or to rep" +
                "lace the defective spare. These are repairable parts that must be returned to HP" +
                " or HP’s designated repair vendor. The End-User requires a limited knowledge on " +
                "how to service the system, and be familiar with the operating system.\n\nEURP Leve" +
                "l D Skills - :  Will almost always require tools to open the access panels, and/" +
                "or to replace the defective spare.These are repairable parts that must be return" +
                "ed to HP or HP’s designated repair vendor. The End-User requires extensive knowl" +
                "edge on how to service the system, and be familiar with the operating system.  \n" +
                "\nNo - The technician must be trained on HP hardware, or have extensive experienc" +
                "e with HP hardware.  In some cases the technician must be an Accredited HP Techn" +
                "ician.\n";
            cell = Row8.Cells.Add();
            cell.StyleID = "s128";
            cell.Data.Type = DataType.String;
            cell.Data.Text = " Disposition";
            cell.Comment.Author = "Valued Employee";
            cell.Comment.Data.Text = "\n1 = Disposable\n2 = Repairable\n3 = Return to Vendor\n4 = Repair/Exchange ONLY\n\n\n";
            Row8.Cells.Add(" New Spare Part ", DataType.String, "s128");
            cell = Row8.Cells.Add();
            cell.StyleID = "s128";
            cell.Data.Type = DataType.String;
            cell.Data.Text = " Warranty Labour Tier";
            cell.Comment.Author = "Peter Lapointe";
            cell.Comment.Data.Text = "\nA = 0 - 5 minutes\nB = 5 - 10 minutes\nC = 15 - 30 minutes\nD = No Reimbursement\n\nT" +
                "his information is provided by the GSF-PSM ";
            cell = Row8.Cells.Add();
            cell.StyleID = "s128";
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Local Stock Advise";
            cell.Comment.Author = "Justin Elder";
            cell.Comment.Data.Text = "1 - Don\'t stock local (non SPOF and not likely to fail)\n2 - Stock Strategically (" +
                "non SPOF and likely to fail)\n3 - Stock Local (SPOF and not likely to fail)\n4 - S" +
                "tock Local Critical (SPOF and likely to fail)\n";
            Row8.Cells.Add("PPC Product Line", DataType.String, "s129");
            Row8.Cells.Add("NA", DataType.String, "s130");
            Row8.Cells.Add("LA", DataType.String, "s130");
            Row8.Cells.Add("APJ", DataType.String, "s130");
            Row8.Cells.Add("EMEA", DataType.String, "s130");
            foreach (DataRow drVersion in dtProductVersions.Rows)
            {
                Row8.Cells.Add(drVersion["Version"].ToString().Trim(), DataType.String, "s132");
            }
            Row8.Cells.Add("Comment", DataType.String, "s132");
            CommentCellIdx = Row8.Cells.Count;
        }
        #endregion

        #region ' Worksheet Row '
        private void AddPrimaryRslRow(WorksheetCollection sheets, DataRow row, DataRow[] drVersions)
        {
            int emptyCellCnt;
            Worksheet sheet = sheets["RSL"];
            WorksheetCell cell;
            // -----------------------------------------------
            WorksheetRow Row9 = sheet.Table.Rows.Add();
            Row9.Cells.Add(row["CategoryName"].ToString(), DataType.String, GetCellStyle(row, string.Empty, "s99"));
            cell = Row9.Cells.Add(row["SpareKitNo"].ToString(), DataType.String, GetCellStyle(row, string.Empty, "s102"));
            //cell.HRef = string.Format("http://partsurfer.hp.com/ShowPhoto.aspx?partnumber={0}", row["SpareKitNo"].ToString());
            Row9.Cells.Add(row["Revision"].ToString(), DataType.String, GetCellStyle(row, "bRevision", "s102"));
            Row9.Cells.Add(row["CrossPlantStatus"].ToString(), DataType.String, GetCellStyle(row, "bCrossPlantStatus", "s102"));
            Row9.Cells.Add(row["Description"].ToString(), DataType.String, GetCellStyle(row, "bDescription", "s101"));
            Row9.Cells.Add(row["MfgSubAssembly"].ToString(), DataType.String, GetCellStyle(row, "bMfgSubAssembly", "s101"));
            Row9.Cells.Add(row["SvcSubAssembly"].ToString(), DataType.String, GetCellStyle(row, "bSvcSubAssembly", "s103"));
            if (row["FirstServiceDt"] == DBNull.Value)
            {
                cell = Row9.Cells.Add();
                cell.StyleID = GetCellStyle(row, string.Empty, "s103");
            }
            else
            {
                Row9.Cells.Add(FormatExcelDate((DateTime)row["FirstServiceDt"]), DataType.DateTime, GetCellStyle(row, "bFirstServiceDt", "s104"));
            }
            Row9.Cells.Add(row["CsrLevel"].ToString(), DataType.String, GetCellStyle(row, "bCsrLevelId", "s103"));
            Row9.Cells.Add(row["Disposition"].ToString() == "0" ? string.Empty : row["Disposition"].ToString(), DataType.String, GetCellStyle(row, "bDisposition", "s103"));
            Row9.Cells.Add((row["ProjectCd"].ToString() != ProjectCd) ? "N" : "Y", DataType.String, GetCellStyle(row, string.Empty, "s103"));
            Row9.Cells.Add(row["WarrantyTier"].ToString() == "0" ? string.Empty : row["WarrantyTier"].ToString(), DataType.String, GetCellStyle(row, "bWarrantyTier", "s103"));
            Row9.Cells.Add(row["LocalStockAdvice"].ToString() == "0" ? string.Empty : row["LocalStockAdvice"].ToString(), DataType.String, GetCellStyle(row, "bLocalStockAdvice", "s103"));
            Row9.Cells.Add(row["PpcProductLine"].ToString(), DataType.String, GetCellStyle(row, "bPpcProductLine", "s103"));
            Row9.Cells.Add(Convert.ToBoolean(row["GeoNa"]) ? "X" : string.Empty, DataType.String, GetCellStyle(row, "bGeoNa", "s103"));
            Row9.Cells.Add(Convert.ToBoolean(row["GeoLa"]) ? "X" : string.Empty, DataType.String, GetCellStyle(row, "bGeoLa", "s103"));
            Row9.Cells.Add(Convert.ToBoolean(row["GeoApj"]) ? "X" : string.Empty, DataType.String, GetCellStyle(row, "bGeoApj", "s103"));
            Row9.Cells.Add(Convert.ToBoolean(row["GeoEmea"]) ? "X" : string.Empty, DataType.String, GetCellStyle(row, "bGeoEmea", "s103"));
            // TODO: Version Logic Goes Here           
            foreach (DataRow vRow in drVersions)
            {
                if (string.IsNullOrEmpty(vRow["VersionSupported"].ToString()))
                    Row9.Cells.Add("", DataType.String, GetCellStyle(row, string.Empty, "s103"));
                else
                    Row9.Cells.Add("X", DataType.String, GetCellStyle(LastPublishDt < DateTime.Parse(vRow["VersionSupported"].ToString()), "s103"));
            }
            // End Version Logic

            emptyCellCnt = CommentCellIdx - Row9.Cells.Count;
            for (int i = 1; i < emptyCellCnt; i++) 
                Row9.Cells.Add(string.Empty, DataType.String, GetCellStyle(row, string.Empty, "s103"));
              
            cell = Row9.Cells.Add(row["Comments"].ToString());
            cell.StyleID = GetCellStyle(row, string.Empty, "s99");

            
        }
        #endregion

        #region ' Close Rsl Worksheet '
        private void CloseWorksheetPrimaryRsl(WorksheetCollection sheets)
        {
            Worksheet sheet = sheets["RSL"];
            // -----------------------------------------------
            //  Options
            // -----------------------------------------------
            sheet.Options.Selected = true;
            sheet.Options.FreezePanes = true;
            sheet.Options.SplitHorizontal = 9;
            sheet.Options.TopRowBottomPane = 9;
            sheet.Options.SplitVertical = 5;
            sheet.Options.LeftColumnRightPane = 5;
            sheet.Options.ActivePane = 0;
            sheet.Options.ProtectObjects = false;
            sheet.Options.ProtectScenarios = false;
            sheet.Options.Print.ValidPrinterInfo = true;
        }
        #endregion
        #endregion

        #region ' Change Log Worksheet '
        #region ' Generate Change Log '
        private void GenerateWorksheetChangeLog(WorksheetCollection sheets)
        {
            Worksheet sheet = sheets.Add("ChangeLog");
            sheet.Table.DefaultRowHeight = 15F;
            //sheet.Table.ExpandedColumnCount = 5;
            //sheet.Table.FullColumns = 1;
            //sheet.Table.FullRows = 1;
            sheet.Table.Columns.Add(51);
            sheet.Table.Columns.Add(64);
            sheet.Table.Columns.Add(216);
            sheet.Table.Columns.Add(100);
            sheet.Table.Columns.Add(350);
            // -----------------------------------------------
            WorksheetRow Row0 = sheet.Table.Rows.Add();
            WorksheetCell cell;
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Date";
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Part Number";
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Description";
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Column";
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Details";
        }
        #endregion

        #region ' Add Change Log Row '
        private void AddChangeLogRow(WorksheetCollection sheets, DataRow dRow)
        {
            Worksheet sheet = sheets["ChangeLog"];
            WorksheetCell cell;
            WorksheetRow Row1 = sheet.Table.Rows.Add();
            Row1.Cells.Add(FormatExcelDate((DateTime)dRow["ChangeDt"]), DataType.DateTime, "s3746");
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["SpareKitNo"].ToString();
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["Description"].ToString();
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["ColumnChanged"].ToString();
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            string oldValue = dRow["OldValue"].ToString();
            string newValue = dRow["NewValue"].ToString();
            int changeType = 0;
            int.TryParse(dRow["ChangeType"].ToString(), out changeType);
            if ((changeType == 5) || (changeType == 1))
            {
                cell.Data.Text = dRow["ChangeTypeDesc"].ToString();
            }
            else
            {
                if ((!string.IsNullOrEmpty(oldValue)) || (!string.IsNullOrEmpty(newValue)))
                {
                    cell.Data.Text = string.Format("{0} --> {1}", dRow["OldValue"].ToString(), dRow["NewValue"].ToString());
                }
            }
        }
        #endregion

        #region ' Close Change Log '
        private void CloseChangeLog(WorksheetCollection sheets)
        {
            Worksheet sheet = sheets["ChangeLog"];
            // -----------------------------------------------
            //  Options
            // -----------------------------------------------
            sheet.Options.Selected = false;
            sheet.Options.ProtectObjects = false;
            sheet.Options.ProtectScenarios = false;
            sheet.Options.PageSetup.Header.Margin = 0.3F;
            sheet.Options.PageSetup.Footer.Margin = 0.3F;
            sheet.Options.PageSetup.PageMargins.Bottom = 0.75F;
            sheet.Options.PageSetup.PageMargins.Left = 0.7F;
            sheet.Options.PageSetup.PageMargins.Right = 0.7F;
            sheet.Options.PageSetup.PageMargins.Top = 0.75F;
        }
        #endregion
        #endregion

        #region ' Generate Mapping Worksheets '
        private void GenerateWorksheetMapping(WorksheetCollection sheets, string brandSeries, DataTable dt)
        {
            Worksheet sheet = sheets.Add(brandSeries);
            sheet.Table.DefaultRowHeight = 15F;
            //sheet.Table.FullColumns = 1;
            //sheet.Table.FullRows = 1;
            sheet.Table.Columns.Add(61);
            sheet.Table.Columns.Add(259);
            if (dt.Columns.Count > 7)
            {
                for (int i = 7; i < dt.Columns.Count; i++)
                {
                    sheet.Table.Columns.Add(80);
                }
            }
            // -----------------------------------------------
            WorksheetRow Row0 = sheet.Table.Rows.Add();
            Row0.Cells.Add("SPS PN#", DataType.String, "s3740");
            Row0.Cells.Add("SPS Description", DataType.String, "s3740");
            if (dt.Columns.Count > 7)
            {
                for (int i = 7; i < dt.Columns.Count; i++)
                {
                    Row0.Cells.Add(dt.Columns[i].ColumnName.ToString(), DataType.String, "s3740");
                }
            }
            WorksheetCell cell;
            cell = Row0.Cells.Add();
            cell.StyleID = "s3743";
            cell = Row0.Cells.Add();
            cell.StyleID = "s3743";
            // -----------------------------------------------
        }

        private void AddWorksheetMappingRow(WorksheetCollection sheets, string brandSeries, DataRow dRow)
        {
            //int mappingId = 0;
            //bool parseIntSuccess = int.TryParse(dRow["SpareKitMappingId"].ToString(), out mappingId);
            //if (!string.IsNullOrEmpty(dRow["AvNo"].ToString()))
            //{
            Worksheet sheet = sheets[brandSeries];
            WorksheetRow Row1 = sheet.Table.Rows.Add();
            WorksheetCell cell;
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["SpareKitNo"].ToString();
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["Description"].ToString();
            // Dynamic Begin Loop
            if (dRow.Table.Columns.Count > 7)
            {
                for (int i = 7; i < dRow.Table.Columns.Count; i++)
                {
                    //Row1.Cells.Add(dRow[i].ToString(), DataType.String, "s3743");
                    AddAvMappingCell(Row1, dRow[i].ToString());
                }
            }
            // End Loop
            //}
        }

        private void AddAvMappingCell(WorksheetRow row, string cellData)
        {
            if (!String.IsNullOrEmpty(cellData) && cellData.Contains(":"))
            {
                string[] dataArray = cellData.Split(':');
                string avNo = dataArray[0];
                string status = dataArray[1];
                DateTime lastUpdDate = DateTime.MinValue;
                DateTime.TryParse(dataArray[2], out lastUpdDate);

                if (status.Equals("A") && lastUpdDate >= LastPublishDt)
                    row.Cells.Add(avNo, DataType.String, "s3743h");
                else if (status.Equals("A") && lastUpdDate < LastPublishDt)
                    row.Cells.Add(avNo, DataType.String, "s3743");
                else if (status.Equals("D"))
                    row.Cells.Add(avNo, DataType.String, "s3743s");
            }
            else if (!String.IsNullOrEmpty(cellData))
            {
                row.Cells.Add(cellData, DataType.String, "s3743");
            }
            else
            {
                row.Cells.Add(string.Empty, DataType.String, "s3743");
            }
        }

        private void CloseWorksheetMappingRow(WorksheetCollection sheets, string brandSeries)
        {
            Worksheet sheet = sheets[brandSeries];

            // -----------------------------------------------
            //  Options
            // -----------------------------------------------
            sheet.Options.Selected = true;
            sheet.Options.ProtectObjects = false;
            sheet.Options.ProtectScenarios = false;
            sheet.Options.PageSetup.Header.Margin = 0.3F;
            sheet.Options.PageSetup.Footer.Margin = 0.3F;
            sheet.Options.PageSetup.PageMargins.Bottom = 0.75F;
            sheet.Options.PageSetup.PageMargins.Left = 0.7F;
            sheet.Options.PageSetup.PageMargins.Right = 0.7F;
            sheet.Options.PageSetup.PageMargins.Top = 0.75F;
        }
        #endregion

        #region ' Av Change Log Worksheet '
        #region ' Generate Av Change Log '
        private void GenerateWorksheetAvChangeLog(WorksheetCollection sheets)
        {
            Worksheet sheet = sheets.Add("AvChangeLog");
            sheet.Table.DefaultRowHeight = 15F;
            //sheet.Table.ExpandedColumnCount = 5;
            //sheet.Table.FullColumns = 1;
            //sheet.Table.FullRows = 1;
            sheet.Table.Columns.Add(65);
            sheet.Table.Columns.Add(65);
            sheet.Table.Columns.Add(225);
            sheet.Table.Columns.Add(90);
            sheet.Table.Columns.Add(65);
            // -----------------------------------------------
            WorksheetRow Row0 = sheet.Table.Rows.Add();
            WorksheetCell cell;
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Date";
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Kit Number";
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Description";
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Av Number";
            cell = Row0.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = "Details";
        }
        #endregion

        #region ' Add Av Change Log Row '
        private void AddAvChangeLogRow(WorksheetCollection sheets, DataRow dRow)
        {
            Worksheet sheet = sheets["AvChangeLog"];
            WorksheetCell cell;
            WorksheetRow Row1 = sheet.Table.Rows.Add();
            Row1.Cells.Add(FormatExcelDate((DateTime)dRow["LastUpdDate"]), DataType.DateTime, "s3746");
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["SpareKitNo"].ToString();
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["Description"].ToString();
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            cell.Data.Text = dRow["AvNo"].ToString();
            cell = Row1.Cells.Add();
            cell.Data.Type = DataType.String;
            if (dRow["Status"].ToString().Equals("A")) { cell.Data.Text = "Added"; } else { cell.Data.Text = "Deleted"; }
        }
        #endregion

        #region ' Close Av Change Log '
        private void CloseAvChangeLog(WorksheetCollection sheets)
        {
            Worksheet sheet = sheets["AvChangeLog"];
            // -----------------------------------------------
            //  Options
            // -----------------------------------------------
            sheet.Options.Selected = false;
            sheet.Options.ProtectObjects = false;
            sheet.Options.ProtectScenarios = false;
            sheet.Options.PageSetup.Header.Margin = 0.3F;
            sheet.Options.PageSetup.Footer.Margin = 0.3F;
            sheet.Options.PageSetup.PageMargins.Bottom = 0.75F;
            sheet.Options.PageSetup.PageMargins.Left = 0.7F;
            sheet.Options.PageSetup.PageMargins.Right = 0.7F;
            sheet.Options.PageSetup.PageMargins.Top = 0.75F;
        }
        #endregion
        #endregion


        #region ' Format Excel Date '

        String FormatExcelDate(DateTime dt)
        {
            StringBuilder s = new StringBuilder();
            s.Append(dt.Year.ToString().Trim());
            s.Append("-");
            s.Append(dt.Month.ToString().PadLeft(2, '0'));
            s.Append("-");
            s.Append(dt.Day.ToString().PadLeft(2, '0'));
            s.Append("T");
            s.Append(dt.Hour.ToString().PadLeft(2, '0'));
            s.Append(":");
            s.Append(dt.Minute.ToString().PadLeft(2, '0'));
            s.Append(":");
            s.Append(dt.Second.ToString().PadLeft(2, '0'));
            s.Append(".000");

            return s.ToString().Trim();
        }
        #endregion

        #region ' GetCellStyle
        private string GetCellStyle(bool ChangedBit, string Style)
        {
            if (ChangedBit)
                return string.Format("{0}h", Style);
            else
                return Style;
        }

        private string GetCellStyle(DataRow Row, string Column, string Style)
        {
            int changeType = 0;
            if (int.TryParse(Row["ChangeType"].ToString(), out changeType))
            {
                if (changeType == 1)
                    return string.Format("{0}h", Style);
            }

            if (string.IsNullOrEmpty(Column))
                return Style;

            object ChangedBit = Row[Column];

            if (ChangedBit == DBNull.Value)
                return Style;

            return GetCellStyle(Convert.ToBoolean(ChangedBit), Style);
        }
        #endregion
    }
}
