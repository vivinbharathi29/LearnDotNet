﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace RslExport
{
    public class RslNfo
    {
        private long _productVersionId = 0;
        public long ProductVersionId
        {
            get { return _productVersionId; }
            set {
                if (_productVersionId == 0)
                {
                    _productVersionId = value;
                    var dw = new HPQ.Excalibur.Data();
                    string sfpn = dw.GetServiceFamilyPn(_productVersionId.ToString());
                    if (!string.IsNullOrEmpty(sfpn))
                        ServiceFamilyPn = sfpn;
                }
            }
        }

        #region " ReadOnly Properties "

        private string _Division;
        public string Division
        {
            get { return _Division; }
        }

        private string _DesktopProductFamilyName;
        public string DesktopProductFamilyName
        {
            get { return _DesktopProductFamilyName; }
        }

        private string _selfRepairDoc;
        public string SelfRepairDoc
        {
            get { return _selfRepairDoc; }
        }

        private string _serviceFamilyPn;
        public string ServiceFamilyPn
        {
            get { return _serviceFamilyPn; }
            set
            {
                _serviceFamilyPn = value;
                var dwExcalibur = new HPQ.Excalibur.Data();
                DataTable dt = dwExcalibur.SelectRslHeader(_serviceFamilyPn);
                _serviceFamilyPn = dt.Rows[0]["ServiceFamilyPn"].ToString();
                _projectCode = dt.Rows[0]["ProjectNumber"].ToString();
                _odmName = dt.Rows[0]["OdmName"].ToString();
                _gplmName = dt.Rows[0]["GplmName"].ToString();
                _family = dt.Rows[0]["FamilyName"].ToString();
                _familyName = dt.Rows[0]["FamilyName"].ToString();
                _selfRepairDoc = dt.Rows[0]["SelfRepairDoc"].ToString();
                _Division = dt.Rows[0]["Division"].ToString();
                _DesktopProductFamilyName = dt.Rows[0]["DesktopProductFamilyName"].ToString();
                long.TryParse(dt.Rows[0]["ProductVersionId"].ToString(), out _productVersionId);
            }

        }

        private string _gplmName;
        public string GplmName
        {
            get { return _gplmName; }
        }

        private string _odmName;
        public string OdmName
        {
            get { return _odmName; }
        }

        private string _projectCode;
        public string ProjectCode
        {
            get { return _projectCode; }
        }

        private string _family;
        public string Family
        {
            get { return _family; }
        }

        private string _familyName;
        public string FamilyName
        {
            get { return _familyName; }
        }
        #endregion

        #region ' Constructors '
        public RslNfo() { }
        public RslNfo(string ServiceFamilyPn) { this.ServiceFamilyPn = ServiceFamilyPn; }
        public RslNfo(long ProductVersionId) { this.ProductVersionId = ProductVersionId; }
        #endregion


    }
}
