using HPQ.Excalibur;
using Org.System.Xml.Sax;
using Org.System.Xml.Sax.Helpers;
using System;
using System.Text;
using System.Web;

public class XmlScmSaxContentHandler : DefaultHandler
{
    #region ' Constants '
    private const string REGION = "region";
    private const string PLANT = "plant";
    private const string CAMPAIGN = "campaign";
    private const string PRODUCT = "product";
    private const string CATEGORY = "category";
    private const string AV = "av";
    private const string PBID = "pbid";
    private const string KMAT = "kmat";
    private const string EZCKMAT = "ezckmat";
    private const string PROJECT_CD = "projectCode";
    private const string PLANT_CD = "plantCode";
    private const string SALES_ORG = "salesOrg";
    private const string ID = "id";
    private const string NAME = "name";
    private const string CONFIG_RULES = "configRules";
    private const string MANUFACTURING_NOTES = "manufacturingNotes";
    private const string STATUS_CD = "statusCd";
    private const string AVNO = "avno";
    private const string GPG_DESCRIPTION = "gpgDescription";
    private const string MKTG_DESCRIPTION = "marketingDescription";
    private const string CPL_BLIND_DT = "cplBlindDt";
    private const string RAS_DISC_DT = "rasDiscDt";
    private const string IDS_SKUS = "idsSkus";
    private const string IDS_CTO = "idsCto";
    private const string RCTO_SKUS = "rctoSkus";
    private const string RCTO_CTO = "rctoCto";
    private const string BSAM_SKUS = "BSAMSkus";
    private const string BSAM_Bparts = "BSAMBparts";
    private const string UPC = "upc";
    private const string WEIGHT = "weight";
    private const string GLOBAL_SERIES_CONFIG = "globalSeriesConfig";
    private const string ACTIVE = "A";
    private const string MACRO_VER = "macroVersion";
    private const string SDF_FLAG = "sdfFlag";
    private const string PHWEB_NOTES = "phWebNote";
    private const string AVID = "avId";
    private const string GROUP1 = "group1";
    private const string GROUP2 = "group2";
    private const string GROUP3 = "group3";
    private const string GROUP4 = "group4";
    private const string GROUP5 = "group5";
    private const string MKTG_DESCRIPTION_2 = "marketingDescription2";
    private const string GA_DATE = "gaDate";
    private const string EXPECTED_MACRO_VERSION = "1.0.4.0";
    #endregion

    private Data _dw = new Data();
    private string pbid = string.Empty;
    private string featureCategoryId = string.Empty;
    private long avSortOrder = 5;
    private long newAvDetailID = 0;
    private string currentUser;
    private StringBuilder sbCharacters = new StringBuilder();
    private string _macroVersion = string.Empty;
    private string productBrandID;
    public string ProductBrandID
    {
        get { return productBrandID; }
        set { productBrandID = value; }
    }
    private ImportMode importMode = ImportMode.Default;
    private string region = string.Empty;
    private string plant = string.Empty;
    private string campaign = string.Empty;

    #region ' StartElement '
    public override void StartElement(string uri, string localName, string qName, IAttributes atts)
    {
        switch (qName)
        {
            case PRODUCT:
                //
                // Handle Product Element
                //
                pbid = atts.GetValue(PBID);
                avSortOrder = avSortOrder + (1000 * _dw.GetProductBrandSortWeight(pbid) - 1);
                region = atts.GetValue(REGION);
                plant = atts.GetValue(PLANT);
                campaign = atts.GetValue(CAMPAIGN);

                if (!string.IsNullOrEmpty(campaign))
                {
                    importMode = ImportMode.Campaign;
                }
                else if (!string.IsNullOrEmpty(plant))
                {
                    importMode = ImportMode.Plant;
                }
                else if (!string.IsNullOrEmpty(region))
                {
                    importMode = ImportMode.Region;
                }

                currentUser = HttpContext.Current.User.Identity.Name;
                _dw.UpdateKmat(atts.GetValue(PBID),
                    atts.GetValue(KMAT),
                    atts.GetValue(EZCKMAT),
                    atts.GetValue(PROJECT_CD),
                    atts.GetValue(PLANT_CD),
                    atts.GetValue(SALES_ORG),
                    currentUser);
                _macroVersion = atts.GetValue(MACRO_VER);
                string[] macroVersion = _macroVersion.Split('.');
                int Major = int.Parse(macroVersion[0]);
                int Minor = int.Parse(macroVersion[1]);
                int Revision = int.Parse(macroVersion[2]);
                int Build = int.Parse(macroVersion[3]);

                string[] expectedVersion = EXPECTED_MACRO_VERSION.Split('.');
                int expectedMajor = int.Parse(expectedVersion[0]);
                int expectedMinor = int.Parse(expectedVersion[1]);
                int expectedRevision = int.Parse(expectedVersion[2]);
                int expectedBuild = int.Parse(expectedVersion[3]);

                if ((Major != expectedMajor) || (Minor != expectedMinor) || (Revision != expectedRevision) || (Build != expectedBuild))
                    throw new Exception(string.Format("Macro Version {0} is less than expected.", _macroVersion));

                if (Revision == 0 && Build < 11)
                    throw new Exception(string.Format("Macro Version {0} is less than expected.", _macroVersion));

                break;
            case CATEGORY:
                //
                // Handle Category Element
                //
                if (importMode == ImportMode.Default)
                {
                    featureCategoryId = atts.GetValue(ID);
                    _dw.UpdateAvFeatureDetail(pbid,
                        atts.GetValue(ID),
                        FixText(atts.GetValue(CONFIG_RULES)),
                        atts.GetValue(MANUFACTURING_NOTES),
                        string.Empty,
                        string.Empty,
                        currentUser);
                }
                break;
            case AV:
                //
                // Handle AV Element
                //
                switch (importMode)
                {
                    case ImportMode.Region:
                        break;
                    case ImportMode.Plant:
                        break;
                    case ImportMode.Campaign:
                        break;
                    default:
                        #region "Default Case"
                        string avNo = atts.GetValue(AVNO);
                        sbCharacters = new StringBuilder();
                        if ((string.IsNullOrEmpty(atts.GetValue(ID))) || (atts.GetValue(ID) == "0"))
                        {
                            newAvDetailID = 0;
                            newAvDetailID = _dw.InsertAvDetail(featureCategoryId, atts.GetValue(AVNO), atts.GetValue(GPG_DESCRIPTION), string.Empty, false.ToString(), currentUser);

                            if (newAvDetailID > 0)
                            {
                                _dw.UpdateAvProductDetail(
                                    newAvDetailID.ToString(),
                                    pbid.ToString(),
                                    ACTIVE,
                                    string.Empty,
                                    FixText(atts.GetValue(CONFIG_RULES)),
                                    FixText(atts.GetValue(MANUFACTURING_NOTES)),
                                    atts.GetValue(IDS_SKUS).ToUpper() == "X" ? "Y" : "N",
                                    atts.GetValue(IDS_CTO).ToUpper() == "X" ? "Y" : "N",
                                    atts.GetValue(RCTO_SKUS).ToUpper() == "X" ? "Y" : "N",
                                    atts.GetValue(RCTO_CTO).ToUpper() == "X" ? "Y" : "N",
                                    avSortOrder.ToString(),
                                    string.Empty,
                                    true.ToString(),
                                    atts.GetValue(GLOBAL_SERIES_CONFIG),
                                    currentUser,
                                    atts.GetValue(SDF_FLAG).ToUpper() == "X" ? "1" : "0",
                                    atts.GetValue(PHWEB_NOTES).ToString(),
                                    atts.GetValue(AVID).ToString(),
                                    atts.GetValue(GROUP1).ToString(),
                                    atts.GetValue(GROUP2).ToString(),
                                    atts.GetValue(GROUP3).ToString(),
                                    atts.GetValue(GROUP4).ToString(),
                                    atts.GetValue(GROUP5).ToString(),
                                    atts.GetValue(BSAM_SKUS).ToUpper() == "X" ? "Y" : "N",
                                    atts.GetValue(BSAM_Bparts).ToUpper() == "X" ? "Y" : "N"
                                    );
                            }
                        }
                        else
                        {
                            if (atts.GetValue(STATUS_CD).ToUpper() == "D")
                            {
                                _dw.DeleteAvProductBrand(atts.GetValue(ID), pbid, currentUser);
                            }
                            else
                            {
                                _dw.UpdateAvProductDetail(atts.GetValue(ID),
                                    pbid,
                                    atts.GetValue(STATUS_CD),
                                    string.Empty,
                                    FixText(atts.GetValue(CONFIG_RULES)),
                                    FixText(atts.GetValue(MANUFACTURING_NOTES)),
                                    atts.GetValue(IDS_SKUS).ToUpper() == "X" ? "Y" : "N",
                                    atts.GetValue(IDS_CTO).ToUpper() == "X" ? "Y" : "N",
                                    atts.GetValue(RCTO_SKUS).ToUpper() == "X" ? "Y" : "N",
                                    atts.GetValue(RCTO_CTO).ToUpper() == "X" ? "Y" : "N",
                                    avSortOrder.ToString(),
                                    string.Empty,
                                    true.ToString(),
                                    atts.GetValue(GLOBAL_SERIES_CONFIG),
                                    currentUser,
                                    atts.GetValue(SDF_FLAG).ToUpper() == "X" ? "1" : "0",
                                    atts.GetValue(PHWEB_NOTES).ToString(),
                                    atts.GetValue(AVID).ToString(),
                                    atts.GetValue(GROUP1).ToString(),
                                    atts.GetValue(GROUP2).ToString(),
                                    atts.GetValue(GROUP3).ToString(),
                                    atts.GetValue(GROUP4).ToString(),
                                    atts.GetValue(GROUP5).ToString(),
                                    atts.GetValue(BSAM_SKUS).ToUpper() == "X" ? "Y" : "N",
                                    atts.GetValue(BSAM_Bparts).ToUpper() == "X" ? "Y" : "N"
                                    );
                            }
                        }

                        avSortOrder += 5;
                        break;
                        #endregion
                }
                break;
            default:
                break;
        }

    }
    #endregion

    #region ' EndElement '
    public override void EndElement(string uri, string localName, string qName)
    {
        //
        // Handle End of Category
        //
        System.Diagnostics.Debug.WriteLine(sbCharacters.ToString());
        sbCharacters = new StringBuilder();

        switch (qName)
        {
            case CATEGORY:
                featureCategoryId = string.Empty;
                avSortOrder = 5;
                break;
            case AV:
                System.Diagnostics.Debug.WriteLine(sbCharacters.ToString());
                sbCharacters = new StringBuilder();
                break;
            default:
                break;
        }
    }
    #endregion

    #region ' FixText '
    private string FixText(string value)
    {
        Char Chr34 = (char)34;
        Char Chr13 = (char)13;
        Char Chr10 = (char)10;

        StringBuilder output = new StringBuilder(value);
        output.Replace("&gt;", ">");
        output.Replace("&lt;", "<");
        output.Replace("&amp;", "&");
        output.Replace("&#37;", "%");
        output.Replace("&quot;", Chr34.ToString());
        output.Replace("&#13;", Chr13.ToString());
        output.Replace("&#10;", Chr10.ToString());

        return output.ToString();
    }
    #endregion

    #region ' Characters '
    public override void Characters(char[] ch, int start, int length)
    {
        sbCharacters.Append(ch);
    }
    #endregion

}

public enum ImportMode
{
    Region,
    Plant,
    Campaign,
    Default
}
