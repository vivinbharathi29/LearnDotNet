﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.SS.Util;
using NPOI.POIFS.FileSystem;
using NPOI.SS.UserModel;

namespace SpbExportNpoi
{
    public class SpbBomNpoi
    {
        public int iRowChangeLogNumber = 4;
        public int iRowSPBRowNumber = 6;

        ICellStyle CellSPBStyle_Restricted;
        ICellStyle CellSPBStyle_ReportGenerated;
        ICellStyle StyleArialBold_Top_Thick;
        ICellStyle StyleArialBold_Botton_Thick;
        ICellStyle CellSPBStyle_Arial_Bold;

        //Bold Blue - SpareKit - Level 2
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Blue;
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Blue_Center;
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Yellow;
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center;
        //ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Strike;

        //Light Blue - Sa - Level 3
        ICellStyle CellSPBStyle_Arial_AllMargin_Grey;
        ICellStyle CellSPBStyle_Arial_AllMargin_Grey_SkyBlue;
        ICellStyle CellSPBStyle_Arial_AllMargin_Grey_Yellow;

        ICellStyle CellSPBStyle_Arial_AllMargin;
        ICellStyle CellSPBStyle_Arial_AllMargin_Center;
        ICellStyle CellSPBStyle_Arial_AllMargin_SkyBlue;
        ICellStyle CellSPBStyle_Arial_AllMargin_Center_SkyBlue;
        ICellStyle CellSPBStyle_Arial_AllMargin_Yellow;
        ICellStyle CellSPBStyle_Arial_AllMargin_Center_Yellow;

        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike;
        ICellStyle CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike;

        ICellStyle CellSPBStyle_Arial_AllMargin_Grey_Strike;
        ICellStyle CellSPBStyle_Arial_AllMargin_Strike;
        ICellStyle CellSPBStyle_Arial_AllMargin_Center_Strike;

        #region ' Properties '

        private bool _newMatrix = false;
        public bool NewMatrix
        {
            get { return _newMatrix; }
            set { _newMatrix = value; }
        }

        private bool _publish = false;
        public bool Publish
        {
            get { return _publish; }
            set { _publish = value; }
        }

        private string _serviceFamilyPn = string.Empty;
        public string ServiceFamilyPn
        {
            get
            {
                return _serviceFamilyPn;
            }
            set { _serviceFamilyPn = value; }
        }

        private string _compareDt = string.Empty;
        public string CompareDt
        {
            get
            {
                DateTime dt;
                if (DateTime.TryParse(_compareDt, out dt))
                {
                    return _compareDt;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _compareDt = value; }
        }

        private string _exportTime = string.Empty;
        public string ExportTime
        {
            get { return _exportTime; }
            set { _exportTime = value; }
        }

        #endregion

        public void GenerateSPBNpoi(Stream SpbStream, string FileName, ref string ErrorMessage)
        {
            try
            {
                HSSFWorkbook hssfWorkBook = new HSSFWorkbook();

                InitializeWorkbook(hssfWorkBook);

                GenerateStyles(hssfWorkBook);

                // Create the Sheets
                ISheet sheetChangeLog = (HSSFSheet)hssfWorkBook.CreateSheet("ChangeLog");
                ISheet sheetSPB = (HSSFSheet)hssfWorkBook.CreateSheet("Service Program BOM");

                hssfWorkBook.GetSheet("ChangeLog").IsSelected = false;
                hssfWorkBook.GetSheet("Service Program BOM").IsSelected = true;
                hssfWorkBook.SetActiveSheet(1);

                GenerateWorksheetChangeLog(sheetChangeLog, hssfWorkBook);
                GenerateWorksheetSPB(sheetSPB, hssfWorkBook);

                GenerateDataRowSPB(sheetSPB, sheetChangeLog, hssfWorkBook, ref ErrorMessage);

                sheetSPB.SetMargin(MarginType.BottomMargin, 0.5);
                sheetSPB.SetMargin(MarginType.LeftMargin, 0.25);
                sheetSPB.SetMargin(MarginType.RightMargin, 0.25);
                sheetSPB.SetMargin(MarginType.TopMargin, 0.5);

                sheetChangeLog.SetMargin(MarginType.BottomMargin, 0.75);
                sheetChangeLog.SetMargin(MarginType.LeftMargin, 0.70);
                sheetChangeLog.SetMargin(MarginType.RightMargin, 0.70);
                sheetChangeLog.SetMargin(MarginType.TopMargin, 0.75);

                WriteToFile(SpbStream, hssfWorkBook);
            }
            catch (Exception ex)
            {
                throw new Exception("Err in GenerateSPBNpoi: " + ServiceFamilyPn + ". " + ex.ToString());
            }

        }


        #region ' ChangeLog '

        private void GenerateWorksheetChangeLog(ISheet sheet, HSSFWorkbook hssfWorkBook)
        {
            //Set Column Widths
            sheet.SetColumnWidth(0, 5000);//Spare Kit
            sheet.SetColumnWidth(1, 5000);//HP Part No
            sheet.SetColumnWidth(2, 5000);// Level
            sheet.SetColumnWidth(3, 6000);//Column
            sheet.SetColumnWidth(4, 20000);//Details

            //1st Row - This is the 1st header row.
            CreateRow(sheet, 0);
            CreateCell(sheet, 0, 0, CellType.STRING);//"s215"   Index = 2
            ReturnCell(sheet, 0, 0).SetCellValue("");

            CreateRow(sheet, 1); //RConfidential
            CreateCell(sheet, 1, 0, CellType.STRING);
            ReturnCell(sheet, 1, 0).SetCellValue("HP - Restricted");
            ReturnCell(sheet, 1, 0).CellStyle = CellSPBStyle_Restricted;

            CreateCell(sheet, 1, 1, CellType.STRING);//Report Generated
            ReturnCell(sheet, 1, 1).SetCellValue("Report Generated " + DateTime.Now.ToString());
            ReturnCell(sheet, 1, 1).CellStyle = CellSPBStyle_ReportGenerated;

            CreateRow(sheet, 2);
            CreateCell(sheet, 2, 0, CellType.STRING);
            ReturnCell(sheet, 2, 0).SetCellValue("Change Log");
            ReturnCell(sheet, 2, 0).CellStyle = StyleArialBold_Top_Thick;

            CreateCell(sheet, 2, 1, CellType.STRING);
            ReturnCell(sheet, 2, 1).CellStyle = StyleArialBold_Top_Thick;
            CreateCell(sheet, 2, 2, CellType.STRING);
            ReturnCell(sheet, 2, 2).CellStyle = StyleArialBold_Top_Thick;
            CreateCell(sheet, 2, 3, CellType.STRING);
            ReturnCell(sheet, 2, 3).CellStyle = StyleArialBold_Top_Thick;
            CreateCell(sheet, 2, 4, CellType.STRING);
            ReturnCell(sheet, 2, 4).CellStyle = StyleArialBold_Top_Thick;

            sheet.AddMergedRegion(new CellRangeAddress(2, 2, 0, 4));

            CreateRow(sheet, 3);

            CreateCell(sheet, 3, 0, CellType.STRING);
            ReturnCell(sheet, 3, 0).SetCellValue("Spare Kit");
            ReturnCell(sheet, 3, 0).CellStyle = StyleArialBold_Botton_Thick;

            CreateCell(sheet, 3, 1, CellType.STRING);
            ReturnCell(sheet, 3, 1).SetCellValue("HP Part No");
            ReturnCell(sheet, 3, 1).CellStyle = StyleArialBold_Botton_Thick;

            CreateCell(sheet, 3, 2, CellType.STRING);
            ReturnCell(sheet, 3, 2).SetCellValue("Level");
            ReturnCell(sheet, 3, 2).CellStyle = StyleArialBold_Botton_Thick;

            CreateCell(sheet, 3, 3, CellType.STRING);
            ReturnCell(sheet, 3, 3).SetCellValue("Column");
            ReturnCell(sheet, 3, 3).CellStyle = StyleArialBold_Botton_Thick;

            CreateCell(sheet, 3, 4, CellType.STRING);
            ReturnCell(sheet, 3, 4).SetCellValue("Details");
            ReturnCell(sheet, 3, 4).CellStyle = StyleArialBold_Botton_Thick;

        }

        private void AddChangeLogRow(HSSFWorkbook hssfWorkBook, String SpsKitPn, string HpPartNo, string Level, string ColumnName, string ChangeDetails)
        {
            if (Publish == true)
            {
                var dwExcalibur = new HPQ.Excalibur.Data();
                dwExcalibur.InsertSpbChangeLog(ServiceFamilyPn, ExportTime, SpsKitPn, HpPartNo, Level, ColumnName, ChangeDetails);
            }

            //Fonts Types
            IFont FontArial = hssfWorkBook.CreateFont();
            IFont FontArial_Bold = hssfWorkBook.CreateFont();

            FontArial.FontName = "Arial";
            FontArial_Bold.FontName = "Arial";
            FontArial_Bold.Boldweight = (short)FontBoldWeight.BOLD;

            // Style
            ICellStyle CellSPBStyle_Arial_Center = hssfWorkBook.CreateCellStyle();
            ICellStyle CellSPBStyle_Arial_Left = hssfWorkBook.CreateCellStyle();
            ICellStyle CellSPBStyle_Arial_PlatformRow = hssfWorkBook.CreateCellStyle();

            CellSPBStyle_Arial_Center = GenerateCellStyles("StylesArial_Center", CellSPBStyle_Arial_Center, FontArial, hssfWorkBook);
            CellSPBStyle_Arial_Left = GenerateCellStyles("StylesArial_Left", CellSPBStyle_Arial_Left, FontArial, hssfWorkBook);
            CellSPBStyle_Arial_PlatformRow = GenerateCellStyles("StylesArial_PlatformRow", CellSPBStyle_Arial_PlatformRow, FontArial_Bold, hssfWorkBook);


            ISheet sheetChangeLog = (HSSFSheet)hssfWorkBook.GetSheet("ChangeLog");

            //1st Row - This is the 1st header row.
            CreateRow(sheetChangeLog, iRowChangeLogNumber);

            //WorksheetCell cell;
            CreateCell(sheetChangeLog, iRowChangeLogNumber, 0, CellType.STRING);
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 0).SetCellValue(SpsKitPn);//s207
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 0).CellStyle = CellSPBStyle_Arial_PlatformRow;

            CreateCell(sheetChangeLog, iRowChangeLogNumber, 1, CellType.STRING);
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 1).SetCellValue(HpPartNo);//s207
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 1).CellStyle = CellSPBStyle_Arial_PlatformRow;

            CreateCell(sheetChangeLog, iRowChangeLogNumber, 2, CellType.STRING);
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 2).SetCellValue(Level);//s207
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 2).CellStyle = CellSPBStyle_Arial_PlatformRow;

            CreateCell(sheetChangeLog, iRowChangeLogNumber, 3, CellType.STRING);
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 3).SetCellValue(ColumnName);//s207
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 3).CellStyle = CellSPBStyle_Arial_PlatformRow;

            CreateCell(sheetChangeLog, iRowChangeLogNumber, 4, CellType.STRING);
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 4).SetCellValue(ChangeDetails);//s212
            ReturnCell(sheetChangeLog, iRowChangeLogNumber, 4).CellStyle = CellSPBStyle_Arial_PlatformRow;

            iRowChangeLogNumber++;
        }

        #endregion

        #region ' SPB '

        private void GenerateWorksheetSPB(ISheet sheet, HSSFWorkbook hssfWorkBook)
        {
            GenerarateSPBHeader(sheet, hssfWorkBook);
        }

        private void GenerarateSPBHeader(ISheet sheet, HSSFWorkbook hssfWorkBook)
        {
            // //Set Column Widths
            sheet.SetColumnWidth(0, 6000);//PartType
            sheet.SetColumnWidth(1, 2000);//Level
            sheet.SetColumnWidth(2, 5000);//OSSP Orderable
            sheet.SetColumnWidth(3, 2000);//Line Item
            sheet.SetColumnWidth(4, 4500);//Spare Kit PN
            sheet.SetColumnWidth(5, 1500);//Rev
            sheet.SetColumnWidth(6, 2000);//CrossPlatStatus
            sheet.SetColumnWidth(7, 1500);//Qty
            sheet.SetColumnWidth(8, 1500);//PriAltGen
            sheet.SetColumnWidth(9, 5000);//HP 6-3 Component
            sheet.SetColumnWidth(10, 10000);//"HP Part Description"
            sheet.SetColumnWidth(11, 4500);//ODM Part Number
            sheet.SetColumnWidth(12, 12000);//ODM Part Description
            sheet.SetColumnWidth(13, 5000);//ODM Bulk Part Number
            sheet.SetColumnWidth(14, 5000);//ODM Production MOQ
            sheet.SetColumnWidth(15, 5000);//ODM Post-Production MOQ
            sheet.SetColumnWidth(16, 5000);//Part Supplier (ODM/OEM)
            sheet.SetColumnWidth(17, 5000);//Model / Mfg Pn
            sheet.SetColumnWidth(18, 5000);//Comment

            //Fonts Types
            IFont FontArial_10_Bold = hssfWorkBook.CreateFont();
            FontArial_10_Bold.FontName = "Arial";
            FontArial_10_Bold.FontHeightInPoints = 10;

            // Style
            ICellStyle CellSPBStyle_Arial10_Bold_Center = hssfWorkBook.CreateCellStyle();
            ICellStyle CellSPBStyle_Arial10_Bold_Right = hssfWorkBook.CreateCellStyle();
            ICellStyle CellSPBStyle_Arial10_Bold_Left = hssfWorkBook.CreateCellStyle();
            ICellStyle CellSPBStyle_Arial10_Bold_WrapText = hssfWorkBook.CreateCellStyle();

            CellSPBStyle_Arial10_Bold_Center = GenerateCellStyles("StylesArial10Bold_Center", CellSPBStyle_Arial10_Bold_Center, FontArial_10_Bold, hssfWorkBook);
            CellSPBStyle_Arial10_Bold_Right = GenerateCellStyles("StylesArial10Bold_Right", CellSPBStyle_Arial10_Bold_Right, FontArial_10_Bold, hssfWorkBook);
            CellSPBStyle_Arial10_Bold_Left = GenerateCellStyles("StylesArial10Bold_Left", CellSPBStyle_Arial10_Bold_Left, FontArial_10_Bold, hssfWorkBook);
            CellSPBStyle_Arial10_Bold_WrapText = GenerateCellStyles("StylesArial10Bold_Wrap", CellSPBStyle_Arial10_Bold_WrapText, FontArial_10_Bold, hssfWorkBook);

            var dwExcalibur = new HPQ.Excalibur.Data();
            DataTable dtSpbDetails = dwExcalibur.SelectSpbDetails(ServiceFamilyPn);
            if (dtSpbDetails.Rows.Count == 0) throw new Exception(String.Format("No Details for Family Pn : {0}", ServiceFamilyPn));

            //string sProductVersionID = Convert.ToInt64(dt.Rows[0]["ProductVersionID"].ToString());
            string sProjectCode = dtSpbDetails.Rows[0]["ProjectCd"].ToString();
            string sPartnerName = dtSpbDetails.Rows[0]["PartnerName"].ToString();
            string sSpdmContact = dtSpbDetails.Rows[0]["SpdmContact"].ToString();
            string sProductVersion = dtSpbDetails.Rows[0]["Version"].ToString();
            string sFamily = dtSpbDetails.Rows[0]["FamilyName"].ToString();
            string sFamilyName = dtSpbDetails.Rows[0]["XFamilyName"].ToString();
            //string sFamilyName = String.Format("{0} {1}.x", sFamily, sProductVersion.Substring(0, sProductVersion.IndexOf(".") - 1));
            dtSpbDetails = null;

            //1st Row - This is the 1st header row.
            CreateRow(sheet, 0);
            //WorksheetCell cells;
            CreateCell(sheet, 0, 0, CellType.STRING);
            ReturnCell(sheet, 0, 0).SetCellValue("Program Name:");
            ReturnCell(sheet, 0, 0).CellStyle = CellSPBStyle_Arial10_Bold_Right;

            CreateCell(sheet, 0, 1, CellType.STRING);
            ReturnCell(sheet, 0, 1).SetCellValue(sFamilyName);
            ReturnCell(sheet, 0, 1).CellStyle = CellSPBStyle_Arial10_Bold_Center;
            CreateCell(sheet, 0, 2, CellType.STRING);
            ReturnCell(sheet, 0, 2).SetCellValue(string.Empty);
            sheet.AddMergedRegion(new CellRangeAddress(0, 0, 1, 2));

            CreateRow(sheet, 1);
            CreateCell(sheet, 1, 0, CellType.STRING);
            ReturnCell(sheet, 1, 0).SetCellValue("Project ID:");
            ReturnCell(sheet, 1, 0).CellStyle = CellSPBStyle_Arial10_Bold_Right;
            sheet.GetRow(1).HeightInPoints = 15;

            CreateCell(sheet, 1, 1, CellType.STRING);
            ReturnCell(sheet, 1, 1).SetCellValue(sProjectCode);
            ReturnCell(sheet, 1, 1).CellStyle = CellSPBStyle_Arial10_Bold_Center;
            CreateCell(sheet, 1, 2, CellType.STRING);
            sheet.AddMergedRegion(new CellRangeAddress(1, 1, 1, 2));

            CreateRow(sheet, 2);
            CreateCell(sheet, 2, 0, CellType.STRING);
            ReturnCell(sheet, 2, 0).SetCellValue("Family SPS Pn:");
            ReturnCell(sheet, 2, 0).CellStyle = CellSPBStyle_Arial10_Bold_Right;

            CreateCell(sheet, 2, 1, CellType.STRING);
            ReturnCell(sheet, 2, 1).SetCellValue(ServiceFamilyPn);
            ReturnCell(sheet, 2, 1).CellStyle = CellSPBStyle_Arial10_Bold_Center;
            CreateCell(sheet, 2, 2, CellType.STRING);
            sheet.AddMergedRegion(new CellRangeAddress(2, 2, 1, 2));

            CreateRow(sheet, 3);
            CreateCell(sheet, 3, 0, CellType.STRING);
            ReturnCell(sheet, 3, 0).SetCellValue("SPDM Contact:");
            ReturnCell(sheet, 3, 0).CellStyle = CellSPBStyle_Arial10_Bold_Right;

            CreateCell(sheet, 3, 1, CellType.STRING);
            ReturnCell(sheet, 3, 1).SetCellValue(sSpdmContact);
            ReturnCell(sheet, 3, 1).CellStyle = CellSPBStyle_Arial10_Bold_Center;
            CreateCell(sheet, 3, 2, CellType.STRING);
            sheet.AddMergedRegion(new CellRangeAddress(3, 3, 1, 2));

            CreateRow(sheet, 4);
            CreateCell(sheet, 4, 0, CellType.STRING);
            ReturnCell(sheet, 4, 0).SetCellValue("ODM:");
            ReturnCell(sheet, 4, 0).CellStyle = CellSPBStyle_Arial10_Bold_Right;

            CreateCell(sheet, 4, 1, CellType.STRING);
            ReturnCell(sheet, 4, 1).SetCellValue(sPartnerName);
            ReturnCell(sheet, 4, 1).CellStyle = CellSPBStyle_Arial10_Bold_Center;
            CreateCell(sheet, 4, 2, CellType.STRING);
            sheet.AddMergedRegion(new CellRangeAddress(4, 4, 1, 2));

            // Row 6 (5,0) Hp Restricted
            GenerateHPRestricted(sheet, hssfWorkBook);

            // Columns Table Data
            CreateRow(sheet, 6);
            sheet.GetRow(6).HeightInPoints = 38;
            CreateCell(sheet, 6, 0, CellType.STRING);
            ReturnCell(sheet, 6, 0).SetCellValue("Part Type");
            ReturnCell(sheet, 6, 0).CellStyle = CellSPBStyle_Arial10_Bold_Left;

            CreateCell(sheet, 6, 1, CellType.STRING);
            ReturnCell(sheet, 6, 1).SetCellValue("Level");
            ReturnCell(sheet, 6, 1).CellStyle = CellSPBStyle_Arial10_Bold_Center;

            //The patriarch is a container 
            HSSFPatriarch patr = (HSSFPatriarch)sheet.CreateDrawingPatriarch();
            //create a comment 
            IComment Comment = patr.CreateCellComment(new HSSFClientAnchor(0, 0, 0, 0, 0, 2, 3, 8));

            string msg = "Level 2 = HP Spare Kit \n\n Level 3 = HP Sub-Assembly or Component  \n\n Level 4 = HP component PN";
            Comment.String = new HSSFRichTextString(msg);
            Comment.Author = " ";
            ReturnCell(sheet, 6, 1).CellComment = Comment;

            CreateCell(sheet, 6, 2, CellType.STRING);
            ReturnCell(sheet, 6, 2).SetCellValue("OSSP Orderable PN Yes/No");
            ReturnCell(sheet, 6, 2).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 3, CellType.STRING);
            ReturnCell(sheet, 6, 3).SetCellValue("Line Item");
            ReturnCell(sheet, 6, 3).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 4, CellType.STRING);
            ReturnCell(sheet, 6, 4).SetCellValue("Spare Kit PN");
            ReturnCell(sheet, 6, 4).CellStyle = CellSPBStyle_Arial10_Bold_Left;

            CreateCell(sheet, 6, 5, CellType.STRING);
            ReturnCell(sheet, 6, 5).SetCellValue("Rev");
            ReturnCell(sheet, 6, 5).CellStyle = CellSPBStyle_Arial10_Bold_Left;

            CreateCell(sheet, 6, 6, CellType.STRING);
            ReturnCell(sheet, 6, 6).SetCellValue("Cross Plant Status");
            ReturnCell(sheet, 6, 6).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 7, CellType.STRING);
            ReturnCell(sheet, 6, 7).SetCellValue("Qty");
            ReturnCell(sheet, 6, 7).CellStyle = CellSPBStyle_Arial10_Bold_Center;

            CreateCell(sheet, 6, 8, CellType.STRING);
            ReturnCell(sheet, 6, 8).SetCellValue("Pri Alt Gen");
            ReturnCell(sheet, 6, 8).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            IComment CommentPriAltGen = patr.CreateCellComment(new HSSFClientAnchor(0, 0, 0, 0, 0, 2, 3, 8));
            string msgPriAltGen = "Primary/Alternate designation simply means use one of the items listed.  Primary does not mean preferred.";
            CommentPriAltGen.String = new HSSFRichTextString(msgPriAltGen);
            CommentPriAltGen.Author = " ";
            ReturnCell(sheet, 6, 8).CellComment = CommentPriAltGen;

            CreateCell(sheet, 6, 9, CellType.STRING);
            ReturnCell(sheet, 6, 9).SetCellValue("HP 6-3 Component or SA PN");
            ReturnCell(sheet, 6, 9).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 10, CellType.STRING);
            ReturnCell(sheet, 6, 10).SetCellValue("HP Part Description");
            ReturnCell(sheet, 6, 10).CellStyle = CellSPBStyle_Arial10_Bold_Left;

            CreateCell(sheet, 6, 11, CellType.STRING);
            ReturnCell(sheet, 6, 11).SetCellValue("ODM Part Number");
            ReturnCell(sheet, 6, 11).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 12, CellType.STRING);
            ReturnCell(sheet, 6, 12).SetCellValue("ODM Part Description");
            ReturnCell(sheet, 6, 12).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 13, CellType.STRING);
            ReturnCell(sheet, 6, 13).SetCellValue("ODM Bulk Part Number");
            ReturnCell(sheet, 6, 13).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 14, CellType.STRING);
            ReturnCell(sheet, 6, 14).SetCellValue("ODM Production MOQ");
            ReturnCell(sheet, 6, 14).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 15, CellType.STRING);
            ReturnCell(sheet, 6, 15).SetCellValue("ODM Post-Production MOQ");
            ReturnCell(sheet, 6, 15).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 16, CellType.STRING);
            ReturnCell(sheet, 6, 16).SetCellValue("Part Supplier (ODM/OEM)");
            ReturnCell(sheet, 6, 16).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 17, CellType.STRING);
            ReturnCell(sheet, 6, 17).SetCellValue("Model / Mfg Pn");
            ReturnCell(sheet, 6, 17).CellStyle = CellSPBStyle_Arial10_Bold_WrapText;

            CreateCell(sheet, 6, 18, CellType.STRING);
            ReturnCell(sheet, 6, 18).SetCellValue("Comment");
            ReturnCell(sheet, 6, 18).CellStyle = CellSPBStyle_Arial10_Bold_Left;
        }

        private void GenerateDataRowSPB(ISheet sheetSPB, ISheet sheetChangeLog, HSSFWorkbook hssfWorkBook, ref string ErrorMessage)
        {
            try
            {
                var dwExcalibur = new HPQ.Excalibur.Data();
                DataTable dt = dwExcalibur.SelectSparesMatrix(ServiceFamilyPn, CompareDt, Publish);


                if (dt.Rows.Count == 0)
                {
                    ErrorMessage = "SPB - No Data - Zero Rows Returned from Spares Matrix:  " + ServiceFamilyPn + ". ";
                    //throw new ApplicationException("SPB- No Data -Zero Rows Returned from Spares Matrx:  " + ServiceFamilyPn + ". ");
                }
                else
                {
                    string sLastSpareKit = String.Empty;
                    string sLastSA = String.Empty;
                    string sLastPart = String.Empty;
                    string SpsKitPn = String.Empty;
                    string aSpsKitPn = String.Empty;
                    string SaPn = String.Empty;
                    string aSaPn = String.Empty;
                    string PartPn = String.Empty;
                    string aPartPn = String.Empty;
                    string XplantStatus = String.Empty;

                    foreach (DataRow row in dt.Rows)
                    {
                        ////if (row["SpsKitPn"].ToString().Trim() == "784981-001")
                        ////{
                        ////    SpsKitPn = row["SpsKitPn"].ToString().Trim();                      
                        ////}
                        SpsKitPn = row["SpsKitPn"].ToString().Trim();
                        aSpsKitPn = row["aSpsKitPn"].ToString().Trim();
                        SaPn = row["SaPn"].ToString().Trim();
                        aSaPn = row["aSaPn"].ToString().Trim();
                        PartPn = row["PartPn"].ToString().Trim();
                        aPartPn = row["aPartPn"].ToString().Trim();
                        XplantStatus = row["SpsXplantStatus"].ToString().Trim();
                        string SpsKitDelCat = row["SpsKitDelCat"].ToString().Trim();


                        if ((XplantStatus != "C1") && (XplantStatus != "C6"))
                        {
                            if ((sLastSpareKit != SpsKitPn) && (SpsKitPn != String.Empty))
                            {
                                AddSpareKitRow(hssfWorkBook, sheetSPB, sheetChangeLog, row);
                                sLastSpareKit = SpsKitPn;
                                sLastSA = SaPn;
                                sLastPart = PartPn;
                            }
                            else if ((aSpsKitPn != String.Empty) && (SpsKitPn == String.Empty) && (aSpsKitPn != sLastSpareKit))
                            {
                                AddSpareKitChangeRow(hssfWorkBook, row, ChangeType.Remove, "spskitpn");
                                sLastSpareKit = aSpsKitPn;
                                sLastSA = aSaPn;
                                sLastPart = aPartPn;
                            }
                            else if ((sLastSA != SaPn) && (SaPn != String.Empty))
                            {
                                AddSaRow(hssfWorkBook, sheetSPB, row);
                                sLastSA = SaPn;
                                sLastPart = PartPn;
                            }
                            else if ((aSaPn != String.Empty) && (SaPn == String.Empty) && (aSaPn != sLastSA))
                            {
                                AddSAChangeRow(hssfWorkBook, row, ChangeType.Remove, "sapn");
                                sLastSA = aSaPn;
                                sLastPart = aPartPn;
                            }
                            else if ((sLastPart != PartPn) && (PartPn != String.Empty))
                            {
                                AddPartRow(hssfWorkBook, sheetSPB, row);
                                sLastPart = PartPn;
                            }
                            else if ((aPartPn != String.Empty) && (PartPn == String.Empty) && (aPartPn != sLastPart))
                            {
                                AddPartChangeRow(hssfWorkBook, row, ChangeType.Remove, "partpn");
                                sLastPart = aPartPn;
                            }
                        }

                    }

                    dt = null;
                }


            }
            catch (Exception ex)
            {
                throw new Exception("SPB-Err in GenerateDataRowSPB " + ex.ToString());
            }
        }

        #endregion

        #region 'SPB DATA'

        private void AddSpareKitRow(HSSFWorkbook hssfWorkBook, ISheet sheetSPB, ISheet sheetChangeLog, DataRow drow)
        {
            try
            {
                if (ValidRow(drow, BomLevelEnum.Kit))
                {

                    iRowSPBRowNumber++;
                    CreateRow(sheetSPB, iRowSPBRowNumber);

                    sheetSPB.GetRow(iRowSPBRowNumber).HeightInPoints = 16;
                    CreateCell(sheetSPB, iRowSPBRowNumber, 0, CellType.STRING);//Part Type
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 0).SetCellValue(drow["SpsKitDelCat"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 0).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsKitDelCat", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 1, CellType.NUMERIC);//Level
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 1).SetCellValue("2");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 1).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 2, CellType.STRING);//Ossp Orderable
                    if (drow["SpsKitOsspOrderable"].ToString() == "")
                    {
                        ReturnCell(sheetSPB, iRowSPBRowNumber, 2).SetCellValue("FG");
                    }
                    else
                    {
                        string sSpsKitOsspOrderable = (bool)drow["SpsKitOsspOrderable"] ? "Yes" : "No";

                        if (sSpsKitOsspOrderable == "Yes")
                        {
                            ReturnCell(sheetSPB, iRowSPBRowNumber, 2).SetCellValue(sSpsKitOsspOrderable);
                        }
                        else
                        {
                            ReturnCell(sheetSPB, iRowSPBRowNumber, 2).SetCellValue("FG");
                        }
                    }
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 2).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center); //+ WrapText

                    CreateCell(sheetSPB, iRowSPBRowNumber, 3, CellType.STRING);//Line Item
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 3).SetCellValue("");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 3).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 4, CellType.STRING);//HP Spare Kit Pn
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 4).SetCellValue(drow["SpsKitPn"].ToString().Trim());
                    string skit = drow["SpsKitPn"].ToString().Trim();
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 4).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsKitPn", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 5, CellType.STRING);//Rev
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 5).SetCellValue(drow["SpsKitRev"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 5).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsKitRev", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center); //+ WrapText

                    CreateCell(sheetSPB, iRowSPBRowNumber, 6, CellType.STRING);//XPlant
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 6).SetCellValue(drow["SpsXplantStatus"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 6).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsXPlantStatus", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);//+ WrapText

                    CreateCell(sheetSPB, iRowSPBRowNumber, 7, CellType.STRING);//Qty
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 7).SetCellValue(drow["SpsQty"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 7).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 8, CellType.STRING);// Pri Alt Gen
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 8).SetCellValue("");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 8).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 9, CellType.STRING);//HP Pn
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 9).SetCellValue("");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 9).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 10, CellType.STRING);// HP Description
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 10).SetCellValue(drow["SpsKitDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 10).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsKitDescription", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 11, CellType.STRING);//Odm Pn
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 11).SetCellValue(drow["SpsOdmPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 11).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmPartNo", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 12, CellType.STRING);//Odm Description
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 12).SetCellValue(drow["SpsOdmPartDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 12).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmPartDescription", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 13, CellType.STRING);//Odm Bulk Pn
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 13).SetCellValue(drow["SpsOdmBulkPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 13).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmBulkPartNo", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 14, CellType.STRING);//Odm Production Moq
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 14).SetCellValue(drow["SpsOdmProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 14).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmProductionMoq", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 15, CellType.STRING);//Odm Post-Production Moq
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 15).SetCellValue(drow["SpsOdmPostProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 15).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsOdmPostProductionMoq", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 16, CellType.STRING);//sparekit Supplier
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 16).SetCellValue(drow["SpsSupplier"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 16).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 17, CellType.STRING);//Model
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 17).SetCellValue(drow["SpsModel"].ToString().Trim());
                    //ReturnCell(sheetSPB, iRowSPBRowNumber, 17).SetCellValue("");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 17).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 18, CellType.STRING);//Comments
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 18).SetCellValue(drow["SpsComments"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 18).CellStyle = GetStyleSparekit(hssfWorkBook, drow, "SpsComments", CellSPBStyle_Arial_AllMargin_Bold_Blue);

                    if (drow["SaPn"].ToString() != String.Empty)
                    {
                        string SaXplantStatus = drow["SaXplantStatus"].ToString().Trim();
                        if ((SaXplantStatus != "C1") && (SaXplantStatus != "C6"))
                        {
                            AddSaRow(hssfWorkBook, sheetSPB, drow);
                        }
                    }
                }
                else
                {
                    //Check to see if the status changed.
                    string SpsXplantStatus = drow["SpsXplantStatus"].ToString().Trim();
                    string aSpsXplantStatus = drow["aSpsXplantStatus"].ToString().Trim();

                    //if (((SpsXplantStatus == "C6") || (SpsXplantStatus == "C1")) && ((aSpsXplantStatus == "C2") || (aSpsXplantStatus == "C5")))
                    if ((aSpsXplantStatus == "C2") || (aSpsXplantStatus == "C5"))
                    {
                        AddChangeLogRow(hssfWorkBook, drow["spskitpn"].ToString().Trim(), String.Empty, "2", "Cross Plant Status", String.Format("{0} -> {1}", drow["aspsxplantstatus"].ToString().Trim(), drow["spsxplantstatus"]));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddSpareKitRow" + ex.ToString());
            }
        }

        private void AddSpareKitChangeRow(HSSFWorkbook hssfWorkBook, DataRow row, ChangeType Type, string ColumnName)
        {
            string sColumnName = string.Empty;
            string sChangeDetails = string.Empty;
            string sLevel = "2";

            if (ColumnName == string.Empty) return;

            string sSpsKitPn = row["SpsKitPn"].ToString().Trim();

            if (sSpsKitPn == string.Empty) sSpsKitPn = row["aSpsKitPn"].ToString().Trim();


            switch (ColumnName.ToLower())
            {
                case "spsdelcat":
                    sColumnName = "Part Type";
                    break;
                case "spskitossporderable":
                    sColumnName = "OSSP Orderable";
                    break;
                case "spskitpn":
                    sColumnName = "Spare Kit Pn";
                    break;
                case "spskitrev":
                    sColumnName = "Revision";
                    break;
                case "spskitdescription":
                    sColumnName = "Description";
                    break;
                case "spsqty":
                    sColumnName = "Quantity";
                    break;
                case "spsusage":
                    sColumnName = "Usage";
                    break;
                case "spsbomitemno":
                    sColumnName = "Item No";
                    break;
                case "spsmatltype":
                    sColumnName = "Material Type";
                    break;
                case "spsxplantstatus":
                    sColumnName = "Cross Plant Status";
                    break;
            }

            sChangeDetails = String.Format("{0} -> {1}", row["a" + ColumnName].ToString().Trim(), row[ColumnName].ToString().Trim());

            if ((Type == ChangeType.Add) && (ColumnName.ToLower()) == "spskitpn")
            {
                sChangeDetails = "Spare Kit Added";
                sColumnName = String.Empty;
            }
            else if (Type == ChangeType.Add) return;


            if ((Type == ChangeType.Remove) && (ColumnName.ToLower()) == "spskitpn")
            {
                sChangeDetails = "Spare Kit Removed";
                sColumnName = String.Empty;
            }
            else if (Type == ChangeType.Remove) return;


            AddChangeLogRow(hssfWorkBook, sSpsKitPn, String.Empty, sLevel, sColumnName, sChangeDetails);

        }

        private void AddSaRow(HSSFWorkbook hssfWorkBook, ISheet sheetSPB, DataRow drow)
        {
            try
            {
                if ((drow["SaPn"].ToString() != String.Empty) && (ValidRow(drow, BomLevelEnum.SubAssembly)))
                {
                    iRowSPBRowNumber++;
                    CreateRow(sheetSPB, iRowSPBRowNumber);
                    sheetSPB.GetRow(iRowSPBRowNumber).HeightInPoints = 16;

                    CreateCell(sheetSPB, iRowSPBRowNumber, 0, CellType.STRING);//Part Type
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 0).SetCellValue(drow["SpsKitDelCat"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 0).CellStyle = GetStyleSA(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Grey);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 1, CellType.STRING);//Level                
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 1).SetCellValue("3");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 1).CellStyle = GetStyleSA(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Center);//s46

                    CreateCell(sheetSPB, iRowSPBRowNumber, 2, CellType.STRING);

                    string sSaOsspOrderable = (bool)drow["SaOsspOrderable"] ? "Yes" : "No";

                    ReturnCell(sheetSPB, iRowSPBRowNumber, 2).SetCellValue(sSaOsspOrderable);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 2).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOsspOrderable", CellSPBStyle_Arial_AllMargin_Center);//s47

                    CreateCell(sheetSPB, iRowSPBRowNumber, 3, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 3).SetCellValue(drow["SaBomItemNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 3).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaBomItemNo", CellSPBStyle_Arial_AllMargin_Center);//s47

                    CreateCell(sheetSPB, iRowSPBRowNumber, 4, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 4).SetCellValue(drow["SpsKitPn"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 4).CellStyle = GetStyleSA(hssfWorkBook, drow, "SpsKitPn", CellSPBStyle_Arial_AllMargin_Grey);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 5, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 5).SetCellValue(drow["SaRev"].ToString());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 5).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaRev", CellSPBStyle_Arial_AllMargin_Center);//s79

                    CreateCell(sheetSPB, iRowSPBRowNumber, 6, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 6).SetCellValue(drow["SaXplantStatus"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 6).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaXPlantStatus", CellSPBStyle_Arial_AllMargin_Center);//s79

                    CreateCell(sheetSPB, iRowSPBRowNumber, 7, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 7).SetCellValue(drow["SaQty"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 7).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaQty", CellSPBStyle_Arial_AllMargin_Center);//s79

                    CreateCell(sheetSPB, iRowSPBRowNumber, 8, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 8).SetCellValue(drow["SaPriAlt"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 8).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaPriAlt", CellSPBStyle_Arial_AllMargin_Center);//s79

                    CreateCell(sheetSPB, iRowSPBRowNumber, 9, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 9).SetCellValue(drow["SaPn"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 9).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaPn", CellSPBStyle_Arial_AllMargin);//s60

                    CreateCell(sheetSPB, iRowSPBRowNumber, 10, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 10).SetCellValue(drow["SaDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 10).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaDescription", CellSPBStyle_Arial_AllMargin);//s60

                    CreateCell(sheetSPB, iRowSPBRowNumber, 11, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 11).SetCellValue(drow["SaOdmPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 11).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmPartNo", CellSPBStyle_Arial_AllMargin);//s60

                    CreateCell(sheetSPB, iRowSPBRowNumber, 12, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 12).SetCellValue(drow["SaOdmPartDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 12).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmPartDescription", CellSPBStyle_Arial_AllMargin);//s60

                    CreateCell(sheetSPB, iRowSPBRowNumber, 13, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 13).SetCellValue(drow["SaOdmBulkPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 13).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmBulkPartNo", CellSPBStyle_Arial_AllMargin);//s60

                    CreateCell(sheetSPB, iRowSPBRowNumber, 14, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 14).SetCellValue(drow["SaOdmProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 14).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmProductionMoq", CellSPBStyle_Arial_AllMargin);//s60

                    CreateCell(sheetSPB, iRowSPBRowNumber, 15, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 15).SetCellValue(drow["SaOdmPostProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 15).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaOdmPostProductionMoq", CellSPBStyle_Arial_AllMargin);//s60

                    CreateCell(sheetSPB, iRowSPBRowNumber, 16, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 16).SetCellValue(drow["SaSupplier"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 16).CellStyle = GetStyleSA(hssfWorkBook, drow, "PartSupplier", CellSPBStyle_Arial_AllMargin);//s60

                    CreateCell(sheetSPB, iRowSPBRowNumber, 17, CellType.STRING);//Model
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 17).SetCellValue(drow["SaModel"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 17).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaModel", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 18, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 18).SetCellValue(drow["SaComments"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 18).CellStyle = GetStyleSA(hssfWorkBook, drow, "SaComments", CellSPBStyle_Arial_AllMargin);//s60

                    if (drow["PartPn"].ToString() != String.Empty)
                    {
                        string PartXPlantStatus = drow["PartXPlantStatus"].ToString().Trim();
                        if ((PartXPlantStatus != "C1") && (PartXPlantStatus != "C6"))
                        {
                            AddPartRow(hssfWorkBook, sheetSPB, drow);
                        }
                    }
                }
                else
                {
                    //Check to see if the status changed.
                    // if (((drow["SaXplantStatus"].ToString().Trim() == "C6" || drow["SaXplantStatus"].ToString().Trim() == "C1")) && ((drow["aSaXplantStatus"].ToString().Trim() == "C2") || (drow["aSaXplantStatus"].ToString().Trim() == "C5")))
                    if ((drow["aSaXplantStatus"].ToString().Trim() == "C2") || (drow["aSaXplantStatus"].ToString().Trim() == "C5"))
                    {
                        AddChangeLogRow(hssfWorkBook, drow["spskitpn"].ToString().Trim(), drow["sapn"].ToString().Trim(), "2", "Cross Plant Status", String.Format("{0} -> {1}", drow["aSaXplantStatus"].ToString().Trim(), drow["SaXplantStatus"]));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddSaRow" + ex.ToString());
            }
        }

        private void AddSAChangeRow(HSSFWorkbook hssfWorkBook, DataRow row, ChangeType Type, string ColumnName)
        {
            string sColumnName = string.Empty;
            string sChangeDetails = string.Empty;
            string sLevel = "3";

            if (ColumnName == String.Empty) return;

            string sSpsKitPn = row["SpsKitPn"].ToString().Trim();
            string sHpPartNo = row["SaPn"].ToString().Trim();

            if (Type == ChangeType.Remove)
            {
                sSpsKitPn = row["aSpsKitPn"].ToString().Trim();
                sHpPartNo = row["aSaPn"].ToString().Trim();
            }

            switch (ColumnName.ToLower())
            {
                case "saossporderable":
                    sColumnName = "OSSP Orderable";
                    break;
                case "saqty":
                    sColumnName = "Quantity";
                    break;
                case "sarev":
                    sColumnName = "Revision";
                    break;
                case "sausage":
                    sColumnName = "Usage";
                    break;
                case "sabomitemno":
                    sColumnName = "BOM Item No";
                    break;
                case "saprialt":
                    sColumnName = "Pri / Alt / Gen";
                    break;
                case "sapn":
                    sColumnName = "HP Part No";
                    break;
                case "sadescription":
                    sColumnName = "Description";
                    break;
                case "saodmpartno":
                    sColumnName = "ODM Part No";
                    break;
                case "saodmpartdescription":
                    sColumnName = "ODM Description";
                    break;
                case "saodmbulkpartno":
                    sColumnName = "ODM Bulk Part No";
                    break;
                case "saodmproductionmoq":
                    sColumnName = "ODM Production MOQ";
                    break;
                case "saodmpostproductionmoq":
                    sColumnName = "ODM Post-Production MOQ";
                    break;
                case "saleadtime":
                    sColumnName = "Lead Time";
                    break;
                case "sasupplier":
                    sColumnName = "Supplier";
                    break;
                case "sacomments":
                    sColumnName = "Comments";
                    break;
                case "samatltype":
                    sColumnName = "Material Type";
                    break;
                case "saxplantstatus":
                    sColumnName = "Cross Plant Status";
                    break;
                case "samodel":
                    sColumnName = "Model / Mfg Pn";
                    break;

            }

            sChangeDetails = String.Format("{0} -> {1}", row["a" + ColumnName].ToString().Trim(), row[ColumnName].ToString().Trim());

            if ((Type == ChangeType.Add) && (ColumnName.ToLower() == "sapn"))
            {
                sChangeDetails = "Sub Assembly Added";
                sColumnName = String.Empty;
            }
            else if (Type == ChangeType.Add)
            {
                return;
            }

            if ((Type == ChangeType.Remove) && (ColumnName.ToLower() == "sapn"))
            {
                sChangeDetails = "Sub Assembly Removed";
                sColumnName = String.Empty;
            }
            else if (Type == ChangeType.Remove)
            {
                return;
            }

            AddChangeLogRow(hssfWorkBook, sSpsKitPn, sHpPartNo, sLevel, sColumnName, sChangeDetails);

        }

        private void AddPartRow(HSSFWorkbook hssfWorkBook, ISheet sheetSPB, DataRow drow)
        {

            try
            {
                if ((drow["PartPn"].ToString() != String.Empty) && (ValidRow(drow, BomLevelEnum.Part)))
                {
                    iRowSPBRowNumber++;
                    CreateRow(sheetSPB, iRowSPBRowNumber);
                    sheetSPB.GetRow(iRowSPBRowNumber).HeightInPoints = 15;

                    CreateCell(sheetSPB, iRowSPBRowNumber, 0, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 0).SetCellValue(drow["SpsKitDelCat"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 0).CellStyle = GetPartStyle(hssfWorkBook, drow, "SpsKitDelCat", CellSPBStyle_Arial_AllMargin_Grey);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 1, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 1).SetCellValue("4");
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 1).CellStyle = GetPartStyle(hssfWorkBook, drow, "", CellSPBStyle_Arial_AllMargin_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 2, CellType.STRING);

                    string sPartOsspOrderable = (bool)drow["PartOsspOrderable"] ? "Yes" : "No";

                    ReturnCell(sheetSPB, iRowSPBRowNumber, 2).SetCellValue(sPartOsspOrderable);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 2).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOsspOrderable", CellSPBStyle_Arial_AllMargin_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 3, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 3).SetCellValue(drow["PartBomItemNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 3).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartBomItemNo", CellSPBStyle_Arial_AllMargin_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 4, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 4).SetCellValue(drow["SpsKitPn"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 4).CellStyle = GetPartStyle(hssfWorkBook, drow, "SpsKitPn", CellSPBStyle_Arial_AllMargin_Grey);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 5, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 5).SetCellValue(drow["PartRev"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 5).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartRev", CellSPBStyle_Arial_AllMargin_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 6, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 6).SetCellValue(drow["PartXplantStatus"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 6).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartXPlantStatus", CellSPBStyle_Arial_AllMargin_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 7, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 7).SetCellValue(drow["PartQty"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 7).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartQty", CellSPBStyle_Arial_AllMargin_Center);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 8, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 8).SetCellValue(drow["PartPriAlt"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 8).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartPriAlt", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 9, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 9).SetCellValue(drow["PartPn"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 9).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartPn", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 10, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 10).SetCellValue(drow["PartDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 10).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartDescription", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 11, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 11).SetCellValue(drow["PartOdmPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 11).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmPartNo", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 12, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 12).SetCellValue(drow["PartOdmPartDescription"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 12).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmPartDescription", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 13, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 13).SetCellValue(drow["PartOdmBulkPartNo"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 13).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmBulkPartNo", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 14, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 14).SetCellValue(drow["PartOdmProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 14).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmProductionMoq", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 15, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 15).SetCellValue(drow["PartOdmPostProductionMoq"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 15).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartOdmPostProductionMoq", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 16, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 16).SetCellValue(drow["PartSupplier"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 16).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartSupplier", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 17, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 17).SetCellValue(drow["PartModel"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 17).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartModel", CellSPBStyle_Arial_AllMargin);

                    CreateCell(sheetSPB, iRowSPBRowNumber, 18, CellType.STRING);
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 18).SetCellValue(drow["PartComments"].ToString().Trim());
                    ReturnCell(sheetSPB, iRowSPBRowNumber, 18).CellStyle = GetPartStyle(hssfWorkBook, drow, "PartComments", CellSPBStyle_Arial_AllMargin);

                }
                else
                {
                    //Check to see if the status changed.
                    if (((drow["PartXplantStatus"].ToString().Trim() == "C6") || (drow["PartXplantStatus"].ToString().Trim() == "C1")) && ((drow["aPartXplantStatus"].ToString().Trim() == "C2") || (drow["aPartXplantStatus"].ToString().Trim() == "C5")))
                    {
                        AddChangeLogRow(hssfWorkBook, drow["spskitpn"].ToString().Trim(), drow["PartPn"].ToString().Trim(), "2", "Cross Plant Status", String.Format("{0} -> {1}", drow["aPartXplantStatus"].ToString().Trim(), drow["PartXplantStatus"]));
                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddPartRow" + ex.ToString());
            }
        }

        private void AddPartChangeRow(HSSFWorkbook hssfWorkBook, DataRow row, ChangeType Type, string ColumnName)
        {
            if (ColumnName == String.Empty)
                return;

            string sSpsKitPn = row["SpsKitPn"].ToString().Trim();
            string sHpPartNo = row["PartPn"].ToString().Trim();

            if (Type == ChangeType.Remove)
            {
                sSpsKitPn = row["aSpsKitPn"].ToString().Trim();
                sHpPartNo = row["aPartPn"].ToString().Trim();
            }

            string sLevel = "4";
            string sColumnName = String.Empty;
            string sChangeDetails = String.Empty;

            switch (ColumnName.ToLower())
            {
                case "partossporderable":
                    sColumnName = "OSSP Orderable";
                    break;
                case "partqty":
                    sColumnName = "Quantity";
                    break;
                case "partrev":
                    sColumnName = "Revision";
                    break;
                case "partusage":
                    sColumnName = "Usage";
                    break;
                case "partbomitemno":
                    sColumnName = "BOM Item No";
                    break;
                case "partprialt":
                    sColumnName = "Pri / Alt / Gen";
                    break;
                case "partpn":
                    sColumnName = "HP Part No";
                    break;
                case "partdescription":
                    sColumnName = "Description";
                    break;
                case "partodmpartno":
                    sColumnName = "ODM Part No";
                    break;
                case "partodmpartdescription":
                    sColumnName = "ODM Description";
                    break;
                case "partodmbulkpartno":
                    sColumnName = "ODM Bulk Part No";
                    break;
                case "partodmproductionmoq":
                    sColumnName = "ODM Production MOQ";
                    break;
                case "partodmpostproductionmoq":
                    sColumnName = "ODM Post-Production MOQ";
                    break;
                case "partleadtime":
                    sColumnName = "Lead Time";
                    break;
                case "partsupplier":
                    sColumnName = "Supplier";
                    break;
                case "partcomments":
                    sColumnName = "Comments";
                    break;
                case "partmatltype":
                    sColumnName = "Material Type";
                    break;
                case "partxplantstatus":
                    sColumnName = "Cross Plant Status";
                    break;
                case "partmodel":
                    sColumnName = "Model / Mfg Pn";
                    break;

            }

            sChangeDetails = String.Format("{0} -> {1}", row["a" + ColumnName].ToString().Trim(), row[ColumnName].ToString().Trim());

            if ((Type == ChangeType.Add) && (ColumnName.ToLower() == "partpn"))
            {
                sChangeDetails = "Component Added";
                sColumnName = String.Empty;
            }
            else if (Type == ChangeType.Add)
            {
                return;
            }

            if ((Type == ChangeType.Remove) && (ColumnName.ToLower() == "partpn"))
            {
                sChangeDetails = "Component Removed";
                sColumnName = String.Empty;
            }
            else if (Type == ChangeType.Remove)
            {
                return;
            }

            AddChangeLogRow(hssfWorkBook, sSpsKitPn, sHpPartNo, sLevel, sColumnName, sChangeDetails);
        }

        private bool ValidRow(DataRow drow, BomLevelEnum BomLevel)
        {
            string sKitMatlType = drow["SpsMatlType"].ToString().Trim();
            string sSaMatlType = drow["SaMatlType"].ToString().Trim();
            string sPartMatlType = drow["PartMatlType"].ToString().Trim();
            bool bValidType = false;

            string sKitXplantStatus = drow["SpsXplantStatus"].ToString().Trim();
            string sSaXplantStatus = drow["SaXplantStatus"].ToString().Trim();
            string sPartXplantStatus = drow["PartXplantStatus"].ToString().Trim();
            bool bValidStatus = false;

            switch (BomLevel)
            {
                case BomLevelEnum.Kit:
                    bValidType = ValidMaterial(sKitMatlType);
                    bValidStatus = ValidStatus(sKitXplantStatus);
                    break;
                case BomLevelEnum.SubAssembly:
                    bValidType = (ValidMaterial(sKitMatlType) && ValidMaterial(sSaMatlType));
                    bValidStatus = (ValidStatus(sKitXplantStatus) && ValidStatus(sSaXplantStatus));
                    break;
                case BomLevelEnum.Part:
                    bValidType = (ValidMaterial(sKitMatlType) && ValidMaterial(sSaMatlType) && ValidMaterial(sPartMatlType));
                    bValidStatus = (ValidStatus(sKitXplantStatus) && ValidStatus(sSaXplantStatus) && ValidStatus(sPartXplantStatus));
                    break;
            }

            return bValidType && bValidStatus;
        }

        private enum ChangeType : int
        {
            Add = 1,
            Change = 2,
            Remove = 3
        };

        private enum BomLevelEnum : int
        {
            Kit,
            SubAssembly,
            Part
        }

        private bool ValidMaterial(string MatlType)
        {
            switch (MatlType.ToUpper().Trim())
            {
                case "HALB":
                    return true;
                case "FERT":
                    return true;
                case "ROH":
                    return true;
                default:
                    return false;
            }
        }

        private bool ValidStatus(string XplantStatus)
        {
            switch (XplantStatus.ToUpper().Trim())
            {
                case "C2":
                    return true;
                case "C5":
                    return true;
                default:
                    return true;
            }
        }

        #endregion

        private void GenerateHPRestricted(ISheet sheetSPB, HSSFWorkbook hssfWorkBook)
        {
            //Fonts Types
            IFont FontVerdana_13_Red = hssfWorkBook.CreateFont();
            FontVerdana_13_Red.FontName = "verdana";
            FontVerdana_13_Red.FontHeightInPoints = 13;

            IFont FontVerdana_13 = hssfWorkBook.CreateFont();
            FontVerdana_13.FontName = "verdana";
            FontVerdana_13.FontHeightInPoints = 13;

            // Styles
            ICellStyle CellSPBStyle_Restricted = hssfWorkBook.CreateCellStyle();
            CellSPBStyle_Restricted = GenerateCellStyles("Restricted", CellSPBStyle_Restricted, FontVerdana_13_Red, hssfWorkBook);

            ICellStyle CellSPBStyle_ReportGenerated = hssfWorkBook.CreateCellStyle();
            CellSPBStyle_ReportGenerated = GenerateCellStyles("Generated", CellSPBStyle_ReportGenerated, FontVerdana_13, hssfWorkBook);

            CreateRow(sheetSPB, 5);//RConfidential
            CreateCell(sheetSPB, 5, 0, CellType.STRING);
            ReturnCell(sheetSPB, 5, 0).SetCellValue("HP - Restricted");
            ReturnCell(sheetSPB, 5, 0).CellStyle = CellSPBStyle_Restricted;

            CreateCell(sheetSPB, 5, 1, CellType.STRING);//Report Generated
            ReturnCell(sheetSPB, 5, 1).SetCellValue("Report Generated " + DateTime.Now.ToString());
            ReturnCell(sheetSPB, 5, 1).CellStyle = CellSPBStyle_ReportGenerated;

        }

        static HSSFWorkbook InitializeWorkbook(HSSFWorkbook hssfWorkBook)
        {
            //create a entry of DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();

            //dsi.Properties
            dsi.Company = "Excalibur Team";
            hssfWorkBook.DocumentSummaryInformation = dsi;

            //create a entry of SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Author = "Excalibur";
            si.LastAuthor = "Excalibur";
            si.CreateDateTime = DateTime.Now;
            si.LastSaveDateTime = DateTime.Now;
            si.RevNumber = "1.00";
            si.Subject = "SPB Export";

            hssfWorkBook.SummaryInformation = si;

            return hssfWorkBook;
        }

        #region ' CellStyle'

        private void GenerateStyles(HSSFWorkbook hssfWorkBook)
        {
            try
            {
                // FONT  Styles
                IFont FontArialBold_Red = hssfWorkBook.CreateFont();

                IFont FontArial = hssfWorkBook.CreateFont();
                IFont FontArial_Strike = hssfWorkBook.CreateFont();
                IFont FontArial_Bold = hssfWorkBook.CreateFont();
                IFont FontArial_Bold_Strike = hssfWorkBook.CreateFont();
                IFont FontArial_Grey = hssfWorkBook.CreateFont();
                IFont FontArial_Grey_Strike = hssfWorkBook.CreateFont();

                FontArial.FontName = "Arial";
                FontArial_Strike.FontName = "Arial";
                FontArial_Grey.FontName = "Arial";
                FontArial_Grey_Strike.FontName = "Arial";


                FontArial_Bold.FontName = "Arial";
                FontArial_Bold.Boldweight = (short)FontBoldWeight.BOLD;

                FontArial_Bold_Strike.FontName = "Arial";
                FontArial_Bold_Strike.Boldweight = (short)FontBoldWeight.BOLD;

                FontArialBold_Red.FontName = "Arial";
                FontArialBold_Red.Boldweight = (short)FontBoldWeight.BOLD;

                //Column Styles
                CellSPBStyle_Restricted = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_ReportGenerated = hssfWorkBook.CreateCellStyle();

                StyleArialBold_Top_Thick = hssfWorkBook.CreateCellStyle();
                StyleArialBold_Botton_Thick = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_Bold = hssfWorkBook.CreateCellStyle();

                StyleArialBold_Top_Thick = GenerateCellStyles("StylesArialBold_Top_Thick", StyleArialBold_Top_Thick, FontArial_Bold, hssfWorkBook);
                StyleArialBold_Botton_Thick = GenerateCellStyles("StylesArialBold_Botton_Thick", StyleArialBold_Botton_Thick, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Restricted = GenerateCellStyles("Restricted", CellSPBStyle_Restricted, FontArialBold_Red, hssfWorkBook);
                CellSPBStyle_ReportGenerated = GenerateCellStyles("Generated", CellSPBStyle_ReportGenerated, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Arial_Bold = GenerateCellStyles("Bold", CellSPBStyle_Arial_Bold, FontArial_Bold, hssfWorkBook);

                //Bold Blue - SpareKit - Level 2
                CellSPBStyle_Arial_AllMargin_Bold_Blue = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Center = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Yellow = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center = hssfWorkBook.CreateCellStyle();
                //CellSPBStyle_Arial_AllMargin_Bold_Strike = hssfWorkBook.CreateCellStyle();

                CellSPBStyle_Arial_AllMargin_Bold_Blue = GenerateCellStyles("StyleArialAllMargin_Bold_Blue", CellSPBStyle_Arial_AllMargin_Bold_Blue, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Center = GenerateCellStyles("StyleArialAllMargin_Bold_Blue_Center", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Bold_Yellow = GenerateCellStyles("StyleArialAllMargin_Bold_Yellow", CellSPBStyle_Arial_AllMargin_Bold_Yellow, FontArial_Bold, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center = GenerateCellStyles("StyleArialAllMargin_Bold_Yellow_Center", CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center, FontArial_Bold, hssfWorkBook);
                //CellSPBStyle_Arial_AllMargin_Bold_Strike = GenerateCellStyles("StyleArialAllMargin_Bold_Strike", CellSPBStyle_Arial_AllMargin_Bold_Strike, FontArial_Bold_Strike, hssfWorkBook);

                //Light Blue - Sa - Level 3
                CellSPBStyle_Arial_AllMargin_Grey = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Grey = GenerateCellStyles("StyleArialAllMargin_Grey", CellSPBStyle_Arial_AllMargin_Grey, FontArial_Grey, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Grey_SkyBlue = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Grey_SkyBlue = GenerateCellStyles("StyleArialAllMargin_SkyBlue_Grey", CellSPBStyle_Arial_AllMargin_Grey_SkyBlue, FontArial_Grey, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Grey_Yellow = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Grey_Yellow = GenerateCellStyles("StyleArialAllMargin_Grey_Yellow", CellSPBStyle_Arial_AllMargin_Grey_Yellow, FontArial_Grey, hssfWorkBook);

                CellSPBStyle_Arial_AllMargin = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin = GenerateCellStyles("StyleArialAllMargin", CellSPBStyle_Arial_AllMargin, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Center = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Center = GenerateCellStyles("StyleArialAllMargin_Center", CellSPBStyle_Arial_AllMargin_Center, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_SkyBlue = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_SkyBlue = GenerateCellStyles("StyleArialAllMargin_SkyBlue", CellSPBStyle_Arial_AllMargin_SkyBlue, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Center_SkyBlue = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Center_SkyBlue = GenerateCellStyles("StyleArialAllMargin_SkyBlue_Center", CellSPBStyle_Arial_AllMargin_Center_SkyBlue, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Yellow = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Yellow = GenerateCellStyles("StyleArialAllMargin_Yellow", CellSPBStyle_Arial_AllMargin_Yellow, FontArial, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Center_Yellow = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Center_Yellow = GenerateCellStyles("StyleArialAllMargin_Yellow_Center", CellSPBStyle_Arial_AllMargin_Center_Yellow, FontArial, hssfWorkBook);

                //strike
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike = GenerateCellStyles("StyleArialAllMargin_Bold_Blue_Strike", CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike, FontArial_Bold_Strike, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike = GenerateCellStyles("StyleArialAllMargin_Bold_Blue_Center_Strike", CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike, FontArial_Bold_Strike, hssfWorkBook);

                CellSPBStyle_Arial_AllMargin_Grey_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Grey_Strike = GenerateCellStyles("StyleArialAllMargin_Grey_Strike", CellSPBStyle_Arial_AllMargin_Grey_Strike, FontArial_Grey_Strike, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Strike = GenerateCellStyles("StyleArialAllMargin_Strike", CellSPBStyle_Arial_AllMargin_Strike, FontArial_Strike, hssfWorkBook);
                CellSPBStyle_Arial_AllMargin_Center_Strike = hssfWorkBook.CreateCellStyle();
                CellSPBStyle_Arial_AllMargin_Center_Strike = GenerateCellStyles("StyleArialAllMargin_Center_Strike", CellSPBStyle_Arial_AllMargin_Center_Strike, FontArial_Strike, hssfWorkBook);


            }
            catch (Exception ex)
            {
                throw new Exception("Error in GenerateStyles: " + ex.ToString());
            }
        }

        private ICellStyle GenerateCellStyles(string Style, ICellStyle CellSPBStyle, IFont FontSPB, HSSFWorkbook hssfWorkBook)
        {
            switch (Style)
            {
                case "StylesArialBold_Top_Thick":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderTop = BorderStyle.THICK;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    break;
                case "StylesArialBold_Botton_Thick":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THICK;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    break;
                case "StylesArial10Bold_Center":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    //CellSPBStyle.BorderBottom = BorderStyle.DOTTED; 
                    break;
                case "StylesArial10Bold_Right":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.RIGHT;
                    //CellSPBStyle.BorderBottom = BorderStyle.DOTTED; 
                    break;
                case "StylesArial10Bold_Left": //s27 //s42
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.LEFT;
                    // CellSPBStyle.BorderBottom = BorderStyle.DOTTED; 
                    break;
                case "StylesArial10Bold_Wrap":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.WrapText = true;
                    break;
                case "Restricted":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    FontSPB.Color = IndexedColors.RED.Index;
                    break;
                case "Generated":
                    FontSPB.Boldweight = (short)FontBoldWeight.BOLD;
                    break;
                case "StyleArialAllMargin_Bold_Blue":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    break;
                case "StyleArialAllMargin_Bold_Blue_Center":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    break;
                case "StyleArialAllMargin_Bold_Yellow":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArialAllMargin_Bold_Yellow_Center":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArialAllMargin_Grey":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    FontSPB.Color = IndexedColors.GREY_50_PERCENT.Index;
                    break;
                case "StyleArialAllMargin_SkyBlue_Grey":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    //CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    CellSPBStyle.FillForegroundColor = GetColour(System.Drawing.Color.FromArgb(219, 238, 243), hssfWorkBook);
                    CellSPBStyle.FillForegroundColor = GetColour(System.Drawing.Color.FromArgb(219, 238, 243), hssfWorkBook);
                    FontSPB.Color = IndexedColors.GREY_50_PERCENT.Index;
                    break;
                case "StyleArialAllMargin_Grey_Yellow":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    FontSPB.Color = IndexedColors.GREY_50_PERCENT.Index;
                    break;
                case "StyleArialAllMargin":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    break;
                case "StyleArialAllMargin_Yellow":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArialAllMargin_SkyBlue":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    //CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    CellSPBStyle.FillForegroundColor = GetColour(System.Drawing.Color.FromArgb(219, 238, 243), hssfWorkBook);
                    break;
                case "StyleArialAllMargin_Center":
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    break;
                case "StyleArialAllMargin_Yellow_Center":
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.YELLOW.Index;
                    break;
                case "StyleArialAllMargin_SkyBlue_Center":
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    //CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    CellSPBStyle.FillForegroundColor = GetColour(System.Drawing.Color.FromArgb(219, 238, 243), hssfWorkBook);
                    break;
                case "StyleArialAllMargin_Bold_Blue_Strike":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    FontSPB.IsStrikeout = true;
                    break;
                case "StyleArialAllMargin_Bold_Blue_Center_Strike":
                    CellSPBStyle.VerticalAlignment = VerticalAlignment.BOTTOM;
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    CellSPBStyle.FillPattern = FillPatternType.SOLID_FOREGROUND;
                    CellSPBStyle.FillForegroundColor = IndexedColors.PALE_BLUE.Index;
                    FontSPB.IsStrikeout = true;
                    break;
                case "StyleArialAllMargin_Strike":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    FontSPB.IsStrikeout = true;
                    break;
                case "StyleArialAllMargin_Grey_Strike":
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    FontSPB.Color = IndexedColors.GREY_50_PERCENT.Index;
                    FontSPB.IsStrikeout = true;
                    break;
                case "StyleArialAllMargin_Center_Strike":
                    CellSPBStyle.Alignment = HorizontalAlignment.CENTER;
                    CellSPBStyle.BorderBottom = BorderStyle.THIN;
                    CellSPBStyle.BorderLeft = BorderStyle.THIN;
                    CellSPBStyle.BorderRight = BorderStyle.THIN;
                    CellSPBStyle.BorderTop = BorderStyle.THIN;
                    FontSPB.IsStrikeout = true;
                    break;

            }

            CellSPBStyle.SetFont(FontSPB);
            return CellSPBStyle;
        }


        private short GetColour(System.Drawing.Color SystemColour, HSSFWorkbook hssfWorkBook)
        {
            HSSFPalette XlPalette = hssfWorkBook.GetCustomPalette();

            NPOI.HSSF.Util.HSSFColor XlColour = XlPalette.FindColor(SystemColour.R, SystemColour.G, SystemColour.B);

            if (XlColour == null)
            {
                //Available colour palette entries: 65 to 32766 (0-64=standard palette; 64=auto, 32767=unspecified)
                if (NPOI.HSSF.Record.PaletteRecord.STANDARD_PALETTE_SIZE < 255)
                {
                    if (NPOI.HSSF.Record.PaletteRecord.STANDARD_PALETTE_SIZE < 64) NPOI.HSSF.Record.PaletteRecord.STANDARD_PALETTE_SIZE = 64;
                    NPOI.HSSF.Record.PaletteRecord.STANDARD_PALETTE_SIZE += 1;
                    XlColour = XlPalette.AddColor(SystemColour.R, SystemColour.G, SystemColour.B);
                }
                else
                {
                    XlColour = XlPalette.FindSimilarColor(SystemColour.R, SystemColour.G, SystemColour.B);
                }

                return XlColour.GetIndex();
            }
            else
            {
                return XlColour.GetIndex();
            }

        }


        private ICellStyle GetStyleSparekit(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName, ICellStyle CellStyle)
        {
            ICellStyle SelectedStyle = CellStyle;

            string Style = GetSpareKitStyleType(hssfWorkBook, row, ColumnName);


            switch (Style)
            {
                case "Normal":
                    SelectedStyle = CellStyle;
                    break;
                case "Highlight":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Bold_Blue) SelectedStyle = CellSPBStyle_Arial_AllMargin_Bold_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Bold_Blue_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Bold_Yellow_Center;
                    break;
                case "Strike":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Bold_Blue) SelectedStyle = CellSPBStyle_Arial_AllMargin_Bold_Blue_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Bold_Blue_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Bold_Blue_Center_Strike;
                    break;
                case "Default":
                    SelectedStyle = CellStyle;
                    break;
            }

            return SelectedStyle;

        }

        private string GetSpareKitStyleType(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName)
        {
            string sNormal = "Normal";
            string sHighlight = "Highlight";
            string sStrike = "Strike";

            if (NewMatrix) return sNormal;

            if ((row["SpsKitPn"].ToString().Trim() != String.Empty) && (row["aSpsKitPn"].ToString().Trim() == String.Empty) && (ColumnName.ToLower() != "spskitpn"))
            {
                return sHighlight;
            }

            if (ColumnName == String.Empty) return sNormal;

            if (((row[ColumnName].ToString().Trim()) != (row["a" + ColumnName].ToString().Trim())) && (!NewMatrix))
            {
                if (row["SpsKitPn"].ToString().Trim() == String.Empty)
                {
                    AddSpareKitChangeRow(hssfWorkBook, row, ChangeType.Remove, ColumnName);
                    return sStrike;
                }
                else if (row["aSpsKitPn"].ToString().Trim() == String.Empty)
                {
                    AddSpareKitChangeRow(hssfWorkBook, row, ChangeType.Add, ColumnName);
                    return sHighlight;
                }
                else
                {
                    AddSpareKitChangeRow(hssfWorkBook, row, ChangeType.Change, ColumnName);
                    return sHighlight;
                }
            }
            else
            {
                return sNormal;
            }
        }

        private ICellStyle GetStyleSA(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName, ICellStyle CellStyle)
        {
            ICellStyle SelectedStyle = CellStyle;

            string Style = GetSAStyleType(hssfWorkBook, row, ColumnName);

            switch (Style)
            {
                case "Normal":
                    SelectedStyle = CellStyle;
                    break;
                case "Highlight":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_Yellow;
                    break;
                case "Halb":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_SkyBlue;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_SkyBlue;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_SkyBlue;
                    break;
                case "Strike":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_Strike;
                    break;
                case "Default":
                    SelectedStyle = CellStyle;
                    break;
            }

            return SelectedStyle;
        }

        private string GetSAStyleType(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName)
        {
            string sNormal = "Normal";
            string sHighlight = "Highlight";//yellow
            string sStrike = "Strike";
            string sHalb = "Halb"; // lightblue


            if (row["SaMatlType"].ToString().ToUpper().Trim() == "HALB") return sHalb;

            if (NewMatrix) return sNormal;

            if ((row["SaPn"].ToString().Trim() != String.Empty) && (row["aSaPn"].ToString().Trim() == String.Empty) && (ColumnName != "sapn"))
            {
                return sHighlight;
            }

            if (ColumnName == String.Empty) return sNormal;
            if (ColumnName.Contains("SpsKitPn")) return sNormal;
            if (ColumnName.Contains("SpsKitDelCat")) return sNormal;

            if (((row[ColumnName].ToString().Trim()) != (row["a" + ColumnName].ToString().Trim())) && (!NewMatrix))
            {
                if (row["SaPn"].ToString().Trim() == String.Empty)
                {
                    AddSAChangeRow(hssfWorkBook, row, ChangeType.Remove, ColumnName);
                    return sStrike;
                }
                else if (row["aSaPn"].ToString().Trim() == String.Empty)
                {
                    AddSAChangeRow(hssfWorkBook, row, ChangeType.Add, ColumnName);
                    return sHighlight;
                }
                else
                {
                    AddSAChangeRow(hssfWorkBook, row, ChangeType.Change, ColumnName);
                    return sHighlight;
                }
            }
            else
            {
                return sNormal;
            }
        }

        private ICellStyle GetPartStyle(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName, ICellStyle CellStyle)
        {
            ICellStyle SelectedStyle = CellStyle;

            string Style = GetPartStyleType(hssfWorkBook, row, ColumnName);

            switch (Style)
            {
                case "Normal":
                    SelectedStyle = CellStyle;
                    break;
                case "Highlight":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_Yellow;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_Yellow;
                    break;
                case "Strike":
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Grey) SelectedStyle = CellSPBStyle_Arial_AllMargin_Grey_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin) SelectedStyle = CellSPBStyle_Arial_AllMargin_Strike;
                    if (CellStyle == CellSPBStyle_Arial_AllMargin_Center) SelectedStyle = CellSPBStyle_Arial_AllMargin_Center_Strike;
                    break;
                case "Default":
                    SelectedStyle = CellStyle;
                    break;
            }
            return SelectedStyle;
        }

        private string GetPartStyleType(HSSFWorkbook hssfWorkBook, DataRow row, string ColumnName)
        {
            string sNormal = "Normal";
            string sHighlight = "Highlight";//yellow
            string sStrike = "Strike";

            if (NewMatrix) return sNormal;

            if ((row["PartPn"].ToString().Trim() != String.Empty) && (row["aPartPn"].ToString().Trim() == String.Empty) && (ColumnName.ToLower() != "partpn")) return sHighlight;

            if (ColumnName == String.Empty) return sNormal;
            if (ColumnName.Contains("SpsKitPn")) return sNormal;
            if (ColumnName.Contains("SpsKitDelCat")) return sNormal;

            if (((row[ColumnName].ToString().Trim()) != (row["a" + ColumnName].ToString().Trim())) && (!NewMatrix))
            {
                if (row["SaPn"].ToString().Trim() == String.Empty)
                {
                    AddPartChangeRow(hssfWorkBook, row, ChangeType.Remove, ColumnName);
                    return sStrike;
                }
                else if (row["aSaPn"].ToString().Trim() == String.Empty)
                {
                    AddPartChangeRow(hssfWorkBook, row, ChangeType.Add, ColumnName);
                    return sHighlight;
                }
                else
                {
                    AddPartChangeRow(hssfWorkBook, row, ChangeType.Change, ColumnName);
                    return sHighlight;
                }

            }
            else
            {
                return sNormal;
            }
        }

        #endregion

        static void WriteToFile(Stream RslStream, HSSFWorkbook hssfWorkBook)
        {
            //Write the stream data of workbook to the root directory
            hssfWorkBook.Write(RslStream);
        }

        #region #NPOI Utility Functions

        public void CreateRow(ISheet sheet1, int row)
        {
            sheet1.CreateRow(row);
        }

        static void CreateCell(ISheet sheet1, int row, int cell, CellType Type)
        {
            sheet1.GetRow(row).CreateCell(cell, Type);
        }

        static ICell ReturnCell(ISheet sheet1, int row, int cell)
        {
            return sheet1.GetRow(row).GetCell(cell);
        }

        #endregion

    }

}

