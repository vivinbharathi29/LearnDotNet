﻿using Org.System.Xml.Sax;

namespace ExcelExportLegacyCSCode
{
    public class XmlSCMFileParser
    {
        string _filePath, _userName;
        string _pbid;
        public XmlSCMFileParser(string filepath, string userName, string productBrandID)
        {
            _pbid = productBrandID;
            _filePath = filepath;
            _userName = userName;
        }

        public void Parse()
        {

            // load the SAX parser assembly
            IXmlReader reader = new AElfred.SaxDriver();

            // set one or more handlers
            XmlScmSaxContentHandler handler = new XmlScmSaxContentHandler();
            handler.ProductBrandID = _pbid;
            reader.ContentHandler = handler;
            reader.Parse(_filePath);
        }

    }
}
