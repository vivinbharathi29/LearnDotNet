﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Data;
using System.Data.SqlClient;

namespace iPulsar.Features.Tests
{
    [TestClass()]
    public class FeaturePropertiesTest
    {
        private static int FeatureID = -1;
        private int intFeatureClassID = 3;
        private int intFeatureCategoryID = 38;
        private int intNamingStandardID = 1132;
        private int intDeliveryTypeID = 1;
        private string charCodeName = string.Empty;
        private string charRuleID = string.Empty;
        private int intStatus = 1;
        private string charChinaIdentifier = string.Empty;
        private int bitRequiresRoot = 0;
        private static string charUser = "";
        private static string charUserName = "";
        private string charFeatureName = "Unit Test Dual Speakers";
        private string charGPGPHweb40_NB = "Unit Test Dual Speakers";
        private string charGPSy40_NB = "Unit Test Dual Speakers";
        private string charPMG100_NB = "Unit Test Dual Speakers";
        private string charGPSy200_NB = "Unit Test Dual Speakers";
        private string charPMG250_NB = "Unit Test Dual Speakers";
        private string charGPGPHweb40_DT = "Unit Test Dual Speakers";
        private string charGPSy40_DT = "Unit Test Dual Speakers";
        private string charPMG100_DT = "Unit Test Dual Speakers";
        private string charGPSy200_DT = "Unit Test Dual Speakers";
        private string charPMG250_DT = "Unit Test Dual Speakers";
        private string charNotes = string.Empty;
        private string charSelectedSMBIOSAddIDs = string.Empty;
        private string charSelectedSMBIOSRemoveIDs = string.Empty;
        private string chrZSRP32_NB = "Unit Test Dual Speakers";
        private string chrZSRP32_DT = "Unit Test Dual Speakers";
        private int intModuleID = 0;
        private int bIsCombo = 0;
        private static int intUserID = 0;
        private string chrFeatureList = "<?xml version=''1.0''?><ChildFeatureList></ChildFeatureList>";
        private int intPlatformID = 0;
        private int intAliasID = 0;
        private int intViewableToODM = 0;
        private string chrSelectedODMIDs = string.Empty;
        private string chrSelectedHPTeamIDs = string.Empty;
        private int intProductVersionID = 0;
        private string strOverrideRequestReason = string.Empty;
        private string BusinessSegmentIDs = string.Empty;
        private string charSpecControl = string.Empty;
        private int intOSID = 0;
        private string chrNSFields = "<?xml version='1.0'?><NSFieldList><NSField><FieldID>1990</FieldID><FieldType>Drop down</FieldType><TextValue></TextValue><DropDownValueID>0</DropDownValueID><LongNameOnly>0</LongNameOnly></NSField><NSField><FieldID>1991</FieldID><FieldType>Text box</FieldType><TextValue>Unit Test</TextValue><DropDownValueID>0</DropDownValueID><LongNameOnly>0</LongNameOnly></NSField><NSField><FieldID>1992</FieldID><FieldType>Drop down</FieldType><TextValue></TextValue><DropDownValueID>0</DropDownValueID><LongNameOnly>0</LongNameOnly></NSField><NSField><FieldID>1993</FieldID><FieldType>Drop down</FieldType><TextValue></TextValue><DropDownValueID>0</DropDownValueID><LongNameOnly>0</LongNameOnly></NSField><NSField><FieldID>1994</FieldID><FieldType>Drop down</FieldType><TextValue></TextValue><DropDownValueID>0</DropDownValueID><LongNameOnly>0</LongNameOnly></NSField><NSField><FieldID>1995</FieldID><FieldType>Drop down</FieldType><TextValue></TextValue><DropDownValueID> 8271</DropDownValueID><LongNameOnly>0</LongNameOnly></NSField><NSField><FieldID>2019</FieldID><FieldType>Text box</FieldType><TextValue></TextValue><DropDownValueID>0</DropDownValueID><LongNameOnly>0</LongNameOnly></NSField></NSFieldList>";
        private string fValue = "unit test f Val";
        private string ms4 = "unit test ms4";
        private bool _allowReference = true;

        [TestMethod()]
        public void SaveFeatureTest()
        {
            UserInfo UI = new UserInfo("americas\\testhp", true);
            if (UI.UserID > 0)
            {
                intUserID = UI.UserID;
                charUser = UI.LastName + ", " + UI.FirstName;
                charUserName = UI.UserName;
            }
            else
                Assert.Fail("Can not find test user");

            FeaturesBLL obj = new FeaturesBLL();
            try
            {
                //creating feature
                FeatureID = obj.SaveFeature(FeatureID, intFeatureClassID, intFeatureCategoryID, intNamingStandardID, intDeliveryTypeID, charCodeName, charRuleID, intStatus, charChinaIdentifier, bitRequiresRoot, charUser, charFeatureName,
                        charGPGPHweb40_NB, charGPSy40_NB, charPMG100_NB, charGPSy200_NB, charPMG250_NB, charGPGPHweb40_DT, charGPSy40_DT, charPMG100_DT, charGPSy200_DT, charPMG250_DT, chrZSRP32_NB, chrZSRP32_DT, charSpecControl, charNotes,
                        charSelectedSMBIOSAddIDs, charSelectedSMBIOSRemoveIDs, intModuleID, bIsCombo, intUserID, chrFeatureList, intPlatformID, ref intAliasID, intOSID, intViewableToODM, chrSelectedODMIDs, chrSelectedHPTeamIDs, fValue, ms4, _allowReference, intProductVersionID,
                        strOverrideRequestReason, BusinessSegmentIDs);

                obj.Feature_NamingStandardModify(FeatureID, chrNSFields, charUserName);

                //feature naming override request
                strOverrideRequestReason = "testing";
                intStatus = 3;
                obj.SaveFeature(FeatureID, intFeatureClassID, intFeatureCategoryID, intNamingStandardID, intDeliveryTypeID, charCodeName, charRuleID, intStatus, charChinaIdentifier, bitRequiresRoot, charUser, charFeatureName,
                            charGPGPHweb40_NB, charGPSy40_NB, charPMG100_NB, charGPSy200_NB, charPMG250_NB, charGPGPHweb40_DT, charGPSy40_DT, charPMG100_DT, charGPSy200_DT, charPMG250_DT, chrZSRP32_NB, chrZSRP32_DT, charSpecControl, charNotes,
                            charSelectedSMBIOSAddIDs, charSelectedSMBIOSRemoveIDs, intModuleID, bIsCombo, intUserID, chrFeatureList, intPlatformID, ref intAliasID, intOSID, intViewableToODM, chrSelectedODMIDs, chrSelectedHPTeamIDs, fValue, ms4, _allowReference, intProductVersionID,
                            strOverrideRequestReason, BusinessSegmentIDs);
            }
            catch (SqlException ex)
            {
                if (ex.Message == "The feature full name already exists. It may be hidden due to security limitations.")
                {
                    //find it if it is created before
                    DataSet ds = new DataSet();
                    ds = obj.FeatureSearch(intFeatureCategoryID, charFeatureName, intFeatureClassID, string.Empty, intUserID, 0, 0);
                    FeatureID = int.Parse(ds.Tables[0].Rows[0]["FeatureID"].ToString());

                    //feature naming override request
                    try
                    {
                        strOverrideRequestReason = "testing";
                        intStatus = 3;
                        obj.SaveFeature(FeatureID, intFeatureClassID, intFeatureCategoryID, intNamingStandardID, intDeliveryTypeID, charCodeName, charRuleID, intStatus, charChinaIdentifier, bitRequiresRoot, charUser, charFeatureName,
                                    charGPGPHweb40_NB, charGPSy40_NB, charPMG100_NB, charGPSy200_NB, charPMG250_NB, charGPGPHweb40_DT, charGPSy40_DT, charPMG100_DT, charGPSy200_DT, charPMG250_DT, chrZSRP32_NB, chrZSRP32_DT, charSpecControl, charNotes,
                                    charSelectedSMBIOSAddIDs, charSelectedSMBIOSRemoveIDs, intModuleID, bIsCombo, intUserID, chrFeatureList, intPlatformID, ref intAliasID, intOSID, intViewableToODM, chrSelectedODMIDs, chrSelectedHPTeamIDs, fValue, ms4, _allowReference, intProductVersionID,
                                    strOverrideRequestReason, BusinessSegmentIDs);
                    }
                    catch (Exception ex1)
                    {
                        Assert.Fail(ex1.Message);
                    }
                }
                else
                {
                    Assert.Fail(ex.Message);
                }
            }

            if (FeatureID == -1)
                Assert.Fail("Failed to create feature");
        }

        [TestMethod()]
        public void GetPreviousReasonforOverrideRequestTest()
        {
            try
            {
                FeaturesBLL obj = new FeaturesBLL();
                obj.GetPreviousReasonforOverrideRequest(FeatureID);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void CancelFNORequestTest()
        {
            try
            {
                FeaturesBLL obj = new FeaturesBLL();
                obj.CancelFNORequest(FeatureID);

                //find it if it is created before
                DataSet ds = new DataSet();
                ds = obj.GetFeatureProperties(FeatureID);
                Assert.AreNotEqual(int.Parse(ds.Tables[0].Rows[0]["OverrideRequest"].ToString()), 1);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void DeleteFeatureTest()
        {
            FeaturesBLL obj = new FeaturesBLL();
            try
            {
                obj.DeleteFeature(FeatureID);
            }
            catch (SqlException ex)
            {
                if (ex.Message != "Feature is used in PRL and cannot be deleted" && ex.Message != "Feature is used in SCM and cannot be deleted")
                {
                    Assert.Fail(ex.Message);
                }
            }
        }
    }
}