﻿using System;
using System.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace iPulsarTests
{
    [TestClass]
    public class UserSearchTest
    {
        [TestMethod]
        public void SearchUsersTest()
        {
            try
            {
                HttpContext.Current = new HttpContext(
                    new HttpRequest(null, "http://localhost/iPulsar/Admin", null),
                    new HttpResponse(null));

                var usersList = UserSearch.SearchUsers("max");

                if (usersList == null)
                {
                    Assert.Fail("No result was returned from the API call of http://localhost/PulsarAPI/svc/UserSearch/SearchUsersStrList");
                }
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void SearchActiveDirectoryUsersTest()
        {
            try
            {
                HttpContext.Current = new HttpContext(
                    new HttpRequest(null, "http://localhost/iPulsar/Admin", null),
                    new HttpResponse(null));

                var strJson = UserSearch.SearchActiveDirectoryUsers("hsuvin", "NtName", "1");
                Console.Write(strJson);

                if (strJson == null)
                {
                    Assert.Fail("No result was returned from the API call of http://localhost/PulsarAPI/svc/UserSearch/SearchActiveDirectoryUsersJsonStr");
                }
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }

        }
    }
}
